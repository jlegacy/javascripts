package com.dancik.om.webservices;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.dancik.om.dao.GenericUtils_DAO;
import com.dancik.om.dataobjects.Visit;

public class GenericUtils_WebService extends Abstract_WebService {
	
	// * --------------------------------------------------------------------------
	// * @method : getAutoSuggest_CustomerSearch
	// * --------------------------------------------------------------------------
	public String getAutoSuggest_CustomerSearch(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		final HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");

		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		GenericUtils_DAO dao = (GenericUtils_DAO) ctx.getBean("genUtilsDAO");

		final JSONObject json = dao.getAutoSuggest_CustomerSearch(visit.getUserConfig().getUser(), this.buildParamsXML());

		ctx = null;
		dao = null;

		return (json == null) ? "" : json.toString();
	}
}
