package com.dancik.om.webservices;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.dancik.om.dao.OM_CashRegister_DAO;
import com.dancik.om.dao.OrderManager_DAO;
import com.dancik.om.dataobjects.Visit;

public class OrderManager_WebService extends Abstract_WebService {

	// * --------------------------------------------------------------------------
	// * @method : search
	// * --------------------------------------------------------------------------
	private String search(HttpServletRequest req, String inStoredProcedure) throws Exception {
		this.setRequest(req);
		final HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");

		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OrderManager_DAO dao = (OrderManager_DAO) ctx.getBean("omDAO");

		final JSONObject json = dao.genericPaginationSearch(inStoredProcedure, visit.getUserConfig().getUser(), this.buildParamsXML());

		ctx = null;
		dao = null;

		return (json == null) ? "" : json.toString();
	}
	// * --------------------------------------------------------------------------
	// * @method : newOrder_CustomerSearch
	// * --------------------------------------------------------------------------
	public String newOrder_CustomerSearch(HttpServletRequest req) throws Exception {
		return this.search(req, "Dancik_OM_NewOrder_CustomerSearch");
	}
	// * --------------------------------------------------------------------------
	// * @method : orderSearch
	// * --------------------------------------------------------------------------
	public String orderSearch(HttpServletRequest req) throws Exception {
		return this.search(req, "Dancik_OM_OrderSearch");
	}
	// * --------------------------------------------------------------------------
	// * @method : newOrder_BilltoSearch
	// * --------------------------------------------------------------------------
	public String newOrder_BilltoSearch(HttpServletRequest req) throws Exception {
		return this.search(req, "Dancik_OM_NewOrder_BilltoSearch");
	}	
	// * --------------------------------------------------------------------------
	// * @method : newOrder_RetailSearch
	// * --------------------------------------------------------------------------
	public String newOrder_RetailSearch(HttpServletRequest req) throws Exception {
		return this.search(req, "Dancik_OM_NewOrder_RetailSearch");
	}	

	
	// * --------------------------------------------------------------------------
	// * @method : validateOrderSelection
	// * --------------------------------------------------------------------------
	public String validateOrderSelection(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		final HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");

		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OrderManager_DAO dao = (OrderManager_DAO) ctx.getBean("omDAO");

		final JSONObject json = dao.validateOrderSelection(visit.getUserConfig().getUser(), this.buildParamsXML());

		ctx = null;
		dao = null;

		return (json == null) ? "" : json.toString();
	}
//	// * --------------------------------------------------------------------------
//	// * @method : installationScheduler_getLineitems
//	// * --------------------------------------------------------------------------
//	public String installationScheduler_getLineitems(HttpServletRequest req) throws Exception {
//		return this.search(req, "Dancik_OM_installationScheduler_getLineitems");
//	}
//	/* --------------------------------------------------------------------------------------- *
//	 * @method : OM_installationScheduler_getLineitems
//	 * --------------------------------------------------------------------------------------- */
//	public String OM_installationScheduler_getLineitems(HttpServletRequest req) throws Exception {
//		this.setRequest(req);
//		HttpSession ses = (HttpSession) req.getSession();
//		final Visit visit = (Visit)ses.getAttribute("Visit");
//		
//		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
//		OrderManager_DAO dao = (OrderManager_DAO) ctx.getBean("omDAO");
//
//		
//		JSONObject json = dao.getOM_installationScheduler_getLineitems(visit.getUserConfig().getUser(), this.buildParamsXML());
//		
//		ctx = null;
//		dao = null;
//		return (json != null) ? json.toString() : "" ;
//	}

	// * --------------------------------------------------------------------------
	// * @method : newOrder_VnB
	// * --------------------------------------------------------------------------
	public String newOrder_VnB(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		final HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");

		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OrderManager_DAO dao = (OrderManager_DAO) ctx.getBean("omDAO");

		// -- Determine Order Type, but default to normal Customer Order...
		String ordertype = this.getString("ordertype");
		String sp = "Dancik_OM_NewOrder_ValidateAndBuild"; 
		if (ordertype.equals("po")) {
			sp = "Dancik_OM_NewPurchaseOrder_Build"; 
		} else {
			if (ordertype.equals("s2s")) {
				sp = "Dancik_OM_NewStockToStockOrder_Build"; 
			}
		}

		final JSONObject json = dao.newOrder_VnD(sp, visit.getUserConfig().getUser(), this.buildParamsXML());

		ctx = null;
		dao = null;

		return (json == null) ? "" : json.toString();
	}	
}
