package com.dancik.om.webservices;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.w3c.dom.Document;

import com.dancik.api.http.Abstract_Http_Tool;
import com.dancik.api.xml.XML_Tool;
import com.dancik.om.dataobjects.Visit;

public abstract class Abstract_WebService extends Abstract_Http_Tool {

	// * --------------------------------------------------------------------------
	// * @method : execute
	// * --------------------------------------------------------------------------
	@SuppressWarnings("unchecked")
	public String execute(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		final HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");

		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		
        Properties properties = new Properties();
		String serviceid = this.getString("serviceid");
		
		InputStream is = ses.getServletContext().getResourceAsStream("/WEB-INF/services/" + serviceid + ".properties"); 
		properties.load( is );
		
		String option = this.getString("option");
		String sp = properties.getProperty(option + ".sp");
		// -- If a "method" is not passed, then assume "executeWithJSONListing", which is execute and anticipate a single cursor/resultset being returned... 
		String daoMethod = properties.getProperty(option + ".method");
		if (daoMethod == null) {
			daoMethod = "executeWithJSONListing";
		}

		String daoId = properties.getProperty("daoid");
		Object dao = ctx.getBean(daoId);

		final Class params2[] = { String.class, String.class };
		final Class params3[] = { String.class, String.class, String.class };
		
		Method m = null;
		JSONObject json = null;
		String userName = visit.getUserConfig().getUser();
		String xmlParams = this.buildParamsXML();

		if (sp == null) {
			m = dao.getClass().getDeclaredMethod(daoMethod,  params2);
			json = (JSONObject)m.invoke( dao, new Object[]{ userName, xmlParams });
		} else {
			m = dao.getClass().getDeclaredMethod(daoMethod,  params3);
			json = (JSONObject)m.invoke( dao, new Object[]{ sp, userName, xmlParams });
		}
		
		ctx = null;
		dao = null;
		m = null;
		
		return (json == null) ? "" : json.toString();
	}
	
	public static String convertStreamToString(InputStream is) throws Exception {
		BufferedReader reader = new BufferedReader(new InputStreamReader(is));
		StringBuilder sb = new StringBuilder();
		String line = null;
		while ((line = reader.readLine()) != null) {
			sb.append(line + "\n");
		}
		is.close();
		return sb.toString();
	}	
}
