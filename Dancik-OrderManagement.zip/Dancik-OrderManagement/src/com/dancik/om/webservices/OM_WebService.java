package com.dancik.om.webservices;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.dancik.om.dao.OrderManager_DAO;
import com.dancik.om.dataobjects.Visit;

public class OM_WebService extends Abstract_WebService {

	// * --------------------------------------------------------------------------
	// * @method : execute
	// * --------------------------------------------------------------------------
	public String execute(HttpServletRequest req) throws Exception {
		return super.execute(req);
	}

	
	// * --------------------------------------------------------------------------
	// * @method : search
	// * --------------------------------------------------------------------------
	private String search(HttpServletRequest req, String inStoredProcedure) throws Exception {
		this.setRequest(req);
		final HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");

		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OrderManager_DAO dao = (OrderManager_DAO) ctx.getBean("omDAO");

		final JSONObject json = dao.genericPaginationSearch(inStoredProcedure, visit.getUserConfig().getUser(), this.buildParamsXML());

		ctx = null;
		dao = null;

		return (json == null) ? "" : json.toString();
	}	
}
