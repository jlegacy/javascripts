package com.dancik.om.webservices;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.dancik.om.dao.OM_CashRegister_DAO;
import com.dancik.om.dataobjects.Visit;

public class OM_CashRegister_WebService extends Abstract_WebService  {

	/* --------------------------------------------------------------------------------------- *
	 * @method : OM_get_CashRegister
	 * --------------------------------------------------------------------------------------- */
	public String OM_get_CashRegister(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");
		
		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OM_CashRegister_DAO dao = (OM_CashRegister_DAO)ctx.getBean("omCashRegisterDAO");
		
		JSONObject json = dao.getOM_CashRegister(visit.getUserConfig().getUser(), this.buildParamsXML());
		
		ctx = null;
		dao = null;
		return (json != null) ? json.toString() : "" ;
	}
	/* --------------------------------------------------------------------------------------- *
	 * @method : OM_post_CashRegister
	 * --------------------------------------------------------------------------------------- */
	public String OM_post_CashRegister(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");
		
		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OM_CashRegister_DAO dao = (OM_CashRegister_DAO)ctx.getBean("omCashRegisterDAO");
		
		JSONObject json = dao.postOM_CashRegister(visit.getUserConfig().getUser(), this.buildParamsXML());
		
		ctx = null;
		dao = null;
		return (json != null) ? json.toString() : "" ;
	}
//	/* --------------------------------------------------------------------------------------- *
//	 * @method : Dancik_OM_GetEndOrderConfig
//	 * --------------------------------------------------------------------------------------- */
//	public String Dancik_OM_GetEndOrderConfig(HttpServletRequest req) throws Exception {
//		this.setRequest(req);
//		HttpSession ses = (HttpSession) req.getSession();
//		final Visit visit = (Visit)ses.getAttribute("Visit");
//		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
//		OM_CashRegister_DAO dao = (OM_CashRegister_DAO)ctx.getBean("omCashRegisterDAO");
//		
//		JSONObject json = dao.Dancik_OM_GetEndOrderConfig(visit.getUserConfig().getUser(), this.buildParamsXML());
//		
//		ctx = null;
//		dao = null;
//		return (json != null) ? json.toString() : "" ;
//	}
	/* --------------------------------------------------------------------------------------- *
	 * @method : OM_SubmitPrintJob
	 * --------------------------------------------------------------------------------------- */
	public String OM_SubmitPrintJob(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");
		
		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OM_CashRegister_DAO dao = (OM_CashRegister_DAO)ctx.getBean("omCashRegisterDAO");
		
		JSONObject json = dao.OM_SubmitPrintJob(visit.getUserConfig().getUser(), this.buildParamsXML());
		
		ctx = null;
		dao = null;
		return (json != null) ? json.toString() : "" ;
	}
	/* --------------------------------------------------------------------------------------- *
	 * @method : OM_SubmitPackingList_PrintJob
	 * --------------------------------------------------------------------------------------- */
	public String OM_SubmitPackingList_PrintJob(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");
		
		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OM_CashRegister_DAO dao = (OM_CashRegister_DAO)ctx.getBean("omCashRegisterDAO");
		
		JSONObject json = dao.OM_SubmitPackingList_PrintJob(visit.getUserConfig().getUser(), this.buildParamsXML());
		
		ctx = null;
		dao = null;
		return (json != null) ? json.toString() : "" ;
	}
	/* --------------------------------------------------------------------------------------- *
	 * @method : OM_SubmitPackingList_PrintJob
	 * --------------------------------------------------------------------------------------- */
	public String OM_SubmitPickingLabels_PrintJob(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");
		
		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OM_CashRegister_DAO dao = (OM_CashRegister_DAO)ctx.getBean("omCashRegisterDAO");
		
		JSONObject json = dao.OM_SubmitPickingLabels_PrintJob(visit.getUserConfig().getUser(), this.buildParamsXML());
		
		ctx = null;
		dao = null;
		return (json != null) ? json.toString() : "" ;
	}
//	/* --------------------------------------------------------------------------------------- *
//	 * @method : DANCIK_OM_CR_GetPaymethodData
//	 * --------------------------------------------------------------------------------------- */
//	public String DANCIK_OM_CR_GetPaymethodData(HttpServletRequest req) throws Exception {
//		this.setRequest(req);
//		HttpSession ses = (HttpSession) req.getSession();
//		final Visit visit = (Visit)ses.getAttribute("Visit");
//		
//		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
//		OM_CashRegister_DAO dao = (OM_CashRegister_DAO)ctx.getBean("omCashRegisterDAO");
//		
//		JSONObject json = dao.DANCIK_OM_CR_GetPaymethodData(visit.getUserConfig().getUser(), this.buildParamsXML());
//		
//		ctx = null;
//		dao = null;
//		return (json != null) ? json.toString() : "" ;
//	}
//	/* --------------------------------------------------------------------------------------- *
//	 * @method : OM_validate_Creditcard_swipe
//	 * --------------------------------------------------------------------------------------- */
//	public String OM_validate_Creditcard_swipe(HttpServletRequest req) throws Exception {
//		this.setRequest(req);
//		HttpSession ses = (HttpSession) req.getSession();
//		final Visit visit = (Visit)ses.getAttribute("Visit");
//		
//		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
//		OM_CashRegister_DAO dao = (OM_CashRegister_DAO)ctx.getBean("omCashRegisterDAO");
//		
//		JSONObject json = dao.OM_validate_Creditcard_swipe(visit.getUserConfig().getUser(), this.buildParamsXML());
//		
//		ctx = null;
//		dao = null;
//		return (json != null) ? json.toString() : "" ;
//	}
	
}
