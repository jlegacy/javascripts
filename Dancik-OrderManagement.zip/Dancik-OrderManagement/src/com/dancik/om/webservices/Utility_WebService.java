package com.dancik.om.webservices;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.dbcp.BasicDataSource;
import org.json.JSONObject;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.dancik.api.util.DataSourceAnalysis;
import com.dancik.om.dataobjects.Visit;

public class Utility_WebService extends Abstract_WebService  {
	
	// * --------------------------------------------------------------------------
	// * @method : getVersion
	// * --------------------------------------------------------------------------
	public String getVersion(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		final HttpSession ses = (HttpSession) req.getSession();
		
		Visit visit = (Visit)ses.getAttribute("Visit");

		return visit.getCurrentVersion();
	} 
	
	// * --------------------------------------------------------------------------
	// * @method : getDataSourceAnalysis
	// * --------------------------------------------------------------------------
	public String getDataSourceAnalysis(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		final HttpSession ses = (HttpSession) req.getSession();

		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		BasicDataSource ds = (BasicDataSource) ctx.getBean("dataSource");

		final JSONObject json = DataSourceAnalysis.toJSON(ds);

		ctx = null;
		ds = null;

		return (json == null) ? "" : json.toString();
	} 
	
}