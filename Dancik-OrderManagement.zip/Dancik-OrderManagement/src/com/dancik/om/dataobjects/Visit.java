package com.dancik.om.dataobjects;

public class Visit extends  com.dancik.rest.dataobjects.Visit {  
}
