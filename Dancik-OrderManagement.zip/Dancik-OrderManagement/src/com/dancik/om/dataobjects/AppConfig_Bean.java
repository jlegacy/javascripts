package com.dancik.om.dataobjects;

import java.util.Hashtable;

@SuppressWarnings("unchecked")
public class AppConfig_Bean  {

	private boolean activeStatus = false;

	// -- "Parameterized" removed while Dancik-Apis is stilled compiled under 1.5 jvm.	
	private Hashtable options = null;
	
	
	public boolean isActiveStatus() {
		return activeStatus;
	}
	public void setActiveStatus(boolean activeStatus) {
		this.activeStatus = activeStatus;
	}
	
	public Hashtable getOptions() {
		return options;
	}
	public void setOptions(Hashtable options) {
		this.options = options;
	}
}
