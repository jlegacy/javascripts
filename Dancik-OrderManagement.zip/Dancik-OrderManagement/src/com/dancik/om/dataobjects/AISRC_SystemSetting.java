package com.dancik.om.dataobjects;

import org.apache.log4j.Logger;

public class AISRC_SystemSetting extends ASystemSetting {

	@SuppressWarnings("unused")
	private static Logger log = Logger.getLogger(AISRC_SystemSetting.class);

	private String allowDiscontinuedItems = "";  // Allow Discontinued Items
	
	private String SCREGORDP1 = "";    // Policy Code 1 - Reg
	private String SCREGORDP2 = "";    // Policy Code 2 - Reg
	private String SCREGORDP3 = "";    // Policy Code 3 - Reg
	private String SCREGORDP4 = "";    // Policy Code 4 - Reg
	private String SCREGPO = "";       // Regular Purchase Order
	           
	private String SCSPCORDP1 = "";    // Policy Code 1 - Spc
	private String SCSPCORDP2 = "";    // Policy Code 2 - Spc
	private String SCSPCORDP3 = "";    // Policy Code 3 - Spc
	private String SCSPCORDP4 = "";    // Policy Code 4 - Spc
	private String SCSPCPO = "";       // Special Order
	           
	private String SCDIRORDP1 = "";    // Policy Code 1 - Dir
	private String SCDIRORDP2 = "";    // Policy Code 2 - Dir
	private String SCDIRORDP3 = "";    // Policy Code 3 - Dir
 	private String SCDIRORDP4 = "";    // Policy Code 4 - Dir
	private String SCDIRPO = "";       // Direct Ship Order
	
	
	@Override
	public void parseRecord() {
		allowDiscontinuedItems = record.substring(2,1).trim();
		
		SCREGORDP1 = record.substring(1,2).trim();
		SCREGORDP2 = record.substring(3,2).trim();
		SCREGORDP3 = record.substring(5,2).trim();
		SCREGORDP4 = record.substring(7,2).trim();
		SCREGPO    = record.substring(8,1).trim();  
		           
		SCSPCORDP1 = record.substring(9,2).trim();
		SCSPCORDP2 = record.substring(11,2).trim();
		SCSPCORDP3 = record.substring(13,2).trim();
		SCSPCORDP4 = record.substring(15,2).trim();
		SCSPCPO    = record.substring(16,1).trim();
		           
		SCDIRORDP1 = record.substring(17,2).trim();
		SCDIRORDP2 = record.substring(19,2).trim();
		SCDIRORDP3 = record.substring(21,2).trim();
		SCDIRORDP4 = record.substring(23,2).trim();
		SCDIRPO    = record.substring(24,1).trim();		
	}

	public String getAllowDiscontinuedItems() {
		return allowDiscontinuedItems;
	}

	public final String getSCREGORDP1() {
		return SCREGORDP1;
	}

	public final String getSCREGORDP2() {
		return SCREGORDP2;
	}

	public final String getSCREGORDP3() {
		return SCREGORDP3;
	}

	public final String getSCREGORDP4() {
		return SCREGORDP4;
	}

	public final String getSCREGPO() {
		return SCREGPO;
	}

	public final String getSCSPCORDP1() {
		return SCSPCORDP1;
	}

	public final String getSCSPCORDP2() {
		return SCSPCORDP2;
	}

	public final String getSCSPCORDP3() {
		return SCSPCORDP3;
	}

	public final String getSCSPCORDP4() {
		return SCSPCORDP4;
	}

	public final String getSCSPCPO() {
		return SCSPCPO;
	}

	public final String getSCDIRORDP1() {
		return SCDIRORDP1;
	}

	public final String getSCDIRORDP2() {
		return SCDIRORDP2;
	}

	public final String getSCDIRORDP3() {
		return SCDIRORDP3;
	}

	public final String getSCDIRORDP4() {
		return SCDIRORDP4;
	}

	public final String getSCDIRPO() {
		return SCDIRPO;
	}

}
