package com.dancik.om.dataobjects;

public abstract class ASystemSetting {
	protected String record = null;
	protected String key = "";
	
	ASystemSetting() {}
	
	ASystemSetting(String value) {
		this.setRecord(value);
		this.parseRecord();
	}
	
	public abstract void parseRecord();
	
	public void setRecord(String value) {
		this.record = value;
	}
	public String getRecord() {
		return this.record;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getKey() {
		return this.key;
	}
}