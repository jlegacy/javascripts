package com.dancik.om.tags.dropdowns;

public class Account_DropDown extends Generic_DropDown {
	public Account_DropDown() {
		super();
		this.onclick = "Search.account(event);";
		this.maxlength = "5";
		this.width = "60";
	}
}
