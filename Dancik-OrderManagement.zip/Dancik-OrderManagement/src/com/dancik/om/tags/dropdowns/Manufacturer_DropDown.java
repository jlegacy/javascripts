package com.dancik.om.tags.dropdowns;

public class Manufacturer_DropDown extends Generic_DropDown {
	public Manufacturer_DropDown() {
		super();
		this.onclick = "Search.manufacturer(event);";
		this.maxlength = "3";
	}
}
