package com.dancik.om.tags.dropdowns;

public class Salesperson_DropDown extends Generic_DropDown {
	public Salesperson_DropDown() {
		super();
		this.onclick = "Search.salesperson(event);";
		this.maxlength = "3";
		this.width = "30";
	}
}
