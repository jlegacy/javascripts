package com.dancik.om.tags.dropdowns;

public class Company_DropDown extends Generic_DropDown {
	public Company_DropDown() {
		super();
		this.onclick = "Search.company(event);";
		this.maxlength = "1";
		this.width = "15";
	}
}
