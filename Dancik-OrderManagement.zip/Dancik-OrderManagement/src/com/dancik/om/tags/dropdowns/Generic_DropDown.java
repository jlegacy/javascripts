package com.dancik.om.tags.dropdowns;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;
import javax.servlet.jsp.tagext.Tag;

import org.apache.log4j.Logger;

public class Generic_DropDown extends SimpleTagSupport {
	private Tag parent = null;
	private static Logger log = Logger.getLogger(Generic_DropDown.class);
	private JspWriter out = null;

	//Tag Class Defaults
	protected String id = "";		//id of input field
	protected String name = "";		//name of input field
	protected String onclick = "";	//onclick function for drop down image
	protected String onchange = "";	//onchange function for drop down input
	protected String width = "100";		//pixel width of input
	protected String maxlength = "10";	//maximum number of characters for input
	protected String value = "";	//default value
	protected String inputclass = "";	//extra class name to add to the input

	//Tag Instance values
	private String _id = null;
	private String _name = null;
	private String _onclick = null;
	private String _onchange = null;
	private String _width = null;
	private String _maxlength = null;
	private String _value = null;
	private String _inputclass = null;
	
	public Generic_DropDown() {
		super();
	}

	public void setParent(Tag p) {
		this.parent = p;
	}

	public Tag getParent() {
		return this.parent;
	}

	public void setId(String t) {
		this._id = t;
	}

	public void setName(String t) {
		this._name = t;
	}
	public void setOnclick(String t) {
		this._onclick = t;
	}
	public void setOnchange(String t) {
		this._onchange = t;
	}
	public void setWidth(String t) {
		this._width = t;
	}
	public void setMaxlength(String t) {
		this._maxlength = t;
	}
	public void setValue(String t) {
		this._value = t;
	}
	public void setInputclass(String t) {
		this._inputclass = t;
	}
	
	public void doTag() {
		this.out = ((PageContext)getJspContext()).getOut();
		
		// -- Put tag Class Defaults in to Instance Values where no attribute specified
		if (this._maxlength == null) {
			this._maxlength = this.maxlength;
		}
		if (this._id == null) {
			this._id = this.id;
		}
		if (this._name == null) {
			this._name = this.name;
		}
		if (this._onclick == null) {
			this._onclick = this.onclick;
		}
		
		// -- Get value from tag body
		try {
			StringWriter stringWriter = new StringWriter();
			JspFragment body = getJspBody();
			if(body!=null) {
				body.invoke(stringWriter);
		        this._value = stringWriter.toString().trim();
		        if(this._value.equals("")) {
					this._value = null;
		        }
			}
		} catch (IOException e) {
			log.debug("Exception in getting body");
		} catch (JspException e) {
			log.debug("Exception in getting body");
		}
        
		if (this._value == null) {
			this._value = this.value;
		}
		if (this._width == null) {
			this._width = this.width;
		}
		if (this._inputclass==null) {
			this._inputclass = this.inputclass;
		}
		
		try {
			out.write("<span class='dws-drop'>");
				out.write("<input type='text' id='" + this._id + "' name='" + this._name + "' class='" + this._inputclass + "' maxlength='" + this._maxlength + "' style='width:" + this._width + "px' value='" + this._value + "' onchange='" + this._onchange + "'/>");
				out.write("<img class='picker' src='../images/bullet_arrow_down.png' onclick='" + this._onclick +  "' alt=''/>"); 
			out.write("</span>");
		
		} catch (IOException e) {
			log.debug("IOException: " + e.getMessage());
		}

		//reset instance defaults for next instance
		this._id = null;
		this._name = null;
		this._onclick = null;
		this._width = null;
		this._maxlength = null;
		this._value = null;
		this._inputclass = null;
	}

	public void release() {
		this.parent = null;
		this.out = null;
	}

}
