package com.dancik.om.tags.dropdowns;

public class Warehouse_DropDown extends Generic_DropDown {
	public Warehouse_DropDown() {
		super();
		this.onclick = "Search.warehouse(event);";
		this.maxlength = "3";
		this.width = "30";
	}
}
