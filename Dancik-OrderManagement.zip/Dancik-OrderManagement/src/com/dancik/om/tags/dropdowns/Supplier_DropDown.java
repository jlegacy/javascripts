package com.dancik.om.tags.dropdowns;

public class Supplier_DropDown extends Generic_DropDown {
	public Supplier_DropDown() {
		super();
		this.onclick = "Search.supplier(event);";
		this.maxlength = "3";
		this.width = "30";
	}
}
