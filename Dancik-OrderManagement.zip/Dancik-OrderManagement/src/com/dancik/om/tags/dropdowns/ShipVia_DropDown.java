package com.dancik.om.tags.dropdowns;

public class ShipVia_DropDown extends Generic_DropDown {
	public ShipVia_DropDown() {
		super();
		this.onclick = "Search.shipvia(event);";
		this.maxlength = "2";
		this.width = "20";
	}
}
