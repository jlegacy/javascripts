package com.dancik.om.tags.dropdowns;

public class SystemTable_DropDown extends Generic_DropDown {
	public SystemTable_DropDown() {
		super();
		this.maxlength = "2";
		this.width = "20";
	}
}
