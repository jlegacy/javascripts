package com.dancik.om.tags.dropdowns;

public class Branch_DropDown extends Generic_DropDown {
	public Branch_DropDown() {
		super();
		this.onclick = "Search.branch(event);";
		this.maxlength = "3";
		this.width = "30";
	}
}
