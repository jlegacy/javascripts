package com.dancik.om.tags;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.apache.log4j.Logger;

public class Generic_ImageWrapper extends SimpleTagSupport {
	private static Logger log = Logger.getLogger(Generic_ImageWrapper.class);
	private JspWriter out = null;

	public Generic_ImageWrapper() {
		super();
	}

	public void doTag() {
		this.out = ((PageContext)getJspContext()).getOut();
		
		try {
			out.write("<span class='dws-drop'>");
			// -- Get value from tag body
			try {
				StringWriter stringWriter = new StringWriter();
				JspFragment body = getJspBody();
				if (body != null) {
					body.invoke(stringWriter);
			        out.write( stringWriter.toString().trim() );
				}
			} catch (IOException e) {
				log.debug("Exception in getting body");
			} catch (JspException e) {
				log.debug("Exception in getting body");
			}
			out.write("</span>");
		
		} catch (IOException e) {
			log.debug("IOException: " + e.getMessage());
		}
	}

	public void release() {
		this.out = null;
	}

}
