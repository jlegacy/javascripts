package com.dancik.om.tags;

import java.io.IOException;
import java.io.StringWriter;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.JspFragment;
import javax.servlet.jsp.tagext.SimpleTagSupport;

import org.apache.log4j.Logger;

public class Generic_GrayBoxWrapper extends SimpleTagSupport {
	private static Logger log = Logger.getLogger(Generic_GrayBoxWrapper.class);
	private JspWriter out = null;

	// -- Tag Instance values
	private boolean avoidTopLeft = false;
	private boolean avoidTopRight = false;
	private boolean avoidBottomLeft = false;
	private boolean avoidBottomRight = false;
	
	public Generic_GrayBoxWrapper() {
		super();
	}

	public void doTag() {
		this.out = ((PageContext)getJspContext()).getOut();
		
		try {
			out.write("<table cellpadding='0' cellspacing='0' class='greyBox-Table'>");
				out.write("<tr>");
					if (!this.avoidTopLeft) {
						out.write("<td class='greyBox-Table-TopLeft'></td>");
					}
					out.write("<td class='greyBox-Table-TopCenter'><img src='../images/clear.gif' alt='' height='1px' width='1px'/></td>");
					if (!this.avoidTopRight) {
						out.write("<td class='greyBox-Table-TopRight'></td>");
					}
				out.write("</tr>");
			out.write("</table>");
			out.write("<table cellpadding='0' cellspacing='0' class='greyBox-Table'>");
				out.write("<tr>");
					out.write("<td class='greyBox-Table-MiddleLeft'></td>");
					out.write("<td class='greyBox-Table-MiddleCenter'>");

					
			// -- Get value from tag body
			try {
				StringWriter stringWriter = new StringWriter();
				JspFragment body = getJspBody();
				if (body != null) {
					body.invoke(stringWriter);
			        out.write( stringWriter.toString().trim() );
				}
			} catch (IOException e) {
				log.debug("Exception in getting body");
			} catch (JspException e) {
				log.debug("Exception in getting body");
			}
        
					out.write("</td>");
					out.write("<td class='greyBox-Table-MiddleRight'></td>");
				out.write("</tr>");
			out.write("</table>");

			out.write("<table cellpadding='0' cellspacing='0' class='greyBox-Table'>");
				out.write("<tr>");
					if (!this.avoidBottomLeft) {
						out.write("<td class='greyBox-Table-BottomLeft'></td>");
					}
					out.write("<td class='greyBox-Table-BottomCenter'><img src='../images/clear.gif' alt='' height='1px' width='1px'/></td>");
					if (!this.avoidBottomRight) {
						out.write("<td class='greyBox-Table-BottomRight'></td>");
					}
				out.write("</tr>");
			out.write("</table>");
			
			
		} catch (IOException e) {
			log.debug("IOException: " + e.getMessage());
		}
	}

	public void release() {
		this.out = null;
	}
	public boolean isAvoidTopLeft() {
		return avoidTopLeft;
	}
	public void setAvoidTopLeft(boolean avoidTopLeft) {
		this.avoidTopLeft = avoidTopLeft;
	}
	public boolean isAvoidTopRight() {
		return avoidTopRight;
	}
	public void setAvoidTopRight(boolean avoidTopRight) {
		this.avoidTopRight = avoidTopRight;
	}
	public boolean isAvoidBottomLeft() {
		return avoidBottomLeft;
	}
	public void setAvoidBottomLeft(boolean avoidBottomLeft) {
		this.avoidBottomLeft = avoidBottomLeft;
	}
	public boolean isAvoidBottomRight() {
		return avoidBottomRight;
	}
	public void setAvoidBottomRight(boolean avoidBottomRight) {
		this.avoidBottomRight = avoidBottomRight;
	}
}
