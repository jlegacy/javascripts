package com.dancik.om.servlets;

import java.io.IOException;
import java.lang.reflect.Method;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.BeansException;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.dancik.api.http.Abstract_HttpServlet_Tool;
import com.dancik.om.dao.OM_AddOns_DAO;
import com.dancik.om.dataobjects.Visit;


public class OM_AddOns_Servlet extends Abstract_HttpServlet_Tool {

	private final static Logger jLogger = Logger.getLogger(OM_AddOns_Servlet.class);

	private WebApplicationContext ctx = null;
	private OM_AddOns_DAO dao = null;

	
	@SuppressWarnings("unchecked")
	protected void doGet (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

//		try {
//			this.setRequest(req);
//			final HttpSession ses = (HttpSession) req.getSession();
//			final Visit visit = (Visit)ses.getAttribute("Visit");
//
//			ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
//			dao = (OM_AddOns_DAO) ctx.getBean("omAddOnsDAO");
//
//			
//			String path[] = req.getServletPath().split("/");
//			
//			// -- Get the Method Name from URL...
//			String methodName = path[path.length-1];
//
//			Class params[] = { String.class, String.class };
//			Method m = dao.getClass().getDeclaredMethod(methodName,  params);
//			
//			final JSONObject json = (JSONObject)m.invoke(dao, new Object[]{ visit.getUserConfig().getUser(), this.buildParamsXML() });
//			
//			
//			req.setAttribute("json", json.toString());
//			
//			String forwardurl = this.getInitParameter("forwardurl");
//			
//			RequestDispatcher rd = req.getRequestDispatcher(forwardurl);
//			rd.forward(req, res);
//			
//			
//			
//		} catch (BeansException e) {
//			e.printStackTrace();
//			jLogger.error("Exception : " + e.getMessage());			
//		} catch (NumberFormatException e) {
//			e.printStackTrace();
//			jLogger.error("Exception : " + e.getMessage());
//		} catch (Exception e) {
//			e.printStackTrace();
//			jLogger.error("Exception : " + e.getMessage());
//		}
//		
//		finally {
//			ctx = null;
//			dao = null;
//		}
    }
	protected void doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
}

