package com.dancik.om.servlets;

import java.io.IOException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.web.context.WebApplicationContext;

import com.dancik.api.beans.IUserConfiguration_Bean;
import com.dancik.api.http.Abstract_HttpServlet_Tool;
import com.dancik.om.dao.JobEstimate_DAO;
import com.dancik.om.dataobjects.Visit;

public class UserConfig_Servlet extends Abstract_HttpServlet_Tool {
	private final static Logger jLogger = Logger.getLogger(UserConfig_Servlet.class);

	private WebApplicationContext ctx = null;
	private JobEstimate_DAO dao = null;

	protected void doGet (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		final HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");
		Map configMap = new HashMap();
		IUserConfiguration_Bean userConfig = visit.getUserConfig();
		Method[] methods = IUserConfiguration_Bean.class.getMethods();
		// Modified from new org.json code
        for (int i = 0; i < methods.length; i += 1) {
            try {
                Method method = methods[i];
                if (Modifier.isPublic(method.getModifiers())) {
                    String name = method.getName();
                    String key = "";
                    if (name.startsWith("get")) {
                    	if (name.equals("getClass") || 
                    			name.equals("getDeclaringClass")) {
                    		key = "";
                    	} else {
                    		key = name.substring(3);
                    	}
                    } else if (name.startsWith("is")) {
                        key = name.substring(2);
                    }
                    if (key.length() > 0 &&
                            Character.isUpperCase(key.charAt(0)) &&
                            method.getParameterTypes().length == 0) {
                        if (key.length() == 1) {
                            key = key.toLowerCase();
                        } else if (!Character.isUpperCase(key.charAt(1))) {
                            key = key.substring(0, 1).toLowerCase() +
                                key.substring(1);
                        }

                        Object result = method.invoke(userConfig, (Object[])null);

                        configMap.put(key, result);
                    }
                }
            } catch (Exception ignore) {
            	//just ignore it. 
            }
        }
        try {
	        JSONObject configJson = new JSONObject(configMap);
	        res.setContentType("application/json");
			res.setHeader("Cache-Control","no-cache"); //HTTP 1.1
			res.setHeader("Pragma","no-cache"); //HTTP 1.0
			res.setDateHeader ("Expires", 0);
			
			configJson.write( res.getWriter() );
			res.getWriter().close();
			res.flushBuffer();
        } catch (JSONException e) {
        	e.printStackTrace();
        	jLogger.error("Exception : " + e.getMessage());
		}
	}	
}
