package com.dancik.om.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.BeansException;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.dancik.api.http.Abstract_HttpServlet_Tool;
import com.dancik.api.xml.XML_Tool;
import com.dancik.om.dao.JobEstimate_DAO;
import com.dancik.om.dataobjects.Visit;

public class JobEstimate_Servlet extends Abstract_HttpServlet_Tool {
	private final static Logger jLogger = Logger.getLogger(JobEstimate_Servlet.class);
	private static enum Action { CREATE, READ, UPDATE, DELETE };

	private WebApplicationContext ctx = null;
	private JobEstimate_DAO dao = null;

	protected void doAction (HttpServletRequest req, HttpServletResponse res, final Action action) throws ServletException, IOException {

		try {
			this.setRequest(req);
			final HttpSession ses = (HttpSession) req.getSession();
			final Visit visit = (Visit)ses.getAttribute("Visit");
			
			ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
			dao = (JobEstimate_DAO)ctx.getBean("jobEstimateDAO");
			Document objDoc = this.buildParamsXMLDOM();
			Node params = objDoc.getFirstChild();
			
			//set parameter flag based on action
			Element actionFlag = objDoc.createElement("parm_orflag");
			params.appendChild(actionFlag);
			switch(action) {
				case CREATE:
					actionFlag.appendChild( objDoc.createTextNode("2") );
					break;
				case UPDATE:
					objDoc.appendChild( objDoc.createTextNode("2") );
					break;
				case READ:
					actionFlag.appendChild( objDoc.createTextNode("1") );
					break;
				case DELETE:
					actionFlag.appendChild( objDoc.createTextNode("1") );	//not supported right now.
					break;
			}
			
			String objXmlStr = XML_Tool.toString( objDoc );
			
//			System.out.println("XML: " + objXmlStr);

			final JSONObject jobEstimate = dao.get(visit.getUserConfig().getUser(), objXmlStr);
			
//			System.out.println(jobEstimate.toString(2));
			
			if( jobEstimate.has("errors") && jobEstimate.getBoolean("errors")) {
				res.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
			}
			
			res.setContentType("application/json");
			res.setHeader("Cache-Control","no-cache"); //HTTP 1.1
			res.setHeader("Pragma","no-cache"); //HTTP 1.0
			res.setDateHeader ("Expires", 0);
			
			jobEstimate.write( res.getWriter() );
			res.getWriter().close();
			res.flushBuffer();
			
		} catch (BeansException e) {
			e.printStackTrace();
			jLogger.error("Exception : " + e.getMessage());			
		} catch (NumberFormatException e) {
			e.printStackTrace();
			jLogger.error("Exception : " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			jLogger.error("Exception : " + e.getMessage());
		}
		
		finally {
			ctx = null;
			dao = null;
		}
    }
	
	protected void doGet (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		//Allow Rails style override of HTTP method for clients that don't support PUT/DELETE
		String method = req.getParameter("_method");
		if( method != null && !method.equalsIgnoreCase("get") ) {
			if( method.equalsIgnoreCase("put") ) {
				doPut(req, res);
			} else if( method.equalsIgnoreCase("post")) {
				doPost(req, res);
			} else if( method.equalsIgnoreCase("delete") ) {
				doDelete(req,res);
			}
		} else {
			doAction(req, res, Action.READ);
		}
	}
	
	protected void doPut (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doAction(req, res, Action.UPDATE);
	}
	
	protected void doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doAction(req, res, Action.CREATE);
	}
	
	protected void doDelete (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doAction(req, res, Action.DELETE);
	}
}
