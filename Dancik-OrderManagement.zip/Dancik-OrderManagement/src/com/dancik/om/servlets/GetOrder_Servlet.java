package com.dancik.om.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.BeansException;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.dancik.api.http.Abstract_HttpServlet_Tool;
import com.dancik.om.dao.OrderManager_DAO;
import com.dancik.om.dataobjects.Visit;


public class GetOrder_Servlet extends Abstract_HttpServlet_Tool {

	private final static Logger jLogger = Logger.getLogger(GetOrder_Servlet.class);

	private WebApplicationContext ctx = null;
	private OrderManager_DAO dao = null;

	
	protected void doGet (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		try {
			this.setRequest(req);
			final HttpSession ses = (HttpSession) req.getSession();
			final Visit visit = (Visit)ses.getAttribute("Visit");

			ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
			dao = (OrderManager_DAO) ctx.getBean("omDAO");

			final JSONObject json = dao.getOrder_ForInitView(visit.getUserConfig().getUser(), this.buildParamsXML());
			
			req.setAttribute("order", json.toString());
			
			RequestDispatcher rd = req.getRequestDispatcher("../app-mgr/order.jsp");
			rd.forward(req, res);
			
			
			
		} catch (BeansException e) {
			e.printStackTrace();
			jLogger.error("Exception : " + e.getMessage());			
		} catch (NumberFormatException e) {
			e.printStackTrace();
			jLogger.error("Exception : " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			jLogger.error("Exception : " + e.getMessage());
		}
		
		finally {
			ctx = null;
			dao = null;
		}
    }
	protected void doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
}

