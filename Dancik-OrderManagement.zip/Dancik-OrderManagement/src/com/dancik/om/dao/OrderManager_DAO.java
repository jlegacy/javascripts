package com.dancik.om.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Hashtable;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.dancik.api.exceptions.ConnectionNotEstablishedException;
import com.dancik.api.services.Abstract_JdbcDaoSupport;

public class OrderManager_DAO extends Abstract_JdbcDaoSupport {
	
	private final static Logger jLogger = Logger.getLogger(OrderManager_DAO.class);
//	private final static boolean logInfo = jLogger.isInfoEnabled();

	// **********************************************************************************************************************
	public JSONObject executeWithJSONListing(String inStoredProcedure, String inUser, String inXMLParams) throws Exception {
		return super.executeWithJSONListing( inStoredProcedure, inUser, inXMLParams);
	}
	// **********************************************************************************************************************
	public JSONObject executeWithJSONObject(String inStoredProcedure, String inUser, String inXMLParams) throws Exception {
		return super.executeWithJSONObject( inStoredProcedure, inUser, inXMLParams);
	}	
	// **********************************************************************************************************************

	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject init(String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;

		try {
			cstmt = conn.prepareCall("CALL Dancik_OM_Manager_Init(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); 		// -- outError (Y)

			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				json = new JSONObject();
				json.put("columns", this.buildArray(rs));
				
				// -- Check to see if any details lines were loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("settings", this.buildObject(rs));
				}
				
				// -- Check to see if any details lines were loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("bulletinboard", this.buildObject(rs));
				}
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());			
			json = this.buildErrors(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return json;
	}
	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject newOrder_VnD(String inStoredProcedure, String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;

		try {
			cstmt = conn.prepareCall("CALL " + inStoredProcedure + "(?,?,?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)
			cstmt.registerOutParameter(4, Types.CHAR); // -- outForwardCode (B/R/C/*blanks)
			cstmt.registerOutParameter(5, Types.CHAR); // -- outNewReference
			
			
			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else { 
				json = new JSONObject();
				json.put("mode", cstmt.getString(4));
				json.put("reference", cstmt.getString(5));
				json.put("records", this.buildArray(rs));
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());			
			json = this.buildErrors(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return json;
	}	
	
	
	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject genericPaginationSearch(String inStoreProcedure, String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;      // BKLG 0280
		
		try {
			cstmt = conn.prepareCall("CALL " + inStoreProcedure + "(?,?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); 		// -- outError (Y)
			cstmt.registerOutParameter(4, Types.INTEGER);	// -- Total Query size

			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				json = new JSONObject();
				json.put("querysize", cstmt.getInt(4));

				json.put("records", this.buildArray(rs));
				
				// -- Check to see if a summary lines were loaded... BKLG 0280
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("retailsummary", this.buildArray(rs));
				}
				
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());			
			json = this.buildErrors(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return json;
	}
	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject validateOrderSelection(String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;

		try {
			cstmt = conn.prepareCall("CALL Dancik_OM_ValidateOrderSelection(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); 		// -- outError (Y) or (R - For Rollover Items found) or (D = Duplicate Reference#s found)

			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				if (cstmt.getString(3).equals("R") || cstmt.getString(3).equals("D") ) {
					json = new JSONObject();
					json.put("records", this.buildArray(rs));
				}
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());			
			json = this.buildErrors(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return json;
	}	
	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject getOrder_ForInitView(String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;

		try {
			cstmt = conn.prepareCall("CALL Dancik_OM_GetOrder_InitView(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)

			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				json = new JSONObject();
				json.put("settings", this.buildObject(rs));
					
				// -- Build Header...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("header", this.buildObject(rs));
				}
				// -- Check to see if any details lines were loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("details", this.buildArray(rs));
				}
				// -- Check to see if the total line was loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("total", this.buildObject(rs));
				}
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());			
			json = this.buildErrors(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return json;
	}	
	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject getHeader(String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;

		try {
			cstmt = conn.prepareCall("CALL Dancik_OM_GetHeader(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); 		// -- outError (Y)

			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				json = new JSONObject();
				json.put("header", this.buildObject(rs));
				
				// -- Get any settings that may be used...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("settings", this.buildObject(rs));
				}
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());			
			json = this.buildErrors(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return json;
	}
	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
//	MAE 7/6/2011	converted to work with restful servlet
//	public JSONObject cancelLine(String inUser, String inXMLParams) throws Exception {
//		Connection conn = this.getConnection();
//
//		CallableStatement cstmt = null;
//		ResultSet rs = null;
//		JSONObject json = null;
//		boolean more = false;
//
//		try {
//			cstmt = conn.prepareCall("CALL Dancik_OM_CancelLine(?,?,?)");
//
//			cstmt.setString(1, inUser);
//			cstmt.setString(2, inXMLParams);
//
//			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)
//
//			cstmt.execute();
//			rs = cstmt.getResultSet();
//			if (cstmt.getString(3).equals("Y")) {
//				json = this.buildErrors(rs);
//			} else {
//				json = new JSONObject();
//				json.put("details", this.buildArray(rs));
//				// -- Check to see if the total line was loaded...
//				more = cstmt.getMoreResults();
//				if (more) {
//					rs = cstmt.getResultSet();
//					json.put("total", this.buildObject(rs));
//				}
//			}
//
//		} catch (Exception e) {
//			jLogger.error("Exception : " + e.getMessage());			
//			json = this.buildErrors(e);
//		} finally {
//			this.releaseConnection(conn);
//			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
//			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
//		}
//
//		return json;
//	}	


	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject getLineItem(String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;

		try {
			cstmt = conn.prepareCall("CALL Dancik_OM_GetLineItem(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); 		// -- outError (Y)

			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				json = new JSONObject();
				json.put("record", this.buildObject(rs));
				
				// -- Check to see if any details lines were loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("settings", this.buildObject(rs));
				}
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());			
			json = this.buildErrors(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return json;
	}	
	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	@SuppressWarnings("unchecked")
	public Hashtable getHeaderHASH(String inUser, String inXMLParams) throws Exception {
		return executeWithHashtable("Dancik_OM_GetHeader", inUser, inXMLParams);
	}

	
	/* ----------------------------------------------------------------------------------------------------------------------
	 * 
	 *  ---------------------------------------------------------------------------------------------------------------------- */
	public JSONObject saveHeader(String inUser, String inXMLParams) throws Exception {
		// -- Make sure connection is established...
		final Connection conn = this.getConnection();
		if (conn == null) {
			throw new ConnectionNotEstablishedException();
		}
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		
		try {
			cstmt = conn.prepareCall("CALL Dancik_OM_UpdateHeader(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);
			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y = Error, A = Alert message)

			cstmt.execute();
			
			if (cstmt.getString(3).equals("Y")) {
				rs = cstmt.getResultSet();
				json = this.buildErrors(rs);
			} else {
				if (cstmt.getString(3).equals("A")) {
					rs = cstmt.getResultSet();
					json = new JSONObject();
					json.put("alerts", this.buildArray(rs));
				}
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}
		return json;
	}	
	
}