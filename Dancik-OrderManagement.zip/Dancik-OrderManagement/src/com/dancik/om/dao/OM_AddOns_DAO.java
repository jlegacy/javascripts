package com.dancik.om.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import org.json.JSONObject;

import com.dancik.api.exceptions.ConnectionNotEstablishedException;
import com.dancik.api.services.Abstract_JdbcDaoSupport;

public class OM_AddOns_DAO extends Abstract_JdbcDaoSupport {

	/* ----------------------------------------------------------------------------------------------------------------------
	 * 
	 *  ---------------------------------------------------------------------------------------------------------------------- */
	public JSONObject executeWithJSONListing(String inStoredProcedure, String inUser, String inXMLParams) throws Exception {
		return super.executeWithJSONListing( inStoredProcedure, inUser, inXMLParams);
	}
	/* ----------------------------------------------------------------------------------------------------------------------
	 * 
	 *  ---------------------------------------------------------------------------------------------------------------------- */
	public JSONObject executeWithJSONObject(String inStoredProcedure, String inUser, String inXMLParams) throws Exception {
		return super.executeWithJSONObject( inStoredProcedure, inUser, inXMLParams);
	}
	/* ----------------------------------------------------------------------------------------------------------------------
	 * 
	 *  ---------------------------------------------------------------------------------------------------------------------- */
	public JSONObject execOrderDates(String inStoredProcedure, String inUser, String inXMLParams) throws Exception {
		// -- Make sure connection is established...
		final Connection conn = this.getConnection();
		if (conn == null) {
			throw new ConnectionNotEstablishedException();
		}
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;
		
		try {
			cstmt = conn.prepareCall("CALL " + inStoredProcedure + "(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);
			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)

			rs = cstmt.executeQuery();

			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				json = new JSONObject();
				json.put("global", this.buildObject(rs));
				
				// -- Check to see if any details lines were loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("header", this.buildObject(rs));
				}
				
				// -- Check to see if any details lines were loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("detail", this.buildArray(rs));
				}
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}
		return json;
	}
	
	/* ----------------------------------------------------------------------------------------------------------------------
	 * 
	 *  ---------------------------------------------------------------------------------------------------------------------- */
	public JSONObject getAvailableShipTo(String inUser, String inXMLParams) throws Exception {
		// -- Make sure connection is established...
		final Connection conn = this.getConnection();
		if (conn == null) {
			throw new ConnectionNotEstablishedException();
		}
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;
		
		try {
			cstmt = conn.prepareCall("CALL Dancik_OM_GetOrderShiptoAddresses(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);
			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)

			rs = cstmt.executeQuery();

			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				json = new JSONObject();
				json.put("order", this.buildObject(rs));
				
				// -- Check to see if any details lines were loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("account", this.buildObject(rs));
				}
				// -- Check to see if any details lines were loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("override", this.buildObject(rs));
				}
				// -- Check to see if any details lines were loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("shipto", this.buildArray(rs));
				}
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}
		return json;
	}

	/* ----------------------------------------------------------------------------------------------------------------------
	 * 
	 *  ---------------------------------------------------------------------------------------------------------------------- */
	public JSONObject updateShipTo(String inUser, String inXMLParams) throws Exception {
		// -- Make sure connection is established...
		final Connection conn = this.getConnection();
		if (conn == null) {
			throw new ConnectionNotEstablishedException();
		}
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;
		
		try {
			cstmt = conn.prepareCall("CALL Dancik_OM_UpdateOrderShipto(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);
			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y = Error, A = Alert message)

			cstmt.execute();
			
			if (cstmt.getString(3).equals("Y")) {
				rs = cstmt.getResultSet();
				json = this.buildErrors(rs);
			} else {
				if (cstmt.getString(3).equals("A")) {
					rs = cstmt.getResultSet();
					json = new JSONObject();
					json.put("alerts", this.buildArray(rs));

					more = cstmt.getMoreResults();
					if (more) {
						rs = cstmt.getResultSet();
						json.put("newvalues", this.buildObject(rs));
					}
				} else {
					json = new JSONObject();
				}
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}
		return json;
	}

	/* ----------------------------------------------------------------------------------------------------------------------
	 * 
	 *  ---------------------------------------------------------------------------------------------------------------------- */
	public JSONObject getPrintOptConfig(String inUser, String inXMLParams) throws Exception {
		// -- Make sure connection is established...
		final Connection conn = this.getConnection();
		if (conn == null) {
			throw new ConnectionNotEstablishedException();
		}
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;
		
		try {
			cstmt = conn.prepareCall("CALL Dancik_OM_GetPrintOptionsConfig(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);
			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)

			rs = cstmt.executeQuery();

			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				json = new JSONObject();
				json.put("record", this.buildObject(rs));
				
				// -- Check to see if any ODS - Auto-Fax options exists...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("ods_fax", this.buildArray(rs));
				}
				// -- Check to see if any ODS - Auto-Email options exists...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("ods_email", this.buildArray(rs));
				}
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}
		return json;
	}
		
}
