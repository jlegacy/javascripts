package com.dancik.om.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;

import org.json.JSONObject;

import com.dancik.api.exceptions.ConnectionNotEstablishedException;
import com.dancik.api.services.Abstract_JdbcDaoSupport;

public class JobEstimate_DAO extends Abstract_JdbcDaoSupport {

	public JSONObject get(String inUser, String inXMLParams) throws Exception {
		// -- Make sure connection is established...
		final Connection conn = this.getConnection();
		if (conn == null) {
			throw new ConnectionNotEstablishedException();
		}
		
		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = new JSONObject();
		
		try {
			cstmt = conn.prepareCall("CALL DANCIK_OM_WORK_WITH_JOB_ESTIMATES(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);
			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)

			rs = cstmt.executeQuery();
			
			if (rs != null  &&  rs.isBeforeFirst()) {
				json.put("records", this.buildArray(rs));
			}
			
			if(cstmt.getString(3).equals("Y")) {
				json.put("errors", true);
			}
			
		} catch (Exception e) {
			throw e;
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}
		return json;
	}
	
}
