package com.dancik.om.dao;

import org.json.JSONObject;

import com.dancik.api.services.Abstract_JdbcDaoSupport;

public class GenericUtils_DAO extends Abstract_JdbcDaoSupport {

	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject getAutoSuggest_CustomerSearch(String inUser, String inXMLParams) throws Exception {
		return this.executeWithJSONListing("Dancik_AutoSuggest_CustomerSearch", inUser, inXMLParams);
	}	
}
