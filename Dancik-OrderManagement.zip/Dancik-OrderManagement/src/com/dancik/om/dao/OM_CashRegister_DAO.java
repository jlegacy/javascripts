package com.dancik.om.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Types;
import java.util.Hashtable;

import org.apache.log4j.Logger;
import org.json.JSONObject;

import com.dancik.api.services.Abstract_JdbcDaoSupport;


public class OM_CashRegister_DAO extends Abstract_JdbcDaoSupport {

	private final static Logger jLogger = Logger.getLogger(OM_CashRegister_DAO.class);
	//private final static boolean logInfo = jLogger.isInfoEnabled();

	// **********************************************************************************************************************
	// *  Get Cash Register info...
	// **********************************************************************************************************************
	public JSONObject getOM_CashRegister(String inUser, String inXMLParams) throws Exception {
		return this.executeWithJSONListing("DANCIK_OM_CashRegisterRetrieve", inUser, inXMLParams);
	}       
	// **********************************************************************************************************************
	// *  Post Cash Register info...
	// **********************************************************************************************************************
	public JSONObject postOM_CashRegister(String inUser, String inXMLParams) throws Exception {
		return this.executeWithJSONListing("DANCIK_OM_CashRegisterProcess", inUser, inXMLParams);
	}   
	// **********************************************************************************************************************
	// *  Print Order Management Options...
	// **********************************************************************************************************************
	public JSONObject OM_SubmitPrintJob(String inUser, String inXMLParams) throws Exception {
		return this.executeWithJSONListing("DANCIK_OM_REPRINTORDERS", inUser, inXMLParams);
	}   
	public JSONObject OM_SubmitPackingList_PrintJob(String inUser, String inXMLParams) throws Exception {
		return this.executeWithJSONListing("DANCIK_OM_PrintPackList", inUser, inXMLParams);
	}   
	public JSONObject OM_SubmitPickingLabels_PrintJob(String inUser, String inXMLParams) throws Exception {
		return this.executeWithJSONListing("DANCIK_OM_PrintPickLabels", inUser, inXMLParams);
	}   
//	public JSONObject DANCIK_OM_CR_GetPaymethodData(String inUser, String inXMLParams) throws Exception {
//	return this.executeWithJSONListing("DANCIK_OM_CR_GetPaymethodData", inUser, inXMLParams);
//}       
//	public JSONObject Dancik_OM_GetEndOrderConfig(String inUser, String inXMLParams) throws Exception {
//		return this.executeWithJSONListing("Dancik_OM_GetEndOrderConfig", inUser, inXMLParams);
//	}  
//	public JSONObject OM_validate_Creditcard_swipe(String inUser, String inXMLParams) throws Exception {
//		return this.executeWithJSONListing("DANCIK_OM_CR_Validate_Swiped_Creditcards", inUser, inXMLParams);
//	}      

//	@SuppressWarnings("unchecked")
//	public Hashtable getPaymentMethodHASH(String inUser, String inXMLParams) throws Exception {
//		Connection conn = this.getConnection();
//
//		CallableStatement cstmt = null;
//		ResultSet rs = null;
//		Hashtable hash = null;
//
//		try {
//			cstmt = conn.prepareCall("CALL DANCIK_OM_GetPaymentMethods(?,?,?)");
//
//			cstmt.setString(1, inUser);
//			cstmt.setString(2, inXMLParams);
//
//			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)
//
//			cstmt.execute();
//			rs = cstmt.getResultSet();
//			if (cstmt.getString(3).equals("Y")) {
//				hash = this.buildErrorsHash(rs);
//			} else {
//				hash = new Hashtable();
//				hash.put("method", this.buildHashtableArray(rs));
//			}
//
//		} catch (Exception e) {
//			jLogger.error("Exception : " + e.getMessage());
//			e.printStackTrace();
//			hash = this.buildErrorsHash(e);
//		} finally {
//			this.releaseConnection(conn);
//			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
//			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
//		}
//
//		return hash;
//	}		

//	public Hashtable Dancik_OM_GetEndOrderConfigHASH(String inUser, String inXMLParams) throws Exception {
//		Connection conn = this.getConnection();
//
//		CallableStatement cstmt = null;
//		ResultSet rs = null;
//		Hashtable hash = null;
//
//		try {
//			cstmt = conn.prepareCall("CALL Dancik_OM_GetEndOrderConfig(?,?,?)");
//
//			cstmt.setString(1, inUser);
//			cstmt.setString(2, inXMLParams);
//
//			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)
//
//			cstmt.execute();
//			rs = cstmt.getResultSet();
//			if (cstmt.getString(3).equals("Y")) {
//				hash = this.buildErrorsHash(rs);
//			} else {
//				hash = new Hashtable();
//				hash.put("settings", this.buildHashtable(rs));
//			}
//
//		} catch (Exception e) {
//			jLogger.error("Exception : " + e.getMessage());
//			e.printStackTrace();
//			hash = this.buildErrorsHash(e);
//		} finally {
//			this.releaseConnection(conn);
//			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
//			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
//		}
//
//		return hash;
//	}		

}