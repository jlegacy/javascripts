package com.dancik.om.dao;

import java.io.IOException;
import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.dancik.api.beans.IUserConfiguration_Bean;
import com.dancik.api.exceptions.NoUserConfigException;
import com.dancik.api.factory.UserConfigurationFactory;
import com.dancik.om.dataobjects.Visit;
import com.dancik.rest.daos.RestfulDAO;
import com.dancik.rest.format.OutputData;

public class Visit_DAO extends RestfulDAO {
	
	private final static Logger jLogger = Logger.getLogger(Visit_DAO.class);
	
//	@SuppressWarnings("unchecked")
//	public Visit build(String inUser) throws Exception {
//		// -- Build a Visit object, to maintain all session objects.  Terminology taken from Tapestry...
//		final Visit visit = new Visit();
//
//		String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><params><appid>om</appid></params>";
//		
//		String sp = "Dancik_Navigator_GetConfig";
//		
//		OutputData output = this.call3ArgProcedure(inUser, xml, sp);
//		if (output != null) {
//			if ( output.mapResult.get("errors") == null ) {
//				// -- User configurations.
//				visit.setUserConfigMap( (Map<String, String>)output.mapResult.get("user") );
//					
//				// -- Navigator accesses
//				List navs = ((List<Map<String, String>>)output.mapResult.get("nav"));
//				Map<String, String> nav = new HashMap<String, String>();
//				int len = navs.size();
//				for (int i=0; i<len; i++) {
//					Map m = (Map<String, String>)navs.get(i);
//					nav.put( (String)m.get("id"), (String)m.get("url") );
//				}
//				visit.setNavConfigMap( nav );
//			
//				// -- Application permissions/settings
//				List apps = ((List<Map<String, String>>)output.mapResult.get("app"));
//				Map<String, String> app = new HashMap<String, String>();
//				len = apps.size();
//				for (int i=0; i<len; i++) {
//					Map m = (Map<String, String>)apps.get(i);
//					app.put( (String)m.get("id"), (String)m.get("allowed") );
//				}
//				
//				visit.setAppConfigMap( app );
//				
//			} else {
//				throw new IOException("Error occurred during configuration retrieval.");
//			}
//		} else {
//			throw new IOException("Error occurred during configuration retrieval.");
//		}
//		
//		visit.setUserConfig( this.getUserConfigBean(inUser) );
//
//		return visit;		
//	}

//	public IUserConfiguration_Bean getUserConfigBean(String inUser) throws Exception {
//		Connection conn = this.getConnection();
//		IUserConfiguration_Bean config = null;
//		
//		try { 
//
//			// -- Retrieve the User Configuration bean....
//			config = (IUserConfiguration_Bean)UserConfigurationFactory.build(conn, inUser);
//	    	if (config == null) {
//	    		throw new NoUserConfigException();
//			}
//			
//	    	
//		} catch (NoUserConfigException e) {
//			jLogger.error("NoUserConfigException : " + e.getMessage());			
//			throw e;
//		} catch (Exception e) {
//			jLogger.error("Exception : " + e.getMessage());			
//			throw e;
//		} finally {
//			this.releaseConnection(conn);
//		}
//		
//		return config;
//	}
//	
}
