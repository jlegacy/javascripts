package com.dancik.om.filters;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.dancik.api.exceptions.NoSessionException;
import com.dancik.api.exceptions.NoUserEstablishedException;
import com.dancik.api.http.Abstract_Http_Tool;
import com.dancik.api.xml.XML_Tool;
import com.dancik.om.dataobjects.Visit;
import com.dancik.rest.config.RestfulConfig;
import com.dancik.rest.daos.Visit_DAO;

public class Abstract_SessionFilter extends Abstract_Http_Tool {

	private final static Logger jLogger = Logger.getLogger(Abstract_SessionFilter.class);
//	private final static boolean logInfo = jLogger.isInfoEnabled();
	
	private ServletContext servletContext = null;
	private WebApplicationContext ctx = null;
	private Visit_DAO dao = null;
	
	
	public void validate(ServletRequest request, ServletResponse response)  throws ServletException, IOException {
		HttpServletRequest req = null;
		HttpSession ses = null;
		String user = "";
		
		try {
			// -- Check request
			if ( request==null ) { throw new NoSessionException(); }
			
			req = (HttpServletRequest) request;
			ses = (HttpSession) req.getSession();

			
			user = (req.getRemoteUser() == null) ? "" : req.getRemoteUser().toUpperCase();
			// -- Retrieve the User from the RemoteUser...
			if (user.trim().length() == 0) {
 				throw new NoUserEstablishedException();
			} else {
				if ( req.getRequestedSessionId()==null || !req.isRequestedSessionIdValid() ) {
					req.getSession(true);
				}
			}
			
			 
			// -- Check Session
			ses = req.getSession(false);
			if ( ses==null ) { throw new NoSessionException(); }

			
			// -- Retrieve VISIT object...
			ses = (HttpSession) req.getSession();
  	    	ses.setAttribute("errormessage",null);
			Visit visit = (Visit)ses.getAttribute("Visit");
			// -- If the session's "visit" object is null, then re-create it...
			if (visit == null) {
				ctx = WebApplicationContextUtils.getWebApplicationContext(req.getSession().getServletContext());
				dao = (Visit_DAO)ctx.getBean("visitDAO");

				String appID = RestfulConfig.getAppId(ctx);
				
				// -- Build a Visit object, to maintain all session objects.  Terminology taken from Tapestry...
				visit = new Visit();
				dao.build(visit, user, appID);
				
				if (visit.getUserConfigMap() == null  || visit.getUserConfigMap().isEmpty()) {
					if (ses != null) {
			  	    	ses.setAttribute("errormessage","User " + user + " is not setup in both CTLPNLUSR / CTRLUSER files correctly.");
					}
	 				throw new IOException();
				}
				
				if (visit.getNavConfigMap() == null  || visit.getNavConfigMap().isEmpty()) {
					if (ses != null) {
			  	    	ses.setAttribute("errormessage", "User " + user + " does not have authority to access Order Management.");
					}
	 				throw new IOException();
				}
				
				// -- Extract out the Version...
				try {
					Document xml = XML_Tool.buildDocument( new File( ses.getServletContext().getRealPath("/WEB-INF/version.xml") ) );
					Element appElem = (Element)xml.getElementsByTagName("app").item(0);
					visit.setCurrentVersion( XML_Tool.getNodeValue( appElem, "current-version" ) );
					visit.setCurrentRevision( XML_Tool.getNodeValue( appElem, "current-revision" ) );
				} catch (Exception e) {
					jLogger.error("(SOFT) Exception : " + e.getMessage());						
				}

				ses.setAttribute("Visit", visit);	
			}

			

		} catch (NoUserEstablishedException e) {
			e.printStackTrace();
			if (ses != null) {
				ses.setAttribute("errormessage", "User is not logged in on remote server.");
			}
			throw e;
		} catch (Exception e) {
			e.printStackTrace();
			jLogger.error("Exception : " + e.getMessage());						
		}
		finally {
			ctx = null;
			dao = null;
		}
	}

	
	public ServletContext getServletContext() {
		return servletContext;
	}
	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}
}
