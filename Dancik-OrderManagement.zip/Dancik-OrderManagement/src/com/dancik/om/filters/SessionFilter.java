package com.dancik.om.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class SessionFilter extends Abstract_SessionFilter implements Filter {
	
    public void init(FilterConfig config) throws ServletException {
        super.setServletContext( config.getServletContext() );
    }
	public void destroy() {
	}

	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws ServletException, IOException {

		try {
			String uri = ((HttpServletRequest)req).getRequestURI();
			
			// -- Avoid filtering through images, error pages, stylesheets and javascript files...
			if (uri.indexOf("/images/") > -1  
				||	uri.indexOf("/errors/") > -1  
				||  uri.endsWith(".css")  
				||  uri.endsWith(".js")) {
				// -- Cache images...
				if ( (uri.indexOf("/images/") > -1) ) {  
					((HttpServletResponse)res).setHeader("Expires", "Tue, 2 Feb 2022 20:00:00 GMT");
				}
			} else {
				validate(req, res);
			}
			
			chain.doFilter(req, res);
			
		} catch (Exception e) {
			e.printStackTrace();
			if (super.getServletContext() != null) {
				super.getServletContext().getRequestDispatcher("/errors/error.jsp").forward(req, res); 			
			}
			
		} finally {
		}

	}

}