package com.dancik.om.filters;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Hashtable;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.dancik.api.exceptions.JSONServiceException;

public class ServiceFilter extends Abstract_SessionFilter implements Filter {

	private final static Logger jLogger = Logger.getLogger(ServiceFilter.class);
//	private final static boolean logInfo = jLogger.isInfoEnabled();
	
	private static final String basePackage = "com.dancik.om.webservices";
	@SuppressWarnings("unchecked")
	private static final Hashtable services = new Hashtable();

	private FilterConfig filterConfig = null;	
	
	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;
	}

	public void destroy() {
	}
	
	

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws ServletException, IOException {
		HttpServletRequest req = null;
		HttpServletResponse res = null;
		HttpSession ses = null;

			try {
				// -- Perform Session & User validation before continuing...
				validate(request, response);
				
				req = (HttpServletRequest) request;
				res = (HttpServletResponse) response;
				ses = (HttpSession) req.getSession();
				this.setRequest( req );	
				
				// find/create service
				String serviceName = req.getServletPath();
				Service service = (Service) services.get(serviceName);
				if ( service == null ) {
					service = createService(serviceName);
					services.put(serviceName, service);
				}
				
				// -- Retrieve the Filter Init-Param to determine the output...
				String output_Param = this.getString("output");				
				String output_Config = this.filterConfig.getInitParameter("output");
				
				// -- If the caller is not expecting an "output" of some sort (JSON, CMLE, etc.), the invoke a service with VOID return...
				if ( (output_Param == null || output_Param.equals("")) && (output_Config == null || output_Config.equals(""))) {
					service.method.invoke(service.instance, new Object[]{ req });
				} else {
					String t = (String)service.method.invoke(service.instance, new Object[]{ req });             
					ServletOutputStream out = res.getOutputStream();
					res.setContentType("application/json");
					out.print( t );
				}
				
				

			} catch (Exception e) {
				e.printStackTrace();
				jLogger.error("Exception : " + e.getMessage());				
				if (ses != null) {
		  	    	ses.setAttribute("errormessage", e.getMessage());
				}
				throw new JSONServiceException();
			}
		
	}
	
	
    
    private Service createService(String serviceName) throws ServletException {
    	
		String path[] = serviceName.split("/");
		StringBuffer className = new StringBuffer(basePackage);
		for ( int c=2; c<path.length-1; c++ ) {
			className.append( (c>2 && path[c-1].charAt(0)>='A' && path[c-1].charAt(0)<='Z') ? "$" : ".");   
			className.append(path[c]);
		} 
		
		Service service = new Service();
		try {
			Class c = Class.forName( className.toString() );
			service.instance = c.newInstance();
			
		} catch (ClassNotFoundException e) { 
			throw new ServletException("Class '" + className.toString() + "' not found.");
			
		} catch (InstantiationException e) {
			throw new ServletException(e);
			
		} catch (IllegalAccessException e) {
			throw new ServletException(e);
			
		}
		
		// look for method
		String methodName = path[path.length-1];
		Method m[] = service.instance.getClass().getDeclaredMethods();
		for (int i = 0; i < m.length; i++) {
			//System.out.println(" m: "+m[i].getName());
			if ( !m[i].getName().equals(methodName) ) continue;
			Class params[] = m[i].getParameterTypes();
			//if ( params.length!=1 ) continue; // always 1 args...
			if ( !params[0].equals(HttpServletRequest.class) ) continue; // first must be request?
			
			service.method = m[i];
			return service;
		}
		
		throw new ServletException("Service " + serviceName + " ("+className+") not found");
	}

    

    
    
	static class Service {
		Object instance;
		Method method;
	}    
}
