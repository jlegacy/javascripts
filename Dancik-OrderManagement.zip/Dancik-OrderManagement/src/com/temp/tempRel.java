package com.temp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;

import com.dancik.api.http.Abstract_HttpServlet_Tool;


public class tempRel extends Abstract_HttpServlet_Tool {

	private static final long serialVersionUID = -2009134411883695170L;

	private final static Logger log = Logger.getLogger(tempRel.class);

	protected void doGet (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		try {
			this.setRequest(req);
			res.setContentType("application/json");
			PrintWriter out = res.getWriter();
						
			out.print("{\"related\": [{\"mfgr\":\"PER\", \"color\":\"3107\", \"patt\":\"020\", \"desc1\":\"PERGO WALLBASE SHAPED\", \"invent\":\"0\", \"uom1\":\"PC\", \"desc2\":\"NEUTRAL (WHITE)\"},{\"mfgr\":\"PER\", \"color\":\"3107\", \"patt\":\"021\", \"desc1\":\"PERGO WALLBASE STRAIGHT\", \"invent\":\"0\", \"uom1\":\"PC\", \"desc2\":\"NEUTRAL (WHITE)\"},{\"mfgr\":\"PER\", \"color\":\"3107\", \"patt\":\"030\", \"desc1\":\"PERGO END PIECES SHAPED\", \"invent\":\"0\", \"uom1\":\"PK\", \"desc2\":\"NEUTRAL (WHITE)\"},{\"mfgr\":\"PER\", \"color\":\"3107\", \"patt\":\"031\", \"desc1\":\"PERGO END PIECES STRAIGHT\", \"invent\":\"0\", \"uom1\":\"PK\", \"desc2\":\"NEUTRAL (WHITE)\"}]}");
			
		} catch (BeansException e) {
			e.printStackTrace();
			log.error("Exception : " + e.getMessage());			
		} catch (NumberFormatException e) {
			e.printStackTrace();
			log.error("Exception : " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception : " + e.getMessage());
		}
		
		finally {
		}
    }
	protected void doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
}

