package com.temp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;

import com.dancik.api.http.Abstract_HttpServlet_Tool;


public class tempIso extends Abstract_HttpServlet_Tool {

	private static final long serialVersionUID = -2009134411883695170L;

	private final static Logger log = Logger.getLogger(tempIso.class);

	protected void doGet (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		try {
			this.setRequest(req);
			res.setContentType("application/json");
			PrintWriter out = res.getWriter();
						
			out.print("{\"iso\": [{\"ware\": \"ANA\", \"item\": \"PERP169\", \"serial\": \"MR96\", \"qty\": \"20.50\", \"uom\": \"SF\", \"price\": \"1.98\", \"comments\": \"TFR\", \"desc1\": \"PERGO CLASSIC COLLECTION ***\", \"location\": \"K73\"}, {\"ware\": \"NYC\", \"item\": \"PERP179\", \"serial\": \"\", \"qty\": \"20.50\", \"uom\": \"SF\", \"price\": \"1.98\", \"comments\": \"B/O 06/28/10 L\", \"desc1\": \"PERGO CLASSIC COLLECTION\"}, {\"ware\": \"NYC\", \"item\": \"PER40001\", \"serial\": \"REG\", \"qty\": \"1.00\", \"uom\": \"EA\", \"price\": \"1.98\", \"comments\": \"\", \"desc1\": \"PERGO GLUE\", \"location\": \"RACK\"}, {\"ware\": \"NYC\", \"item\": \"PER40012\", \"serial\": \"\", \"qty\": \"1.00\", \"uom\": \"EA\", \"price\": \"1.98\", \"comments\": \"B/O 06/23/10 L\", \"desc1\": \"PERGO UNDERLAY FOAM\"}, {\"ware\": \"RAL\", \"item\": \"PER40014\", \"serial\": \"RG\", \"qty\": \"1.00\", \"uom\": \"PK\", \"price\": \"1.74\", \"comments\": \"TFR\", \"desc1\": \"SOUND-INSULATING UNDERFLOORX \"}]}");
			
		} catch (BeansException e) {
			e.printStackTrace();
			log.error("Exception : " + e.getMessage());			
		} catch (NumberFormatException e) {
			e.printStackTrace();
			log.error("Exception : " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception : " + e.getMessage());
		}
		
		finally {
		}
    }
	protected void doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
}

