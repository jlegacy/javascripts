package com.temp;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.BeansException;

import com.dancik.api.http.Abstract_HttpServlet_Tool;


public class tempGet extends Abstract_HttpServlet_Tool {

	private static final long serialVersionUID = -2009134411883695170L;

	private final static Logger log = Logger.getLogger(tempGet.class);

	protected void doGet (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		try {
			this.setRequest(req);
			res.setContentType("application/json");
			PrintWriter out = res.getWriter();
						
			if(this.getString("item").equals("PERP169")) {
				out.print("{\"bom\": [{\"mfgr\": \"PER\", \"color\": \"P169\", \"patt\": \" \", \"qty\": \"1.00\", \"uom1\": \"SF\", \"comment\": \"OAK 6169 \", \"invent\": \"0\", \"desc1\": \"PERGO CLASSIC COLLECTION ***\", \"desc2\":\"OAK BLOCKED DROP\"}, {\"mfgr\": \"PER\", \"color\": \"P179\", \"patt\": \" \", \"qty\": \"2.00\", \"uom1\": \"SF\", \"comment\": \"BIRCH 6179 \", \"invent\": \"0\", \"desc1\": \"PERGO CLASSIC COLLECTION\", \"desc2\":\"CURLY BIRCH BLOCKED\"}, {\"mfgr\": \"PER\", \"color\": \"4000\", \"patt\": \"1 \", \"qty\": \"1.00\", \"uom1\": \"EA\", \"comment\": \"GLUE \", \"invent\": \"9964\", \"desc1\": \"PERGO GLUE\", \"desc2\":\"\"}, {\"mfgr\": \"PER\", \"color\": \"4001\", \"patt\": \"2 \", \"qty\": \"1.00\", \"uom1\": \"EA\", \"comment\": \"FOAM \", \"invent\": \"0\", \"desc1\": \"PERGO UNDERLAY FOAM\", \"desc2\":\"65 FT X 2'6\\\" (162.5 SF)\"}, {\"mfgr\": \"PER\", \"color\": \"4001\", \"patt\": \"4 \", \"qty\": \"1.00\", \"uom1\": \"PK\", \"comment\": \"UNDERFLOOR 2345678 \", \"invent\": \"0\", \"desc1\": \"SOUND-INSULATING UNDERFLOOR\", \"desc2\":\"(20 PCS PER PACK)\"}]}");
			}
			
		} catch (BeansException e) {
			e.printStackTrace();
			log.error("Exception : " + e.getMessage());			
		} catch (NumberFormatException e) {
			e.printStackTrace();
			log.error("Exception : " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception : " + e.getMessage());
		}
		
		finally {
		}
    }
	protected void doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
}

