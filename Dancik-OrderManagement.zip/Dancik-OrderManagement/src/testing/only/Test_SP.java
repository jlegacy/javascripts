package testing.only;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Types;
import java.util.Date;

import org.json.JSONObject;

public class Test_SP {

	public static void main(String[] args) {
//		System.out.println("Begin Connection");				
		long beginConn = new Date().getTime(); 
//		Connection conn = TestingConnection.get("DMOSLEY12D", "CLIFF1986");
		long endConn = new Date().getTime(); 
//		System.out.println("After Connection");				

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		long endPrepare = 0; 
		long endRegister = 0; 
		long endExecute = 0; 

		try {
//			cstmt = conn.prepareCall("CALL DMLIB_TIME_TEST(?)");
			endPrepare = new Date().getTime(); 

			String xml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?>" +
					"<params>" +
//						"<parm_ReferenceId>1017886</parm_ReferenceId>" +
						"<parm_ReferenceId>1002388</parm_ReferenceId>" +
					"</params>";
			
//			cstmt.setString(1, "DANCIK");
//			cstmt.setString(2, xml);
//			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)

//			endRegister = new Date().getTime(); 

			for (int i=0; i<25; i++) {
				Connection conn = TestingConnection.get("DMOSLEY12D", "CLIFF1986");
				cstmt = conn.prepareCall("CALL DMLIB_TIME_TEST_New(?)");
				cstmt.registerOutParameter(1, Types.CHAR);
				cstmt.execute();
				System.out.println(cstmt.getString(1).trim());
				cstmt = null;
				conn = null;
			}
			System.out.println("==============");
//			endExecute = new Date().getTime(); 
			for (int i=0; i<25; i++) {
				Connection conn = TestingConnection.get("DMOSLEY12D", "CLIFF1986");
				cstmt = conn.prepareCall("CALL DMLIB_TIME_TEST_Old(?)");
				cstmt.registerOutParameter(1, Types.CHAR);
				cstmt.execute();
				System.out.println(cstmt.getString(1).trim());
				cstmt = null;
				conn = null;
			}
			
//			do {
//				rs = cstmt.getResultSet();
//	
//				final ResultSetMetaData meta = rs.getMetaData(); 
//				final int cols = meta.getColumnCount();
////				System.out.println("# columns : " + cols);
//				
//				while (rs.next()) {
//					for (int i=0; i<cols; i++) {
////						System.out.println(meta.getColumnName(i+1).toLowerCase() + " : " + rs.getString(i+1));
//					}
////					System.out.println("");
//				}
////				System.out.println("--------------------------------------------------------------------------------");
//			} while (cstmt.getMoreResults());
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			long endAll = new Date().getTime();
			
//			System.out.println("Connection : " + (endConn - beginConn));
//			System.out.println("Prepare : " + (endPrepare - endConn));
//			System.out.println("Register : " + (endRegister - endPrepare));
//			System.out.println("Execute : " + (endExecute - endRegister));
//			System.out.println("Extraction : " + (endAll - endExecute));
			
		}
		
		
	}
	
}
