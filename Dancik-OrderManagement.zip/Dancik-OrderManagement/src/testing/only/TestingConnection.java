package testing.only;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.commons.dbcp.BasicDataSource;


public class TestingConnection {

	static BasicDataSource ds = null;
	static Connection con = null;
	static Class driver = null;
	static String url;

	/**
	 */
	public static void kill() {
		try {
			if (con != null) {
				con.close();
				con = null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	public static Connection get() {
		if (con == null) {

			try {
               Class.forName( "com.ibm.as400.access.AS400JDBCDriver" );
				url = "jdbc:as400:sal.dancik.com;naming=system;translate binary=true;user=RADARUSER;password=RADARUSER";
				con = DriverManager.getConnection(url);
			} catch (Exception e) {
				System.out.println(e);
			}
		}
		return con;
	}


	/**
	 */
	public static Connection get(String user, String pwd) {
		if (con == null) {

			try {
               Class.forName( "com.ibm.as400.access.AS400JDBCDriver" );
				url = "jdbc:as400:sal.dancik.com;naming=system;translate binary=true;user=" + user + ";password="+ pwd;
				con = DriverManager.getConnection(url);

			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		return con;
	}
	/**
	 */
	public static Connection get(String ip, String user, String pwd) {
		kill();
System.out.println(con);		
			try {
               Class.forName( "com.ibm.as400.access.AS400JDBCDriver" );
				url = "jdbc:as400:" + ip + ";naming=system;translate binary=true;user=" + user + ";password="+ pwd;
				con = DriverManager.getConnection(url);

			} catch (Exception e) {
				e.printStackTrace();
			}

		return con;
	}
	
	
	public static BasicDataSource getDS() {
		if (ds == null) {
			ds = new BasicDataSource();
			((BasicDataSource) ds).setDriverClassName("com.ibm.as400.access.AS400JDBCDriver");
			((BasicDataSource) ds).setUrl("jdbc:as400:local;naming=system;translate binary=true");
			((BasicDataSource) ds).setUsername("RADARUSER");
			((BasicDataSource) ds).setPassword("RADARUSER");
			
			// -- The initial number of connections that are created when the pool is started.
			((BasicDataSource) ds).setInitialSize(2);
			
			// -- The minimum number of active connections that can remain idle in the pool, without extra ones being created, or 0 to create none.
			((BasicDataSource) ds).setMinIdle(1);
			
			// -- The maximum number of connections that can remain idle in the pool, without extra ones being released, or negative for no limit.
			((BasicDataSource) ds).setMaxIdle(10);
			
			// -- The maximum number of active connections that can be allocated from this pool at the same time, or negative for no limit.
			((BasicDataSource) ds).setMaxActive(20);
			
			// -- The maximum number of milliseconds that the pool will wait (when there are no available connections) for a connection to be returned before throwing an exception, or <= 0 to wait indefinitely.
			((BasicDataSource) ds).setMaxWait(-1);
			
		}
		return ds;
	}
	public static BasicDataSource getDS(String user, String pwd) {
		if (ds == null) {
			ds = new BasicDataSource();
			((BasicDataSource) ds).setDriverClassName("com.ibm.as400.access.AS400JDBCDriver");
			((BasicDataSource) ds).setUrl("jdbc:as400:local;naming=system;translate binary=true");
			((BasicDataSource) ds).setUsername(user);
			((BasicDataSource) ds).setPassword(pwd);
			((BasicDataSource) ds).setInitialSize(2);
			((BasicDataSource) ds).setMinIdle(1);
			((BasicDataSource) ds).setMaxIdle(10);
			((BasicDataSource) ds).setMaxIdle(20);
			((BasicDataSource) ds).setMaxWait(-1);
		}
		return ds;
	}
	public static BasicDataSource getDS(String ip, String user, String pwd) {
		if (ds == null) {
			ds = new BasicDataSource();
			((BasicDataSource) ds).setDriverClassName("com.ibm.as400.access.AS400JDBCDriver");
			((BasicDataSource) ds).setUrl("jdbc:as400:" + ip + ";naming=system;translate binary=true");
			((BasicDataSource) ds).setUsername(user);
			((BasicDataSource) ds).setPassword(pwd);
			((BasicDataSource) ds).setInitialSize(2);
			((BasicDataSource) ds).setMinIdle(1);
			((BasicDataSource) ds).setMaxIdle(10);
			((BasicDataSource) ds).setMaxIdle(20);
			((BasicDataSource) ds).setMaxWait(-1);
		}
		return ds;
	}
}