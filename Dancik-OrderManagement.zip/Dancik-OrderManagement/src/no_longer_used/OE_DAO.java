package no_longer_used;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Hashtable;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.json.XML;

import com.dancik.api.exceptions.ConnectionNotEstablishedException;
import com.dancik.api.services.Abstract_JdbcDaoSupport;

public class OE_DAO extends Abstract_JdbcDaoSupport {
	
	private final static Logger jLogger = Logger.getLogger(OE_DAO.class);
//	private final static boolean logInfo = jLogger.isInfoEnabled();
	

	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject newOrder_InitialSearch(String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;

		try {
			cstmt = conn.prepareCall("CALL Dancik_NewOrder_InitialSearch(?,?,?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)
			cstmt.registerOutParameter(4, Types.CHAR); // -- outForwardCode (B/R/C/*blanks)
			cstmt.registerOutParameter(5, Types.CHAR); // -- outNewReference

			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else { 
				json = new JSONObject();
				json.put("mode", cstmt.getString(4));
				json.put("reference", cstmt.getString(5));
				json.put("records", this.buildArray(rs));
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());			
			json = this.buildErrors(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return json;
	}

	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject getPendingLineItem(String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;

		try {                              
			cstmt = conn.prepareCall("CALL Dancik_OE_GetPendingLineItem(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)

			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				json = new JSONObject();
				json.put("header", this.buildObject(rs));
					
				// -- Check to see if any details lines were loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("details", this.buildArray(rs));
				}
				// -- Check to see if the total line was loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("total", this.buildObject(rs));
				}
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());			
			json = this.buildErrors(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return json;
	}	
	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public Hashtable getPendingHeaderHASH(String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		Hashtable hash = null;
		boolean more = false;

		try {
			cstmt = conn.prepareCall("CALL Dancik_OE_GetPendingHeader(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)

			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				hash = this.buildErrorsHash(rs);
			} else {
				hash = new Hashtable();
				hash.put("header", this.buildHashtable(rs));
				
				// -- Check to see if the total line was loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					final ResultSetMetaData meta = rs.getMetaData(); 
					final int cols = meta.getColumnCount();
					while (rs.next()) {
						hash.put("message_" + rs.getString(2), this.buildHashtable(rs, meta, cols));
					}
					
				}
				
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());
			e.printStackTrace();
			hash = this.buildErrorsHash(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return hash;
	}	

	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject getPendingHeader(String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;

		try {
			cstmt = conn.prepareCall("CALL Dancik_OE_GetPendingHeader(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)

			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				json = new JSONObject();
				json.put("header", this.buildObject(rs));
				
				// -- Check to see if the total line was loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("messages", this.buildArray(rs));
				}
				
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());			
			json = this.buildErrors(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return json;
	}		
	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject deleteLine(String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;
		boolean more = false;

		try {
			cstmt = conn.prepareCall("CALL Dancik_OE_DeletePendingLine(?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); // -- outError (Y)

			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				json = new JSONObject();
				json.put("details", this.buildArray(rs));
					
				// -- Check to see if the total line was loaded...
				more = cstmt.getMoreResults();
				if (more) {
					rs = cstmt.getResultSet();
					json.put("total", this.buildObject(rs));
				}
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());			
			json = this.buildErrors(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return json;
	}
	
	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject newOrder_BilltoSearch(String inUser, String inXMLParams) throws Exception {
		return genericPaginationSearch("Dancik_NewOrder_BilltoSearch", inUser, inXMLParams);
	}
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject newOrder_RetailSearch(String inUser, String inXMLParams) throws Exception {
		return genericPaginationSearch("Dancik_NewOrder_RetailSearch", inUser, inXMLParams);
	}
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject newOrder_CombinedCustomerSearch(String inUser, String inXMLParams) throws Exception {
		return genericPaginationSearch("Dancik_NewOrder_CombinedCustomerSearch", inUser, inXMLParams);
	}
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject pendingOrderSearch(String inUser, String inXMLParams) throws Exception {
		return genericPaginationSearch("Dancik_OE_PendingOrderSearch", inUser, inXMLParams);
	}
	
	// **********************************************************************************************************************
	// *
	// **********************************************************************************************************************
	public JSONObject genericPaginationSearch(String inStoreProcedure, String inUser, String inXMLParams) throws Exception {
		Connection conn = this.getConnection();

		CallableStatement cstmt = null;
		ResultSet rs = null;
		JSONObject json = null;

		try {
			cstmt = conn.prepareCall("CALL " + inStoreProcedure + "(?,?,?,?,?,?,?)");

			cstmt.setString(1, inUser);
			cstmt.setString(2, inXMLParams);

			cstmt.registerOutParameter(3, Types.CHAR); 		// -- outError (Y)
			cstmt.registerOutParameter(4, Types.INTEGER);	// -- Records Read
			cstmt.registerOutParameter(5, Types.INTEGER);	// -- Next Record to be Read...
			cstmt.registerOutParameter(6, Types.INTEGER);	// -- Total Query size
			cstmt.registerOutParameter(7, Types.CHAR);		// -- EOF indicator (Y)

			cstmt.execute();
			rs = cstmt.getResultSet();
			if (cstmt.getString(3).equals("Y")) {
				json = this.buildErrors(rs);
			} else {
				json = new JSONObject();
				json.put("recordsread", cstmt.getInt(4));
				json.put("nextrecord", cstmt.getInt(5));
				json.put("querysize", cstmt.getInt(6));
				json.put("eof", cstmt.getString(7));

				json.put("records", this.buildArray(rs));
			}

		} catch (Exception e) {
			jLogger.error("Exception : " + e.getMessage());			
			json = this.buildErrors(e);
		} finally {
			this.releaseConnection(conn);
			try { if (cstmt != null) { cstmt.close(); cstmt = null; } } catch (Exception e) { }
			try { if (rs != null) { rs.close(); rs = null; } } catch (Exception e) { }
		}

		return json;
	}	
}
