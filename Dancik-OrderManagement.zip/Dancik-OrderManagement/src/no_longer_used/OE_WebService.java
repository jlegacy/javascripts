package no_longer_used;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.dancik.api.xml.XML_Tool;
import com.dancik.om.dao.OrderManager_DAO;
import com.dancik.om.dataobjects.Visit;
import com.dancik.om.webservices.Abstract_WebService;

public class OE_WebService extends Abstract_WebService {
	
	
	
	// * --------------------------------------------------------------------------
	// * @method : deleteLine
	// * --------------------------------------------------------------------------
	public String deleteLine(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		final HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");

		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OE_DAO dao = (OE_DAO) ctx.getBean("oeDAO");

		final JSONObject json = dao.deleteLine(visit.getUserConfig().getUser(), this.buildParamsXML());

		ctx = null;
		dao = null;

		return (json == null) ? "" : json.toString();
	}	
	
	// * --------------------------------------------------------------------------
	// * @method : newOrder_InitialSearch
	// * --------------------------------------------------------------------------
	public String newOrder_InitialSearch(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		final HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");

		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OE_DAO dao = (OE_DAO) ctx.getBean("oeDAO");

		final JSONObject json = dao.newOrder_InitialSearch(visit.getUserConfig().getUser(), this.buildParamsXML());

		ctx = null;
		dao = null;

		return (json == null) ? "" : json.toString();
	}
	// * --------------------------------------------------------------------------
	// * @method : pendingOrderSearch
	// * --------------------------------------------------------------------------
	public String pendingOrderSearch(HttpServletRequest req) throws Exception {
		this.setRequest(req);
		final HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");

		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OE_DAO dao = (OE_DAO) ctx.getBean("oeDAO");

		final JSONObject json = dao.pendingOrderSearch(visit.getUserConfig().getUser(), this.buildForPendingSearch());

		ctx = null;
		dao = null;

		return (json == null) ? "" : json.toString();		
	}
	// * --------------------------------------------------------------------------
	// * @method : newOrder_BilltoSearch
	// * --------------------------------------------------------------------------
	public String newOrder_BilltoSearch(HttpServletRequest req) throws Exception {
		return this.search(req, "Dancik_NewOrder_BilltoSearch");
	}	
	// * --------------------------------------------------------------------------
	// * @method : newOrder_RetailSearch
	// * --------------------------------------------------------------------------
	public String newOrder_RetailSearch(HttpServletRequest req) throws Exception {
		return this.search(req, "Dancik_NewOrder_RetailSearch");
	}	
	// * --------------------------------------------------------------------------
	// * @method : newOrder_CustomerSearch
	// * --------------------------------------------------------------------------
	public String newOrder_CustomerSearch(HttpServletRequest req) throws Exception {
		return this.search(req, "Dancik_NewOrder_CustomerSearch");
	}
	
	// * --------------------------------------------------------------------------
	// * @method : search
	// * --------------------------------------------------------------------------
	private String search(HttpServletRequest req, String inStoredProcedure) throws Exception {
		this.setRequest(req);
		final HttpSession ses = (HttpSession) req.getSession();
		final Visit visit = (Visit)ses.getAttribute("Visit");

		WebApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
		OE_DAO dao = (OE_DAO) ctx.getBean("oeDAO");

		final JSONObject json = dao.genericPaginationSearch(inStoredProcedure, visit.getUserConfig().getUser(), this.buildParamsXML());

		ctx = null;
		dao = null;

		return (json == null) ? "" : json.toString();
	}
	
	
	// * --------------------------------------------------------------------------
	// * @method : buildForPendingSearch
	// * --------------------------------------------------------------------------
	private String buildForPendingSearch() throws Exception {
		Document doc = XML_Tool.buildDocument();
		String paramName = "";
		
		Element params = doc.createElement("params");
	
		// -- Construct non-array elements...	
		Enumeration paramNames = this.getRequest().getParameterNames();
		for (; paramNames.hasMoreElements(); ) {
	        paramName = (String)paramNames.nextElement();
	        if (paramName.indexOf("filter_") == -1) {
		        if (!this.isStringEmpty(paramName)) {
					final Element element = doc.createElement(paramName);
					element.appendChild( doc.createTextNode(this.getString(paramName)) );
					params.appendChild( element );
		        }
	        }
	    }

		
		String[] filter_variables = this.getRequest().getParameterValues("filter_variable");
		if (filter_variables != null) {
			String[] filter_ops = this.getRequest().getParameterValues("filter_op");
			String[] filter_values = this.getRequest().getParameterValues("filter_value");

			Element filters = doc.createElement("parm_Filters");
			int len = filter_variables.length;
			for (int i=0; i<len; i++) {
				final Element filter = doc.createElement("filter");

	    		final Element field = doc.createElement("field");
	    		field.appendChild( doc.createTextNode( filter_variables[i] ) );
	    		filter.appendChild( field );
				
	    		final Element op = doc.createElement("op");
	    		op.appendChild( doc.createTextNode( filter_ops[i] ) );
	    		filter.appendChild( op );
				
	    		final Element value = doc.createElement("value");
	    		value.appendChild( doc.createTextNode( filter_values[i] ) );
	    		filter.appendChild( value );
				
				filters.appendChild(filter);
			}
			params.appendChild( filters );
		}
		
		doc.appendChild( params );
		
		String xml = XML_Tool.toString( doc );
		doc = null;
		
		return xml;
		
	}
}
