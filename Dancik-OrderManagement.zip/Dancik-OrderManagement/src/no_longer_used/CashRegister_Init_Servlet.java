package no_longer_used;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.dancik.api.http.Abstract_HttpServlet_Tool;


public class CashRegister_Init_Servlet extends Abstract_HttpServlet_Tool {

	private final static Logger jLogger = Logger.getLogger(CashRegister_Init_Servlet.class);

	protected void doGet (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		try {

			this.setRequest(req);
			
			
			
			
			
			


			RequestDispatcher rd = null;
			rd = req.getRequestDispatcher("../app-mgr-cashregister/index.jsp");
				
			rd.forward(req, res);
			
		} catch (Exception e) {
			e.printStackTrace();
			jLogger.error("Exception : " + e.getMessage());
		}
		
		finally {
		}
    }
	protected void doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
}

