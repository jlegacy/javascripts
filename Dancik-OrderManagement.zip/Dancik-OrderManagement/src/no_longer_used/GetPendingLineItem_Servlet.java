package no_longer_used;

import java.io.IOException;
import java.util.Hashtable;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import no_longer_used.OE_DAO;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.BeansException;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.dancik.api.http.Abstract_HttpServlet_Tool;
import com.dancik.om.dataobjects.Visit;


public class GetPendingLineItem_Servlet extends Abstract_HttpServlet_Tool {

	private final static Logger jLogger = Logger.getLogger(GetPendingLineItem_Servlet.class);

	private WebApplicationContext ctx = null;
	private OE_DAO dao = null;

	
	protected void doGet (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {

		try {
			this.setRequest(req);
			final HttpSession ses = (HttpSession) req.getSession();
			final Visit visit = (Visit)ses.getAttribute("Visit");

			ctx = WebApplicationContextUtils.getWebApplicationContext(ses.getServletContext());
			dao = (OE_DAO) ctx.getBean("oeDAO");

long start = new java.util.Date().getTime();
			final JSONObject json = dao.getPendingLineItem(visit.getUserConfig().getUser(), this.buildParamsXML());
//			final Hashtable hash = dao.getPendingOrder_ForView(visit.getUserConfig().getUser(), this.buildParamsXML());
			
long end = new java.util.Date().getTime();
System.out.println("GetPendingLineItem_Servlet() Time : " + (end-start));			
			
			req.setAttribute("item", json.toString());
			
			RequestDispatcher rd = req.getRequestDispatcher("../app-oe/lineItem.jsp");
			rd.forward(req, res);
			
			
			
		} catch (BeansException e) {
			e.printStackTrace();
			jLogger.error("Exception : " + e.getMessage());			
		} catch (NumberFormatException e) {
			e.printStackTrace();
			jLogger.error("Exception : " + e.getMessage());
		} catch (Exception e) {
			e.printStackTrace();
			jLogger.error("Exception : " + e.getMessage());
		}
		
		finally {
			ctx = null;
			dao = null;
		}
    }
	protected void doPost (HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		doGet(req, res);
	}
}

