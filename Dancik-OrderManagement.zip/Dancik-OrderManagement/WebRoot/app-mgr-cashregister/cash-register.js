// *******************************************************************************************************
//*******************************************************************************************************
//*******************************************************************************************************
var CashRegister_Popup = Class.create(Dancik_ConfirmWindow, {
	referenceid : '',
	orderid : '',
	payment_ready : false,

	
	// ---------------------------------------------------------------------------------------------------
	// -  intialize
	// ---------------------------------------------------------------------------------------------------
	initialize: function($super, params, opts) {
		// -- Construct 'options'...
		this.popup_options = Object.extend({
			beforeSubmit : null,				// -- Additional function(s) to execute (before) Submit().
			afterSubmit : null					// -- Additional function(s) to execute (after) Submit().
		}, opts || {} );
	
		var _this = this;
		_this.popupid="CashReg_PopupWdw_" + new Date().getTime();
		
		_this.referenceid = params.parm_ReferenceId;
		_this.orderid = params.parm_OrderId;

		
		var h = Dancik.getDocumentHeight()-100;
		var w = 800;
		
		$super(Object.extend({ 
				color : "blue",
				showAsPopup : true,
				popupTitle  : 'Complete Order',
				destroyOnClose : true,
				modal : true,
				message: '<div id="' + _this.popupid + '" class="cash-register" style="width:' + w + 'px;position:relative;"><img src="../../dws/images/loading.gif"/></div>',
				buttons : {},
				onResize : function() { _this.resizeWdw(); }
			}, opts || {})
		);
		
		//MAE 07/11/11 Open CR screen with busy indicator before loading 
		var template = new EJS({url: '../app-mgr-cashregister/register.ejs'});
		$(_this.popupid).update(template.render({
				popupid: _this.popupid,
				order: {},
				config: {},
				paymethods: [],
				details: []
			})
		);
		_this.open();
		_this.resize();
		jQuery("#" + _this.popupid).dancikBusy();
		
		
		Validation.add('num7_2neg','%T format is (-)9999999.99.',{
			pattern: /^-?(\d{0,7}|\d{0,7}\.\d{0,2})$/
		})
		
		
		var model = new Dancik_Model('../api/cash-reg/init');
 		model.get( params , function(is_success, json) {	
 			
 			try{
				if (json == null) { return; }
				// -- If errors are returned, then display and exit...
				if (json.errors != null) {
					var html = []; json.errors.each( function(o) { html.push("<li> - " + o.errmsg + "</li>") } );
					new Dancik_ConfirmWindow({ 
						color : "red",
						showAsInfoOnly : true,
						modal : true,
						destroyOnClose : true,
						zIndexModal : 11000,
						contentHTML : "The following errors occurred:",
						extraContentHTML : '<ul class="error-list">' + html.join('') + '</ul>'
					}).open();
					_this.close();
					return;
				}
				
				// -- Save the retrieved cash register configuration settings, for later use...
				_this.crConfig = json.config || {};
				// -- Save the retrieved payment methods, for later use...
				_this.paymentMethods = json.paymethods || {};
				// -- Save the retrieved order information, for later use...
				_this.order = json.order || {};

				// -- Render screen
				var template = new EJS({url: '../app-mgr-cashregister/register.ejs'});
				$(_this.popupid).update( template.render(Object.extend(json,{ 
					popupid : _this.popupid
				})) );
				
				Event.observe(_this.popupid + '_paymethod', 'change', _this.togglePayments.bindAsEventListener(_this));
				
				Event.observe(_this.popupid + '_Bttn_Continue', 'click', _this.continueEndOfOrder.bindAsEventListener(_this));
				if (json.order.terms_code_description =="C.O.D."){
					$('terms_field').toggleClassName('terms-field2');
				}
				this.validator = new Validation(_this.popupid + '_Form',{
					onValidSubmit: function(event){ 
							event.stop();
							_this.applyPayment(); 
						},
					fieldNames: {
						paymethod : "Payment Method",
						payment_amount: "Payment",
						received_amount: "Received Amount"
					},
					errorMessages : {
						paymethod : {
								required : "Payment Method is required."
						}
					},
					errorMessageKeys: {
						payment_amount: {
							num7_2neg: "format7_2neg"
						},
						received_amount: {
							num7_2neg: "format7_2neg"
						}
					}
				});				
				
				
				_this.resize();

 			} catch(e) {
 				_this.throwAjaxError('initialize', e);
 			}
		});		
	},
	// ---------------------------------------------------------------------------------------------------
	// -  applyPayment
	// ---------------------------------------------------------------------------------------------------
	applyPayment: function(event) {
		var _this = this;
		var params = $(this.popupid + '_Form').serialize(true);
		
		$(this.popupid + '_SubmitBttns').hide();
		$(this.popupid + '_WaitImg').show();
		
		var model = new Dancik_Model('../api/cash-reg/applypayment');
 		model.get( params , function(is_success, json) {	
 			try{
 				
 				$(_this.popupid + '_SubmitBttns').show();
 				$(_this.popupid + '_WaitImg').hide();
 				
 				
				if (json == null) { return; }
				// -- If errors are returned, then display and exit...
				if (json.errors != null) {
					var html = []; json.errors.each( function(o) { html.push("<li> - " + o.errmsg + "</li>") } );
					new Dancik_ConfirmWindow({ 
						color : "red",
						showAsInfoOnly : true,
						modal : true,
						destroyOnClose : true,
						zIndexModal : 11000,
						contentHTML : "The following errors occurred:",
						extraContentHTML : '<ul class="error-list">' + html.join('') + '</ul>'
					}).open();
					return;
				}
				// -- Save the retrieved order information, for later use...
				_this.order = json.order || {};
				
				var totalsTemplate = new EJS({url: '../app-mgr-cashregister/totals.ejs'});
				$(_this.popupid + '_Totals').update( totalsTemplate.render(Object.extend(json,{ 
					popupid : _this.popupid,
					config : _this.crConfig
				})) );

				var paymentsTemplate = new EJS({url: '../app-mgr-cashregister/payments.ejs'});
				$(_this.popupid + '_Payments').update( paymentsTemplate.render(Object.extend(json,{ popupid : _this.popupid })) );
				
				// -- Reset 'Payment' fields...
				$(_this.popupid + '_Form').select('input[type="text"]').each(function(o) {
					o.value = '';
				});
				
				$(_this.popupid + '_Form').select('select').each(function(o) {
					 Dancik.Select.resetSelected(o);
					 
				});				
				$(_this.popupid + '_Form').select('.cr-entry').each(function(o) {
					o.hide();
				});				

				// -- Load hidden fields, with new calculations
				if ( json.change ) {
					var changeObj = json.change; 
					if ( changeObj.cash_received > 0 ) {
						var changeTemplate = new EJS({url: '../app-mgr-cashregister/session_totals.ejs'});
						$(_this.popupid + '_SessionTotals').update( changeTemplate.render(changeObj) );
					}
					$(_this.popupid + '_session_cashreceived').value = changeObj.cash_received;
					$(_this.popupid + '_session_paymentsreceived').value = changeObj.paid_received;
					$(_this.popupid + '_session_changedue').value = changeObj.change_due;
				}
				
				_this.resize();      

				if (Prototype.Browser.IE) {
					$(_this.popupid + '_paymentsection').hide();
					$(_this.popupid + '_paymentsection').show();
				}
				$(_this.popupid + '_paymethod').activate();
				
				
 			} catch(e) {
 				_this.throwAjaxError('applyPayment', e.message);
 			}
		});		
	},
	// ---------------------------------------------------------------------------------------------------
	// -  continueEndOfOrder
	// ---------------------------------------------------------------------------------------------------
	continueEndOfOrder: function(event) {
		var _this = this;
		var params = $(_this.popupid + '_Form').serialize(true);
		
		// -- Make sure a payment is not lingering, before "continueing"...
		if (params['paymethod'].strip() != '') {
			new Dancik_ConfirmWindow({
				contentHTML : $M("om.lingeringPayment"), 
				extraContentHTML : $M("om.lingeringPaymentDetails"),
				showAsInfoOnly: true,
				modal:true
			}).open();
			
			return;		
		}
		
		
		var model = new Dancik_Model('../api/cash-reg/continue');
 		model.get( params , function(is_success, json) {	
 			try{
				if (json == null) { return; }
				// -- If errors are returned, then display and exit...
				if (json.errors != null) {
					var html = []; json.errors.each( function(o) { html.push("<li> - " + o.errmsg + "</li>") } );
					new Dancik_ConfirmWindow({ 
						color : "red",
						showAsInfoOnly : true,
						modal : true,
						destroyOnClose : true,
						zIndexModal : 11000,
						contentHTML : "The following errors occurred:",
						extraContentHTML : '<ul class="error-list">' + html.join('') + '</ul>'
					}).open();
					return;
				}

				// -- If attention messages are returned, then display, before continuing...
				if (json.attention != null) {
					var html = []; json.attention.each( function(o) { html.push("<li> - " + o.message + "</li>") } );
					
					new Dancik_ConfirmWindow({
						destroyOnClose:true,
						showAsInfoOnly:true,
						content: html.join(''),
						modal:true,
						color:"yellow",
						onConfirm: function(){ _this.printOptions(); }
					}).open();
				} else {
					_this.printOptions();
				}		
				
		} catch(e) {
			_this.throwAjaxError('continueEndOfOrder', e.message);
		}
	}); 			
		
	},
	// ---------------------------------------------------------------------------------------------------
	// -  printOptions
	// ---------------------------------------------------------------------------------------------------
	printOptions: function(event) {
		var _this = this;
		
		new PrintOrderOptions_Popup({ 
			parm_referenceid : _this.referenceid, 
			parm_orderid : _this.orderid || 0,
			forUnprocessedOrder : (_this.orderid == null) 
		}, {
			zIndexModal : 11000,
			returnToOrderFunction : function() {
				_this.close();
			},
			afterSubmit : function() {
				_this.afterSubmit();
			}							
		});		
	},
	// ---------------------------------------------------------------------------------------------------
	// -  printOptions
	// ---------------------------------------------------------------------------------------------------
	afterSubmit: function(event) {
		var _this = this;
		if (_this.popup_options.afterSubmit) {
			_this.popup_options.afterSubmit();
		}
	},
	// ---------------------------------------------------------------------------------------------------
	// -  togglePayments
	// ---------------------------------------------------------------------------------------------------
	togglePayments: function(event) {
		$(this.popupid + '_Form').select('.cr-entry').each(function(o) {
				o.hide();
		});
		
		// -- Pull the Payment Method selection...
		var pm = $F(this.popupid + '_paymethod');
		var i = this.paymentMethods.pluck("id").indexOf(pm);
		// -- If selection does not exists, then stop toggle...
		if (i === -1) { return; }

		// -- Show the Button...
		$(this.popupid + '_Bttn_ApplyPayment').show();
		$(this.popupid + '_Bttn_ClearPayment').show();
		
		// -- Pull the array element...
		var payMethod = this.paymentMethods[i];
		// -- If Credit Card / Check is required....
		if ( payMethod.cc_check_required == 'Y' ) {
			$(this.popupid + '_cardnumber_block').show();
			$(this.popupid + '_rcvdamount').value = "";
			// -- If a Check type method, then change the label accordingly...
			if ( payMethod.check_method == 'Y' ) {
				$(this.popupid + '_Label_CardNumber').update( 'Check Number:' );
			} else {
				$(this.popupid + '_Label_CardNumber').update( 'Card Number:' );
			}
		}
		// -- If Expiration Date is required....
		if ( payMethod.expiration_date_required == 'Y' ) {
			$(this.popupid + '_expirationdate_block').show();
			$(this.popupid + '_rcvdamount').value = "";
		}
		// -- If Other Reference is required....
		if ( payMethod.other_reference_required == 'Y' ) {
			$(this.popupid + '_otherreference_block').show();
			$(this.popupid + '_rcvdamount').value = "";
		}
		// -- If Approval Code is required....
		if ( payMethod.approval_code_required == 'Y' ) {
			$(this.popupid + '_approvalcode_block').show();
			$(this.popupid + '_rcvdamount').value = "";
		}
		// -- If PayMethod is NOT a Non-Payment method or if it's a (expiration date required)...
		if ( (payMethod.non_payment != 'Y') && (payMethod.expiration_date_required != 'Y') ) {
			$(this.popupid + '_rcvdamount_block').show();
		}
		
		// -- Amount is automatically entered when using this code?
		if ( payMethod.amount_auto_entered == 'Y' ) {
			$(this.popupid + '_payment_amount').set( this.order.balance_due_notformatted );
			if ( payMethod.expiration_date_required != 'Y')  {
				$(this.popupid + '_rcvdamount').set( this.order.balance_due_notformatted );
			}
		}
	},

	// ---------------------------------------------------------------------------------------------------
	// -  resizeWdw
	// ---------------------------------------------------------------------------------------------------
	resizeWdw: function() {
		var _this = this;
		
		if ( !$(_this.popupid + '_PaymentsTable') ) { return; };
		
		var viewH = Dancik.getDocumentHeight()-100; // 100 for possible margin loss
		var availableH = ( viewH - 360 ) - Element.getHeight(_this.popupid + '_SessionTotals'); // 360 for used space in window
		var tableH = Element.getHeight(_this.popupid + '_PaymentsTable');
		
		if ( tableH < availableH) {
			Element.setStyle(_this.popupid + '_PaymentsDiv', {height: tableH+'px'});
		} else if ( availableH < 100) {  // min-height
			if ( tableH < 100) {
				Element.setStyle(_this.popupid + '_PaymentsDiv', {height: tableH+'px'});
			} else {
				Element.setStyle(_this.popupid + '_PaymentsDiv', {height: '100px'});
			}
		} else {
			Element.setStyle(_this.popupid + '_PaymentsDiv', {height: availableH+'px'}); 
		}
	},

	// ---------------------------------------------------------------------------------------------------
	// -  throwAjaxError
	// ---------------------------------------------------------------------------------------------------
	throwAjaxError: function(from, e) {
		new Dancik_ConfirmWindow({ 
			color : "red",
			showAsInfoOnly : true,
			modal : true,
			destroyOnClose : true,
			zIndexModal : 11000,
			contentHTML : "The following error occurred in CashRegister_Popup." + from + '() :',
			extraContentHTML :  '<ul class="error-list"><li>' + e.message + '</li></ul>'
		}).open();
	}
});