//******************************************************************************
//	Class : OM_PopupWindow
//******************************************************************************
var OM_PopupWindow = Class.create({
	o : null,

	initialize : function(opts) {
		// -- Construct 'options'...
		this.options = Object.extend({
				style : {zIndex:10},	// -- Style overrides for the window object.
				title : '',				// -- Sets the Title area.
				avoidTopBar : false,	// -- When true, avoids rendering the Title and Close bttn. (Will probably be loaded in IFRAME.)
				beforeClose : null,		// -- Additional function(s) to execute (before) onClose().
				afterClose : null,		// -- Additional function(s) to execute (after) onClose().
				destroyOnClose : false,	// -- Destroy(remove) window object from <body> onClose().
				beforeOpen : null,		// -- Additional function(s) to execute (before) open().
				afterOpen : null,		// -- Additional function(s) to execute (after) open().
				content : null,			// -- Sets the main content (object).
				contentHTML : '',		// -- Sets the main content (html).  This is the default if 'content' is null.
				modal: false,			// -- put up a div behind the message to require users to confirm before proceeding.
				useAsSmallWdw: false	// -- When true, will use a SMALL-Border window.
			}, opts || {} );
		this.id="omPopupWdw_" + new Date().getTime();
	
		
		// -- Begin writing contents...
		var html = [];
		
		// -- Construct the main (window) element...
		html.push('<div class="om-Popup' + (this.options.useAsSmallWdw ? '-SM' : '') + '" id="' + this.id + '" style="display:none;">');
		
		html.push("<table id='" + this.id + "_Table' class='om-Popup-Table' cellpadding='0' cellspacing='0'>");
			html.push("<tbody>");
				// -- Top bar...
				html.push("<tr>");
					html.push("<td class='om-Popup-Table-TopLeft om-flashable'></td>");
					html.push("<td class='om-Popup-Table-TopCenter om-flashable'>&nbsp;</td>");
					html.push("<td class='om-Popup-Table-TopRight om-flashable'></td>");
				html.push("</tr>");
				// -- Middle
				html.push("<tr>");
					html.push("<td class='om-Popup-Table-MiddleLeft om-flashable'></td>");
					html.push("<td class='om-Popup-Table-MiddleCenter'>");
						if (!this.options.avoidTopBar) {
							html.push("<div id='" + this.id + "_Title' class='om-Popup-Title'>" + this.options.title + "</div>");
							html.push("<div id='" + this.id + "_Close' class='om-Popup-Close'>");
								html.push("<img src='../../dws/images/close.png' class='hand' title='Close'/>");
							html.push("</div>");
						}
						html.push("<div id='" + this.id + "_Content' class='om-Popup-Content'></div>");
					html.push("</td>");
					html.push("<td class='om-Popup-Table-MiddleRight om-flashable'></td>");
				html.push("</tr>");
		
				// -- Bottom bar...
				html.push("<tr>");
					html.push("<td class='om-Popup-Table-BottomLeft om-flashable'></td>");
					html.push("<td class='om-Popup-Table-BottomCenter om-flashable'>&nbsp;</td>");
					html.push("<td class='om-Popup-Table-BottomRight om-flashable'></td>");
				html.push("</tr>");
			html.push("</tbody>");
		html.push("</table>");
		// -- Close the main (window) element...
		html.push("</div>");
		
		// -- Put in document
		$(document.body).insert(html.join(""));
		
		
		// -- Get element
		this.o = $(this.id);
		
		// -- Set content - hear instead of in array so content can be an element
		if(this.options.content) {
			this.setContent(this.options.content);
		} else {
			this.setContentHTML(this.options.contentHTML);
		}
		
		// -- Set the style...
		this.setStyle(this.options.style);
		if(this.options.style) {
			if(this.options.style.width || (typeof(this.options.style)=="string" && this.options.style.include("width"))) {
				$(this.id+"_Table").setStyle({width:"100%"});
			}
		}
		if (!this.options.avoidTopBar) {
			Event.observe($(this.id+"_Close"), "click", this.close.bindAsEventListener(this));
		}
	},
	open: function() {
		this.notify("beforeOpen");
		this.openModal();
		this.centerWindow();
		this.show();
		this.notify("afterOpen");
	},
	centerWindow: function() {
		Dancik.centerElementViaDocument(this.o);
	},
	openModal: function() {
		if(this.options.modal) {
			this.o.insert({after:'<div id="' + this.id + '_modal" class="om-Modal"></div>'});
			this.o.setStyle({zIndex:1000});
			Event.observe(this.id+"_modal","click",this.flash.bindAsEventListener(this));
		}
	},
	closeModal: function() {
		if ($(this.id+"_modal")) {
			$(this.id+"_modal").remove();
		}
	},
	setTitle: function(title) {
		if ($(this.id+"_Title")) {
			$(this.id+"_Title").update(title);
		}
	},
	setContent: function(element) {
		if(typeof(element)=="string") {
			this.setContentHTML(element);
		} else {
			$(this.id + '_Content').update();
			$(this.id + '_Content').appendChild(element);
		}
	},
	setContentHTML: function(html) {
		$(this.id + '_Content').update( html );
	},
	show: function() {
		this.o.show();
	},
	visible: function() {
		return Element.visible(this.o);
	},
	close: function() {
		if ( !this.o ) {
			return;
		}
		this.notify("beforeClose");
		this.o.hide();
		this.closeModal();
		if (this.options.destroyOnClose) {
			document.body.removeChild( this.o );
			this.o = null;
		}
		this.notify("afterClose");
	},
	setStyle : function(options) {
		if (this.o === null) { return; }
		if (!options) { return; }
		Element.setStyle( this.o, options );
	},
	notify: function(event) {
		if(typeof(this.options[event])=="function") {
			this.options[event](this);
		}
	},
	flash: function() {
		this.flashCount = 3;
		this._flash();
	},
	_flash: function() {
		if(this.flashCount>0) {
			this.o.addClassName("om-flash");
			this._unflash.bindAsEventListener(this).delay(.1);
			this.flashCount--;
		}
	},
	_unflash: function() {
		this.o.removeClassName("om-flash");
		if(this.flashCount>0) {
			this._flash.bindAsEventListener(this).delay(.1);
		}
	}
});
