var OM_Main = {
	ajax : null,
	errorWdw : null,
	hdrWdw : null,
	optionsWdw : null,

	// -------------------------------------------------------------------------------
	// -- Build the necessary internal objects...
	// -------------------------------------------------------------------------------
	setSettings : function(settings) {
		if (this.settings) {
			this.settings = Object.extend(this.settings, settings || {} );
		} else {
			this.settings = Object.extend({
				allow_to_enterorders : 'N',
				allow_to_enterdirectships : 'N',
				allow_to_enterpurchaseorders : 'N',
				allow_to_viewcosts : 'N',
                                multi_unit_customer: 'N',
				use_jobestimates : 'N',
				use_rollover : 'N',
				editMode : false
			}, settings || {} );
		}
	},
	// -------------------------------------------------------------------------------
	// -- Build the necessary internal objects...
	// -------------------------------------------------------------------------------
	open_ErrorWdw : function(opts) {
		new Dancik_ConfirmWindow(Object.extend({ 
			color : "red",
			showAsInfoOnly : true,
			modal : true,
			destroyOnClose : true
		}, opts || {})).open();
	},

	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------
	// ---------------------------------------------------------------------------------------------------
	build_OptionsWdw : function () {
		// -- Check to see if it already exists...
		if (Main.optionsWdw) { return; }
		
		Main.optionsWdw = new Dancik_OptionsWindow({ 
			style : 'width:175px;',
			title : 'Available Options'
		});
	},
	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.openHeaderWdw()
	// - Parameter	 : { (req)in_referenceid, in_orderid, parm_AccessMode}
	// --------------------------------------------------------------------------------------------------- 
	openHeaderWdw: function(params, opts) {
		var h = Dancik.getDocumentHeight()-100;
		var w = ((Dancik.getDocumentWidth()-75) > 950) ? 950 : (Dancik.getDocumentWidth()-75);
		this.hdrWdw = new Dancik_ConfirmWindow(Object.extend({
			color : "blue",
			showAsPopup : true,
			message : '',
			buttons : {},
			modal : true,
			destroyOnClose : true,
			extraContentHTML : '<iframe src="../app-mgr/header.jsp?' + Object.toQueryString(params) + '" frameborder="0" width="' + (w) + 'px" height="' + (h) + '"px;></iframe>'
		}, opts || {}));
		this.hdrWdw.open();
	},	
	// ***********************************************************************************************
	//	*.AddOns 
	// ***********************************************************************************************
	AddOns : {
	
		// -------------------------------------------------------------------------------
		// -- Main.AddOns.jobEstimating()
		// -------------------------------------------------------------------------------
		jobEstimating : function(in_ReferenceId) {
			// -- Construct window...
			var h = 225;
			var w = 435;
			
			var params = {reference : in_ReferenceId}
			var url = '../app-mgr-addons/jobest.jsp?' + Object.toQueryString(params);
			
			new Dancik_ConfirmWindow({
				color : "blue",
				showAsPopup : true,
				popupTitle : 'Job Estimating',
				destroyOnClose : true,
				modal : true,
				message : '<iframe src="' + url + '" frameborder="0" width="' + w + 'px" height="' + h + 'px;"></iframe>',
				buttons : {}
			}).open();
		},		
		// -------------------------------------------------------------------------------
		// -- Main.AddOns.orderReview()
		// -------------------------------------------------------------------------------
		orderReview : function(in_ReferenceId, in_OrderId) {
			// -- Construct window...
			var h = Dancik.getDocumentHeight()-100;
			var w = Dancik.getDocumentWidth()-50;
			
			var params = {parm_ReferenceId : in_ReferenceId, parm_OrderId : (in_OrderId || '') };
			var url = '../app-mgr-addons/orderReview.jsp?' + Object.toQueryString(params);
			
			new Dancik_ConfirmWindow({
				color : "blue",
				showAsPopup : true,
				popupTitle : 'Order Review',
				destroyOnClose : true,
				modal : true,
				message : '<iframe src="' + url + '" frameborder="0" width="' + (w) + 'px" height="' + (h) + 'px;"></iframe>',
				buttons : {}
			}).open();
		},	
		// -------------------------------------------------------------------------------
		// -- Main.AddOns.installationScheduler()
		// -------------------------------------------------------------------------------
		installationScheduler : function(in_ReferenceId, in_OrderId) {
			// -- Construct window...
			var h = ( (Dancik.getDocumentHeight()-100) >= 500 ) ? 500 : (Dancik.getDocumentHeight()-100);
			var w = ( (Dancik.getDocumentWidth()-50) >= 950 ) ? 950 : (Dancik.getDocumentWidth()-50);
			
			var params = {parm_ReferenceId : in_ReferenceId, parm_OrderId : (in_OrderId || '') };
			var url = '../app-mgr-addons/installationScheduler.jsp?' + Object.toQueryString(params);
			
			new Dancik_ConfirmWindow({
				color : "blue",
				showAsPopup : true,
				popupTitle : 'Installation Scheduler',
				destroyOnClose : true,
				modal : true,
				message : '<iframe src="' + url + '" frameborder="0" width="' + (w) + 'px" height="' + (h) + 'px;"></iframe>',
				buttons : {}
			}).open();
		}
	},
	// *******************************************************************************
	// * Main.Validate Object...
	// *******************************************************************************
	Validate : {
		// -- Main.Validate.isDate() 
		isDate: function(mm, dd, yyyy) {
			var d = new Date(mm + "/" + dd + "/" + yyyy);
			return d.getMonth() + 1 == mm && d.getDate() == dd && d.getFullYear() == yyyy;
		},
				
		// -- Main.Validate.isDateValid() 
		isDateValid: function(mmddyy) {
			var parts = mmddyy.split("/");
			if (parseInt(parts[2]) < 31) {
				parts[2] = '20' + parts[2];
			} else {
				parts[2] = '19' + parts[2];
			}
			if (!Main.Validate.isDate(parts[0], parts[1], parts[2])) {
				return false;
			}
			
			return true;
		}		
	}
}