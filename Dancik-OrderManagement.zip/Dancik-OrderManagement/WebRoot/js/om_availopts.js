
//******************************************************************************
//	Class : OM_AvailableOptions
//******************************************************************************
var OM_AvailableOptions = Class.create();
OM_AvailableOptions.prototype = {
	funcs : [],
	// -------------------------------------------------------------------------------
	initialize : function(opts) {
		// -- Construct 'options'...
		this.options = Object.extend({
			style : {zIndex:2},	// -- Style overrides for the window object.
			title : 'Available Options',
			onClick : null,
			parentElement : null
			}, opts || {} );
		this.id = "omAvailOptions_" + new Date().getTime();

		// -- Begin writing contents...
		var html = [];
		
		// -- Construct the main (window) element...
		html.push("<div id='" + this.id + "' class='AvailableOptions dws-mouseover1'>");
			html.push("<div id='" + this.id + "_Title'>")
				html.push("<div class='AvailableOptions_Title'>" + this.options.title + "</div>")
			html.push("</div>")
			html.push("<div class='AvailableOptions_OptionsWdw' id='" + this.id + "_Window' style='display:none; top:23px; left:28px;'>");
				html.push("<table width='100%' cellpadding='0' cellspacing='0'>")
					html.push("<tbody id='" + this.id + "_tbody'></tbody>")
				html.push("</table>")
			html.push("</div>")
		html.push("</div>")
		
		// -- Put in document
		if (this.options.parentElement) {
			$(this.options.parentElement).insert(html.join(""));
		} else {
			$(document.body).insert(html.join(""));
		}
				
		Element.setStyle($(this.id), this.options.style);
		
		var _this = this; 		
		Event.observe($(this.id + '_Title'), "click", this.open.bindAsEventListener(this));
		
		Element.show(this.id);
	},
	// -------------------------------------------------------------------------------
	open: function(event) {
		var _this = this;
		document.onmousedown = function(e) { _this.mousedown(e) };
		Element.show(this.id + '_Window');
	},
	// -------------------------------------------------------------------------------
	close: function() {
		Element.hide(this.id + '_Window');
		document.onmousedown = null;
	},
	// -------------------------------------------------------------------------------
 	clearOptions: function() {
		$(this.id + '_tbody').update();
		this.funcs.clear();
	},
	// -------------------------------------------------------------------------------
 	addOption: function(opts) {
		var _this = this;
		// -- Construct 'options'...
		var options = Object.extend({
			icon: "../images/clear.gif",	// -- Sets the options icon src
			title: "",						// -- Sets the option title
			onClick : null,					// -- Sets the onClick function
			addSeperator : false			// -- Writes a seperator (border) to the top of the row.
		}, opts || {} );
 		
		var cls = options.addSeperator ? 'seperator' : '';
		
		var i = this.funcs.length;
		var element =
			Builder.node("tr", { className : cls },
				Builder.node("td", 
					Builder.node("div", { className : 'dws-OptsRow om-OptsRow dws-mouseover1' }, [
						Builder.node("div", { className : 'dws-OptsIcon om-OptsIcon' },
							Builder.node("img", { src : options.icon, style : 'margin-top:2px;' } )
						),
						Builder.node("div", { className : 'dws-OptsDtl om-Opts' }, options.title)
					])
				)
			);
		
		Event.observe(element, "click", function() { _this.close(); options.onClick(); } );
		$(this.id + '_tbody').appendChild( element );
 	},

	// -------------------------------------------------------------------------------
	mousedown: function(e) {
		var e = e ? e : window.event;
		
		// -- Determine the clicked (x,y) position.
		var x = Event.pointerX(e);
		var y = Event.pointerY(e);
		
        var topleft = Element.cumulativeOffset( $(this.id + '_Window') );
        var bottomright = [
            topleft[0] +  $(this.id + '_Window').offsetWidth,
            topleft[1] +  $(this.id + '_Window').offsetHeight
        ];
        
        // -- If not within (false), then close window...
	    if ( ((y >= topleft[1])  &&  (y <  bottomright[1])  &&  (x >= topleft[0])  &&  (x <  bottomright[0])) == false ) {
    		this.close();
   		}
	}
}
