// *******************************************************************************************************
//*******************************************************************************************************
//*******************************************************************************************************
var OrderShipto_Popup = Class.create(Dancik_ConfirmWindow, {
     initialize: function ($super, params, opts) {
          // -- Construct 'options'...
          this.popup_options = Object.extend({
               beforeUpdate: null, // -- Additional function(s) to execute (before) update().
               afterUpdate: null						// -- Additional function(s) to execute (after) update().
          }, opts || {});


          var _this = this;
          this.popupid = "ordShpToPopupWdw_" + new Date().getTime();

          var h = Dancik.getDocumentHeight() - 100;
          var w = Dancik.getDocumentWidth() - 50;


          $super(Object.extend({
               color: "blue",
               showAsPopup: true,
               popupTitle: 'ShipTo Address',
               destroyOnClose: true,
               modal: true,
               message: '<div class="OrderShipto_Popup" id="OrderShipto_Popup_' + this.popupid + '" style="height:' + h + 'px;"></div>',
               buttons: {}
          }, opts || {})
                  );

          parent.$App.Fire('overlay', 'Retrieving Records');

          this.model = new Dancik_Model('../jsonservice/OM_WebService/execute');
          this.model.get(Object.extend({
               serviceid: 'addons',
               option: 'getAvailableShipTo',
               random: new Date().getTime()
          }, params || {}),
                  function (is_success, json) {
                       try {


                            json = Object.extend(json, {id: _this.popupid});
                            var template = new EJS({url: '../app-mgr-addons/shipto.ejs'});
                            $('OrderShipto_Popup_' + _this.popupid).update(template.render(json));

                            Event.observe('OrderShipTo_Query_' + _this.popupid, "keyup", _this.query.bindAsEventListener(_this));

                            Element.select($(_this.popupid + '_Form'), 'div.box').each(function (o) {
                                 Event.observe(o, 'click', _this.adjustSelections.bindAsEventListener(_this));
                            });

                            // -- Prepare Field Restricter/Formatter...
                            var frm = new RestrictedInputForm($(_this.popupid + '_Form'));

                            // -- Build validator...
                            var testValidator = new Validation($(_this.popupid + '_Form'), {
                                 onValidSubmit: function (event) {
                                      event.stop();
                                      _this.submit();

                                 },
                                 errorMessages: {
                                      parm_shipto_manual_phone1_a: {validateDigits: "Only numbers are allowed in field Phone1."},
                                      parm_shipto_manual_phone1_b: {validateDigits: "Only numbers are allowed in field Phone1."},
                                      parm_shipto_manual_phone1_c: {validateDigits: "Only numbers are allowed in field Phone1."},
                                      parm_shipto_manual_phone2_a: {validateDigits: "Only numbers are allowed in field Phone2."},
                                      parm_shipto_manual_phone2_b: {validateDigits: "Only numbers are allowed in field Phone2."},
                                      parm_shipto_manual_phone2_c: {validateDigits: "Only numbers are allowed in field Phone2."}
                                 }
                            });
                            _this.getDeliveryDate(params);
                       } catch (e) {
                            alert(e.message);
                       }
                  });
     },
     submit: function (event) {
          var _this = this;
          // -- At least one selection can be made to submit update...		
          if ($$(this.popupid + '_Form', 'input[type="radio"]:checked').length == 0) {
               return;
          }
          ;

          if (_this.popup_options.beforeUpdate) {
               _this.popup_options.beforeUpdate();
          }

          this.model.update(Object.extend(Form.serialize(this.popupid + '_Form', true), {
               serviceid: 'addons',
               option: 'updateShipTo',
               random: new Date().getTime()
          }), function (is_success, json) {
               try {

                    if (json.errors) {
                         var html = [];
                         json.errors.each(function (msg) {
                              html.push("<li> - " + msg + "</li>")
                         });

                         new Dancik_ConfirmWindow({
                              color: "red",
                              showAsInfoOnly: true,
                              modal: true,
                              destroyOnClose: true,
                              contentHTML: "The following errors occurred:",
                              extraContentHTML: '<ul class="error-list">' + html.join('') + '</ul>'
                         }).open();
                    } else if (json.alerts) {

                         // -- Reload new values, if passed...
                         if (json.newvalues) {
                              $('parm_shipto_manual_city').value = json.newvalues.city;
                              $('parm_shipto_manual_state').value = json.newvalues.state;
                         }

                         // -- Load the alert message...
                         var html = [];
                         json.alerts.each(function (m) {
                              html.push(m.errmsg)
                         });

                         new Dancik_ConfirmWindow({
                              color: "yellow",
                              showAsPopup: true,
                              popupTitle: '',
                              modal: true,
                              destroyOnClose: true,
                              message: '<div style="padding:15px;">' + html.join('') + '</div>',
                              zIndexModal: 11000,
                              buttons: {}
                         }).open();

                    } else {

                         var deliveryUpdate = {
                              OM_referenceId: $j("#delivery_referenceID").val(),
                              OM_OrderId: $j("#delivery_orderID").val(),
                              OM_ShipVia: $j("#parm_shipviaid").val(),
                              OM_TruckRoute: $j("#parm_truckrouteid").val(),
                              OM_Stop: $j("#parm_truckstopid").val(),
                              OM_Run: $j("#parm_truckrunid").val(),
                              window: _this
                         };
                         $App.Fire("update_delivery", deliveryUpdate);
                         //update delivery info
                         setTimeout(function () {
                              if (_this.popup_options.afterUpdate) {
                                   _this.popup_options.afterUpdate();
                              }
                         }, 1000);



                         //_this.close();
                    }
               } catch (e) {
                    alert(e.message);
               }
          });
     },
     adjustSelections: function (event) {
          var element = Event.element(event);
          var box = element.hasClassName("box") ? element : element.up(".box");
          if (box.hasClassName("selected")) {
               return;
          }

          $$(this.popupid + '_Form', 'div.box.selected').invoke("removeClassName", "selected");
          box.addClassName("selected");
          box.down("input").checked = true;
     },
     query: function (event) {
          var element = event.element();
          var v = $F(element).toUpperCase().trim();

          var parts = $("extraAddresses" + this.popupid).select(".box").partition(function (o) {
               return o.innerHTML.indexOf(v) >= 0 || v.blank();
          })
          parts[0].invoke("show");
          parts[1].invoke("hide");
     }
     ,
     getDeliveryDate: function (params) {
          this.model1 = new Dancik_Model('../jsonservice/OM_WebService/execute');
          this.model1.get(Object.extend({
               option: 'getOrderDates',
               parm_Ord: params.parm_orderid,
               parm_Ref: params.parm_referenceid,
               serviceid: 'addons'
          }, params || {}),
                  function (is_sucess, json1) {
                       try {
//			 		if (!json1) { throw 'EmptyResult'; }
//			 		if ( json1.errors != null) { throw 'ErrorCaught'; }
                            //_this.shiptoPopup($super, params, opts, json1);
                            //	Main.render(json);
                            $j("#parm_truckrouteid").val(json1.global.omtrrt);
                            $j("#parm_shipviaid").val(json1.global.omshpvia);
                            $j("#parm_truckstopid").val(json1.global.omstop);
                            $j("#parm_truckrunid").val(json1.global.omrun);
                            $j("#header_warehouse").html(json1.header.omhdrwhs)
                            $j("#to_city").html(json1.global.omcity);
                            $j("#requested_date").html(json1.global.omshdt);
                            $j("#delivery_referenceID").val(json1.header.omordprm);
                            $j("#delivery_orderID").val(json1.header.omord);

                            if (json1.global.omhl1 == "Y") {
                                 $j("#omhl1").addClass("bold");
                            }
                            if (json1.global.omhl2 == "Y") {
                                 $j("#omhl2").addClass("bold");
                            }
                            if (json1.global.omhl3 == "Y") {
                                 $j("#omhl3").addClass("bold");
                            }
                            if (json1.global.omhl4 == "Y") {
                                 $j("#omhl4").addClass("bold");
                            }
                            if (json1.global.omhl5 == "Y") {
                                 $j("#omhl5").addClass("bold");
                            }
                            if (json1.global.omhl6 == "Y") {
                                 $j("#omhl6").addClass("bold");
                            }
                            if (json1.global.omhl7 == "Y") {
                                 $j("#omhl7").addClass("bold");
                            }
                            if (json1.global.omhl1_r == "Y") {
                                 $j("#omhl1").addClass("nextavailable");
                            }
                            if (json1.global.omhl2_r == "Y") {
                                 $j("#omhl2").addClass("nextavailable");
                            }
                            if (json1.global.omhl3_r == "Y") {
                                 $j("#omhl3").addClass("nextavailable");
                            }
                            if (json1.global.omhl4_r == "Y") {
                                 $j("#omhl4").addClass("nextavailable");
                            }
                            if (json1.global.omhl5_r == "Y") {
                                 $j("#omhl5").addClass("nextavailable");
                            }
                            if (json1.global.omhl6_r == "Y") {
                                 $j("#omhl6").addClass("nextavailable");
                            }
                            if (json1.global.omhl7_r == "Y") {
                                 $j("#omhl7").addClass("nextavailable");
                            }
                            if (json1.global.omdyofwk == " Sunday") {
                                 $j("#omhl7").addClass("nextavailable");
                            }

                            parent.$App.Fire('clear_overlay');

                       } catch (e) {
                       }
                  });
     }
});