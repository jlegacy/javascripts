// *******************************************************************************************************
// *******************************************************************************************************
// *******************************************************************************************************
var OM_BulletinBoard_Popup = Class.create(Dancik_ConfirmWindow, {
	// ---------------------------------------------------------------------------------------------------
	initialize: function($super, params, opts) {
		// -- Construct 'options'...
		this.popup_options = Object.extend({
			showNoMessagesMessage: false, // -- If no BB messages exists, should you indicate/display it.	
			beforeUpdate : null, // -- Additional function(s) to execute (before) update().
			afterUpdate : null // -- Additional function(s) to execute (after) update().
		}, opts || {} );
	
		var _this = this;
		var _$super = $super;
		
		this.popupid="om_BB_PopupWdw_" + new Date().getTime();

		var h = Dancik.getDocumentHeight()-100;
		var w = Dancik.getDocumentWidth()-50;

		
		this.model = new Dancik_Model('../jsonservice/OM_WebService/execute');
		this.model.get(Object.extend({
				serviceid : 'addons', 
				option : 'getBulletinBoard', 
				random : new Date().getTime() ,
				//actionButtonText: "Add Line"
			}, params || {}), 
			function(is_success, json) { 
				try {
					if (json && json.record && json.record.messagesexists == 'Y') {
						_$super(Object.extend({ 
								color : "blue",
								showAsPopup : true,
								popupTitle  : 'Bulletin Board',
								destroyOnClose : true,
								modal : true,
								message: '<div class="OM_BB_Popup" id="OM_BB_Popup_' + _this.popupid + '" style="position:relative; width:550px;"></div>',
								buttons : {action: "OK"}
							}, _this.popup_options)
						);
						
						json = Object.extend(json, { id : _this.popupid });
						var template = new EJS({url: '../app-mgr-addons/bulletinboard.ejs'});
						$('OM_BB_Popup_' + _this.popupid).update( template.render(json) );
						
						_this.open();
						$j('.dws-Confirm-Footer').find('button').focus();
				
					} else if (_this.popup_options.showNoMessagesMessage) {
						_$super({ 
							color : "red",
							showAsInfoOnly : true,
							destroyOnClose : true,
							modal : true,
							contentHTML : "No bulletin board messages were found.",
							buttons : {action: "OK"}
						});
						_this.open();
						$j('.dws-Confirm-Footer').find('button').focus();
					}
				} catch(e) { alert(e.message); }
			});		
	}
});