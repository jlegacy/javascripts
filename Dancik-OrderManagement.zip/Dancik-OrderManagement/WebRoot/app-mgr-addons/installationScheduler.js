// ***************************************************************************************************
// - Main
// ***************************************************************************************************
var Main = Object.extend( OM_Main, {
	ajax : null,	
	printWdw : null,
	mainWdw : null,
	ordertotal : 0,	
	balance_due_global : 0,
	tab_control : 0,
	ControlPanelSettings : 0,
	quickInstallWindow : null,
	new_area_Window : null,
	getAvailableInstallersWdw : null,
	additional_line_notes_Wdw : null,
	finalInstallationWdw : null,
	customer_acct : null,
 	customer_name : null,
 	order_number : null,
 	reference_number : null,
	model : null,
	records : [],
	records2 : [],

	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.initialize()
	// --------------------------------------------------------------------------------------------------- 
	initialize: function() {
		Messaging.init('../../dws/');

		Main.model = new Dancik_Model('../jsonservice/OM_WebService/execute');

		Validation.add('validate-installStatus',"",function(value,element) {
			return Validation.get('IsEmpty').test(value) || Main.Search.installStatusValues().pluck("id").indexOf(value)>-1;
		})
		Validation.add('validate-measureStatus',"",function(value,element) {
			return Validation.get('IsEmpty').test(value) || Main.Search.measureStatusValues().pluck("id").indexOf(value)>-1;
		})
		
		Main.resize();
		Main.order_number = $('parm_OrderId').value;
	 	Main.reference_number = $('parm_ReferenceId').value;
	 	
	 	Main.records = [];

		var params = {
				parm_ReferenceId: Main.reference_number,
				parm_OrderId: Main.order_number
		}
		
		// -- Avoid multi-loading...
		var model = new Dancik_Model('../api/inst-sched/getMeasureStatus');
 		model.get( params , function(is_success, json) {	
 			try{
 				if ( json && json.measured == 'Y' ) {
 					Main.tab_control = 1;
				}
		
		 		// -- Construct 'settings'...
				new TabSet ('installationTabs', {
					activeTab: Main.tab_control,
					style:'small',
					onSelect:{
						'installationTab': function(){
							Main.loadInstallationTable();
						},
						'measureTab': function(){
							Main.loadMeasureTable();
						},
						'notesTab': function(){
							Main.loadNotes();
						},
						'documentsTab': function(){
							Main.loadDocuments();
						}
					}
				});

 			} catch (e) { 
			}
		});
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.loadMeasureTable()
	// --------------------------------------------------------------------------------------------------- 
	loadMeasureTable : function() {
		Dancik.Blanket.InProcess.show({ message : 'Retrieving Data', sizeByStretch : true, zIndex: 100000 });
	 	Main.records = [];
	 	
	 	
	 	var params = {
	 		parm_Mode: 'get_Data',
	 		parm_OrderId: Main.order_number,
	 		parm_ReferenceId: Main.reference_number 
	 	}
		
		// -- Avoid multi-loading...
		var model = new Dancik_Model('../api/inst-sched/getMeasureInfo');
 		model.get( params , function(is_success, json) {	
 			try{
 				Dancik.Blanket.InProcess.setMessage('Loading Data');
 				
				if (!json) { throw 'NoRecords'; }

				// -- If errors are returned, then display and exit...
				if (json.errors != null) {
					var errHtml = [];
					json.errors.each( function (msg) { errHtml.push("<div>" + msg + "</div>") } );
					Main.open_ErrorWindow(  errHtml.join('') );
					return;
				}
				
				$('installationTabs').show();
				Main.customer_acct = json.record.customer_acct;
			 	Main.customer_name = json.record.customer_name;
			 	$('customer_account').innerHTML = json.record.customer_acct;
			 	$('customer_name').innerHTML = json.record.customer_name;

			 	var template = new EJS({url: 'installationMeasure.ejs'});
		 		$('measureTab').update(template.render(json));
				
		 		Main.measureValidator = new Validation("Measure_Form",{
					onSubmit: function() {
						Dancik.Blanket.InProcess.show({ message : 'Retrieving Data', sizeByStretch : true });
					},
					onInvalidSubmit: Dancik.Blanket.InProcess.hide,
					onValidSubmit: Main.updateMeasureTable,
					fieldNames: {
						measureStatusDate: "Measure Status Date",
						measureRequestDate: "Requested Measure Date",
						parm_measureStatus: "Measure Status"
					},
					errorMessageKeys: {
						parm_measureStatus: {
							validateMeasureStatus: "errorFieldInvalid"
						}
					}
				})
				new FormFormatter("Measure_Form");
			} catch (e) { 
				if (e == "NoRecords") { 
					$('installationTabs').show();
					Main.open_ErrorWdw({ contentHTML : "There are no lines on this order."});
				} else {
					Main.open_ErrorWdw({ contentHTML : "Error : Main.initialzize() :", extraContentHTML : "- " + e.message});
				}
			}
			Dancik.Blanket.InProcess.hide();
    	});
	},	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.updateMeasureTable()
	// --------------------------------------------------------------------------------------------------- 
	updateMeasureTable : function(event) {
		Event.stop(event);
		
		var form = Event.element(event);
		var params = form.serialize(true);
		
		var divHTML = [];
		
		if ( (params.parm_measureFlag!="Y") && (params.parm_measureStatus!="R") ) {
			divHTML.push('<li> - If Measure is no, Measure Status must be "R - Ready to Install". </li>');
		}
		if ( (params.parm_measureFlag!="Y") && (!params.parm_measureTeam.blank()) ) {
			divHTML.push('<li> - If Measure is no, Install Company and Measure Team must be blank. </li>');
		}
		if ( (params.parm_measureFlag!="Y") && (!params.measureStatusDate.blank()) ) {
			divHTML.push('<li> - If Measure is no, Measure Status Date must be blank. </li>');
		}
		if ( (params.parm_measureFlag!="Y") && (!params.measureRequestDate.blank()) ) {
			divHTML.push('<li> - If Measure is no, Requested Measure Date must be blank. </li>');
		}
		if ( (params.parm_measureFlag == "Y") && (params.measureStatusDate.blank()) ) {
			divHTML.push('<li> - If Measure is yes, Measure Status Date must have a value. </li>');
		}
		if ( (!params.parm_measureTeam.blank())  && (params.parm_measureStatus == 'U') ) {
			divHTML.push('<li> - Measure Team must be blank when Measure Status is "U - Unmeasured". </li>');
		}
		if ( params.parm_measureInstaller.blank() && !params.parm_measureTeam.blank() ) {
			divHTML.push('<li> -  Must select an Install Company if a Measure Team is selected.  </li>');
		}
		if ( !params.parm_measureInstaller.blank() && params.parm_measureTeam.blank() ) {
			divHTML.push('<li> -  Must select a Measure Team if an Install Company is selected.  </li>');
		}

		if ( divHTML.length > 0 ) {
			Main.open_ErrorWdw({
				style : { zIndex:'300' },
				contentHTML : "The following errors occurred:", 
				extraContentHTML : '<ul class="error-list">' + divHTML.join('') + '</ul>'
			});
	 		Dancik.Blanket.InProcess.hide();
			return;
		}
		
 		Main.records = [];

		// -- Avoid multi-loading...
 		Main.model.get( params , function(is_success, json) {	
 			try{
 				Dancik.Blanket.InProcess.setMessage('Updating Records');
 				if ( !json.records[0].error_message.isEmpty() )  {
 					divHTML.push('<li> -  ' + json.records[0].error_message + '</li>');
 					Main.open_ErrorWdw({
 						style : { zIndex:'300' },
 						contentHTML : "The following errors occurred:", 
 						extraContentHTML : '<ul class="error-list">' + divHTML.join('') + '</ul>'
 					});
 					Dancik.Blanket.InProcess.hide();
 					return;
 				} else {
 					Main.confirmation_Window();
 				}
			} catch (e) { 
				if (e == "NoRecords") { 
				} else {
					Main.open_ErrorWdw({ contentHTML : "Error : Main.updateMeasureTable() :", extraContentHTML : "- " + e.message});
				}
			}
			Dancik.Blanket.InProcess.hide();
			
		})	;
 		
	},	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.loadInstallationTable()
	// --------------------------------------------------------------------------------------------------- 
	loadInstallationTable : function() {
		Dancik.Blanket.Full.kill();
		Dancik.Blanket.InProcess.show({ message : 'Retrieving Data', sizeByStretch : true });

		Main.records = [];
		
		var model = new Dancik_Model('../api/inst-sched/getlist');

	 	var params = {
	 		parm_Mode: 'get_Data',
	 		parm_OrderId: Main.order_number,
	 		parm_ReferenceId: Main.reference_number 
	 	}
	 		
		// -- Avoid multi-loading...
 		model.get( params , function(is_success, json) {	
 			try{
 				Dancik.Blanket.InProcess.setMessage('Loading Data');
				if (json == null) { throw 'NoRecords'; }
				// -- If errors are returned, then display and exit...
				if (json.errors != null) {
					var errHtml = [];
					json.errors.each( function (msg) { errHtml.push("<div>" + msg + "</div>") } );
					Main.open_ErrorWindow(  errHtml.join('') );
					return;
				}
				$('installationTabs').show();
				json.tableId = 'installation_table';
				Main.customer_acct = json.records[0].customer_acct;
			 	Main.customer_name = json.records[0].customer_name;
			 	Main.order_number = $('parm_OrderId').value;
			 	Main.reference_number = $('parm_ReferenceId').value;
			 	$('customer_account').innerHTML = json.records[0].customer_acct;
			 	$('customer_name').innerHTML = json.records[0].customer_name;
			 	json.tableId = 'installation_table';
			 	
			 	var template = new EJS({url: 'installationScheduler.ejs'});
		 		$('installationTab').update(template.render(json));

		 		if ( json.records[0].installflag == 'Y'){
					$('parm_installFlag1').checked = true;
		 		} else {
		 			$('parm_installFlag2').checked = true;
				}
			
				//Make it into a ScrollTable	
		 		var table = new ScrollTable('installation_table', {
		 			splitCol: 8, 
		 			tableHeight: 290,
		 			fixRowHeights: true
		 		});
				
			} catch (e) { 
				if (e == "NoRecords") { 
					$('installationTabs').show();
				} else {
					Main.open_ErrorWdw({ contentHTML : "Error : Main.initialzize() :", extraContentHTML : "- " + e.message});
				}
			}
    	});
 		Dancik.Blanket.InProcess.hide();
 	},	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.loadNotes()
	// --------------------------------------------------------------------------------------------------- 
 	loadNotes : function() {
		// -- Show the Full-Screen "In-Process" blanket...
			Dancik.Blanket.InProcess.show({ message : 'Retrieving Data', sizeByStretch : true });
		
		Main.records = [];
		
		var params = {
			parm_OrderId: Main.order_number,
			parm_ReferenceId: Main.reference_number,
			serviceid : 'instsched', 
			option : 'getUpdInstallNotes',
			parm_Mode: 'load_notes'
		}
		
		// -- Avoid multi-loading...
		Main.model.get( params , function(is_success, json) {	
			try{
				Dancik.Blanket.InProcess.setMessage('Table Build In-Progess');
				var template = new EJS({url: 'installationSchedulerInstallNotes.ejs'});
		 		// replace notesTab DIV contents with the template 
		 		$('notesTab').update(template.render(json));
		 		$('parm_InstallNotes').value = json.records[0].install_notes;
		 	
			} catch (e) { 
				if (e == "NoRecords") { 
				} else {
					Main.open_ErrorWdw({ contentHTML : "Error : Main.loadNotes() :", extraContentHTML : "- " + e.message});
				}
			}
	
			Dancik.Blanket.InProcess.hide();
		
		})	;
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.loadDocuments()
	// --------------------------------------------------------------------------------------------------- 
 	loadDocuments : function() {
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.updateInstallNotes()
	// --------------------------------------------------------------------------------------------------- 
	updateInstallNotes : function() {
		// -- Show the Full-Screen "In-Process" blanket...
		Dancik.Blanket.InProcess.show({ message : 'Updating', sizeByStretch : true });
		
		var params = $("install_notes_form").serialize(true);
		// -- Avoid multi-loading...
		Main.model.get( params , function(is_success, json) {	
			try{
			} catch (e) { 
			}

			Dancik.Blanket.InProcess.hide();
			Main.confirmation_Window();
		
		})	;
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.deleteScheduling()
	// --------------------------------------------------------------------------------------------------- 
	deleteScheduling : function() {
		new Dancik_ConfirmWindow({
			color:"yellow",
			content: "This will delete scheduling for all selected lines.",
			modal: true,
			destroyOnClose: true,
			onConfirm: function() {
				Main.deleteSelectedLines();
			}
		}).open();
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.updateInstallFlag()
	// --------------------------------------------------------------------------------------------------- 
	updateInstallFlag : function() {
		// -- Show the Full-Screen "In-Process" blanket...
 		Dancik.Blanket.InProcess.show({ message : 'Updating', sizeByStretch : true });
 		//$('parm_Mode').value = 'update_install_flag';
 		
 		var params = Form.serialize('Installer_Form', true);
		params = Object.extend( params, {
			serviceid : 'instsched', 
			option : 'getList',
			parm_Mode: 'update_install_flag'
		});	
		
		// -- Avoid multi-loading...
 		Main.model.get( params , function(is_success, json) {	
 			try{
 		 	} catch (e) { 
			}
			Dancik.Blanket.InProcess.hide();
		})	;
 		
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.quickInstall()
	// --------------------------------------------------------------------------------------------------- 
 	quickInstall : function() {
 		if (!Main.quickInstallWindow) {
			// -- Construct window...
			var h = Dancik.getDocumentHeight()-100;
			var w = (Dancik.getDocumentWidth() > 940) ? 940 : (Dancik.getDocumentWidth()-25);
			var template = new EJS({url: 'installationSchedulerQuickInstall.ejs'});
			var html = template.render();
			
			Main.quickInstallWindow  = new OM_PopupWindow({ 
				zIndex : '10', 
				width : w, 
				height : h,
				title : 'Quick Install',
				modal : true,
				content : html,
				useAsSmallWdw : true
			});
			new Validation("quick_install_form",{
				onSubmit: function() {
					Dancik.Blanket.InProcess.show({ message : 'Updating', sizeByStretch : true, zIndex: 100000 });
				},
				onInvalidSubmit: Dancik.Blanket.InProcess.hide,
				onValidSubmit: Main.quickInstallUpdate,
				fieldNames: {
					quickInstallDate: "Install Date",
					parm_quickInstaller: "Install Company",
					parm_quickTeam: "Install Team"
				}
			});
			new FormFormatter("quick_install_form");
 		}
		Main.quickInstallWindow.open();
 	},	
 	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.quickInstallUpdate()
	// --------------------------------------------------------------------------------------------------- 
	quickInstallUpdate : function(event) {
		Event.stop(event);
		
		var params = Form.serialize('quick_install_form', true)
		
		// -- Avoid multi-loading...
 		Main.model.get( params , function(is_success, json) {
			
 			try{
 				if ( !json.records[0].error_message.isEmpty() ) {
 					Main.open_ErrorWdw({
 						style : { zIndex:'300' },
 						contentHTML : "The following errors occurred:", 
 						extraContentHTML : '<ul class="error-list">' + json.records[0].error_message + '</ul>'
 					});
 					Dancik.Blanket.InProcess.hide();
 					return;
 				} else {
 				}
 		 	} catch (e) { 
			}
			Dancik.Blanket.InProcess.hide();
			Main.confirmation_Window();
			Main.quickInstallWindow.close();
			Main.loadInstallationTable();
		});
 		
 		
 		
	},	
	// -------------------------------------------------------------------------------
	// -- Main.getAvailableInstallers()
	// -------------------------------------------------------------------------------
	getAvailableInstallers : function(lines) {
		if (Main.finalInstallationWdw) {
			Main.finalInstallationWdw.close();
			Main.finalInstallationWdw = null;
		}
		
		if (lines) {
			var lineArray = lines.split(",")
			$$('.available-items').each(function(o) {
				o.checked = false;
			});
			lineArray.each( function(l) {
				if ( $("installation_table_parm_checked_lines_"+l) ) {
					$("installation_table_parm_checked_lines_"+l).checked=true;
				}
			});
			
		}
		
		Main.records2 = [];

		var params = Form.serialize($('Installer_Form'),true);
		
		if (!params.parm_checked_lines){
			Main.open_ErrorWdw({ contentHTML : "Must select at least one line."});
			return;
		}
		
		// -- Avoid multi-loading...
		Dancik.Blanket.InProcess.show({  sizeByStretch : true });
			try{ 
		Main.model.get( params , function(is_success, json) {	
 				if (json.records == null) { throw 'NoRecords'; };
				// -- If errors are returned, then display and exit...
				if (json.errors != null) {
					var errHtml = [];
					json.errors.each( function (msg) { errHtml.push("<div>" + msg + "</div>") } );
					Main.open_ErrorWindow(  errHtml.join('') );
					return;
				} else {
					if(Main.getAvailableInstallersWdw) {
						Main.getAvailableInstallersWdw.close();
						Main.getAvailableInstallersWdw = null;
					}
					
					// -- Construct window...
					var h = Dancik.getDocumentHeight()-75;
					var w = ((Dancik.getDocumentWidth()-75) > 940) ? 940 : (Dancik.getDocumentWidth()-75);
					json.parm_checked_lines = [params.parm_checked_lines].flatten().compact();
					var template = new EJS({url: 'installationSchedulerAvailInstallers.ejs'});
					
					Main.getAvailableInstallersWdw = new Dancik_ConfirmWindow({
						showAsPopup: true,
						popupTitle: "Available Installation Dates and Teams",
						message: '<div style="position:relative; width:' + w + 'px; height:' + h + 'px; overflow:auto;">' + template.render(json) + '</div>',
						modal: true,
						color: "grey",
						buttons: {},
						destroyOnClose: true,
						beforeClose: function() {
							Main.availableFinalFormFormatter.destroy();
							Main.availableFinalFormFormatter=null;
						}
					}); 
					new Validation("available_filters_form",{
						onSubmit: function() {
							Dancik.Blanket.InProcess.show({  sizeByStretch : true });
						},
						onInvalidSubmit: Dancik.Blanket.InProcess.hide,
						onValidSubmit: Main.updateAvailableInstallers,
						fieldNames: {
							requestedInstallDate: "Requested Install Date",
							parm_limitbyDuration: "Hours Required"
						}
					})
					
					Main.availableFinalFormFormatter = new FormFormatter("available_filters_form");
					new Validation("available_final_form",{
						onSubmit: function() {
							Dancik.Blanket.InProcess.show({  sizeByStretch : true });
						},
						onInvalidSubmit: Dancik.Blanket.InProcess.hide,
						onValidSubmit: Main.loadFinalScheduleScreen
					})
					Main.getAvailableInstallersWdw.open();
					
					
				}
				$('parm_limitbyCostCenter').value = json.records[0].limitbycctr;
				$('view_limitbyCostCenter').innerHTML = json.records[0].limitbyccdesc;
				$('parm_limitbyWare').value = json.records[0].limitbyware;
				$('view_limitbyWare').innerHTML = json.records[0].limitbywaredesc;
				
				
		
	
			Dancik.Blanket.InProcess.hide();
		})	;
 			} catch (e) { 
				if (e == "NoRecords") { 
					Main.open_ErrorWdw({ contentHTML : "No Install Teams available."});
				} else {
					Main.open_ErrorWdw({ contentHTML : "Error : Main.getAvailableInstallers() :", extraContentHTML : "- " + e.message});
				}
			}

	},
	// -------------------------------------------------------------------------------
	// -- Main.updateAvailableInstallers()
	// -------------------------------------------------------------------------------
	updateAvailableInstallers : function(event) {
		Event.stop(event);
		Main.records2 = [];
		
		var form = Event.element(event);
		var params = form.serialize(true);
		
		// -- Avoid multi-loading...
		$('table_detail_tbody').update();
		Dancik.Blanket.OverElement.show($('table_detail'), {zIndex:500});
		Main.model.get( params , function(is_success, json) {	
 			try{ 
 				if (json.records == null) { throw 'NoRecords'; };
				// -- If errors are returned, then display and exit...
				if (json.errors != null) {
					var errHtml = [];
					json.errors.each( function (msg) { errHtml.push("<div>" + msg + "</div>") } );
					Main.open_ErrorWindow(  errHtml.join('') );
					return;
				} else {
					var html = [];
					var template = new EJS({url: 'installationSchedulerAvailInstallersLine.ejs'});
					for(var i=0;i<json.records.length;i++) {
						var record = json.records[i];
						record.json = Object.toJSON(record).replace(/"/g,"&quot;");
						html.push(template.render(json.records[i]));
					}
					Dancik.Blanket.OverElement.hide();
					$('table_detail_tbody').update(html.join(""));
				}
				
 			} catch (e) { 
				if (e == "NoRecords") {
					var divHTML = [];
					divHTML.push('<li> - '+$M("om.availableInstallersNotFound")+'</li>');
					Main.open_ErrorWdw({
						style : { zIndex:'300' },
						contentHTML : "The following errors occurred:", 
						extraContentHTML : '<ul class="error-list">' + divHTML.join('') + '</ul>'
					});
					Dancik.Blanket.OverElement.hide();
					Dancik.Blanket.InProcess.hide();
				} else {
					Main.open_ErrorWdw({ contentHTML : "Error : Main.updateAvailableInstallers() :", extraContentHTML : "- " + e.message});
				}
			}
 			Dancik.Blanket.InProcess.hide();
		})	;
		
	},
	// -------------------------------------------------------------------------------
	// -- Main.loadFinalScheduleScreen()
	// -------------------------------------------------------------------------------
	loadFinalScheduleScreen : function(event) {
		Event.stop(event);
		var form = Event.element(event);
		var params = form.serialize(true);
		
		var json = null;
		try {
			//value of radio button is json object representing install team
			json = params.parm_installer_checked.evalJSON();
		} catch (e) {}
		json = Object.extend({
			installer:"",
			team:"",
			install_date:"",
			day_of_week:"",
			team_desc:"",
			jobs_avail:"",
			hours_avail:""
		},json || {});

		//set selected install team in to params
		params.final_installer =  json.installer;
		params.final_team = json.team;
		params.final_date = json.install_date;
		params.final_day = json.day_of_week;
		params.final_team_desc = json.team_desc;
		params.jobsAvailCheck = json.jobs_avail;
		params.hoursAvailCheck = json.hours_avail;
		
		var divHTML = [];
		if (Main.finalInstallationWdw) {
			Main.finalInstallationWdw.close();
			Main.finalInstallationWdw = null;
		}

		if ( params.final_installer.isEmpty() ) {
			divHTML.push('<li> -  Must select at least one Install Team.  </li>');
		}
		if ( params.jobsAvailCheck.isEmpty() && params.hoursAvailCheck.isEmpty() && !params.final_installer.isEmpty() ) {
			divHTML.push('<li> -  This Install Team is not available.  </li>');
		}
		if ( divHTML.length > 0 ) {
			Main.open_ErrorWdw({
				style : { zIndex:'300' },
				contentHTML : "The following errors occurred:", 
				extraContentHTML : '<ul class="error-list">' + divHTML.join('') + '</ul>'
			});
			Dancik.Blanket.InProcess.hide();
			return;
		}
		Main.records2 = [];
		
		if (Main.getAvailableInstallersWdw) {
			Main.getAvailableInstallersWdw.close();
		}
		
		// -- Avoid multi-loading...
 		Main.model.get( params , function(is_success, json) {	
 			try{
				// -- If errors are returned, then display and exit...
				if (json.errors) {
					var errHtml = [];
					json.errors.each( function (msg) { errHtml.push("<div>" + msg + "</div>") } );
					Main.open_ErrorWdw(  errHtml.join('') );
					Dancik.Blanket.InProcess.kill();
					
					return;
				} else {
	 				if (json.records == null) { throw 'NoRecords'; };
					
					json.referenceId = $('parm_ReferenceId').value;
					json.orderNumber = $('parm_OrderId').value;
					json.parm_checked_lines = [params.parm_checked_lines].flatten();
					json.final_installer = params.final_installer;
					json.final_team = params.final_team;
					json.final_date = params.final_date;
					json.final_day = params.final_day;
					
					
					// -- Construct window...
					var h = Dancik.getDocumentHeight()-75;
					var w = ((Dancik.getDocumentWidth()-89) > 940) ? 940 : (Dancik.getDocumentWidth()-89);
					var template = new EJS({url: 'installationSchedulerFinalize.ejs'});
					
					Main.finalInstallationWdw = new Dancik_ConfirmWindow({
						showAsPopup: true,
						popupTitle: "Schedule Install Date and Team",
						message: '<div style="position:relative; width:' + w + 'px; height:' + h + 'px; overflow:auto;">' + template.render(json) + '</div>',
						modal: true,
						color: "grey",
						destroyOnClose: true,
						buttons: {}
					}); 
					
					new Validation("finalize_filters_form",{
						onSubmit: function() {
							Dancik.Blanket.InProcess.show({  sizeByStretch : true });
						},
						onInvalidSubmit: Dancik.Blanket.InProcess.hide,
						onValidSubmit: Main.updateFinalScheduleScreen,
						fieldNames: {
							parm_final_start: "Start Time",
							parm_final_end: "End Time",
							parm_final_duration: "Duration"
						}
					});
					new FormFormatter("finalize_filters_form");
					Main.finalInstallationWdw.open();
					
					$('parm_final_installer').innerHTML = json.records[0].outinstaller;
					$('parm_final_team').innerHTML = json.records[0].outteam;
					$('parm_final_date').innerHTML = json.records[0].outdate;
					//$('parm_startTime').innerHTML = json.records[0].outbegtime;
					//$('parm_endTime').innerHTML = json.records[0].outendtime;
					$('parm_Time').innerHTML = json.records[0].outtime;
					$('parm_finalDuration').innerHTML = json.records[0].outhrsavail;
					$('parm_finalJobsAvailable').innerHTML = json.records[0].outjobsavail;
					$('current_job_div').innerHTML = 'Current Job Schedule for ' + json.records[0].outteam + ' on ' + json.records[0].outdate;
					$('parm_final_startAmPm1').checked = true;
					$('parm_final_endAmPm1').checked = true;
				}
			} catch (e) { 
				if (e == "NoRecords") { 
					alert(e.message);
				} else {
					Main.open_ErrorWdw({ contentHTML : "Error : Main.loadFinalScheduleScreen() :", extraContentHTML : "- " + e.message});
				}
			}
	
			Dancik.Blanket.InProcess.kill();
			
		});
 	},
	// -------------------------------------------------------------------------------
	// -- Main.updateFinalScheduleScreen()
	// -------------------------------------------------------------------------------
	updateFinalScheduleScreen : function(event) {
		Event.stop(event);
		var form = Event.element(event);
		var params = form.serialize(true);
		
 		var divHTML = [];
		
		var entries = [params.parm_final_start.trim(), params.parm_final_end.trim(), params.parm_final_duration.trim()].without("");
		if(entries.length<2) {
			divHTML.push('<li> -  Must enter at least two of Start Time, End Time, and Duration.</li>');
		}

		if ( divHTML.length > 0 ) {
			Main.open_ErrorWdw({
				style : { zIndex:'300' },
				contentHTML : "The following errors occurred:", 
				extraContentHTML : '<ul class="error-list">' + divHTML.join('') + '</ul>'
			});
			Dancik.Blanket.Full.kill();
			return;
		}
		
	 	Main.records2 = [];

	 	// -- Avoid multi-loading...
 		Main.model.get( params , function(is_success, json) {	
 			try{
				// -- If errors are returned, then display and exit...
				if (json.errors) {
					var errHtml = [];
					json.errors.each( function (msg) { errHtml.push("<div>" + msg + "</div>") } );
					Main.open_ErrorWdw(  errHtml.join('') );
					Dancik.Blanket.InProcess.kill();
					
					return;
				} else {
	 				if (json.records == null) { throw 'NoRecords'; };
					
	 				
	 				json.referenceId = $('parm_ReferenceId').value;
					json.orderNumber = $('parm_OrderId').value;
					if (!json.records[0].scheduledstart.isEmpty())  {
						$('parm_final_start').value = json.records[0].scheduledstart;
					}
					if (!json.records[0].scheduledend.isEmpty())  {
						$('parm_final_end').value = json.records[0].scheduledend;
					}
					if (!json.records[0].scheduledduration.isEmpty())  {
						$('parm_final_duration').value = json.records[0].scheduledduration;
					}
					
					if ( json.records[0].scheduledstartampm == 'PM' ) {
						$('parm_final_startAmPm2').checked = true;
					} else {
						$('parm_final_startAmPm1').checked = true;
					}
					
					if ( json.records[0].scheduledendampm == 'PM' ) {
						$('parm_final_endAmPm2').checked = true;
					} else {
						$('parm_final_endAmPm1').checked = true;
					}
					
					$('parm_finalDuration').innerHTML = json.records[0].outhrsavail;
				  	$('parm_finalJobsAvailable').innerHTML = json.records[0].outjobsavail;
				  	var errmsg = ' ';
				  	
				  	for(var i=0;i<json.records.length;i++) {
				  		if (!json.records[i].outerr.isEmpty()) {
				  			errmsg = json.records[i].outerr;
				  		}
				  	}
				  		
				  	if (errmsg.isEmpty()) {
				  		var html = [];
					  	var template = new EJS({url:"installationSchedulerFinalizeTable.ejs"});
					  	for(var i=0;i<json.records.length;i++) {
					  		if ( !json.records[i].outordref.isEmpty() ) {
					  			html.push(template.render(json.records[i]));
					  		}
					  	}
					  	$("final_table_detail_tbody").update(html.join(""));
						Main.confirmation_Window();
						Main.loadInstallationTable();
					} else {
							divHTML.push('<li> -  ' + errmsg + '</li>');
							Main.open_ErrorWdw({
							style : { zIndex:'300' },
							contentHTML : "The following errors occurred:", 
							extraContentHTML : '<ul class="error-list">' + divHTML.join('') + '</ul>'
						});
					}
				}
			} catch (e) { 
				if (e == "NoRecords") { 
					alert(e.message);
				} else {
					Main.open_ErrorWdw({ contentHTML : "Error : Main.updateFinalScheduleScreen() :", extraContentHTML : "- " + e.message});
				}
			}
	
			Dancik.Blanket.InProcess.kill();
			
		});
 	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.select_all_lines()
	// --------------------------------------------------------------------------------------------------- 
	select_all_lines: function(element) {
		$$('.available-items').each(function(o) {
			o.checked = element.checked;
		});
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.additional_line_notes()
	// --------------------------------------------------------------------------------------------------- 
	additional_line_notes: function(line) {
		var params = {
			serviceid : 'instsched', 
			option : 'getUpdLineNotes',
			parm_Mode: 'get_notes',
			parm_ReferenceId: Main.reference_number,
			parm_OrderId: Main.order_number,
			parm_line: line
		}
		
		// -- Avoid multi-loading...
		Main.model.get( params , function(is_success, json) {	
			try{
				Dancik.Blanket.InProcess.setMessage('Table Build In-Progess');
				// replace notesTab DIV contents with the template 
		 		if (!Main.additional_line_notes_Wdw) {
					// -- Construct window...
					var h = Dancik.getDocumentHeight()-100;
					var w = ((Dancik.getDocumentWidth()-300) > 940) ? 940 : (Dancik.getDocumentWidth()-300);
					var template = new EJS({url: 'installationSchedulerAdditionalLineNotes.ejs'});
			 		Main.additional_line_notes_Wdw  = new OM_PopupWindow({ 
						title : 'Additional Line Notes',
						modal : true,
						content : '<div style="position:relative; width:' + w + 'px; height:' + h + 'px; overflow:auto;">' + template.render(json) + '</div>',
						useAsSmallWdw : true
					});
			 		
				}
				Main.additional_line_notes_Wdw.open();
				$('view_aln_line').innerHTML = $('view_line').innerHTML;
				$('view_aln_item_number').innerHTML = $('view_item_number').innerHTML;
				$('view_aln_itemDescription1').innerHTML = $('view_itemDescription1').innerHTML;
				$('view_aln_itemDescription2').innerHTML = $('view_itemDescription2').innerHTML;
				$('view_aln_line_note').innerHTML = $('parm_single_note').value;
				$('parm_aln_notes').value = json.records[0].install_notes;
				$("aln_line").value = line;
		 	
			} catch (e) { 
				if (e == "NoRecords") { 
				} else {
					Main.open_ErrorWdw({ contentHTML : "Error : Main.loadNotes() :", extraContentHTML : "- " + e.message});
				}
			}
		})	;

		Dancik.Blanket.InProcess.hide();
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.updateAdditional_line_notes()
	// --------------------------------------------------------------------------------------------------- 
	updateAdditional_line_notes: function() {
		
		// -- Show the Full-Screen "In-Process" blanket...
 		Dancik.Blanket.InProcess.show({ message : 'Updating', sizeByStretch : true });
 		
 		var params = Form.serialize('additional_line_notes_form', true);
		
		// -- Avoid multi-loading...
 		Main.model.get( params , function(is_success, json) {	
 			try{
 		 	} catch (e) { 
			}
			Dancik.Blanket.InProcess.hide();
		});
 		
 		Main.confirmation_Window();
 		Main.additional_line_notes_Wdw.close();
	
	},
	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.confirmation_Window()
	// --------------------------------------------------------------------------------------------------- 
	confirmation_Window : function() {
		new Dancik_ConfirmWindow({
			destroyOnClose:true,
			content:"Records have been updated.",
			modal:true,
			onNo: this.close,
			color:"blue",
			showAsInfoOnly : true
		}).open();
	},

	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.new_area()
	// --------------------------------------------------------------------------------------------------- 
	new_area : function() {
		if (!Main.new_area_Window) {
			// -- Construct window...
			var h = Dancik.getDocumentHeight()-100;
			var w = (Dancik.getDocumentWidth() > 940) ? 940 : (Dancik.getDocumentWidth()-25);
			var template = new EJS({url: 'installationSchedulerNew_area_Window.ejs'});
	 		Main.new_area_Window  = new OM_PopupWindow({ 
				zIndex : '10', 
				width : w, 
				height : h,
				title : 'Add New Installation Area',
				modal : true,
				content : template.render(),
				useAsSmallWdw : true
			});
		}
		$("parm_new_Area").value = "";
		$("parm_new_Area_Desc").value = "";
		Main.new_area_Window.open();
		
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.new_area_Update()
	// --------------------------------------------------------------------------------------------------- 
	new_area_Update : function() {
		var divHTML = [];
		if ( $F('parm_new_Area').isEmpty() ) {
			divHTML.push('<li> - Must enter an area.</li>');
		}
		if ( $F('parm_new_Area_Desc').isEmpty() ) {
			divHTML.push('<li> - Must enter a description.</li>');
		}
			
		if ( divHTML.length > 0 ) {
			Main.open_ErrorWdw({
				style : { zIndex:'300' },
				contentHTML : "The following errors occurred:", 
				extraContentHTML : '<ul class="error-list">' + divHTML.join('') + '</ul>'
			});
			return;
		}
		
		Main.model = new Dancik_Model('../jsonservice/OM_WebService/execute');
	
		var params = Form.serialize($('new_area_form'), true);
		
		// -- Avoid multi-loading...
 		Main.model.get( params , function(is_success, json) {	
 			try{
 				if ( !json.records[0].error_message.isEmpty() ) {
 					Main.open_ErrorWdw({
 						style : { zIndex:'300' },
 						contentHTML : "The following errors occurred:", 
 						extraContentHTML : '<ul class="error-list">' + json.records[0].error_message + '</ul>'
 					});
 					return;
 				} else {
 				}
 		 	} catch (e) { 
			}
 		 	Main.confirmation_Window();
 		 	Main.new_area_Window.close();
			Dancik.Blanket.InProcess.hide();
			Main.Options.loadAreas();
		});
 	},	
	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.line_edit_update()
	// --------------------------------------------------------------------------------------------------- 
	line_edit_update : function() {
		Dancik.Blanket.Full.kill();
		Dancik.Blanket.InProcess.show({  sizeByStretch : true });
		var divHTML = [];
	 	
	 	if (!Main.lineDetailValidator.validate()) {
	 		Dancik.Blanket.InProcess.hide();
	 		return;
	 	}
	 	
	 	var params = Form.serialize("line_Detail_Form",true);
		var timeFields = [params.parm_start_time.trim(),params.parm_end_time.trim(),params.parm_duration.trim()].without("");
		if(timeFields.length==1) {
			divHTML.push('<li> -  Must enter at least two of start time, end time, and duration. </li>');
		}
		if ( divHTML.length > 0 ) {
			Main.open_ErrorWdw({
				style : { zIndex:'300' },
				contentHTML : "The following errors occurred:", 
				extraContentHTML : '<ul class="error-list">' + divHTML.join('') + '</ul>'
			});
			Dancik.Blanket.Full.kill();
			return;
		}
		
	 	var model = new Dancik_Model('../api/inst-sched/getline');	 	
		// -- Avoid multi-loading...
		model.get( params , function(is_success, json) {	
			try{ 
				if ( json.errors ) {
					divHTML = [];
					json.errors.each(function(msg) { divHTML.push('<li> - ' + msg + '</li>'); });
					
					Main.open_ErrorWdw({
						style : { zIndex:'300' },
						contentHTML : "The following errors occurred:", 
						extraContentHTML : '<ul class="error-list">' + divHTML.join('') + '</ul>'
					});
					Dancik.Blanket.Full.kill();
					return;
				}
				if (!json.record.scheduledstart.isEmpty()) {
					$('parm_start_time').value = json.record.scheduledstart;
				}
				if (!json.record.scheduledend.isEmpty()) {
					$('parm_end_time').value = json.record.scheduledend;
				}
				if (!json.record.scheduledduration.isEmpty()) {
					$('parm_duration').value = json.record.scheduledduration;
				}
				
				if ( json.record.scheduledstartampm == 'PM' ) {
					$('parm_startAmPm2').checked = true;
				} else {
					$('parm_startAmPm1').checked = true;
				}
				
				if ( json.record.scheduledendampm == 'PM' ) {
					$('parm_endAmPm2').checked = true;
				} else {
					$('parm_endAmPm1').checked = true;
				}
				Main.confirmation_Window();
				
			} catch (e) { 
				if (e == "NoRecords") { 
				} else {
					Main.open_ErrorWdw({ contentHTML : "Error : Main.editLineItem() :", extraContentHTML : "- " + e.message});
				}
			}
			Dancik.Blanket.InProcess.hide();
		});
	},
		

	// *******************************************************************************
	// - Main.Search
	// ******************************************************************************* 
	Search : {
		measureStatus: function(e) {
			var event = e || window.event;
			var element = Event.element(event);
			var parent = element.up();
			var input = parent.down("input");
					Popup_Search.open(event,{
						title: "Measure Status",
						preloadedContents: Main.Search.measureStatusValues(),
						toElements: [input],
						positionElement: parent,
						bufferLeft: 2,
						bufferTop:-3,
						heightOverride: 80,
						widthOverride: 135,
						hideHeader: true,
						finalFunction: function(id, description) {
							$("view_parm_measureStatus").update(description);
						}
					})
			},
			measureStatusValues: function() {
				return [
					{id: "U" , description: "Unmeasured"},
					{id: "S" , description: "Scheduled"},
					{id: "M" , description: "Measured"},
					{id: "R" , description: "Ready to Install"}
				];
			},
			measureStatusDescription: function(value) {
				var record = Main.Search.measureStatusValues().find(function(r) { return r.id==value.toUpperCase() }) || {description:""};
				return record.description;
			},
	
		installStatus: function(e) {
			var event = e || window.event;
			var element = Event.element(event);
			var parent = element.up();
			var input = parent.down("input");
			
			Popup_Search.open(event,{
				title: "Install Status",
				preloadedContents: Main.Search.installStatusValues(),
				toElements: [input],
				positionElement: parent,
				bufferLeft: 2,
				bufferTop:-3,
				heightOverride: 80,
				widthOverride: 135,
				hideHeader: true,
				finalFunction: function(id, description) {
					$("view_parm_installStatus").update(description);
				}
			})
		},
		installStatusValues: function() {
			return [
				{id: "S" , description: "Scheduled"},
				{id: "I" , description: "Installed"},
				{id: "U" , description: "Unscheduled"},
				{id: "D" , description: "Delete"}
			];
		},
		installStatusDescription: function(value) {
			var record = Main.Search.installStatusValues().find(function(r) { return r.id==value.toUpperCase() }) || {description:""};
			return record.description;
		},
		

		popupMeasureDate : function(e) {
			var event = e || window.event;
			var element = Event.element(event);
			var parent = element.up();
			
			new CalendarObject({
				toElements : [ 'measureRequestDate', 'parm_measureRequestDate' ],  
			    toFormats : [ 'M/D/Y', 'CYMD' ],
			    positionElement: parent,
				offsetTop: -1,
				zIndex:100000
			});
		},
		popupMeasureStatusDate : function(e) {
			var event = e || window.event;
			var element = Event.element(event);
			var parent = element.up();
			
			new CalendarObject({
				toElements : [ 'measureStatusDate', 'parm_measureStatusDate' ],  
			    toFormats : [ 'M/D/Y', 'CYMD' ],
			    positionElement: parent,
				offsetTop: -1,
				zIndex:100000
			});
		},
		measureTeam : function(e) {
			if ( $F('parm_measureInstaller').isEmpty() ) { 
				Main.open_ErrorWdw({
				style : { zIndex:'300' },
				contentHTML : "The following errors occurred:", 
				extraContentHTML : 'Must enter an Install Company first.'
				});
				return;
			} 
			
			Popup2Search.open(e, { 
				title : 'Measure Team',
				file : 'iscdteam',
				positionElement : 'parm_measureTeam',
				toElements : ['parm_measureTeam'],
				descriptionElement : 'view_measureTeam',
				omitIdInDescription : true,
				additionalParams : { addlFilterField : 'ISCDEINST', addlFilterValue : $F('parm_measureInstaller').toUpperCase() },
				bufferLeft : 2,
				preload : true
			});		
		},
		measureInstaller : function(e) {
			Popup2Search.open(e, { 
				title : 'Install Company',
				file : 'iscdinst',
				positionElement : 'parm_measureInstaller',
				toElements : ['parm_measureInstaller'],
				descriptionElement : 'view_measureInstaller',
				omitIdInDescription : true,
				bufferLeft : 2,
				preload : true
			});		
		},
		popupquickInstallDate : function(e) {
			Popup_Calendar.open(e, { 
				toElements : [ 'quickInstallDate', 'parm_quickInstallDate' ],  
	       		toFormats : [ '*M/D/Y', '*CYMD' ],
	       		avoidClearDate : false,
	       		positionElement: 'quickInstallDate',
		   		bufferTop : 30,
		   		bufferLeft : 1
		   });			
		},
		quickTeam : function(e) {
			if ( $F('parm_quickInstaller').isEmpty() ) { 
				Main.open_ErrorWdw({
				style : { zIndex:'300' },
				contentHTML : "The following errors occurred:", 
				extraContentHTML : 'Must enter an Install Company first.'
				});
				return;
			} 
			Popup2Search.open(e, { 
				title : 'Install Team',
				file : 'iscdteam',
				positionElement : 'parm_quickTeam',
				toElements : ['parm_quickTeam'],
				descriptionElement : 'view_quickTeam',
				additionalParams : { addlFilterField : 'ISCDEINST', addlFilterValue : $F('parm_quickInstaller').toUpperCase() },
				omitIdInDescription : true,
				bufferLeft : 2,
				preload : true
			});		
		},
		quickInstaller : function(e) {
			Popup2Search.open(e, { 
				title : 'Install Company',
				file : 'iscdinst',
				positionElement : 'parm_quickInstaller',
				toElements : ['parm_quickInstaller'],
				descriptionElement : 'view_quickInstaller',
				omitIdInDescription : true,
				bufferLeft : 2,
				preload : true
			});		
		},
		availableTeam : function(e) {
			if ( $F('parm_limitbyInstaller').isEmpty() ) { 
				Main.open_ErrorWdw({
				style : { zIndex:'300' },
				contentHTML : "The following errors occurred:", 
				extraContentHTML : 'Must enter an Install Company first.'
				});
				return;
			} 
			Popup2Search.open(e, { 
				title : 'Install Team',
				file : 'iscdteam',
				positionElement : 'parm_limitbyTeam',
				toElements : ['parm_limitbyTeam'],
				descriptionElement : 'view_limitbyTeam',
				additionalParams : { addlFilterField : 'ISCDEINST', addlFilterValue : $F('parm_limitbyInstaller').toUpperCase() },
				omitIdInDescription : true,
				bufferLeft : 2,
				preload : true
			});		
		},
		availableInstaller : function(e) {
			Popup2Search.open(e, { 
				title : 'Install Company',
				file : 'iscdinst',
				positionElement : 'parm_limitbyInstaller',
				toElements : ['parm_limitbyInstaller'],
				descriptionElement : 'view_limitbyInstaller',
				omitIdInDescription : true,
				bufferLeft : 2,
				preload : true
			});		
		},
		costCenter : function(e) {
			Popup2Search.open(e, { 
				title : 'Cost Center',
				file : 'costcenter',
				positionElement : 'parm_limitbyCostCenter',
				toElements : ['parm_limitbyCostCenter'],
				descriptionElement : 'view_limitbyCostCenter',
				omitIdInDescription : true,
				bufferLeft : 2,
				preload : true
			});		
		},
		warehouse : function(e) {
			Popup2Search.open(e, { 
				title : 'Warehouse',
				file : 'warehouse',
				positionElement : 'parm_limitbyWare',
				toElements : ['parm_limitbyWare'],
				descriptionElement : 'view_limitbyWare',
				omitIdInDescription : true,
				bufferLeft : 2,
				preload : true
			});		
		},
		popuprequestedInstallDate : function(e) {
			var event = e || window.event;
			var element = Event.element(event);
			var parent = element.up();
			var input = parent.down("input");
			
			new CalendarObject({
				toElements : [ 'requestedInstallDate', 'parm_requestedInstallDate' ],  
			    toFormats : [ 'M/D/Y', 'CYMD' ],
			    positionElement: parent,
				offsetTop: -1,
				zIndex:100000
			});
		},
		editTeam : function(e) {
			if ( $F('parm_editInstaller').isEmpty() ) { 
				Main.open_ErrorWdw({
				style : { zIndex:'300' },
				contentHTML : "The following errors occurred:", 
				extraContentHTML : 'Must enter an Install Company first.'
				});
				return;
			} 
			Popup2Search.open(e, { 
				title : 'Install Team',
				file : 'iscdteam',
				positionElement : 'parm_editTeam',
				toElements : ['parm_editTeam'],
				descriptionElement : 'view_editTeam',
				additionalParams : { addlFilterField : 'ISCDEINST', addlFilterValue : $F('parm_editInstaller').toUpperCase() },
				omitIdInDescription : true,
				bufferLeft : 2,
				preload : true
			});		
		},
		editInstaller : function(e) {
			Popup2Search.open(e, { 
				title : 'Install Company',
				file : 'iscdinst',
				positionElement : 'parm_editInstaller',
				toElements : ['parm_editInstaller'],
				descriptionElement : 'view_editInstaller',
				omitIdInDescription : true,
				bufferLeft : 2,
				preload : true
			});		
		},
		popupinstallDate : function(e) {
			Popup_Calendar.open(e, { 
				toElements : [ 'installDate', 'parm_installDate' ],  
	       		toFormats : [ '*M/D/Y', '*CYMD' ],
	       		avoidClearDate : false,
	       		positionElement: 'installDate',
		   		bufferTop : 30,
		   		bufferLeft : 1                                    
	       });			
		}
	},
	// ***********************************************************************************************
	//	Main.ItemOptions 
	// ***********************************************************************************************
	ItemOptions : {
		wdw : null,	
		i : -1,
		// ---------------------------------------------------------------------------------------------------
		// ---------------------------------------------------------------------------------------------------
		// ---------------------------------------------------------------------------------------------------
		open : function(element) {
			var parentElement = Element.up(element, 'TR'); 
			this.i = parentElement.rowIndex;

			// -- Check to see if it already exists...
			new Dancik_RightClicks({
				 dataKey : "item",
				 key : Main.records[this.i].full_item
				},
				{}).open(element);			
	 	}
	},		
	// ***********************************************************************************************
	//	Main.Options 
	// ***********************************************************************************************
	Options : {
		i : -1,	
		// ---------------------------------------------------------------------------------------------------
		// ---------------------------------------------------------------------------------------------------
		// ---------------------------------------------------------------------------------------------------
		open : function(element) {
			var parentElement = Element.up(element, 'TR'); 
			this.i = parentElement.rowIndex;
			var line = Main.records[this.i].line;
			Main.build_OptionsWdw();

			Main.optionsWdw.removeOptions();
			Main.optionsWdw.addOption( { title : "Edit Details", icon : '../../dws/images/edit.png', action : function() { Main.Options.editLineItem(line) } } );
			Main.optionsWdw.addOption( { title : "Schedule Installation", icon : '../images/icons/orderDate.png', action : function() { Main.getAvailableInstallers(line) } } );
			
	
			Main.optionsWdw.setTitle('Line ' + Main.records[this.i].line + ' Options');			
			Main.optionsWdw.open(element);
			
	 	},
	 	// ---------------------------------------------------------------------------------------------------
		// -- editLineItem 
		// ---------------------------------------------------------------------------------------------------
	 	editLineItem : function(in_line) {
			Dancik.Blanket.Full.kill();
	 	 	Dancik.Blanket.InProcess.show({  sizeByStretch : true });
		 	
	 	 	var params = {
				parm_line: in_line,
				parm_Mode: 'load_line_detail',
				parm_OrderId: Main.order_number,
		 		parm_ReferenceId: Main.reference_number
			}
			
	 	 	var model = new Dancik_Model('../api/inst-sched/getline');			
			// -- Avoid multi-loading...
			model.get( params , function(is_success, json) {	
	 			try{ 
					// -- If errors are returned, then display and exit...
					if (json.errors) {
						var errHtml = [];
						json.errors.each( function (msg) { errHtml.push("<div>" + msg + "</div>") } );
						Main.open_ErrorWindow(  errHtml.join('') );
						return;
					} else {
						var template = new EJS({url: 'installationSchedulerLineDetails.ejs'});
				 		// replace installationTab DIV contents with the template 
						json.record.line = in_line;
						$('installationTab').update(template.render(json));
				 		new FormFormatter("line_Detail_Form");
						
				 		Main.lineDetailValidator = new Validation("line_Detail_Form",{
				 			fieldNames: {
					 			parm_editInstaller: "Install Company",
					 			parm_editTeam: "Install Team",
					 			parm_installStatus: "Install Status",
					 			installDate: "Install Date",
					 			parm_start_time: "Start Time",
					 			parm_end_time: "End Time",
					 			parm_duration: "Duration" 
					 		},
							errorMessageKeys: {
								parm_installStatus: {
									validateInstallStatus: "errorFieldInvalid"
								}
							}
						})
				 		
						Main.Options.loadAreas();
						Dancik.Blanket.OverElement.hide();
					}
	 			} catch (e) { 
					if (e == "NoRecords") { 
					} else {
						Main.open_ErrorWdw({ contentHTML : "Error : Main.editLineItem() :", extraContentHTML : "- " + e.message});
					}
				}
	 			Dancik.Blanket.InProcess.hide();
			});
	 	},
		unloadLineItem: function() {
			FormFormatter.destroy("line_Detail_Form");
			Main.loadInstallationTable();
		},
	 	// ---------------------------------------------------------------------------------------------------
		// -- loadAreas
		// ---------------------------------------------------------------------------------------------------
	 	loadAreas : function() {
	 		Main.records2 = [];
	 		
	 		var params = {
				serviceid : 'instsched', 
				option : 'getUpdArea',
				parm_Mode: 'get_areas'
			}
	 		
	 		Main.model = new Dancik_Model('../jsonservice/OM_WebService/execute');
			// -- Avoid multi-loading...
			Main.model.get( params , function(is_success, json) {	
	 			try{ 
	 				if (json.records == null) { throw 'NoRecords'; };
					// -- If errors are returned, then display and exit...
					if (json.errors != null) {
						var errHtml = [];
						json.errors.each( function (msg) { errHtml.push("<div>" + msg + "</div>") } );
						Main.open_ErrorWindow(  errHtml.join('') );
						return;
					} else {
						var template = new EJS({url: 'installationSchedulerAreasTableLine.ejs'});
						var html = [];
						for (var i = 0; i<json.records.length;i++){
							var record = json.records[i];
							html.push(template.render(record));
						}
						$('area_table_detail').update(html.join(''));
					}
	 			} catch (e) { 
					if (e == "NoRecords") { 
					} else {
						Main.open_ErrorWdw({ contentHTML : "Error : Main.Options.loadAreas() :", extraContentHTML : "- " + e.message});
					}
				}
	 		});
	 	},
		selectArea: function(json) {
			//we will add new value to box
			//current text will be trimmed
			
			var value = $("parm_single_area").value.trim();
			json = json.evalJSON();
			var newVal = json.area_desc.trim();
			
			if(newVal.blank()) {return;}
			
			//if current text is not blank, new value is added to end after ", "
			if(!value.blank()) {
				//we check for existing comma to not duplicate
				if(!value.endsWith(",")) {
					value+=",";
				}
				value+=" "
			}
			value += newVal;
			
			//check to make sure value will fit in box
			if(value.length>60) {
				//warn user if not
				alert("Installation areas has a max of 60 characters.");
				value = value.substr(0,60);
			}
			$("parm_single_area").value = value;
		}
	},


	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.resize()
	// --------------------------------------------------------------------------------------------------- 
	resize : function() {
		
		Dancik.Blanket.Full.resize();
	}
});
