// *******************************************************************************************************
//*******************************************************************************************************
//*******************************************************************************************************
var OrderNotepad_Popup = Class.create(Dancik_ConfirmWindow, {

	current_pageid : 1,
	lines : [],
	// ----------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------
	initialize: function($super, params, opts) {
		this.params = params || {};
		// -- Construct 'options'...
		this.popup_options = Object.extend({
			editmode : false,				// -- Tells class if to allow editing.
			beforeUpdate : null,			// -- Additional function(s) to execute (before) update().
			afterUpdate : null			// -- Additional function(s) to execute (after) update().
		}, opts || {} );
	
	
		var _this = this;
		this.popupid="OrderNotepad_Popup_" + new Date().getTime();
		
		var dim = this.getDimensions();
		
		$super(Object.extend({ 
				color : "blue",
				showAsPopup : true,
				popupTitle  : 'Order Notepad',
				destroyOnClose : true,
				modal : true,
				message: '<div class="OrderNotepad_Popup" id="' + this.popupid + '" style="height:' + dim.height + 'px; width:' + dim.width + 'px;"></div>',
				buttons : {},
				onResize : function() { 
					var dim = _this.getDimensions();
					$(_this.popupid).setStyle({height: dim.height+'px', width: dim.width+'px'});
				}
			}, opts || {})
		)

		this.model_search = new Dancik_Model('../api/notepad/search');
		
 		// -- Load initial view and set observers...
		this.model = new Dancik_Model('../api/notepad');

		this.model.get(Object.extend({
				random : new Date().getTime(),
				parm_pageid :  _this.current_pageid || 1
			}, this.params || {}), 
			function(is_success, json) { 
				try{
					json = Object.extend(json, { 
						id : _this.popupid,
						editmode : _this.popup_options.editmode
					});
					_this.lines = json.records;
					var template = new EJS({url: '../app-mgr-addons/notepad.ejs'});
					$(_this.popupid).update( template.render(json) );
					$(_this.popupid + '_notepad_lines').scrollTop = 0;

					// -- Build tabset features...
					new TabSet (_this.popupid + '_notepad_tabs', {
						activeTab: 0,
						style:'small'
					});		
					
					// -- Build validator...
					var testValidator = new Validation($(_this.popupid + '_notepad_form'), {
						onValidSubmit : function(event) {
							event.stop();
							_this.getPage($F(_this.popupid + '_pageid'));
						},
						errorMessages: {
							parm_pageid: { validateDigits: "Only numbers are allowed in Page field." }
						}
					});					
					
					
					Event.observe(_this.popupid + '_forward', "click", function() { _this.getPage( (_this.current_pageid == 99) ? 1 : _this.current_pageid+1 ) });
					Event.observe(_this.popupid + '_forward_all', "click", function() { _this.getPage(99) });
					Event.observe(_this.popupid + '_backward', "click", function() { _this.getPage( (_this.current_pageid == 1) ? 99 : _this.current_pageid-1 ) });
					Event.observe(_this.popupid + '_backward_all', "click", function() { _this.getPage(1) });
					
					Event.observe(_this.popupid + '_searchbutton', "click", function() { _this.search() });

					// -- Only execute blur()-update, when in editmode...
					if (_this.popup_options.editmode) {
						Element.select($(_this.popupid), 'div.line input').each(function(o, i) {
							Event.observe(o, "blur", function() { _this.update(this, i) });
						});
					}
					
				} catch(e) { alert(e.message); }
				
				this.orderdetails= new Dancik_Model('../../dancik-aws/om/getOrderSupplementInfo');
				//this.post(data,'../dancik-aws/getOrderSupplementInfo', callback, errorCallback);
				this.orderdetails.get(Object.extend({
					random : new Date().getTime(),
					parm_pageid :  _this.current_pageid || 1,
					omOrder : params.parm_orderid,
					omDate : $('oeHdr_Box4_Ttl').innerHTML
				}, this.params || {}), 
				function(is_success, json) { 
					try{
						$('np_date_keyed').innerHTML=json.success.datekeyed;
						$('np_date_processed').innerHTML=json.success.dateprocessed;
						$('np_entered_by').innerHTML=json.success.enteredbyinitials;
						$('np_entered_by_name').innerHTML=json.success.enteredbyname;
						$('np_sent_ch').innerHTML=json.success.datecredithold;
						$('np_released_ch').innerHTML=json.success.datecreditreleased;
						$('np_salesperson1').innerHTML=json.success.salespersoncode;
						$('np_salesperson2').innerHTML=json.success.secsalespersoncode;
						$('np_time_keyed').innerHTML=json.success.timekeyed;
						$('np_time_processed').innerHTML=json.success.timeprocessed;
						$('np_time_credit_hold').innerHTML=json.success.timecredithold;
						$('np_time_released_hold').innerHTML=json.success.timecreditreleased;
						$('np_keyed_ws').innerHTML=json.success.keyedbyws;
						$('np_released_by').innerHTML=json.success.releasedbyinitials;
						$('np_sales_name').innerHTML=json.success.salespersondesc;
						$('np_sales_name2').innerHTML=json.success.secsalespersondesc;
						
					} catch(e) { alert(e.message); }
				});	
		});			
	},
	// ----------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------
	getDimensions: function() {
		var h = (Dancik.getDocumentHeight()-100) > 555 ? 555 : Dancik.getDocumentHeight()-100;
		var w = (Dancik.getDocumentWidth()-50) > 750 ? 750 : Dancik.getDocumentWidth()-50;
		
		return { height : h, width : w };
	},
	// ----------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------
	getPage: function(newPageId) {
		var _this = this;
		_this.current_pageid = parseInt(newPageId);
		$(_this.popupid + '_pageid').value = _this.current_pageid; 
		
		_this.model.get(Object.extend({
				random : new Date().getTime(),
				parm_pageid :  _this.current_pageid || 1
			}, this.params || {}), 
			function(is_success, json) { 
				try{
					
					json = Object.extend(json, { 
						editmode : _this.popup_options.editmode
					});
					
					var template = new EJS({url: '../app-mgr-addons/notepad-lines.ejs'});
					$(_this.popupid + '_notepad_lines').update( template.render(json) );
					$(_this.popupid + '_notepad_lines').scrollTop = 0;
					
	
					Element.select($(_this.popupid), 'div.line input').each(function(o, i) {
						Event.observe(o, "blur", function() { _this.update(this, i) });
					})
					
				} catch(e) { alert(e.message); 
				}
			});
	},
	// ----------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------
	update: function(element, i) {
		var _this = this;

		// -- If the line's text did not change, do nothing...
		if (_this.lines[i].text != element.value) {
			_this.lines[i].text = element.value;
		} else {
			return;
		} 
		
		// -- Execute the update(post)...
		_this.model.post(Object.extend({
				random : new Date().getTime(),
				parm_pageid :  _this.current_pageid,
				parm_lineid : i + 1,  // -- Line# are stored started at 1, not 0...
				parm_text : element.value
			}, this.params || {})
		);
	},
	// ----------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------
	// ----------------------------------------------------------------------------------------------
	search: function() {
		var _this = this;
		var filter = $F(_this.popupid + '_searchfilter');
		
		// -- Execute the update(post)...
		_this.model_search.get(Object.extend({
				random : new Date().getTime(),
				parm_filter : filter
			}, this.params || {}),
			function(is_success, json) { 
				try{
					var template = new EJS({url: '../app-mgr-addons/notepad-searchresults.ejs'});
					$(_this.popupid + '_notepad_searchresults').update( template.render(json) );
	
				} catch(e) { alert(e.message); 
				}
		});
	}
});