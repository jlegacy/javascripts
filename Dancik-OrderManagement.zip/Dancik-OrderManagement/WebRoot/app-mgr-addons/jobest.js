var spinnerDiv = new Element('div', {
	style: 'background: url(../../dws/images/rotating_large.gif) no-repeat center center; width: 100%; height: 100%;'
});

//Define classes & functions
var JobEstimateModel = Class.create(Dancik_Model, {
	initialize: function($super) {
		$super('job_estimate');
	},
	in_filter: function(job_estimate) {
		if( job_estimate && job_estimate.records ) {
			job_estimate = job_estimate.records[0];
			job_estimate.orref = job_estimate['orref#'];
			delete job_estimate['orref#'];
			return job_estimate;
		} else {
			return {};
		}
	},
	out_filter: function(job_estimate) {
		new_job_estimate = {};
		for(var prop in job_estimate) {
			new_job_estimate['parm_' + prop] = job_estimate[prop];	//prefix properties with parm
		}
		return new_job_estimate;
	}
});

var JobEstimate = new JobEstimateModel();

var populate = function(data, context) {
	var keys = Object.keys(data);
	var $context = context ? $(context) : $(document.body);	//use context if supplied, otherwise entire document
	var target = null;
	//find elements to populate with this value
	for(var i=0; i<keys.length; i++) {
		var key = keys[i];
		targets = $context.select('[bind=' + key + ']');
		
		//if we found an element, populate it
		if(targets.length > 0) {
			set_content(data[key], targets);
		}
	}
}

var set_content = function(value, targets) {
	for(var i=0; i<targets.length; i++) {
		var name, radios;
		var $target = $(targets[i]);
		switch ($target.tagName.toLowerCase()) {
			case 'input':
			case 'select':
				if( $target.readAttribute('type') == 'radio' ) {
					//radio buttons require a more detailed check
					name = $target.readAttribute('name');
					radios = $$('input[name='+name+']'); //TODO: No context - could be inefficient in large pages
					radios.each(function(radio) {
							if( radio.readAttribute('value') == value ) {
								$target = radio;
								throw $break;
							}
					});
				}
				$target.setValue(value);
				break;
			default:
				if($target.hasClassName("commas")) {
					value = value.toString().commas();
				}
				$target.update(value);
		}
	}
}

//function to save job estimate
var save_estimate = function() {
	var $form = $('job-estimate');
	var job_estimate = $form.serialize({hash: true});
	Dancik.Blanket.InProcess.show({
		overlayObject: $(document.body).down('div'),
		extraElement: spinnerDiv,
		appendInOverlay: true,
		zIndex: 10100
	});
	JobEstimate.update(job_estimate, function(is_success, new_job_estimate){
		Dancik.Blanket.InProcess.kill();
		if( is_success ) {
			populate(new_job_estimate, $('jobEstimate'));
		} else {
			var error_msg = new Dancik_ErrorWindow({
				contentHTML: '<div>' + new_job_estimate.records[0].errmsg + '</div>'
			});
			error_msg.open();
		}		
	});
	return false;
};

Validation.add('num7_2neg','%T format is (-)9999999.99.',{
	pattern: /^-?(\d{0,7}|\d{0,7}\.\d{0,2})$/
})
Event.observe(window, 'load', function() {
	// Configure form validation
	var validation = new Validation('job-estimate',{
		onValidSubmit: function(ev) { ev.stop(); save_estimate(); },
		errorMessages: {
			orpassword: {
				required: 'A password is required.'
			},
			orpricemat: {
				validateNumber: 'Materials price is not a valid number.',
				num7_2neg: "Materials price format is (-)9999999.99."
			},
			orpricelab: {
				validateNumber: 'Labor price is not a valid number.',
				num7_2neg: "Labor price format is (-)9999999.99."
			},
			orcostmat: {
				validateNumber: 'Materials cost is not a valid number.',
				num7_2neg: "Materials cost format is (-)9999999.99."
			},
			orcostlab: {
				validateNumber: 'Labor cost is not a valid number.',
				num7_2neg: "Labor cost format is (-)9999999.99."
			}

		}	
	});

	//load job estimate
	var job_id = window.location.search.parseQuery()['reference'];
	if( job_id ) {	
		Dancik.Blanket.InProcess.show({
			overlayObject: $(document.body).down('div'),
			extraElement: spinnerDiv,
			appendInOverlay: true,
			zIndex: 10100
		});
		JobEstimate.get( 
			{orref: job_id}, 
			function(is_success, job_estimate) {
				Dancik.Blanket.InProcess.kill();
				if( is_success ) {
					populate(job_estimate, $('jobEstimate'));
				} else {
					var error_msg = new Dancik_ErrorWindow({
						contentHTML: '<div>' + new_job_estimate.errmsg + '</div>'
					});
					error_msg.open();
				}
		});
	}

});
