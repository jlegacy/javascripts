// *******************************************************************************************************
// * A T T E N T I O N  : This file MUST be loaded AFTER the </body> tag. 
// * 						Else, manually load the required files (as loaded at bottom)/
// *******************************************************************************************************
var PrintOrderOptions_Popup = Class.create(Dancik_ConfirmWindow, {
	// ---------------------------------------------------------------------------------------------------
	initialize: function($super, params, opts) {
		this.params = $H(Object.extend({
			fromEndOrder : true // -- To determine if class is being accessed via From End of Order, or just being called, to print.		
		}, params || {} ));
	
		// -- Construct 'options'...
		this.popup_options = Object.extend({
			beforeSubmit : null, // -- Additional function(s) to execute (before) create().
			afterSubmit : null, // -- Additional function(s) to execute (after) create().
			returnToOrderFunction : null 
		}, opts || {} );
	
		var _this = this;
		
		var dh = Dancik.getDocumentHeight()-60;
		
		this.model = new Dancik_Model('../jsonservice/OM_WebService/execute');

		this.popupid = "OM_PrintOptions_PopupWdw_" + new Date().getTime();
		$super(Object.extend({ 
				color : "blue",
				showAsPopup : true,
				popupTitle  : this.params.get('fromEndOrder') ? 'End-of-Order Options' : 'Available Print Options',
				destroyOnClose : true,
				modal : true,
				message: '<div id="' + this.popupid + '" style="position:relative; overflow-x:hidden; overflow-y:auto; width:600px;"></div>',
				buttons : {}
			}, this.popup_options)
		);
		this.openModal();
		this.reload();
	},
	// --------------------------------------------------------------------------------------------------
	reload: function() {
		var _this = this;
		
		var params = _this.params.toObject();
		
		this.model.get(Object.extend({
			serviceid : 'addons', 
			option : 'getPrintOptConfig', 
			random : new Date().getTime() 
		}, params || {}), 
		function(is_success, json) {
			try{
				json = Object.extend(json, { 
					id : _this.popupid, 
					referenceid : _this.params.get('parm_referenceid'),
					orderid : (_this.params.get('parm_orderid') || ''),
					fromEndOrder : (_this.params.get('fromEndOrder') || false),
					editmode : (_this.params.get('editmode') || false),
					forUnprocessedOrder : (_this.params.get('forUnprocessedOrder') || false),
					showReturnToOrderBttn : (_this.popup_options.returnToOrderFunction || false)
				});
				var template = new EJS({url: '../app-mgr-addons/print-options.ejs'});
				$(_this.popupid).update( template.render(json) );
				
				//add data to form
				$j('#' + _this.popupid + '_ODS_Options_Form').data(json);
				
				// -- If "allow_order_entry" is blank, N, or H, then limited the print usage....
				if ( json.record.allow_order_entry == 'Y' ) {
					Element.select($(_this.popupid + '_PrintOptions_Form'), ".processed-options").each(function(o) { o.show(); });
				} else {
					Element.select($(_this.popupid + '_PrintOptions_Form'), ".unprocessed-options").each(function(o) { o.show(); });
				}
				
				Event.observe(_this.popupid + '_SubmitBttn', 'click', _this.processSubmitBttn.bindAsEventListener(_this) );
				Event.observe(_this.popupid + '_AdditionalSubmitBttn', 'click', _this.processAdditionalSubmitBttn.bindAsEventListener(_this) );
				Event.observe(_this.popupid + '_ReturnToOptionsBttn', 'click', _this.returnToOptions.bindAsEventListener(_this) );
				if (_this.popup_options.returnToOrderFunction) {
					Event.observe(_this.popupid + '_ReturnToOrderBttn', 'click', _this.returnToOrder.bindAsEventListener(_this) );
				}
				Event.observe(_this.popupid + '_ODS_Submit_PrintBttn', 'click', _this.submitRegular.bindAsEventListener(_this) );
				Event.observe(_this.popupid + '_ODS_Submit_DistributionBttn', 'click', _this.submitODSBttn.bindAsEventListener(_this) );
				Event.observe(_this.popupid + '_ODS_ReturnToOptionsBttn', 'click', _this.returnToOptions.bindAsEventListener(_this) );
				
				
				Element.select($(_this.popupid + '_PrintAdditionalOptions_Form'), 'IMG.picker').each(function(o) {
					Event.observe(o, 'click',  _this.prompt.bindAsEventListener(_this) );
				});
				
				// -- Save certains settings returned from call...
				_this.ods_setting = json.record.ods_setting;
				_this.ods_records = json.ods || [];
				
				_this.open();
			} catch(e) { 
				new Dancik_ConfirmWindow({ 
					color : "red",
					showAsInfoOnly : true,
					modal : true,
					destroyOnClose : true,
					zIndexModal : 12000,
					contentHTML : "The following error occurred:",
					extraContentHTML : '<ul class="error-list"><li> - ' + e.message + '</li></ul>',
					afterClose : function() { _this.close(); } 
				}).open();
			}
		});		
	},
	
	// --------------------------------------------------------------------------------------------------
	prompt: function(event) {
		Event.stop(event);
		var element = Event.element(event);
		var o = element.up('SPAN.dws-drop').down('INPUT');
		var tr = element.up('tr');
		
		Popup2Search.open(event , { 
			title : 'Order Status',
			file : 'orstat',
			positionElement : o.id, 
			toElements : [o.id], 
			omitIdInDescription : true,
			bufferLeft : 4,
			preload : true
		});
	},	
	// ---------------------------------------------------------------------------------------------------
	processSubmitBttn: function() {
		var _this = this;
		
		var params = Form.serialize(this.popupid + '_PrintOptions_Form', true);
		
		// -- Do nothing, if nothing is selected...
		if ( !params.parm_printoption  ||  params.parm_printoption == '') {
			new Dancik_ConfirmWindow({ 
				color : "red",
				showAsInfoOnly : true,
				modal : true,
				destroyOnClose : true,
				zIndexModal : 12000,
				contentHTML : "The following errors occurred:",
				extraContentHTML : '<ul class="error-list"><li> - Must select an option.</li></ul>'
			}).open();
		} else if ( ['F02','F04','F05'].indexOf(params.parm_printoption) >= 0 ) {
			// -- (1=Always Ask, 2=Ask if Customer has Fax/Email, 3=Never Ask)
			if ( (_this.ods_setting == '1') || ( _this.ods_setting == '2' && _this.ods_records.length > 0 ) ) {	
				_this.openODSscreen();
			} else {
				_this.submitRegular();
			}
		} else if ( params.parm_printoption == 'F09') {	
			_this.submitF9();
		} else if ( params.parm_printoption == 'F10') {	
			_this.openF10screen();
		} else if ( params.parm_printoption == 'F11') {
			_this.openF11screen();
		} else {
			_this.submitRegular();
		}		
	},	
	// ---------------------------------------------------------------------------------------------------
	returnToOrder: function() {
		if (this.popup_options.returnToOrderFunction) {
			this.popup_options.returnToOrderFunction();
		}
		this.close();		
	},	
	// ---------------------------------------------------------------------------------------------------
	processAdditionalSubmitBttn: function() {
		var _this = this;

		var params = Form.serialize(this.popupid + '_PrintOptions_Form', true);
		if ( params.parm_printoption == 'F10') {
			_this.submitF10();
		} else if ( params.parm_printoption == 'F11') {
			_this.submitF11();
		}		
	},
	// ---------------------------------------------------------------------------------------------------
	returnToOptions: function() {
		Element.show(this.popupid + '_Options');
		Element.hide(this.popupid + '_AdditionalOptions');
		Element.hide(this.popupid + '_ODS_Options');
		
		var dh = Dancik.getDocumentHeight()-60;
		var h = (dh >= 300) ? 300 : dh;
		Element.setStyle(this.popupid, {height:h+'px'});
		
		this.centerWindow();
	},
	// ---------------------------------------------------------------------------------------------------
	openODSscreen: function() {
		Element.hide(this.popupid + '_Options');
		Element.show(this.popupid + '_ODS_Options');
		
		var dh = Dancik.getDocumentHeight()-60;
		var h = (dh >= 400) ? 400 : dh;
		Element.setStyle(this.popupid, {height:h+'px'});

		this.centerWindow();

		var container = $j('#' + this.popupid + '_ODS_Options_Form'),
			fax_div = container.find('div#ods-fax-data'),
			email_div = container.find('div#ods-email-data'),
			fax_row = '', email_row = '',
			data = container.data();

		//if ods fax data exists
		if (data.ods_fax) {
			//loop through data and add to row
			$j.each(data.ods_fax, function (index, value) {
				if (value.auto_ak == 'Y') {
					//push in row
					fax_row += '<tr style="margin:1px; float:left;">' +	
						'<td>' +													
							'<input type="checkbox" name="parm_ods_fax_' + index + '_selected" class="dws-form-valid" style="width:1em; clear: left; float: left;" checked="checked"/>' +
						'</td>' +
						'<td>&nbsp;&nbsp;</td>' +
						'<td>' +
							'<input type="text" name="parm_ods_fax_' + index + '" class="dws-no-caps" maxlength="25" style="width:15em; clear: right; float: left;" value="' + value.faxnumber + '"/>' +
						'</td>' +
					'</tr>';
				}
			});
		} else {
			//if no records exist at all, push in blank row
			//default index to 0 if no records
			fax_row += '<tr style="margin:1px; float:left;">' +	
				'<td>' +													
					'<input type="checkbox" name="parm_ods_fax_' + 0 + '_selected" class="dws-form-valid" style="width:1em; clear: left; float: left;"/>' +
				'</td>' +
				'<td>&nbsp;&nbsp;</td>' +
				'<td>' +
					'<input type="text" name="parm_ods_fax_' + 0 + '" class="dws-no-caps" maxlength="25" style="width:15em; clear: right; float: left;"/>' +
				'</td>' +
			'</tr>';
		}

		//put data in table
		fax_div.find('table#ods_fax_data_table').html(fax_row);
		
		//if ods email data exists
		if (data.ods_email) {
			//loop through data and add to row
			$j.each(data.ods_email, function (index, value) {
				if (value.auto_ak == 'Y') {
					//push in row
					email_row += '<tr style="margin:1px; float:left;">' +
							'<td>' +													
								'<input type="checkbox" name="parm_ods_email_' + index + '_selected" class="dws-form-valid" style="width:1em; clear: left; float: left;" checked="checked"/>' + 
							'</td>' +
							'<td>&nbsp;&nbsp;</td>' +
							'<td>' +
								'<input type="text" name="parm_ods_email_' + index + '" class="dws-no-caps" maxlength="50" style="width:27em; clear: right; float: left;" value="' + value.emailaddress + '"/>' +
							'</td>' +
						'</tr>';
				}
			});
		} else {
			//if no records exist at all, push in blank row
			//default index to 0 if no records
			email_row += '<tr style="margin:1px; float:left;">' +
						'<td>' +													
							'<input type="checkbox" name="parm_ods_email_' + 0 + '_selected" class="dws-form-valid" style="width:1em; clear: left; float: left;"/>' + 
						'</td>' +
						'<td>&nbsp;&nbsp;</td>' +
						'<td>' +
							'<input type="text" name="parm_ods_email_' + 0 + '" class="dws-no-caps" maxlength="50" style="width:27em; clear: right; float: left;"/>' +
						'</td>' +
					'</tr>';
		}

		//put data in table
		email_div.find('table#ods_email_data_table').html(email_row);
		
		//add blur event to fax inputs
		fax_div.find('table#ods_fax_data_table input[type="text"]:last').on('blur', function () {
			var text_input = $j(this),
				chk_bx_name = text_input.attr('name') + '_selected';
			//if input has value and check box is selected	
			if (text_input.val() && $j('input[name="' + chk_bx_name + '"]').prop('checked')) {
				//remove blur functionality on current row
				text_input.off('blur');
				
				//get table and rows
				fax_table = fax_div.find('table#ods_fax_data_table');
				current_rows = fax_table.find('tr');
				
				//insert new blank field if less than 16
				if (current_rows.length < 16) {
					fax_row = '<tr style="margin:1px; float:left;">' +
						'<td>' +													
							'<input type="checkbox" name="parm_ods_fax_' + current_rows.length + '_selected" class="dws-form-valid" style="width:1em; clear: left; float: left;"/>' +
						'</td>' +
						'<td>&nbsp;&nbsp;</td>' +
						'<td>' +
							'<input type="text" name="parm_ods_fax_' + current_rows.length + '" class="dws-no-caps" maxlength="25" style="width:15em; clear: right; float: left;"/>' +
						'</td>' +
					'</tr>';
					//append new row to table
					fax_table.append(fax_row);
					//add blur functionality to last input
					//arguments.callee is previously defined function
					fax_div.find('table#ods_fax_data_table input[type="text"]:last').on('blur', arguments.callee);
				}
			}
		});
		
		//add blur event to email inputs
		email_div.find('table#ods_email_data_table input[type="text"]:last').on('blur', function () {
			var text_input = $j(this),
				chk_bx_name = text_input.attr('name') + '_selected';
			//if input has value and check box is selected	
			if (text_input.val() && $j('input[name="' + chk_bx_name + '"]').prop('checked')) {
				//remove blur functionality on current row
				text_input.off('blur');
				
				//get table and rows
				email_table = email_div.find('table#ods_email_data_table');
				current_rows = email_table.find('tr');
				
				
				//insert new blank field if less than 16 (max allowed
				if (current_rows.length < 16) {
					email_row = '<tr style="margin:1px; float:left;">' +
						'<td>' +
							'<input type="checkbox" name="parm_ods_email_' + current_rows.length + '_selected" class="dws-form-valid" style="width:1em; clear: left; float: left;"/>' +
						'</td>' +
						'<td>&nbsp;&nbsp;</td>' +
						'<td>' +
							'<input type="text" name="parm_ods_email_' + current_rows.length + '" class="dws-no-caps" maxlength="50" style="width:27em; clear: right; float: left;"/>' +
						'</td>' +
					'</tr>';
					//append new row to table
					email_table.append(email_row);
					//add blur functionality to last input
					//arguments.callee is previously defined function
					email_div.find('table#ods_email_data_table input[type="text"]:last').on('blur', arguments.callee);
				}
			}
		});
		
		
	},
	// ---------------------------------------------------------------------------------------------------
	openF10screen: function() {
		Element.hide(this.popupid + '_Options');
		Element.show(this.popupid + '_AdditionalOptions');
		
		$('picklist_title').update('Print Partial Pick List');
		this.centerWindow();
	},
	// ---------------------------------------------------------------------------------------------------
	openF11screen: function() {
		Element.hide(this.popupid + '_Options');
		Element.show(this.popupid + '_AdditionalOptions');
		
		$('picklist_title').update('Print Packing List');
		this.centerWindow();
	},
	// ---------------------------------------------------------------------------------------------------
	submitRegular: function() {
		var _this = this;
		
		var params = Form.serialize(this.popupid + '_PrintOptions_Form', true);
		params = Object.extend(params, {
			serviceid : 'addons', 
			option : 'submitPrint', 
			random : new Date().getTime() 
		});
		
		_this.execModel(params);
	},
	// ---------------------------------------------------------------------------------------------------
	submitODSBttn: function() {
		var _this = this;
		
		var params = Form.serialize(this.popupid + '_PrintOptions_Form', true);
		params = Object.extend(params, Form.serialize(this.popupid + '_ODS_Options_Form', true));
		params = Object.extend(params, {
			serviceid : 'addons', 
			option : 'submitPrint', 
			random : new Date().getTime() 
		});
		
		_this.execModel(params);		
	},	
	// ---------------------------------------------------------------------------------------------------
	submitF9: function() {
		var _this = this;
		
		var params = Form.serialize(this.popupid + '_PrintOptions_Form', true);
		params = Object.extend(params, {
			serviceid : 'addons', 
			option : 'submitF9PrintPickLabels', 
			random : new Date().getTime() 
		});
		
		_this.execModel(params);		
	},
	// ---------------------------------------------------------------------------------------------------
	submitF10: function() {
		var _this = this;
		
		var mode = '';
		if (_this.params.get('parm_orderid')) {
			if (_this.params.get('fromEndOrder')) {
				mode = '1';
			} else {
				mode = 'I';
			}
		} else {
			mode = '0';
		}
		
		
		var params = Form.serialize(this.popupid + '_PrintOptions_Form', true);
		params = Object.extend(params, Form.serialize(this.popupid + '_PrintAdditionalOptions_Form', true));
		params = Object.extend(params, {
			parm_mode : mode,
			serviceid : 'addons', 
			option : 'submitPrint', 
			random : new Date().getTime() 
		});
		
		_this.execModel(params);		
	},
	// ---------------------------------------------------------------------------------------------------
	submitF11: function() {
		var _this = this;
		
		var params = Form.serialize(this.popupid + '_PrintOptions_Form', true);
		params = Object.extend(params, Form.serialize(this.popupid + '_PrintAdditionalOptions_Form', true));
		params = Object.extend(params, {
			serviceid : 'addons', 
			option : 'submitF11PrintPackList', 
			random : new Date().getTime() 
		});
		
		_this.execModel(params);		
	},
	// ---------------------------------------------------------------------------------------------------
	execModel: function(params) {
		var _this = this;
		
		if (this.popup_options.beforeSubmit) {
			this.popup_options.beforeSubmit();
		}
		this.model.get(params, function(is_success, json) { 
			try {
				 	var msg = "";
//				 	if ( (params.is_this_a_purchase_order == 'Y') || (params.is_this_a_direct_ship=='Y') ) {
//				 		if ( params.parm_printoption == 'F01') { msg = "Purchase order print";
//						} else if ( params.parm_printoption == 'F03') {  msg = "Purchase order edit";
//						} else if ( params.parm_printoption == 'F12') {  msg = "Process purchase order but do not print";
//						} else  {  msg = "Your request";
//						}
//				 	} else {	
//						if ( params.parm_printoption == 'F01') { msg = "Pick List";
//						} else if ( params.parm_printoption == 'F02') {  msg = "Quotation";
//						} else if ( params.parm_printoption == 'F03') {  msg = "Material Selection Form";
//						} else if ( params.parm_printoption == 'F04') {  msg = "Pick List and Acknowledgment";
//						} else if ( params.parm_printoption == 'F05') {  msg = "Acknowledgment";
//						} else if ( params.parm_printoption == 'F09') {  msg = "Pick Labels";
//						} else if ( params.parm_printoption == 'F10') {  msg = "Partial Pick List";
//						} else if ( params.parm_printoption == 'F11') {  msg = "Packing List";
//						} else if ( params.parm_printoption == 'F12') {  msg = "Process order but do not print";
//						} else  {  msg = "Your request";
//						}
//				 	}
				 	msg = "Your request";
					msg += ' has been submitted.'
					var html = [];
					var extraContent = null;
					
//					if ( json.records[0] != null) {
//						if ( json.records[0].errorflag == 'Y' ) {
//							html.push('<ul class="error-list">');
//							html.push("<li> - " + json.records[0].errormessage + "</li>");
//							html.push('</ul>');
//							extraContent = html.join('');
//						}		
//					}
					new Dancik_ConfirmWindow({
						destroyOnClose:true,
						content: msg,
						modal:true,
						color:"blue",
						showAsInfoOnly : true,
						zIndexModal : 12000,
						extraContentHTML : extraContent,
						onConfirm : function() {
							if (_this.popup_options.afterSubmit) {
								_this.popup_options.afterSubmit();
							}
							_this.close();
						}
					}).open();	
			} catch(e) { alert(e.message); }
		});		
	}	
});

(function(){
	Dancik.addScriptFile("../../dws/js-tools/Dancik-Model.js");
	Dancik.addScriptFile("../../dws/js-tools/ejs.js");
	Dancik.addScriptFile("../../dws/js-components/lists/popup2search.js");
})();