var Main = Object.extend( OM_Main, {
		
	// ---------------------------------------------------------------------------------------------------
	// - Function : Main.initialize(json)
	// --------------------------------------------------------------------------------------------------- 
	initialize: function(json) {
		Main.execute({ 
			parm_Ref : $F('parm_Ref'), 
			parm_Ord : $F('parm_Ord'), 
			option : 'getOrderDates'
		});
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function : Main.chgDate()
	// --------------------------------------------------------------------------------------------------- 
	chgDate: function() {
		Main.execute({ 
			parm_Ref : $F('parm_Ref'), 
			parm_Ord : $F('parm_Ord'), 
			parm_Shdt : $F('omchgdte'), 
			option : 'updateOrderDates'
		});
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function : Main.execute()
	// --------------------------------------------------------------------------------------------------- 
	execute: function(params) {
		// -- Show the Full-Screen "In-Process" blanket...
		Dancik.Blanket.InProcess.show({ sizeByStretch : true });
		
		params = Object.extend( params, { serviceid : 'addons' }); 
		
		Main.ajax = new Ajax.Request('../jsonservice/OM_WebService/execute', {
			 method: 'get', 
			 parameters: params,	 
			 evalJSON: "force",
			 onSuccess: function(res) {
			 	try {
			 		var json = res.responseJSON;
			 		if (!json) { throw 'EmptyResult'; }
			 		if ( json.errors != null) { throw 'ErrorCaught'; }
				
			 		Main.render(json);
			 		
			 		
			 	} catch(e) {
					var contentHTML = "";
					var extraContentHTML = "";
			 		
			 		if (e == 'ErrorCaught') {
						contentHTML = "The following errors occurred:";
						var html = [];
						json.errors.each( function(msg) { html.push("<div>- " + msg + "</div>") } );
						extraContentHTML = html.join('');
			 		} else if (e == 'EmptyResult') {
						contentHTML = "No results returned.";
			 		} else {
						contentHTML = "Error : Main.execute() :";
						extraContentHTML = "- " + e.message;
			 		}
					Main.open_ErrorWdw({ contentHTML : contentHTML, extraContentHTML : extraContentHTML });
			 		
			 	} finally {
			 	}
		 	},
		 	onComplete: function(res) {
		 		Dancik.Blanket.InProcess.kill();
		 	},
		 	onFailure: Dancik.catchAjaxError
		 });		
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function : Main.render(json)
	// --------------------------------------------------------------------------------------------------- 
	render: function(json) {
		
		var glbl = $H(json.global);
		var hdr = $H(json.header);
		var itms = json.detail;
		
		// -- Global data
		$$('.glblDta').each(function(o) { o.update( glbl.get(o.id) ); });
		
		// -- Header data
		$$('.hdrDta').each(function(o) {
			switch (o.tagName.toLowerCase()) {
				case 'input':
					o.setValue(hdr.get(o.id));
					break;
				default:
					o.update(hdr.get(o.id));
			}
		});
		
		// -- (Shipping) Days of the week...
		$$('.dow').each(function(o) { 
			if ( glbl.get(o.id) == 'Y' ) { o.addClassName('bold'); } 
			if ( glbl.get(o.id+'_r') == 'Y' ) { o.addClassName('nextavailable'); } 
		});
		
		// Items
		Element.update('items');
		if (itms) {
			var html = [];
			var len = itms.length;
			for (var i=0; i<len; i++) {
				html.push("<tr class='" + (itms[i].omred.equals('Y') ? 'err' : '') + "'>");
					html.push("<td class='dtlCell lft'><div class='col1'>" + itms[i].omwarehs + "</div></td>");
					html.push("<td class='dtlCell'><div class='col2'>" + itms[i].omiitem16 + "</div></td>");
					html.push("<td class='dtlCell'><div class='col3'>" + itms[i].omitmnam + "</div></td>");
					html.push("<td class='dtlCell'><div class='col4'>" + itms[i].omsdate + "</div></td>");
					html.push("<td class='dtlCell'><div class='col5'>" + itms[i].omrdate + "</div></td>");
					html.push("<td class='dtlCell'><div class='col6'>" + itms[i].omrtime + "</div></td>");
				html.push("</tr>");
			}
			$('items').update( html.join("") );
		}
		
		// -- If Change Date is passed...
		if (hdr.get('omprocessed') != 'Y'  && hdr.get('omchgdte') != '') {
			Element.show('bttnDiv');
			$('bttn').update("Change date to" + hdr.get('omchgdte'));
		} else {
			Element.hide('bttnDiv');
		}

		// -- If there is an error...
		if (hdr.get('omerror') == 'Y') {
			Element.addClassName('ommsg1', 'err');
			Element.addClassName('ommsg2', 'err');
		} else {
			Element.removeClassName('ommsg1', 'err');
			Element.removeClassName('ommsg2', 'err');
		}
		
		// -- Load labels accordingly...
		if (hdr.get('omwcall') == 'Y') {
			$('Lbl1').update('Shipping and Pickup Dates');
			$('Lbl2').update('Available for Pickup/Shipment');
			$('Lbl4').update('');
			$('Lbl5').update('');
			$('Lbl6').update('');
			  
		} else {
			$('Lbl1').update('Shipping and Receiving Dates');
			$('Lbl4').update('Earliest<br>Ship Date');
			$('Lbl5').update('Earliest<br>Received Date');
			$('Lbl6').update('Approx<br>Time');
		}
	}
});