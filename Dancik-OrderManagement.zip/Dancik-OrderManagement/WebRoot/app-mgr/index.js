/*global Prototype,$,$A,$F,$H,Ajax,Builder,Element,Event,Form,Position,Dancik */
/*jslint browser:true */
// ------------------------------------------------------------------------------------
var Main = Object.extend(OM_Main, {
	ajax: null,
	records: [],
	newSession: [],
	savedParams: null,
	useDetailLevel: false,
	searchType_Mode: 'processed',
	sort_Field: null,
	sort_Direction: null,
	prevSortSrc: null,
	appOptions: null,
	errorWdw: null,
	columnsWdw: null,
	newCustOrdWdw: null,
	loadedView: false,
	currentDetailView: [],
	currentHeaderView: [],
	loadedHeaderView: [],
	loadedDetailView: [],
	settings: {},
	cached_views: {},
	columnControl_HeaderLevel: [],
	columnControl_DetailLevel: [],
	defaultHeaderView: ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9"],
	defaultHeaderList: ["Order Date", "Order#", "Reference#", "Name", "Account#", "Ship Date", "Customer PO#", "Branch", "Warehouse", "Salesperson 1"],
	defaultDetailView: ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50"],
	defaultDetailList: ["Order Date", "Order#", "Reference#", "Line#", "Name", "Item#", "Item Description 1", "Item Description 2", "Quantity Ordered", "Account#", "UOM", "Unit Price", "Line Status", "ISO", "Ship Date", "Customer PO#", "Branch", "Warehouse", "Salesperson 1", "Address 1", "Address 2", "City", "Cross Reference Invoice#", "Cross Reference Order#", "Customer Price List", "ETA Date", "Floor Plan Account#", "Floor Plan Terms Code", "FOB", "Handling Charge Discount", "Initials", "Install", "Job Name", "Job#", "Measure", "Order Handling Code", "Order Type", "Other Tax", "Reason Code", "Salesperson 2", "Ship Via", "State", "State Tax", "Supplier", "Supplier Name", "Terms Code", "Terms Days", "Terms Discount", "Use Floor Plan", "Where Shown", "Zip Code"],
	// ---------------------------------------------------------------------------------------------------
	// - Main.initialize()
	// ---------------------------------------------------------------------------------------------------
	initialize: function () {
		Main.loadFilters();
		Main.loadDetailFilters();
		var _this;
		_this = this;

		var url_params = window.location.search.toQueryParams();
		// -- Upper right menu
		$j('.links > li').bind('mouseover', openSubMenu);
		$j('.links > li').bind('mouseout', closeSubMenu);
		function openSubMenu () {
			$j(this).find('ul').css('visibility', 'visible');
		}
		;
		function closeSubMenu () {
			$j(this).find('ul').css('visibility', 'hidden');
		}
		;
		//PO or other//
		switch (url_params.type) {
			case "PO":
				_this.buildPOMenu();
				break;
			default:
				_this.buildDefaultMenu();
				break;
		}

		Messaging.init("../../dws/");
		// -- Open up the bulletin board.
		if (Main.newSession.length == 0) {
			var bb = new OM_BulletinBoard_Popup();
		}
		Main.newSession = [0, 2];
		// -- Prepare Field Restricter/Formatter...
		var rif = new RestrictedInputForm('Mgr_Filter_Form');
		var frm = new FormFormatter('Mgr_Filter_Form');


		// -- Build validator...
		var testValidator = new Validation('Mgr_Filter_Form', {
			onValidSubmit: function (event) {
				event.stop();
				//console.log("inside init-",Main.currentDetailView);
				Main.submitNewSearch();
			},
			fieldNames: {
				parm_FilterDateOrdered_From: "Order Starting Date",
				parm_FilterDateOrdered_To: "Order To Date",
				parm_FilterDateRequired_From: "Ship Starting Date",
				parm_FilterDateRequired_To: "Ship To Date"
			}
		});

		new Validation("Mgr_Direct_Form_R", {
			onValidSubmit: Main.Orders.gotoOrder,
			fieldNames: {
				parm_ReferenceId: "Reference Number"
			}
		});
		new Validation("Mgr_Direct_Form_O", {
			onValidSubmit: Main.Orders.gotoOrder,
			fieldNames: {
				parm_OrderId: "Order Number"
			}
		});


		$('parm_FilterMfgr').observe('keyup', function (event) {
			var input = Event.element(event),
				key = event.keyCode || event.which;
			if (key == 32 || key == 8 || key == 46 || (key >= 48 && key <= 90) || (key >= 96 && key <= 111) || (key >= 186 && key <= 222)) {
				if ($('parm_FilterMfgr').value.length == $('parm_FilterMfgr').getAttribute('maxlength')) {
					$('parm_FilterColor').focus();
				}
			}

		});
		$('parm_FilterColor').observe('keyup', function (event) {
			var input = Event.element(event),
				key = event.keyCode || event.which;
			if (key == 32 || key == 8 || key == 46 || (key >= 48 && key <= 90) || (key >= 96 && key <= 111) || (key >= 186 && key <= 222)) {
				if ($('parm_FilterColor').value.length == $('parm_FilterColor').getAttribute('maxlength')) {
					$('parm_FilterPattern').focus();
				}
			}
		});
		$('parm_UseDetailLevel_N').observe('click', function (event) {
			Element.select($('Mgr_Filter_Form'), 'tr.detailOnly').each(function (o) {
				Element.hide(o);
			});
			Element.select($('Mgr_Filter_Form'), 'tr.detailAndProcessed').each(function (o) {
				Element.hide(o);
			});
		});
		$('parm_UseDetailLevel_Y').observe('click', function (event) {
			Element.select($('Mgr_Filter_Form'), 'tr.detailOnly').each(function (o) {
				Element.show(o);
			});
			//if detail only AND Processed Only
			if (Main.searchType_Mode == "processed") {
				Element.select($('Mgr_Filter_Form'), 'tr.detailAndProcessed').each(function (o) {
					Element.show(o);
				});
			}
		});

		// -- Resize...
		this.resize();


		// If PO then decorate screen accordingly
		if (url_params.type == "PO") {
			_this.decoratePO();
		}

	},
	buildPOMenu: function () {
		var links, button;

		// -- Build PO Menu from Jquery Vs Prototype...
		Main.appOptions = $App.Utils.po_dropDown($j('#available-options-container'), {
			menuActions: {
				'option-1': function () {
					$j('#available-options-container').removeClass('dws-options-open')
					Main.Orders.createAltOrder('po');
				}
			}
		});

		Main.appOptions = $App.Utils.po_dropDown($j('#available-options-container2'), {
			menuActions: {
				'option-1': function () {
					Main.Orders.createAltOrder('po');
				}
			}
		});


		// Set up Jquery Click On Main Button //
		// Let Prototype continue to handle child options
		$j('#available-options-container').off();
		button = $j('#available-options-container').find('.dws-options-title');
		button.on('click', function () {
			Main.Orders.createAltOrder('po');
		});

		//check for links//
		links = $j('#available-options-container').find('a');
		$j.each(links, function () {
			$j(this).on('click', function () {
				$j('#available-options-container').removeClass('dws-options-open');
				$j(this).attr('href')
				switch ($j(this).attr('href')) {
					//call create new PO//
					case '#option-1':
						Main.Orders.createAltOrder('po');
						break;
					default:
						break;
				}

			});
		});

		//check for links//
		links = $j('#available-options-container2').find('a');
		$j.each(links, function () {
			$j(this).on('click', function () {
				$j('#available-options-container2').removeClass('dws-options-open');
				$j(this).attr('href')
				switch ($j(this).attr('href')) {
					//call create new PO//
					case '#option-1':
						$App.Fire("purchasing_reorder_calc_init", {});
						//      Main.Orders.createAltOrder('po');
						break;
					case '#option-2':
						$App.Fire("purchasing_rules_init", {});
						//      Main.Orders.createAltOrder('po');
						break;
					default:
						break;
				}

			});
		});


	},
	buildDefaultMenu: function () {
		// -- Build Order Options...
		Main.appOptions = new OptionsDropdown('available-options-container', {
			menuActions: {
				'option-1': function () {
					Main.Orders.openNewCustomerOrderWindow();
				},
				'option-2': function () {
					Main.Orders.openNewCustomerOrderWindow('Q');
				},
				'option-3': function () {
					Main.Orders.createAltOrder('po');
				},
				'option-4': function () {
					Main.Orders.createAltOrder('s2s');
				},
				'option-5': function () {
					Main.Orders.openNewCustomerOrderWindow('D');
				},
				'option-6': function () {
					$App.Fire("c3_scheduler", {});
				}
			}

		});
	},
	decoratePO: function () {

		var containerFilters, containerTabs, availableOptions1, links, availableOptions2, containerOrderSection;
		containerFilters = $j('#Mgr_SearchFilters');
		containerTabs = $j('#Mgr_SearchTabsSection');
		containerOrderSection = $j('#Mgr_GotoOrderSection');
		availableOptions1 = $j('#available-options-container');
		availableOptions2 = $j('#available-options-container2');

		$j("#typeOpt_S2S").hide();
		$j("#typeOpt_Customer").hide();
		$j("#parm_FilterOrderType_2").prop("checked", true).attr("enabled", true);
		$j("#parm_FilterOrderType_1").prop("checked", false).attr("disabled", true);
		$j("#parm_FilterOrderType_3").prop("checked", false).attr("disabled", true);

		$j(".po_NotShow").hide();
		$j(".po_Show").show();

		$j('#parm_FilterOrderType_2').on('click', function () {
			$j(this).prop("checked", true);
		});

		//Set up Clicks on New Purchase Order Button//
		availableOptions1.find('.dws-options-handle').off();
		availableOptions1.find('.dws-options-handle').on('click', function () {
			availableOptions1.toggleClass('dws-options-open')
			links = availableOptions1.find('a');
			//Dynamically remove menu if no options//
			if (links.length === 0)
			{
				availableOptions1.removeClass('dws-options-open')
			}
		});

		//Set up Clicks on PO Available Options//
		availableOptions2.find('.dws-options-handle').off();
		availableOptions2.find('.dws-options-handle').on('click', function () {
			availableOptions2.toggleClass('dws-options-open')
			links = availableOptions2.find('a');
			//Dynamically remove menu if no options//
			if (links.length === 0)
			{
				availableOptions2.removeClass('dws-options-open')
			}
		});

		//Set up Clicks on PO Available Options//
		availableOptions2.find('.dws-options-title').off();
		availableOptions2.find('.dws-options-title').on('click', function () {
			availableOptions2.toggleClass('dws-options-open')
			links = availableOptions2.find('a');
			//Dynamically remove menu if no options//
			if (links.length === 0)
			{
				availableOptions2.removeClass('dws-options-open')
			}
		});


		$j('body').click(function (event) {
			if (!$j(event.target).closest('#available-options-container').length) {
				$j('#available-options-container').removeClass('dws-options-open');
			}
		});

		$j('body').click(function (event) {
			if (!$j(event.target).closest('#available-options-container2').length) {
				$j('#available-options-container2').removeClass('dws-options-open');
			}
		});

		//Add purchasing order class to po_options for screen manipulation//
		$j('#po_options').addClass('purchase-order');

		//set height on button bar left and hide po checkbox
		containerFilters.find('#FilterSectionTitles_2').hide();
		containerFilters.find('#Mgr_FilterSection').attr("style", 'position:absolute; top:67px; bottom:30px; left:0; right:0; overflow-x:hidden; overflow-y:auto;');

	},
	loadFilters: function () {
		//Filter.myFilters = [];
		//Filter.publicFilters = [];
		var _this = this,
			selectedView = "";
		if (Main.useDetailLevel) {
			selectedView = "ordermanagerd";
		}
		else {
			selectedView = "ordermanagerh";
		}
		var naj = new Ajax.Request("../../fm/service/FM_Service/getFilters", {
			method: "get",
			parameters: {
				output: "JSON",
				parm_FileName: selectedView
			},
			evalJSON: "force",
			onSuccess: function (res) {
				var json = res.responseJSON;
				//_this.parseOrder(json);
				var new_records = [];
				//console.log('loadViews - json', json.records);
				//	Main.cached_views[data.file] = json.records;
				$j.each(json.records, function (index, view) {
					//parse out the filter_values to objects
					view.filter_values = $j.parseJSON(view.filter_values);
					if (view.filter_values.isDefault == true && view.user != "DANCIK") {
						if (view.user !== "DANCIK") {
							var new_view = {
								id: view.keyid,
								description: view.description,
								is_default: (view.filter_values.isDefault === true || view.filter_values.isDefault == 'Y'),
								is_private: view['private'] == 'Y',
								user: view.user,
								sort: view.filter_values.sort,
								filters: view.filter_values.set,
								fm_file: view.file_name,
								is_Dancik: view['private'] == '', //pp1
								is_public: view['private'] == 'N'  //pp1
							};
							new_records.push(new_view);
							//console.log("new records",new_records);
							Main.currentHeaderView = new_records[0].sort;
							Main.currentDetailView = Main.defaultDetailView;
						}
					}
				});
				if (Main.currentHeaderView == "") {
					Main.currentHeaderView = Main.defaultHeaderView;
					Main.currentDetailView = Main.defaultDetailView;
				}


			},
			onFailure: function (res) {
			}
		});
	},
	loadDetailFilters: function () {
		//Filter.myFilters = [];
		//Filter.publicFilters = [];
		var _this = this,
			selectedView = "ordermanagerd";
		var naj = new Ajax.Request("../../fm/service/FM_Service/getFilters", {
			method: "get",
			parameters: {
				output: "JSON",
				parm_FileName: selectedView
			},
			evalJSON: "force",
			onSuccess: function (res) {
				var json = res.responseJSON;
				//_this.parseOrder(json);
				var new_records = [];
				//console.log('loadViews - json', json.records);
				//	Main.cached_views[data.file] = json.records;
				$j.each(json.records, function (index, view) {
					//parse out the filter_values to objects
					view.filter_values = $j.parseJSON(view.filter_values);
					if (view.filter_values.isDefault == true && view.user != "DANCIK") {
						var new_view = {
							id: view.keyid,
							description: view.description,
							is_default: (view.filter_values.isDefault === true || view.filter_values.isDefault == 'Y'),
							is_private: view['private'] == 'Y',
							user: view.user,
							sort: view.filter_values.sort,
							filters: view.filter_values.set,
							fm_file: view.file_name,
							is_Dancik: view['private'] == '', //pp1
							is_public: view['private'] == 'N'  //pp1
						};
						new_records.push(new_view);
						//console.log("new records",new_records);
						Main.currentDetailView = new_records[0].sort;
					}
				});
				if (Main.currentDetailView == "") {
					Main.currentDetailView = Main.defaultDetailView;
				}
				_this.loadColumns();
			},
			onFailure: function (res) {
			}
		});
	},
	parseOrder: function (data) {
		//console.log('parse Order', data);
	},
	loadColumns: function () {
		Dancik.Blanket.InProcess.show({message: 'Retrieving Settings', sizeByStretch: true, zIndex: 100});
		new Ajax.Request('../jsonservice/OM_WebService/execute', {
			method: 'get',
			parameters: {
				serviceid: 'manager',
				option: 'init',
				random: new Date().getTime()
			},
			evalJSON: "force",
			onInteractive: function (res) {
				Dancik.Blanket.InProcess.setMessage("Building View");
			},
			onSuccess: function (res) {
				try {
					var json = res.responseJSON;
					if (!json) {
						throw 'EmptyResult';
					}

					// -- Populate the 2 types of column results...
					var len = json.columns.length;
					for (var i = 0; i < len; i++) {
						// -- Avoid loading the 'Details Only' columns into the Header Level columns...
						if (!json.columns[i].detaillevelonly.equals('Y')) {
							Main.columnControl_HeaderLevel[Main.columnControl_HeaderLevel.length] = json.columns[i];
						}
						Main.columnControl_DetailLevel[Main.columnControl_DetailLevel.length] = json.columns[i];
					}

					// -- Establish settings from configuration...
					Main.setSettings(json.settings);

					if (Main.settings.multi_unit_customer == 'Y') {
						$j('li.c3scheduler').show();
					}

					// -- Check ROLLOVER...
					if (!Main.settings.use_rollover.equals('Y')) {
						Element.select($('Mgr_GotoOrderSection'), '.rolloveritem').each(function (o) {
							Element.hide(o);
						});
					}
					// -- Headings...
					Main.loadHeadings();

				} catch (e) {
					var contentHTML = "";
					var extraContentHTML = "";

					if (e == 'EmptyResult') {
						contentHTML = "The Order Manager configuration is not properly setup.</div><div style='margin-top:15px;'>Please contact Dancik for further assistance.";
					} else {
						contentHTML = "Error : Main.initialize() :";
						extraContentHTML = "- " + e.message;
					}
					Main.open_ErrorWdw({
						contentHTML: contentHTML,
						extraContentHTML: extraContentHTML,
						afterClose: function () {
							location.href = '../main.jsp';
						}
					});

				} finally {
					Dancik.Blanket.InProcess.kill();
				}

			},
			onFailure: Dancik.catchAjaxError
		});
	},
	// ---------------------------------------------------------------------------------------------------
	// - Main.resize() - Contians static content that needs resizing or repositionin, onResize of window.
	// ---------------------------------------------------------------------------------------------------
	resize: function () {

		// -- Determine size of IFRAME...
		$('Main_OrderIframe').style.height = Element.getHeight('Mgr_OrderSection') + 'px';

		if (this.newCustOrdWdw) {
			this.newCustOrdWdw.centerWindow();
		}
	},
	// ---------------------------------------------------------------------------------------------------
	// - Main.loadHeadings()
	// ---------------------------------------------------------------------------------------------------
	loadHeadings: function () {
		$('Mgr_SearchHeaders_THEAD').update();
		var html = [],
			_this = this;
		html.push("<tr>");
		var cc = [];
		if (Main.useDetailLevel) {
			//console.log('inside using Detail Level - currentDetailView -', Main.currentDetailView);
			$j.each(Main.currentDetailView, function (index, column) {
				Main.columnControl_DetailLevel[column].viewable = "Y";
				//console.log(Main.columnControl_DetailLevel[index]);
			});
			cc = this.columnControl_DetailLevel.clone();
		} else {
			$j.each(Main.columnControl_HeaderLevel, function (index, column) {
				Main.columnControl_HeaderLevel[index].viewable = "N";
			});
			$j.each(Main.currentHeaderView, function (index, column) {

				Main.columnControl_HeaderLevel[column].viewable = "Y";
				Main.columnControl_HeaderLevel[column].vieworder = index;

			});
			cc = this.columnControl_HeaderLevel.clone();
			//console.log("cc",cc);
		}
		var len = cc.length;
		//console.log(cc);
		//			for (var i=0; i<len; i++) {
		//				if (cc[i].viewable.equals('Y')) {
		//					console.log(cc[i].vieworder);
		//					html.push("<th id='col-"+i+"' class='EXCEL-Header sortable'> <div class='mgr-col-" + cc[i].id + "' style='width:" + cc[i].width + "px;' onclick='Main.resort(this);'>" + cc[i].heading.replace(/\[br\]/,"<br/>") + "</div></th>");
		//				}
		//			}
		var viewToUse = [];
		if (Main.useDetailLevel) {
			viewToUse = Main.currentDetailView;
		}
		else {
			viewToUse = Main.currentHeaderView;
		}
		$j.each(viewToUse, function (index, val) {
			if (cc[val].viewable.equals('Y')) {
				html.push("<th id='col-" + val + "' class='EXCEL-Header sortable'> <div class='mgr-col-" + cc[val].id + "' style='width:" + cc[val].width + "px;' onclick='Main.resort(this);'>" + cc[val].heading.replace(/\[br\]/, "<br/>") + "</div></th>");
			}
		});


		html.push("<th><div class='mgr-Extra'>&nbsp;</div></th>");
		html.push("</tr>");
		$('Mgr_SearchHeaders_THEAD').update(html.join(''));

		if ($('Mgr_SearchHeaders_THEAD').getWidth() > 0) {
			$('Mgr_Search-XScroll-Inner').style.width = ($('Mgr_SearchHeaders_THEAD').getWidth()) + "px";
		}

		$('Mgr_Search-XScroll').scrollLeft = 1;
		$('Mgr_SearchHeaders').scrollLeft = 1;
		$('Mgr_SearchData').scrollLeft = 1;
	},
	// ---------------------------------------------------------------------------------------------------
	// - Main.clearFilters()
	// ---------------------------------------------------------------------------------------------------
	clearFilters: function () {
		Element.select($('Mgr_Filter_Form'), 'input[type="text"]').each(function (o) {
			o.value = '';
		});
		Element.select($('Mgr_Filter_Form'), 'input[type="checkbox"]').each(function (o) {
			o.checked = false;
		});
		Element.select($('Mgr_Filter_Form'), 'div.viewOnly').each(function (o) {
			o.update();
		});

		$('parm_FilterRetailId').value = '';
	},
	// ---------------------------------------------------------------------------------------------------
	// - Main.toggleSearchType()
	// ---------------------------------------------------------------------------------------------------
	toggleSearchType: function (element, mode) {
		Element.select($('Mgr_SearchTabsSection'), 'div.dws-tabs').each(function (o) {
			Element.removeClassName(o, 'selected').addClassName('unselected');
		});

		Main.searchType_Mode = mode;
		Element.addClassName(Element.up(element, 'DIV'), 'selected').removeClassName('unselected');
		if (mode.equals('processed')) {
			Element.select($('Mgr_Filter_Form'), 'tr.processedOnly').each(function (o) {
				Element.show(o);
			});
			if ($j('input[name=parm_UseDetailLevel]:checked', '#Mgr_Filter_Form').val() == "Y") {
				Element.select($('Mgr_Filter_Form'), 'tr.detailAndProcessed').each(function (o) {
					Element.show(o);
				});
			}
		} else {
			Element.select($('Mgr_Filter_Form'), 'tr.processedOnly').each(function (o) {
				Element.hide(o);
			});
			Element.select($('Mgr_Filter_Form'), 'tr.detailAndProcessed').each(function (o) {
				Element.hide(o);
			});
		}

		this.records = [];
		$('Mgr_SearchData_TBODY').update();
		$('Mgr_SearchDataOptions_TBODY').update();
		Element.hide('Mgr_MoreBttn');
		$('Mgr_QuerySize').update();

		this.toggleFilters('show');
	},
	// ---------------------------------------------------------------------------------------------------
	// - Main.toggleFilters()
	// ---------------------------------------------------------------------------------------------------
	toggleFilters: function (option) {
		if (!option) {
			option = Element.visible('Mgr_SearchFilters') ? 'hide' : 'show';
		}

		if (option.equals('hide')) {
			Element.hide($('Mgr_SearchFilters'));
			$('Mgr_SearchResults').style.left = '5px';
			Element.hide('ToggleFilters_ExpandImg');
			Element.show('ToggleFilters_CollapseImg');
		} else {
			Element.show($('Mgr_SearchFilters'));
			$('Mgr_SearchResults').style.left = '375px';
			Element.show('ToggleFilters_ExpandImg');
			Element.hide('ToggleFilters_CollapseImg');
		}
	},
	// ---------------------------------------------------------------------------------------------------
	// - Main.submitNewSearch()
	// ---------------------------------------------------------------------------------------------------
	submitNewSearch: function () {
		// -- Re-initialze variables...
		//console.log(Main.currentDetailView);
		//console.log("submit new search")
		this.sort_Field = '';
		this.sort_Direction = '';

		this.savedParams = Form.serialize('Mgr_Filter_Form', true);

		this.useDetailLevel = $('parm_UseDetailLevel_Y').checked;

		this.loadHeadings();

		this.reload();
	},
	// ---------------------------------------------------------------------------------------------------
	// - Main.reload()
	// ---------------------------------------------------------------------------------------------------
	reload: function () {
		// -- Avoid trying to reload, when a previous search had not been executed...
		if (!this.savedParams) {
			return;
		}

		this.records = [];
		$('Mgr_SearchData_TBODY').update();
		$('Mgr_SearchDataOptions_TBODY').update();

		$('Mgr_Search-XScroll').scrollLeft = 1;
		$('Mgr_SearchHeaders').scrollLeft = 1;
		$('Mgr_SearchData').scrollLeft = 1;

		this.toggleFilters('hide');
		this.populate();
	},
	// ---------------------------------------------------------------------------------------------------
	// - Main.moreRecords()
	// ---------------------------------------------------------------------------------------------------
	moreRecords: function () {
		this.populate();
	},
	// ---------------------------------------------------------------------------------------------------
	// - Main.populate()
	// ---------------------------------------------------------------------------------------------------
	populate: function () {
		//console.log("populate function");
		//console.log(Main.useDetailLevel);
		// -- Avoid multi-loading...
		Dancik.abortAjax(Main.ajax);

		// -- Prepare to start search...
		$('Mgr_QuerySize').update();
		Element.hide('Mgr_MoreBttn');
			// -- Show the Full-Screen "In-Process" blanket...
		Dancik.Blanket.InProcess.show({ message : 'Retrieving Records', sizeByStretch : true, zIndex : 100 });

		// -- Build parameters...
		var params = Object.extend(this.savedParams, {
			parm_SearchType: Main.searchType_Mode,
			parm_RowsRetrieved: Main.records.length,
			parm_SortField: Main.sort_Field,
			parm_SortDirection: Main.sort_Direction,
			parm_RecordCount: $F('parm_RecordCount')
		});


		// -- Execute search...
		Main.ajax = new Ajax.Request('../jsonservice/OrderManager_WebService/orderSearch', {
			method: 'get',
			parameters: params,
			evalJSON: "force",
			onInteractive: function (res) {
				Dancik.Blanket.InProcess.setMessage("Building Table");
			},
			onSuccess: function (res) {
				try {
					var url_params = window.location.search.toQueryParams();
					var json = res.responseJSON;
					if (!json) {
						throw 'EmptyResult';
					}
					if (json.errors) {
						throw 'ErrorCaught';
					}

					if (json.records) {
						var html = [];
						var htmlOpts = [];

						var cc = [];
						if (Main.useDetailLevel) {
							cc = Main.columnControl_DetailLevel.clone();
						} else {
							$j.each(Main.columnControl_HeaderLevel, function (index, column) {
								Main.columnControl_HeaderLevel[index].viewable = "N";

							});
							$j.each(Main.currentHeaderView, function (index, column) {
								//console.log("view shown",column);
								Main.columnControl_HeaderLevel[column].viewable = "Y";
								Main.columnControl_HeaderLevel[column].vieworder = index;
								//console.log("Header",Main.columnControl_HeaderLevel[index]);
							});
							cc = Main.columnControl_HeaderLevel.clone();
						}
						var lenCC = cc.length;

						var len = json.records.length;
						for (var i = 0; i < len; i++) {
							Main.records[  Main.records.length ] = json.records[i];
							var hashRecord = $H(json.records[i]);

							htmlOpts.push("<tr>");
							htmlOpts.push("<td class='EXCEL-Cell'>");
							htmlOpts.push("<div class='mgr-col-opts'>");

							switch (url_params.type) {
								case "PO":
									htmlOpts.push("<img class='loneOption' src='../../dws/images/option_arrow.png' class='img' alt='Available Options' onclick='Main.Options.poOpen(this);'>");
									break;
								default:
									htmlOpts.push("<img class='loneOption' src='../../dws/images/option_arrow.png' class='img' alt='Available Options' onclick='Main.Options.open(this);'>");
									break;
							}

							htmlOpts.push("</div>");
							htmlOpts.push("</td>");
							htmlOpts.push("</tr>");


							html.push("<tr>");

							var viewToUse = [];
							if (Main.useDetailLevel) {
								viewToUse = Main.currentDetailView;
							}
							else {
								viewToUse = Main.currentHeaderView;
							}

							$j.each(viewToUse, function (index, val) {
								if (cc[val].viewable.equals('Y')) {
									html.push("<td class='EXCEL-Cell'>");
									html.push("<div class='mgr-col-" + cc[val].id + "' style='text-align:" + (cc[val].alignment || "center") + "; width:" + cc[val].width + "px;'>");
									html.push("<span>" + hashRecord.get(cc[val].id) + "</span>");
									if (cc[val].id == 'orderid') {
										html.push(' <span><img src="../images/icons/creditHold_sm.png" alt="Credit Hold" title="Credit Hold" style="visibility:' + (hashRecord.get('creditholdflag') == 'Y' ? 'visible' : 'hidden') + ';"/></span>');
										html.push(' <span><img src="../images/icons/invoice_sm.png" alt="Being Invoiced" title="Being Invoiced" style="visibility:' + (hashRecord.get('beinginv') == 'Y' ? 'visible' : 'hidden') + ';"/></span>');
									}
									html.push("</div>");
									html.push("</td>");
								}
							});
							html.push("</tr>");

						}
						$('Mgr_SearchData_TBODY').insert({
							bottom: html.join("")
						});
						$('Mgr_SearchDataOptions_TBODY').insert({
							bottom: htmlOpts.join("")
						});

						$('Mgr_QuerySize').update(Main.records.length + " of " + json.querysize);

						$('Mgr_Search-XScroll-Inner').style.width = ($('Mgr_SearchHeaders_THEAD').getWidth()) + "px";

						$('Mgr_SearchHeaders').scrollLeft = $('Mgr_Search-XScroll').scrollLeft;
						$('Mgr_SearchData').scrollLeft = $('Mgr_Search-XScroll').scrollLeft;
					} else {
						$('Mgr_SearchData_TBODY').update("<tr><td style='padding:5px;'>No records matched your search criteria.</td></tr>");
						Main.toggleFilters('show');
					}


					// -- Determine if the Query has maxed out, and the More button needs to be disabled...
					if (Main.records.length < json.querysize) {
						Element.show('Mgr_MoreBttn');
					}

				} catch (e) {
					var errHtml = [];
					if (e == 'ErrorCaught') {
						json.errors.each(function (msg) {
							errHtml.push("<div style='margin-bottom:10px;'>- " + msg + "</div>")
						});
						Main.open_ErrorWdw({
							contentHTML: "The following errors occurred:",
							extraContentHTML: errHtml.join('')
						});
					} else if (e == 'EmptyResult') {
					} else {
						Main.open_ErrorWdw({
							contentHTML: "<div>Error : Main.reload() :</div>",
							extraContentHTML: "<div>- " + e.message + "</div>"
						});
					}
					Main.toggleFilters('show');
				} finally {
					Dancik.Blanket.InProcess.kill();
				}

			},
			onFailure: Dancik.catchAjaxError
		}
		);

	},
	// ---------------------------------------------------------------------------------------------------
	// - Main.repopulate()
	// ---------------------------------------------------------------------------------------------------
	repopulate: function () {
		$('Mgr_SearchDataOptions_TBODY').update();
		$('Mgr_SearchData_TBODY').update();
		var html = [];
		var htmlOpts = [];

		var len = Main.records.length;
		for (var i = 0; i < len; i++) {
			var hashRecord = $H(Main.records[i])

			htmlOpts.push("<tr>");
			htmlOpts.push("<td class='EXCEL-Cell'>");
			htmlOpts.push("<div class='mgr-col-opts'>");
			htmlOpts.push("<img class='loneOption' src='../../dws/images/option_arrow.png' class='img' alt='Available Options' onclick='Main.Options.open(this);''>");
			htmlOpts.push("</div>");
			htmlOpts.push("</td>");
			htmlOpts.push("</tr>");


			html.push("<tr>");
			var cc = [];
			if (Main.useDetailLevel) {
				cc = this.columnControl_DetailLevel.clone();
			} else {
				$j.each(Main.columnControl_HeaderLevel, function (index, column) {
					Main.columnControl_HeaderLevel[index].viewable = "N";
				});
				$j.each(Main.currentHeaderView, function (index, column) {
					Main.columnControl_HeaderLevel[column].viewable = "Y";
					Main.columnControl_HeaderLevel[column].vieworder = index;
				});
				cc = this.columnControl_HeaderLevel.clone();
			}

			var len2 = cc.length;
			for (var j = 0; j < len2; j++) {
				if (cc[j].viewable.equals('Y')) {
					html.push("<td class='EXCEL-Cell'>");
					html.push("<div class='mgr-col-" + cc[j].id + "' style='text-align:" + (cc[j].alignment || "center") + "; width:" + cc[j].width + "px;'>");
					html.push(hashRecord.get(cc[j].id));

					html.push("</div>");
					html.push("</td>");
				}
			}
			html.push("</tr>");

		}
		$('Mgr_SearchData_TBODY').insert({
			bottom: html.join("")
		});
		$('Mgr_SearchDataOptions_TBODY').insert({
			bottom: htmlOpts.join("")
		});

		$('Mgr_Search-XScroll-Inner').style.width = ($('Mgr_SearchHeaders_THEAD').getWidth()) + "px";

	},
	// ---------------------------------------------------------------------------------------------------
	// - Main.resort()
	// ---------------------------------------------------------------------------------------------------
	resort: function (element) {
		// -- Avoid trying to reload, when a previous search had not been executed...
		if (!this.savedParams) {
			return;
		}

		var o = Element.up(element, 'TH');
		var i = o.cellIndex;

		var column = null;
		if (Main.useDetailLevel) {
			column = this.columnControl_DetailLevel[i];
		} else {
			column = this.columnControl_HeaderLevel[i];
		}

		if (!Main.prevSortSrc) {
			Main.sort_Direction = 'asc';
		} else {
			Main.prevSortSrc.removeClassName("selected");
			Main.prevSortSrc.removeClassName("(asc|desc)");

			o.removeClassName("selected");
			o.removeClassName("(asc|desc)");

			if (Main.prevSortSrc == o) {
				if (Main.sort_Direction.equals('asc')) {
					Main.sort_Direction = 'desc';
				} else {
					Main.sort_Direction = 'asc';
				}
			} else {
				Main.sort_Direction = 'asc';
			}
		}
		o.addClassName(Main.sort_Direction);
		o.addClassName("selected");

		Main.prevSortSrc = o;

		Main.sort_Field = column.sortfield.isEmpty() ? column.id : column.sortfield;
		Main.reload();
	},
	// ***********************************************************************************************
	//	Main.Orders
	// ***********************************************************************************************
	Orders: {
		companyWdw: null,
		// ---------------------------------------------------------------------------------------------------
		// - Main.Orders.closeOrderFrame()
		// ---------------------------------------------------------------------------------------------------
		closeOrderFrame: function (resetSearch) {
			Element.hide('Mgr_OrderSection');
			Element.show('Mgr_GotoOrderSection');
			Element.show('Main_Canvas');
			$('Main_OrderIframe').src = "about:blank";

			// -- Reset 'direct' parameters...
			$('parm_OrderId').value = '';
			$('parm_ReferenceId').value = '';
			// -- Check to see if a full reset, including the search results, should be applied...
			if (resetSearch) {
				Main.records = [];
				$('Mgr_SearchData_TBODY').update();
				$('Mgr_SearchDataOptions_TBODY').update();
				Element.hide('Mgr_MoreBttn');
				$('Mgr_QuerySize').update();

				Main.toggleFilters('show');
			}
		},
		// -------------------------------------------------------------------------------
		// -- Main.Orders.openOrder()
		// -------------------------------------------------------------------------------
		openOrder: function (params) {
			//console.log('openOrder - index.js', params);
			//add multi unit flag
			$j.extend(params, {
				multi_unit_customer: Main.settings.multi_unit_customer,
				type: params.type
			});

			Element.hide('Mgr_GotoOrderSection');
			Element.hide('Main_Canvas');
			Element.show('Mgr_OrderSection');

			$('Main_OrderIframe').style.height = Element.getHeight('Mgr_OrderSection') + 'px';
			$('Main_OrderIframe').src = "../app-mgr/order.jsp?om=&" + Object.toQueryString(params);
		},
		// ---------------------------------------------------------------------------------------------------
		// - Main.Orders.gotoOrder()
		// ---------------------------------------------------------------------------------------------------
		gotoOrder: function (event) {
			//console.log("gotoorder1 - event", event);
			Event.stop(event);
			var form = Event.element(event);

			// -- Show the Full-Screen "In-Process" blanket...
			Dancik.Blanket.InProcess.show({
				sizeByStretch: true,
				zIndex: 100
			});

			//var params = Object.extend( Form.serialize('Mgr_Direct_Form', true), { parm_GotoType : type } );
			var params = form.serialize(true);


			// -- Avoid multi-loading...
			Dancik.abortAjax(Main.ajax);
			Main.ajax = new Ajax.Request('../jsonservice/OrderManager_WebService/validateOrderSelection', {
				method: 'get',
				parameters: params,
				evalJSON: "force",
				onInteractive: function (res) {
				},
				onSuccess: function (res) {
					var errHtml = [];

					try {
						var json = res.responseJSON;
						if (!json) {
							throw 'Continue';
						}
						if (!json.errors && !json.records) {
							throw 'Continue';
						}

						if (json.errors) {
							json.errors.each(function (msg) {
								errHtml.push("<div>- " + msg + "</div>")
							});
							Main.open_ErrorWdw({
								contentHTML: "The following errors occurred:",
								extraContentHTML: errHtml.join('')
							});
						} else {
							Main.MultiOrders.openWindow(json.records);
						}

					} catch (e) {
						if (e == 'Continue') {
							Main.Orders.openOrder(params);
						} else {
							Main.open_ErrorWdw({
								contentHTML: "<div>Error : Main.Orders.gotoOrder() :</div>",
								extraContentHTML: "<div>- " + e.message + "</div>"
							});

						}
					} finally {
						Dancik.Blanket.InProcess.kill();
					}

				},
				onFailure: Dancik.catchAjaxError
			});
		},
		// -------------------------------------------------------------------------------
		// -- Main.Orders.openNewCustomerOrderWindow()
		// -------------------------------------------------------------------------------
		openNewCustomerOrderWindow: function (orderType) {
			var params = {
				parm_OrderType: orderType
			};
			//if OrderType exist AND equals "Q" then 'Quote Entry',else 'Order Entry'.  OR   equals "D"
			if (!orderType) {
				var ttl = "Order Entry";
			}
			else {
				var ttl = (orderType && orderType.equals("Q")) ? 'Quote Entry' : 'Order Entry' || (orderType && orderType.equals("D")) ? 'Direct Ship Order' : 'Order Entry';
			}

			// -- Make sure window is built and customized...
			this.newCustOrdWdw = new OM_PopupWindow({
				title: ttl,
				style: {
					zIndex: '10'
				},
				contentHTML: "<div id='NewCustomerOrderWindow' style='position:relative; overflow:hidden; background-color:#fff; height:400px; width:839px;'>" +
					"<iframe id='NewCustomerOrderWindow_IFRAME' name='NewCustomerOrderWindow_IFRAME' src='newCustomerOrder.jsp?" + Object.toQueryString(params) + "' frameBorder='0' style='width:835px; height:400px;'></iframe>" +
					"</div>",
				afterClose: function () {
				},
				modal: true
			});

			if ($('NewCustomerOrderWindow_IFRAME').contentWindow.Main) {
				$('NewCustomerOrderWindow_IFRAME').contentWindow.Main.CustomerSearch.openWindow();
			}
			this.newCustOrdWdw.open();
		},
		// -------------------------------------------------------------------------------
		// -- Main.Orders.closeNewCustomerOrderWindow()
		// -------------------------------------------------------------------------------
		closeNewCustomerOrderWindow: function () {
			this.newCustOrdWdw.close();
			this.newCustOrdWdw = null;
		},
		// -------------------------------------------------------------------------------
		// -- Main.Orders.createAltOrder()
		// -------------------------------------------------------------------------------
		createAltOrder: function (type, company) {
			// -- Build parameters...
			var params = {
				ordertype: type
			};
			if (company) {
				params = Object.extend(params, {
					parm_NewOrder_Company: company
				});
			}
			// -- Avoid multi-loading...
			Dancik.abortAjax(Main.ajax);
			Main.ajax = new Ajax.Request('../jsonservice/OrderManager_WebService/newOrder_VnB', {
				method: 'post',
				parameters: params,
				evalJSON: "force",
				onSuccess: function (res) {

					try {
						var json = res.responseJSON;
						if (!json) {
							throw 'EmptyResult';
						}
						if (json.errors) {
							throw 'ErrorCaught';
						}
						if (!json.mode) {
							throw 'NoMode';
						}

						// -- ? -> A Company is required...
						if (json.mode.equals("?")) {
							Main.Orders.altOrder_CompanySelection(type);
						} else {
							Main.Orders.openOrder({
								parm_ReferenceId: json.reference,
								neworder: true
							});
						}

					} catch (e) {
						var errHtml = [];
						if (e == 'ErrorCaught') {
							json.errors.each(function (msg) {
								errHtml.push("<div style='margin-bottom:10px;'>- " + msg + "</div>")
							});
							Main.open_ErrorWdw({
								contentHTML: errHtml.join('')
							});

						} else if (e == 'EmptyResult') {
						} else if (e == 'NoMode') {
						} else {
							Main.open_ErrorWdw({
								contentHTML: "<div>Error : Main.Orders.createPurchaseOrder() :</div>",
								extraContentHTML: "<div>- " + e.message + "</div>"
							});
						}
					} finally {
					}

				},
				onFailure: Dancik.catchAjaxError
			});
		},
		// -------------------------------------------------------------------------------
		// -- Main.Orders.altOrder_CompanySelection()
		// -------------------------------------------------------------------------------
		altOrder_CompanySelection: function (type) {
			// -- Check to see if it already exists...
			if (!Main.Orders.companyWdw) {
				Main.Orders.companyWdw = new OM_AltOrderCompanyWindow(type)
			} else {
				Main.Orders.companyWdw.open(type);
			}
		}
	},
	// ***********************************************************************************************
	//	Main.Options
	// ***********************************************************************************************
	Options: {
		i: -1,
		/** -------------------------------------------------------------------------
		 *    Main.Options.open :
		 *   ------------------------------------------------------------------------- */
		open: function (element) {
			var parentElement = Element.up(element, 'TR');
			parentElement.addClassName("selected");

			this.i = parentElement.rowIndex;
			var o = Main.records[this.i];


			Main.build_OptionsWdw();
			Main.optionsWdw.removeOptions();

			Main.optionsWdw.addOption({
				title: "Go To Order",
				icon: '../../dws/images/page_go.png',
				action: function () {
					Main.Options.gotoOrder();
				}
			});
			Main.optionsWdw.addOption({
				title: 'View Order Header',
				icon: '../../dws/images/viewDisplay.png',
				action: function () {
					Main.Options.gotoHeader();
				}
			});
			Main.optionsWdw.addOption({
				title: 'Installation Scheduler',
				icon: '../images/icons/orderDate.png',
				action: function () {
					Main.Options.installationScheduler();
				}
			});

			if ($App.Controller("Config").getConfig().user.allowAccessToTheUpdateOrderStatusAndShippingDataProgram) {
				Main.optionsWdw.addOption({
					title: 'Order Status',
					icon: '../images/icons/orderDate.png',
					action: function () {
						$App.Fire("order-status", {
							referenceid: o.referenceid,
							orderid: o.orderid
						});
					}
				});
			}

			// -- If not allowed to Print, when in Inquiry mode...
			if (Main.settings.allow_to_orderinquiry_toprint == 'Y') {
				Main.optionsWdw.addOption({
					title: 'Print',
					icon: '../../dws/images/printer.png',
					action: function () {
						Main.Options.openPrintWindow();
					}
				});
			}

			Main.optionsWdw.open(element);

		},
		poOpen: function (element) {
			var parentElement = Element.up(element, 'TR');
			parentElement.addClassName("selected");

			this.i = parentElement.rowIndex;
			var o = Main.records[this.i];


			Main.build_OptionsWdw();
			Main.optionsWdw.removeOptions();

			Main.optionsWdw.addOption({
				title: "Go To Order",
				icon: '../../dws/images/page_go.png',
				action: function () {
					Main.Options.gotoOrder();
				}
			});
			Main.optionsWdw.addOption({
				title: 'View Order Header',
				icon: '../../dws/images/viewDisplay.png',
				action: function () {
					Main.Options.gotoHeader();
				}
			});

			if ($App.Controller("Config").getConfig().user.allowAccessToTheUpdateOrderStatusAndShippingDataProgram) {
				Main.optionsWdw.addOption({
					title: 'Order Status',
					icon: '../images/icons/orderDate.png',
					action: function () {
						$App.Fire("order-status", {
							referenceid: o.referenceid,
							orderid: o.orderid
						});
					}
				});
			}

			// -- If not allowed to Print, when in Inquiry mode...
			if (Main.settings.allow_to_orderinquiry_toprint == 'Y') {
				Main.optionsWdw.addOption({
					title: 'Print',
					icon: '../../dws/images/printer.png',
					action: function () {
						Main.Options.openPrintWindow();
					}
				});
			}

			Main.optionsWdw.open(element);

		},
		/** -------------------------------------------------------------------------
		 *    Main.Options.gotoOrder :
		 *   ------------------------------------------------------------------------- */
		gotoOrder: function () {
			//console.log("gotoOrder2")
			//console.log("this.i - ",this);
			if (this.i == -1) {
				return;
			}
			var o = Main.records[this.i];

			Main.Orders.openOrder({
				parm_ReferenceId: o.referenceid,
				parm_OrderId: (o.orderid.equals('N/A') ? '' : o.orderid)
			});
		},
		gotoOrderSplit: function (referenceid, orderid) {
			//console.log("gotoOrder3")
			Main.Orders.openOrder({
				parm_ReferenceId: referenceid,
				parm_OrderId:  orderid
			});
		},
		// -------------------------------------------------------------------------------
		// --	Main.Options.openPrintWindow :
		// -------------------------------------------------------------------------------
		openPrintWindow: function () {
			if (this.i == -1) {
				return;
			}
			var o = Main.records[this.i];

			new PrintOrderOptions_Popup({
				parm_referenceid: o.referenceid,
				parm_orderid: (o.orderid.equals('N/A') ? '' : o.orderid),
				fromEndOrder: false,
				forUnprocessedOrder: (o.orderid.equals('N/A'))
			});
		},
		// -------------------------------------------------------------------------------
		// -- Main.Options.installationScheduler()
		// -------------------------------------------------------------------------------
		installationScheduler: function () {
			if (this.i == -1) {
				return;
			}
			var o = Main.records[this.i];

			Main.AddOns.installationScheduler(o.referenceid, (o.orderid.equals('N/A') ? '' : o.orderid));
		},
		// -------------------------------------------------------------------------------
		// -------------------------------------------------------------------------------
		// -- Main.Options.orderDates()
		// -------------------------------------------------------------------------------
		orderDates: function () {
			if (this.i == -1) {
				return;
			}
			var o = Main.records[this.i];

			Main.AddOns.orderDates(o.referenceid, (o.orderid.equals('N/A') ? '' : o.orderid));
		},
		// -------------------------------------------------------------------------------
		// -- Main.Options.jobEstimating()
		// -------------------------------------------------------------------------------
		jobEstimating: function () {
			if (this.i == -1) {
				return;
			}
			var o = Main.records[this.i];

			Main.AddOns.jobEstimating(o.referenceid);
		},
		// ---------------------------------------------------------------------------------------------------
		// - Function    : Main.gotoHeader()
		// ---------------------------------------------------------------------------------------------------
		gotoHeader: function () {
			if (this.i == -1) {
				return;
			}
			var o = Main.records[this.i];
			Main.openHeaderWdw({
				parm_referenceid: o.referenceid,
				parm_orderid: (o.orderid.equals('N/A') ? '' : o.orderid)
			});
		},
		/** -------------------------------------------------------------------------
		 *    Main.Options.rmvRowHiLite :
		 *   ------------------------------------------------------------------------- */
		rmvRowHiLite: function () {
			var o = $('Mgr_SearchData_TBODY').rows[this.i];
			if (o) {
				o.removeClassName('selected');
			}
		}
	},
	// ***********************************************************************************************
	//	Main.ColumnControl
	// ***********************************************************************************************
	ColumnControl: {
		// -------------------------------------------------------------------------------
		// -- Main.ColumnControl.openWindow()
		// -------------------------------------------------------------------------------
		openViewSort: function () {
			(function ($) {
				var _this = this,
					selectedView = "";
				if (Main.useDetailLevel) {
					selectedView = "ordermanagerd";
				}
				else {
					selectedView = "ordermanagerh";
				}
				$App.Fire('open-view-window', {
					fm_file: selectedView
				});
			})(jQuery);
			////Attempt to run an $App.Fire on Friday and do all programming in MVC.
		},
		openWindow: function () {
			var h = Dancik.getDocumentHeight();

			// -- Make sure window is built and customized...
			if (Main.columnsWdw == null) {
				Main.columnsWdw = new OM_PopupWindow({
					title: 'Display options',
					style: {
						zIndex: '10'
					},
					content: $('Mgr_ColumnControl_Window'),
					afterClose: function () {
					},
					modal: true
				});
				Element.show('Mgr_ColumnControl_Window');
			}

			$('Mgr_ColumnControl_Window').style.height = (h - 200) + 'px';
			$('SelectedColumns').update();
			$('AvailableColumns').update();
			var htmlA = [];
			var htmlS = [];

			var cc = [];
			if (Main.useDetailLevel) {
				cc = Main.columnControl_DetailLevel.clone();
			} else {
				cc = Main.columnControl_HeaderLevel.clone();
			}
			cc.each(function (o, index) {
				if (o.viewable.equals('Y')) {
					htmlS.push("<li class='columnSelection' id='columnNames_" + index + "'>");
					htmlS.push("<table>");
					htmlS.push("<tr>");
					htmlS.push("<td><input type='checkbox' onclick='Main.ColumnControl.toggle(this);' style='cursor:pointer;'/></td>");
					htmlS.push("<td>" + o.heading.replace(/\[br\]/, " ") + "</td>");
					htmlS.push("</tr>");
					htmlS.push("</table>");
					htmlS.push("</li>");
				} else {
					htmlA.push("<li class='columnSelection' id='columnNames_" + index + "'>");
					htmlA.push("<table>");
					htmlA.push("<tr>");
					htmlA.push("<td><input type='checkbox' onclick='Main.ColumnControl.toggle(this);' style='cursor:pointer;'/></td>");
					htmlA.push("<td>" + o.heading.replace(/\[br\]/, " ") + "</td>");
					htmlA.push("</tr>");
					htmlA.push("</table>");
					htmlA.push("</li>");
				}
			});
			$('SelectedColumns').insert({
				bottom: htmlS.join("")
			});
			$('AvailableColumns').insert({
				bottom: htmlA.join("")
			});

			Sortable.create($('SelectedColumns'), {
				scroll: 'SelectedColumns_Container'
			});
			Sortable.create($('AvailableColumns'), {
				scroll: 'AvailableColumns_Container'
			});

			Droppables.add('SelectedColumns', {
				onDrop: function (o) {
					o.removeClassName("selected");
				},
				onEnd: function () {
				}
			});
			Droppables.add('AvailableColumns', {
				onDrop: function (o) {
					o.removeClassName("selected");
				},
				onEnd: function () {
				}
			});

			// -- Open and show window...
			Main.columnsWdw.open();

		},
		// ---------------------------------------------------------------------------------------------------
		// - Function    : Main.ColumnControl.toggle()
		// ---------------------------------------------------------------------------------------------------
		toggle: function (element) {
			var li = Element.up(element, 'li');
			if (element.checked) {
				li.addClassName("selected");
			} else {
				li.removeClassName("selected");
			}
		},
		// ---------------------------------------------------------------------------------------------------
		// - Function    : Main.ColumnControl.moveToAvailable()
		// ---------------------------------------------------------------------------------------------------
		moveToAvailable: function () {
			Sortable.destroy('SelectedColumns');
			Sortable.destroy('AvailableColumns');

			Element.select($('SelectedColumns'), 'li[class~="selected"]').each(function (o) {
				$('SelectedColumns').removeChild(o);
				$('AvailableColumns').appendChild(o);
				o.removeClassName("selected");
				Element.select(o, 'input[type="checkbox"]').each(function (oInput) {
					oInput.checked = false;
				});
			});

			Sortable.create($('SelectedColumns'), {
				scroll: 'SelectedColumns_Container'
			});
			Sortable.create($('AvailableColumns'), {
				scroll: 'AvailableColumns_Container'
			});
		},
		// ---------------------------------------------------------------------------------------------------
		// - Function    : Main.ColumnControl.moveToSelected()
		// ---------------------------------------------------------------------------------------------------
		moveToSelected: function () {
			Sortable.destroy('SelectedColumns');
			Sortable.destroy('AvailableColumns');

			Element.select($('AvailableColumns'), 'li[class~="selected"]').each(function (o) {
				$('AvailableColumns').removeChild(o);
				$('SelectedColumns').appendChild(o);
				o.removeClassName("selected");
				Element.select(o, 'input[type="checkbox"]').each(function (oInput) {
					oInput.checked = false;
				});
			});

			Sortable.create($('SelectedColumns'), {
				containment: ['SelectedColumns'],
				scroll: 'SelectedColumns_Container'
			});
			Sortable.create($('AvailableColumns'), {
				containment: ['AvailableColumns'],
				scroll: 'AvailableColumns_Container'
			});
		},
		// ---------------------------------------------------------------------------------------------------
		// - Function    : Main.ColumnControl.update()
		// ---------------------------------------------------------------------------------------------------
		update: function () {
			try {
				var selected = Sortable.sequence('SelectedColumns');
				var unselected = Sortable.sequence('AvailableColumns');

				var cc = [];
				var prevVersion = [];
				if (Main.useDetailLevel) {
					prevVersion = Main.columnControl_DetailLevel.clone();
					Main.columnControl_DetailLevel.clear();
				} else {
					prevVersion = Main.columnControl_HeaderLevel.clone();
					Main.columnControl_HeaderLevel.clear();
				}

				selected.each(function (i) {
					cc[cc.length] = Object.extend(prevVersion[i], {
						viewable: 'Y'
					});
				});
				unselected.each(function (i) {
					cc[cc.length] = Object.extend(prevVersion[i], {
						viewable: ''
					});
				});

				if (Main.useDetailLevel) {
					Main.columnControl_DetailLevel = cc.clone();
				} else {
					Main.columnControl_HeaderLevel = cc.clone();
				}


				Main.loadHeadings();
				Main.repopulate();

				Sortable.destroy('SelectedColumns');
				Sortable.destroy('AvailableColumns');

			} catch (e) {
				Main.open_ErrorWdw({
					contentHTML: "<div style='margin-bottom:10px;'>Error : Main.ColumnControl.update() : </div>",
					extraContentHTML: "<div>- " + e.message + "</div>"
				});
			}
			finally {
				Main.columnsWdw.close();
			}
		}
	},
	// ***********************************************************************************************
	//	Main.MultiOrders
	// ***********************************************************************************************
	MultiOrders: {
		records: [],
		wdw: null,
		// -------------------------------------------------------------------------------
		// -- Main.MultiOrders.openWindow()
		// -------------------------------------------------------------------------------
		openWindow: function (records) {
			// -- Check to see if it already exists...
			if (!Main.MultiOrders.wdw) {
				Main.MultiOrders.wdw = new OM_PopupWindow({
					title: 'Multiple Orders Were Found',
					style: {
						zIndex: '20'
					},
					afterClose: function () {
					},
					modal: true
				});
			}

			var html = [];
			// -- Construct the main (window) element...
			html.push('<div style="width:650px; margin:10px;">');
			html.push('<div style="margin-bottom:10px; text-align:left; font-family:Verdana, Arial, sans-serif; font-size:10pt;">Please select one of the orders below to continue.</div>');
			html.push('<div style="border-top:1px solid #ccc; border-left:1px solid #ccc;">');
			html.push("<table cellpadding='0' cellspacing='0' width='100%'>");
			html.push("<tbody>");
			html.push("<tr>");
			html.push("<td class='EXCEL-Header'>Order Date</td>");
			html.push("<td class='EXCEL-Header'>Account#</td>");
			html.push("<td class='EXCEL-Header'>Order#</td>");
			html.push("<td class='EXCEL-Header'>Reference#</td>");
			html.push("<td class='EXCEL-Header'>Name</td>");
			html.push("<td class='EXCEL-Header'>Rollover?</td>");
			html.push("</tr>");

			Main.MultiOrders.records = [];
			var len = records.length;
			for (var i = 0; i < len; i++) {
				Main.MultiOrders.records[Main.MultiOrders.records.length] = records[i];
				html.push("<tr class='selectable' onclick='Main.MultiOrders.gotoOrder(this);'>");
				html.push("<td class='EXCEL-Cell'>" + records[i].orderdate + "</td>");
				html.push("<td class='EXCEL-Cell'>" + records[i].accountid + "</td>");
				html.push("<td class='EXCEL-Cell'>" + records[i].orderid + "</td>");
				html.push("<td class='EXCEL-Cell'>" + records[i].referenceid + "</td>");
				html.push("<td class='EXCEL-Cell'> <div style='padding-left:3px; text-align:left;'>" + records[i].main_name + "</div></td>");
				html.push("<td class='EXCEL-Cell'>" + records[i].rollover + "</td>");
				html.push("</tr>");
			}

			html.push("</tbody>");
			html.push("</table>");
			html.push("</div>");
			// -- Close the main (window) element...
			html.push("</div>");

			Main.MultiOrders.wdw.setContentHTML(html.join(''));
			// -- Open and show window...
			Main.MultiOrders.wdw.open();
		},
		// -------------------------------------------------------------------------------
		// -- Main.MultiOrders.gotoOrder()
		// -------------------------------------------------------------------------------
		gotoOrder: function (element) {
			//console.log("gotoOrder3");
			var o = Main.MultiOrders.records[element.rowIndex - 1]; // -- Subtract 1, to offset the header-row..

			Main.Orders.openOrder({
				parm_ReferenceId: o.referenceid,
				parm_OrderId: o.orderid
			});

			Main.MultiOrders.wdw.close();
		}
	},
	// *******************************************************************************
	// * Search Object...
	// *******************************************************************************
	Search: {
		item: function (e) {
			Popup_Search_ForITEM.open(e, {
				blanketStretchBySize: true,
				showOptions: true,
				finalFunction: function (item) {
					var o = Dancik.Build.KeyParam.forItem(item);
					$('parm_FilterMfgr').value = o.key01;
					$('parm_FilterColor').value = o.key02;
					$('parm_FilterPattern').value = o.key03;
				},
				afterClear: function () {
					$('parm_FilterMfgr').value = '';
					$('parm_FilterColor').value = '';
					$('parm_FilterPattern').value = '';
				}
			});
		},
		warehouse: function (e) {
			Popup2Search.open(e, {
				title: 'Warehouse',
				file: 'warehouse',
				positionElement: 'parm_FilterWarehouse',
				toElements: ['parm_FilterWarehouse'],
				bufferLeft: Prototype.Browser.IE ? 1 : -2,
				bufferTop: Prototype.Browser.IE ? 3 : 0,
				preload: true
			});
		},
		company: function (e) {
			Popup2Search.open(e, {
				title: 'Company',
				file: 'company_numericsonly',
				positionElement: 'parm_FilterCompany',
				toElements: ['parm_FilterCompany'],
				bufferLeft: Prototype.Browser.IE ? 1 : -2,
				bufferTop: Prototype.Browser.IE ? 3 : 0,
				preload: true
			});
		},
		account: function (e) {
			if ($F('parm_FilterCompany').isEmpty()) {
				Main.open_ErrorWdw({
					contentHTML: "Search request failed :",
					extraContentHTML: "- Company is required to perform an account search."
				});
			} else {
				Popup_Search_ForBILLTO.open(e, {
					title: 'Account',
					toElements: ['parm_FilterAccount'],
					params: 'parm_FilterFileType=B&parm_FilterCompany=' + $F('parm_FilterCompany'),
					killOnClose: true,
					showOptions: true,
					blanketStretchBySize: true
				});
			}
			;
		},
		retailCustomer: function (e) {
			Popup_Search_ForBILLTO.open(e, {
				title: 'Retail Customer',
				toElements: ['parm_FilterRetailId'],
				descriptionElement: $('view_FilterRetailName'),
				params: 'parm_FilterFileType=R',
				omitIdInDescription: true,
				showIdInTable: false,
				retailOnlyMode: true,
				killOnClose: true,
				blanketStretchBySize: true
			});
		},
		branch: function (e) {
			if ($F('parm_FilterCompany').isEmpty()) {
				Main.open_ErrorWdw({
					contentHTML: "Search request failed :",
					extraContentHTML: "- Company is required to perform a branch search."
				});
			} else {
				Popup2Search.open(e, {
					title: 'Branch',
					file: 'branch',
					positionElement: 'parm_FilterBranch',
					toElements: ['parm_FilterBranch'],
					additionalParams: {
						filterCompany: $F('parm_FilterCompany')
					},
					bufferLeft: Prototype.Browser.IE ? 1 : -2,
					bufferTop: Prototype.Browser.IE ? 3 : 0,
					preload: true
				});
			}
		},
		salesperson: function (e) {
			Popup2Search.open(e, {
				title: 'Salesperson',
				file: 'salesman',
				positionElement: 'parm_FilterSalesperson',
				toElements: ['parm_FilterSalesperson'],
				additionalParams: {
					filterCompany: $F('parm_FilterCompany')
				},
				bufferLeft: Prototype.Browser.IE ? 1 : -2,
				bufferTop: Prototype.Browser.IE ? 3 : 0,
				preload: true
			});
		},
		supplier: function (e) {
			Popup2Search.open(e, {
				title: 'Supplier',
				file: 'supplier',
				positionElement: 'parm_FilterSupplier',
				toElements: ['parm_FilterSupplier'],
				bufferLeft: Prototype.Browser.IE ? 1 : -2,
				bufferTop: Prototype.Browser.IE ? 3 : 0,
				preload: true
			});
		},
		shipvia: function (e) {
			Popup2Search.open(e, {
				title: 'Ship Via',
				file: 'ship_via',
				positionElement: 'parm_FilterShipVia',
				toElements: ['parm_FilterShipVia'],
				preload: true
			});
		},
		ordertype: function (e) {
			Popup2Search.open(e, {
				title: 'Order Type',
				file: 'systtbl_ordertype',
				positionElement: 'parm_FilterOrderType',
				toElements: ['parm_FilterOrderType'],
				bufferLeft: Prototype.Browser.IE ? 1 : -2,
				bufferTop: Prototype.Browser.IE ? 3 : 0,
				widthOverride: 360,
				preload: true
			});
		},
		orderstatus: function (e) {
			Popup2Search.open(e, {
				title: 'Order Status',
				file: 'orstat_o',
				positionElement: 'parm_FilterOrderStatus',
				toElements: ['parm_FilterOrderStatus'],
				bufferLeft: Prototype.Browser.IE ? 1 : -2,
				bufferTop: Prototype.Browser.IE ? 3 : 0,
				widthOverride: 360,
				preload: true
			});
		},
		fromShipDate: function (e) {
			new CalendarObject({
				toElements: [$('parm_FilterDateRequired_From')],
				toFormats: ['M/D/Y'],
				positionElement: Element.up('parm_FilterDateRequired_From', 'SPAN'),
				offsetTop: Prototype.Browser.IE ? -1 : 1
			});
		},
		toShipDate: function (e) {
			new CalendarObject({
				toElements: [$('parm_FilterDateRequired_To')],
				toFormats: ['M/D/Y'],
				positionElement: Element.up('parm_FilterDateRequired_To', 'SPAN'),
				offsetTop: Prototype.Browser.IE ? -1 : 1
			});
		},
		fromOrderDate: function (e) {
			new CalendarObject({
				toElements: [$('parm_FilterDateOrdered_From')],
				toFormats: ['M/D/Y'],
				positionElement: Element.up('parm_FilterDateOrdered_From', 'SPAN'),
				offsetTop: Prototype.Browser.IE ? -1 : 1
			});
		},
		fromReorderDate: function (e) {
			new CalendarObject({
				toElements: [$('parm_FilterDateReorder_From_MDY'), $('parm_FilterDateReorder_From_CYMD')],
				toFormats: ['M/D/Y', 'CYMD'],
				positionElement: Element.up('parm_FilterDateReorder_From_MDY', 'SPAN'),
				offsetTop: Prototype.Browser.IE ? -1 : 1
			});
		},
		toReorderDate: function (e) {
			new CalendarObject({
				toElements: [$('parm_FilterDateReorder_To_MDY'), $('parm_FilterDateReorder_To_CYMD')],
				toFormats: ['M/D/Y', 'CYMD'],
				positionElement: Element.up('parm_FilterDateReorder_To_MDY', 'SPAN'),
				offsetTop: Prototype.Browser.IE ? -1 : 1
			});
		},
		reorderBackOrderDate: function (e) {
			new CalendarObject({
				toElements: [$('parm_FilterDateBackorder_MDY'), $('parm_FilterDateBackorder_CYMD')],
				toFormats: ['M/D/Y', 'CYMD'],
				positionElement: Element.up('parm_FilterDateBackorder_MDY', 'SPAN'),
				offsetTop: Prototype.Browser.IE ? -1 : 1
			});
		},
		toOrderDate: function (e) {
			new CalendarObject({
				toElements: [$('parm_FilterDateOrdered_To')],
				toFormats: ['M/D/Y'],
				positionElement: Element.up('parm_FilterDateOrdered_To', 'SPAN'),
				offsetTop: Prototype.Browser.IE ? -1 : 1
			});
		},
		ETA_Date: function (e) {
			new CalendarObject({
				toElements: [$('parm_FilterETADate_MDY'), $('parm_FilterETADate')],
				toFormats: ['M/D/Y', 'CYMD'],
				positionElement: Element.up('parm_FilterETADate_MDY', 'SPAN'),
				offsetTop: Prototype.Browser.IE ? -1 : 1
			});
		},
		Reorder_Calc_From_Date: function (e) {
			new CalendarObject({
				toElements: [$('parm_reorder_calc_from_date_MDY'), $('parm_reorder_calc_from_date_CYMD')],
				toFormats: ['M/D/Y', 'CYMD'],
				positionElement: Element.up('parm_reorder_calc_from_date_MDY', 'SPAN'),
				offsetTop: Prototype.Browser.IE ? -1 : 1,
				zIndex: 50000

			});
		},
		Reorder_Calc_To_Date: function (e) {
			new CalendarObject({
				toElements: [$('parm_reorder_calc_to_date_MDY'), $('parm_reorder_calc_to_date_CYMD')],
				toFormats: ['M/D/Y', 'CYMD'],
				positionElement: Element.up('parm_reorder_calc_to_date_MDY', 'SPAN'),
				offsetTop: Prototype.Browser.IE ? -1 : 1,
				zIndex: 50000
			});
		}
	},
	about: function () {
		new Ajax.Request("../about.jsp", {
			method: "get",
			onSuccess: function (res) {
				new Dancik_ConfirmWindow({
					showAsInfoOnly: true,
					content: '<div style="text-align:left;">' + res.responseText.replace(/\r\n\s*/g, "").replace(/.*<body>(.*)<\/body>.*/, "$1") + '</div>',
					destroyOnClose: true,
					color: "blue",
					modal: true
				}).open();
			}
		});
	}
});


//******************************************************************************
//Class : OM_AltOrderCompanyWindow
//******************************************************************************
var OM_AltOrderCompanyWindow = Class.create();
OM_AltOrderCompanyWindow.prototype = {
	wdw: null,
	ordertype: "",
	records: [],
	initialize: function (type) {

		this.wdw = new OM_PopupWindow({
			modal: true,
			content: $('AltOrdCompWdw')
		});
		Element.show('AltOrdCompWdw');
		$('AltOrdCompWdw_Tbody').update("<tr><td colspan='2'><img src='../../dws/images/loading.gif' alt=''/></td></tr>");

		this.open(type);

		this.records = [];
		var _this = this;

		Main.ajax = new Ajax.Request('../../dws/jsonservice/Popup2Search_WebService/exec', {
			method: 'get',
			parameters: {
				file: 'company_numericsonly'
			},
			evalJSON: "force",
			onSuccess: function (res) {
				try {
					var json = res.responseJSON;
					if (!json) {
						throw 'EmptyResult';
					}
					if (json.errors) {
						throw 'ErrorCaught';
					}

					var html2 = [];
					if (json.records) {
						var len = json.records.length;
						for (var i = 0; i < len; i++) {
							_this.records[ _this.records.length ] = json.records[i];

							html2.push("<tr class='selectableRows'>");
							html2.push("<td class='EXCEL-Cell'><div class='comp-col0'>" + json.records[i].id + "</div></td>");
							html2.push("<td class='EXCEL-Cell'><div class='comp-col1' style='text-align:left;'>" + json.records[i].description + "</div></td>");
							html2.push("</tr>");

						}
						$('AltOrdCompWdw_Tbody').update(html2.join(''));

						// -- Specify Button Actions
						Element.select($('AltOrdCompWdw_Tbody'), "tr").each(function (o) {
							Event.observe(o, "click", function () {
								_this.select(this);
							});
						});

					}

				} catch (e) {
					alert(e.message);
				} finally {
				}

			},
			onFailure: Dancik.catchAjaxError
		});


	},
	open: function (ordertype) {
		this.ordertype = ordertype;

		var ttl = ordertype.equals('po') ? 'Purchase Order' : 'Stock-to-Stock Order';
		$('AltOrdCompWdw_Title').update(ttl);

		this.wdw.setTitle(ttl + 'Entry');

		this.wdw.open();
	},
	close: function () {
		this.wdw.close();
	},
	select: function (element) {
		var o = this.records[element.rowIndex - 1];

		this.wdw.close();

		Main.Orders.createAltOrder(this.ordertype, o.id);
	}

};
