var MultiEntry = Class.create({
	initialize: function(opts) {
		this.id = new Date().getTime();
		
		this.newBlankLine = this._newBlankLine.bindAsEventListener(this);
		var viewDims = document.viewport.getDimensions();
		this.options = Object.extend({
			height: viewDims.height-80, //default height of related items box
			items: Main.record.header.items || null, //array of items for multi line entry
			id: this.id,
			title: "Multi Line Entry"
		}, opts||{});
		
		var template = new EJS({url:"multiEntry.ejs"});
		var html = template.render(this.options);
		
		this.win = new Dancik_ConfirmWindow({
			showAsPopup: true,
			popupTitle: this.options.title,
			color: "blue",
			buttons: {},
			destroyOnClose: true,
			message: html,
			modal:true,
			zIndexModal: 300
		});
		this.win.open();
		this.processValdiator = new Validation("multiEntryForm"+this.id,{
			onValidSubmit: this.processSubmit.bindAsEventListener(this),
			fieldNames: {
				priceover_array: "Price Override",
				qty_array: "Quantity"
			},
			errorMessageKeys: {
				qty_array: {
					num5_2neg: "format5_2neg"
				},
				priceover_array: {
					num6_3: "format6_3"
				}
			}
		});
		Event.observe("multiEntryForm"+this.id,"click",this.handleClick.bindAsEventListener(this));
		
		this.addItems(this.options.items);
	},
	handleClick: function(event) {
		var element = Event.element(event);
		if (element.hasClassName("rowOptions")) {
			this.rowOptions(element);
		}
		if(element.hasClassName("dws-contextlink")) {
			this.itemOptions(element);
		}
		if(element.hasClassName("folder")) {
			$("multiEntryWrap"+this.id).toggleClassName("unfold");
			//alert(1);
			//$("multiEntryTBody"+this.id).hide().show.bind($("multiEntryTBody"+this.id)).defer();
			//alert(2);
		}
	},
	rowOptions: function(element) {
		var tr = element.up("tr");
		var itemInput = tr.down('input[name="json"]');
		var data = itemInput.value.evalJSON();
		if(data.item.blank()) {
			data.item = tr.down('input[name="item_array"]').value;
		}
		data.entry = this;
		
		if(!MultiEntry.optionsWdw) {
			MultiEntry.optionsWdw = new Dancik_OptionsWindow({ 
				style : 'width:175px;z-index:50000;',
				title : 'Available Line Options'
			});
		}
		MultiEntry.optionsWdw.removeOptions();
		//MultiEntry.optionsWdw.setTitle(data.item);
		
		MultiEntry.optionsWdw.addOption({ title : "Related Items", icon : "../../dws/images/icons/relatedItems.png", action : function () { new RelatedItems(data); } } );
		MultiEntry.optionsWdw.open(element);
	},
	itemOptions: function(element) {
		var tr = element.up("tr");
		var itemInput = tr.down('input[name="json"]');
		var data = itemInput.value.evalJSON();
		data.entry = this;
		
		var popup = new Dancik_RightClicks({
			 dataKey : "item",
			 key : data.item
			},
			{style : {width:'175px', zIndex: 100000}});
		popup.addOption({ title : "Related Items", icon : "../../dws/images/icons/relatedItems.png", action : function () { new RelatedItems(data); } },"itemRelated" );
		popup.open(element);
	},
	processSubmit: function(event) {
		Event.stop(event);
		var form = Event.element(event);
		var data = form.serialize(true);
		
		var arrays = [];
		var counts = [];
		$H(data).each(function(pair) {
			if(pair.key.endsWith("_array")) {
				data[pair.key] = [data[pair.key]].flatten().compact();
				arrays.push(pair.key);
				counts.push(data[pair.key].length);
			}
		})
		
		var items = [];
		for(var i=0;i<counts.max();i++) {
			var item = {};
			arrays.each(function(key) {
				var key2 = key.replace(/_array$/,"");
				item[key2] = data[key][i];
			})
			items.push(item)
		}
		
		var itemNumbers = items.collect(function(item) {return item.item.trim();}).without("");
		if(itemNumbers.length!=itemNumbers.uniq().length) {
			Main.open_ErrorWdw({
				contentHTML : $M("om.combineQty")
			});
			return;
		}
		
		var numReg = /[1-9]/;
		var itemQtys = items.findAll(function(i) {
			return numReg.test(i.qty)
		})
		
		if(itemQtys.length==0) {
			Main.open_ErrorWdw({
				contentHTML : $M("om.oneQtyRequired")
			});
			return;
		}
		
		var template = new EJS({url:"multiEntryISO.ejs"});
		var html = template.render(this.options);
		
		
		var dims = document.viewport.getDimensions();
		this.iso = new Dancik_ConfirmWindow({
			color:"grey",
			showAsPopup: true,
			popupTitle: "Add Multiple Lines: Inventory Selection Optimizer",
			message: html,
			destroyOnClose: true,
			modal:true,
			zIndexModal: 600,
			buttons:{},
			onClose: function() {
				ISO.deallocateForm("meISOForm"+this.id);
				this.iso.close();
			}.bind(this)
		});
		this.iso.open();

		ISO.runISO({
			items: items,
			target: "meIso"+this.id,
			onError: function(errArray) {
				var errors = errArray.pluck("errmsg");
				var html = '<div>- '+errors.join("</div><div>- ")+'</div>';
				Main.open_ErrorWdw({
					contentHTML : "The following error"+(errors.length>1?"s":"")+" occurred:", 
					extraContentHTML : html
				});
				this.iso.close();
			}.bind(this)
		});
		this.isoValdiator = new Validation('meISOForm'+this.id,{
			onValidSubmit: this.processIso.bindAsEventListener(this)
		});
		//set focus to button
		$j('form#meISOForm' + this.id).find('div.isoTableButtons input[value="Add Selected Inventory"]').focus();
	},
	processIso: function(event) {
		Event.stop(event);
		var form = Event.element(event);
		var processOnce = $j('form#meISOForm' + this.id).find('input[name="processed"]').val(); //EVNT 29W2
		
		if (!processOnce) {
		    $j('form#meISOForm' + this.id).find('input[name="processed"]').val('true');  //EVNT 29W2
			AddItem.addItemsFromForm(form,{
				onAdded: function(items,res) {
					this.win.close();
					this.iso.close();
				}.bind(this),
				onError: function(errArray,res) {
					var errors = errArray.pluck("errmsg");
					var html = '<div>- '+errors.join("</div><div>- ")+'</div>';
					Main.open_ErrorWdw({
						contentHTML : "The following error"+(errors.length>1?"s":"")+" occurred:", 
						extraContentHTML : html
					});
				}	
			});
		}
	},
	addItems: function(itemsArray) {
		itemsArray = [itemsArray].flatten().compact();
		var templateL = new EJS({url:"multiEntryLineL.ejs"});
		var templateR = new EJS({url:"multiEntryLineR.ejs"});
		var left = [];
		var right = [];
		var kit = false;
		for(var i=0;i<itemsArray.length;i++) {

			if(i==0 && $("multiEntryTbodyL"+this.id).childElements().length==0 && itemsArray[0].kitflag=="Y") {
				kit="true";
				continue;
			}
			
			var data = itemsArray[i];
			data.me_id = this.id;
			left.push(templateL.render(data));
			right.push(templateR.render(data));
		}
		
		if($("me"+this.id+"_blankL")) {
			$("me"+this.id+"_blankL").insert({before:left.join("")});
			$("me"+this.id+"_blankR").insert({before:right.join("")});
		} else {
			if(!kit) {
				left.push(templateL.render(this.options)); //add open line?
				right.push(templateR.render(this.options)); //add open line?
			}
			$("multiEntryTbodyL"+this.id).insert(left.join(""));
			$("multiEntryTbodyR"+this.id).insert(right.join(""));
			if(!kit) {
				$("me"+this.id+"_blankL").observe("keypress",this.newBlankLine);
			}
		}
		if(itemsArray.length > 0){
			$j('input[name=qty_array]').first().focus();
		}
	},
	_newBlankLine: function(event) {
		var element = Event.element(event);
		var tr = element.up("tr");
		tr.stopObserving("keypress",this.newBlankLine);
		tr.writeAttribute("id","");
		this.addItems();
	}
});

Element.addMethods({trigger: function(element,event) {
	if(document.createEvent){
		// dispatch for firefox + others
		var evt = document.createEvent("HTMLEvents");
		evt.initEvent(event, true, true ); // event type,bubbling,cancelable
		return !element.dispatchEvent(evt);
	} else {
		// dispatch for IE
		var evt = document.createEventObject();
		return element.fireEvent('on'+event)
	}
}});

MultiEntry.searchItem = function(e) {
	var event = e || window.event;
	var element = Event.element(event);
	var input = element.up().down("input"); 
	Popup_Search_ForITEM.open(e, { 
		blanketStretchBySize : true,
		toElements: [input],
		finalFunction : function (item,description) {
			input.value = item.replace(/\s*$/,"");
			input.trigger("keypress");
		}
	});		
}
MultiEntry.dropR = function(e) {
	var event = e || window.event;
	var element = Event.element(event);
	var span = element.up();
	var input = span.down("input");
	Popup_Search.open(event,{
		title: "Restriction Code",
		positionElement: span,
		hideHeader: true,
		widthOverride: 225,
		heightOverride:60,
		preloadedContents: [
				{id:"R",description:"Roll/balance roll price."},
				{id:"C",description:"Cut roll price."},
				{id:"M",description:"Manager approved price/mid-price."}
			],
		bufferLeft: Prototype.Browser.IE?2:1,
		bufferTop: -3,
		toElements: [input],
		finalFunction: function() {
			input.trigger("keypress");
		}
	})
}
MultiEntry.dropRcv = function(e) {
	var event = e || window.event;
	var element = Event.element(event);
	var span = element.up();
	var input = span.down("input");
	Popup_Search.open(event,{
		title: "Receive Code",
		positionElement: span,
		hideHeader: true,
		widthOverride: 200,
		heightOverride:80,
		preloadedContents: [
				{id:"B",description:"Back order"},
				{id:"T",description:"Transfer"},
				{id:"Y",description:"Return to stock"},
				{id:"N",description:"No return to stock"}
			],
		bufferLeft: Prototype.Browser.IE?2:1,
		bufferTop: -3,
		toElements: [input],
		finalFunction: function() {
			input.trigger("keypress");
		}
	})
}
MultiEntry.dropCC = function(e) {
	var event = e || window.event;
	var element = Event.element(event);
	var span = element.up();
	var input = span.down("input");
	Popup2Search.open(e, { 
		title : 'Credit Code', 
		file : 'classes_cc', 
		positionElement : span, 
		toElements : [input], 
		bufferLeft: Prototype.Browser.IE?0:-1,
		bufferTop: 4,
		preload : true 
	});		
}

