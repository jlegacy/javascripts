//*******************************************************************************************************
//*******************************************************************************************************
//*******************************************************************************************************
var MessageLines_Popup = Class.create(Dancik_ConfirmWindow, {
	// --------------------------------------------------------------------------------------------------
	initialize: function($super, params, opts) {
		this.params = $H(params || {});
		// -- Construct 'options'...
		this.popup_options = Object.extend({
			editmode : false,		// -- Put fields in edit mode.
			beforeUpdate : null,	// -- Additional function(s) to execute (before) update().
			afterUpdate : null		// -- Additional function(s) to execute (after) update().
		}, opts || {} );
	
		var _this = this;
		this.popupid="msgLine_PopupWdw_" + new Date().getTime();
		this.recordChangedIndicator = false;
		
		var h = 320;
		var w = 900;
		$super(Object.extend({ 
			color : "blue",
			showAsPopup : true,
			popupTitle  : 'Message Lines and Miscellaneous Charges',
			destroyOnClose : true,
			modal : true,
			message: '<div class="MessageLines_Popup" id="MessageLines_Popup_' + this.popupid + '" style="position:relative; height:' + h + 'px; width:' + w + 'px;"></div>',
			buttons : {}
		}, opts || {})
	);

		
		this.model = new Dancik_Model('../jsonservice/OM_WebService/execute');
		this.reload();
	},
	// --------------------------------------------------------------------------------------------------
	save: function(event) {
		var _this = this;
		
		if (this.popup_options.beforeUpdate) {
			this.popup_options.beforeUpdate();
		}
		
		var params = Form.serialize('MessageLines_Form_'+this.popupid, true);
		
		this.model.get(Object.extend({
			serviceid : 'manager', 
			option : 'updateMsgLines', 
			random : new Date().getTime() 
		}, params || {}), 
		function(is_success, json) { 
			
			if (json.errors) {
				var html = []; json.errors.each( function(msg) { html.push("<li> - " + msg + "</li>") } );
			
				new Dancik_ConfirmWindow({ 
					color : "red",
					showAsInfoOnly : true,
					modal : true,
					destroyOnClose : true,
					contentHTML : "The following errors occurred:",
					extraContentHTML : '<ul class="error-list">' + html.join('') + '</ul>'
				}).open();
			} else {
				if (_this.popup_options.afterUpdate) {
					_this.popup_options.afterUpdate();
				}
				_this.close();
			}
			
		});
	},
	// --------------------------------------------------------------------------------------------------
	chglines: function() {
		if ($F('MessageLines_Line_'+this.popupid).isEmpty() ) { return; }
		
		this.params.set('parm_line', $F('MessageLines_Line_'+this.popupid));
		
		this.reload();
	},
	// --------------------------------------------------------------------------------------------------
	reload: function() {
		var _this = this;
		_this.recordChangedIndicator = false;
		
		var params = _this.params.toObject();
		
		this.model.get(Object.extend({
			serviceid : 'manager', 
			option : 'getMsgLines', 
			random : new Date().getTime() 
		}, params || {}), 
		function(is_success, json) { 
			try{
				json = Object.extend(json, { 
					id : _this.popupid, 
					referenceid : _this.params.get('parm_referenceid'),
					orderid : _this.params.get('parm_orderid') || '',
					accountid : _this.params.get('parm_accountid') || '',
					accountname : _this.params.get('parm_accountname') || '',
					line : _this.params.get('parm_line'),
					editmode : _this.options.editmode
				});

				_this.saved_records = json.records;
				
				var template = new EJS({url: '../app-mgr/message-lines.ejs'});
				$('MessageLines_Popup_' + _this.popupid).update( template.render(json) );
				

				Element.select($('MessageLines_Form_'+_this.popupid), 'input[type="text"]').each(function(o) {
					Event.observe(o, 'focus', function() { this.select() });
				});
				//Element.select($('OrderShipTo_Form_'+_this.popupid), 'IMG.picker').each(function(o) {
				//	Event.observe(o, 'click',  _this.prompt.bindAsEventListener(_this) );
				//});

				if ($('MessageLines_MMButton_'+_this.popupid)) {
					Event.observe('MessageLines_MMButton_'+_this.popupid, 'click', _this.macromsgs.bindAsEventListener(_this) );
				}

				Event.observe('MessageLines_ChgLineButton_'+_this.popupid, 'click', _this.chglines.bindAsEventListener(_this) );
								
				
				// -- Sets up all fields in Form, to watch for 'unsaved' changes
				_this.recordChangedIndicator = false;
				$('MessageLines_Form_'+_this.popupid).select('input[type="text"]').invoke("observe","change", function() { _this.recordChangedIndicator = true; });
				$('MessageLines_Form_'+_this.popupid).select('input[type="checkbox"]').invoke("observe","change", function() { _this.recordChangedIndicator = true; });
				
				
				// -- Build validator...
				var testValidator = new Validation('MessageLines_Form_'+_this.popupid, {
					onValidSubmit : function(event) {
						event.stop();
						_this.save();
					},
					fieldNames: {
						parm_messageprice_1: "Line# 1 Price",
						parm_messageprice_2: "Line# 2 Price",
						parm_messageprice_3: "Line# 3 Price",
						parm_messageprice_4: "Line# 4 Price",
						parm_messageprice_5: "Line# 5 Price",
						parm_messageprice_6: "Line# 6 Price",
						parm_messageprice_7: "Line# 7 Price",
						parm_messageprice_8: "Line# 8 Price",
						parm_messageprice_9: "Line# 9 Price",
						parm_messagecost_1: "Line# 1 Cost",
						parm_messagecost_2: "Line# 2 Cost",
						parm_messagecost_3: "Line# 3 Cost",
						parm_messagecost_4: "Line# 4 Cost",
						parm_messagecost_5: "Line# 5 Cost",
						parm_messagecost_6: "Line# 6 Cost",
						parm_messagecost_7: "Line# 7 Cost",
						parm_messagecost_8: "Line# 8 Cost",
						parm_messagecost_9: "Line# 9 Cost",
						parm_messageglid_1: "Line# 1 GL Acct#",
						parm_messageglid_2: "Line# 2 GL Acct#",
						parm_messageglid_3: "Line# 3 GL Acct#",
						parm_messageglid_4: "Line# 4 GL Acct#",
						parm_messageglid_5: "Line# 5 GL Acct#",
						parm_messageglid_6: "Line# 6 GL Acct#",
						parm_messageglid_7: "Line# 7 GL Acct#",
						parm_messageglid_8: "Line# 8 GL Acct#",
						parm_messageglid_9: "Line# 9 GL Acct#",
						parm_messagecostctr_1: "Line# 1 Cost Center",
						parm_messagecostctr_2: "Line# 2 Cost Center",
						parm_messagecostctr_3: "Line# 3 Cost Center",
						parm_messagecostctr_4: "Line# 4 Cost Center",
						parm_messagecostctr_5: "Line# 5 Cost Center",
						parm_messagecostctr_6: "Line# 6 Cost Center",
						parm_messagecostctr_7: "Line# 7 Cost Center",
						parm_messagecostctr_8: "Line# 8 Cost Center",
						parm_messagecostctr_9: "Line# 9 Cost Center"
						
					}
				});			
				$j('#parm_message_1').focus();				
			} catch(e) { alert(e.message); }
		});		
	},
	// --------------------------------------------------------------------------------------------------
	macromsgs: function(event) {
		var _this = this;
		
		new MacroMessages_Popup(
				{ parm_referenceid: _this.params.get('parm_referenceid'), parm_orderid:_this.params.get('parm_orderid') },
				{ references : { 
					startline : 0, 
					msg: 'parm_message_', 
					price: 'parm_messageprice_', 
					cost: 'parm_messagecost_', 
					glid: 'parm_messageglid_', 
					cstctr: 'parm_messagecostctr_', 
					taxable: 'parm_messagetaxable_',
					deleteline: 'parm_deleteline_'
				} }
		).open();
		
	}
});

MessageLines_Popup.prompt = function(e) {
	var event = e || window.event;
	Event.stop(event);
	var element = Event.element(event);
	
	var o = element.up('SPAN.dws-drop').down('INPUT');
	var tr = element.up('tr');
	//var rec = this.saved_records[tr.rowIndex-1]; // -- Subtract 1, for THEAD...
	
	if (o.name.indexOf('parm_messageglid') >= 0) {
		Popup2Search.open(event, {
			title : 'GL Account#', 
			file : 'qchart-CHHOLD_NE_H', 
			positionElement : o.id, 
			toElements : [o.id], 
			additionalParams : { filterCompany: Main.record.header.billingaccount.substring(0,1) },
			bufferLeft: 4,
			preload : true});
	} else if (o.name.indexOf('parm_messagecostctr') >= 0) {
		Popup2Search.open(event, {
			title : 'Cost Center', 
			file : 'costcenter', 
			positionElement : o.id, 
			toElements : [o.id], 
			bufferLeft: 4,
			preload : true});
	}
}


//*******************************************************************************************************
//*******************************************************************************************************
//*******************************************************************************************************
var MacroMessages_Popup = Class.create(Dancik_ConfirmWindow, {
	initialize: function($super, params, opts) {
		// -- Construct 'options'...
		this.popup_options = Object.extend({
			beforeUpdate : null,					// -- Additional function(s) to execute (before) update().
			afterUpdate : null						// -- Additional function(s) to execute (after) update().
		}, opts || {} );
	
		var _this = this;
		this.popupid="macromsg_PopupWdw_" + new Date().getTime();
		
		this.references = opts.references;
		
		var h = 300;
		var w = 920;	
		$super(Object.extend({
			style : {zIndex : 20000},
			color : "grey",
			showAsPopup : true,
			popupTitle  : 'Macro Messages',
			destroyOnClose : true,
			message: '<div class="MacroMessages_Popup" id="MacroMessages_Popup_' + this.popupid + '" style="position:relative; height:' + h + 'px; width:' + w + 'px;"></div>',
			buttons : {}
		}, opts || {})
	);

		
		this.model = new Dancik_Model('../jsonservice/OM_WebService/execute');
		this.model.get(Object.extend({
			serviceid : 'addons', 
			option : 'getAvailableMacroMsgs', 
			random : new Date().getTime() 
		}, params || {}), 
		function(is_success, json) { 
			try{
				json = Object.extend(json, { id : _this.popupid, startline : _this.references.startline });
				
				_this.saved_records = json.records;
				
				var template = new EJS({url: '../app-mgr/macromessages.ejs'});
				$('MacroMessages_Popup_' + _this.popupid).update( template.render(json) );
				
				_this.reset();
				
				Event.observe('MacroMsg_LoadButton_'+_this.popupid, "click", _this.load.bindAsEventListener(_this));
				Event.observe('MacroMsg_ClearButton_'+_this.popupid, "click", _this.clear.bindAsEventListener(_this));
				Event.observe('MacroMsg_ResetButton_'+_this.popupid, "click", _this.reset.bindAsEventListener(_this));

				Element.select( $('MacroMessage_Form_'+_this.popupid), 'input[type="text"]').each(function(o) {
					Event.observe(o, 'focus', function() { this.select() });
				});
				Element.select( $('MacroMessage_AvailableMacros_'+_this.popupid), 'tr').each(function(o) {
					Event.observe(o, 'click',  _this.selectMM.bindAsEventListener(_this) );
				});
				
				
			} catch(e) { alert(e.message); }
		});		

	},
	// ---------------------------------------------------------------------------------------------------
	selectMM: function(event) {
		var element = Event.element(event);
		if (!element.tagName.toLowerCase().equals('tr')) {
			element = element.up('tr');
		}
		var o = $H(this.saved_records[element.rowIndex-1]); // -- Avoid THEAD record...
		
		
		// -- Determine the starting point that the messages will be populated at... (default is Line 2)
		var startPos = Dancik.Radio.getChecked( $('MacroMessage_Form_'+this.popupid)['mmStartHere'] );
		if (startPos.isEmpty()) { 
			startPos = 1;
		} else {
			startPos = startPos.getInteger();
		}

		var j = 0;	
		for (var i=startPos; i<10; i++) {
			j++;
			// ---- Break when the first non-empty field is reached, to avoid overlaying...
			//		-- *Except on the first iteration.  One the first loop around, the input field will be overlaid if populated...
			if (j > 1   &&  !$F('mmMsg_' + i).isEmpty()) { break; }

			var x = this.references.startline + i;
			$('mmMsg_' + i).setValue( o.get('message' + j) );
			$('mmPrice_' + i).setValue( o.get('price' + j) );
			$('mmCost_' + i).setValue( o.get('cost' + j) );
			$('mmGlId_' + i).setValue( o.get('glid' + j) );
			
			//change to put in Costcenter anytime Danielle 3/28/12
			if(!o.get('message' + j).blank()){
				//only fill cost center if there is a price or cost.
				$('mmCstCtr_' + i).setValue( o.get('costcenter') );
			}
			$('mmTaxable_' + i).checked = false;
		}
	},
	// ---------------------------------------------------------------------------------------------------
	clear: function(event) {
		Element.select($(this.id), 'INPUT[type="text"],INPUT[type="hidden"]').each(function(o){ o.setValue(''); });
		Element.select($(this.id), 'INPUT[type="checkbox"]').each(function(o){ o.checked = false; });
	},
	// ---------------------------------------------------------------------------------------------------
	reset: function(event) {
		for (var i=9; i>0; i--) {
			var x = this.references.startline + i;
			$('mmMsg_' + i).setValue( $F(this.references.msg + x) );
			$('mmPrice_' + i).setValue( $F(this.references.price + x) );
			$('mmCost_' + i).setValue( $F(this.references.cost + x) );
			$('mmGlId_' + i).setValue( $F(this.references.glid + x) );
			$('mmCstCtr_' + i).setValue( $F(this.references.cstctr + x) );
			$('mmTaxable_' + i).checked = $(this.references.taxable + x).checked;
			$('mmStartHere_'+i).checked = ($F(this.references.msg + x).isEmpty());
		}
	},
	// ---------------------------------------------------------------------------------------------------
	load: function(event) {
		if (this.popup_options.beforeUpdate) {
			this.popup_options.beforeUpdate();
		}
		for (var i=1; i<10; i++) {
			var x = this.references.startline + i;
			$(this.references.msg + x).setValue( $F('mmMsg_' + i) );
			$(this.references.price + x).setValue( $F('mmPrice_' + i) );
			$(this.references.cost + x).setValue( $F('mmCost_' + i) );
			$(this.references.glid + x).setValue( $F('mmGlId_' + i) );
			$(this.references.cstctr + x).setValue( $F('mmCstCtr_' + i) );
			$(this.references.taxable + x).checked = $('mmTaxable_' + i).checked;
		}

		if (this.popup_options.afterUpdate) {
			this.popup_options.afterUpdate();
		}
		this.close();
	}
});