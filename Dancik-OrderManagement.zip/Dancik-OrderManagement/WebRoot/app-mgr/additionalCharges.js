var AdditionalCharges = Class.create({
	initialize: function(opts) {
		this.options = Object.extend({
			referenceid: 0,
			orderid: 0
		},opts || {});
		
		this.add = this._add.bind(this);
		
		this.get();
		
	},
	get: function() {
		Dancik.Blanket.InProcess.show({ message : 'Retrieving Additional Charges', sizeByStretch : true, zIndex : 1000 });
		
		var params = {
				parm_ReferenceId: this.options.referenceid,
				parm_OrderId: this.options.orderid
		};
		new Ajax.Request("../api/specialCharges",{
			parameters: params,
			onSuccess: function(res) {
				var json = res.responseJSON;
				
				/*
				json.results = [
				            	{
				            		hdr_description: "Minimum Order Charges",
				            		hdr_type: "H",
				            		specialcharges: "",
				            		taxable: ""
				            	},
				            	{
				            		hdr_description: "YYYYYum Order Charge",
				            		hdr_type: "D",
				            		specialcharges: "15.00",
				            		taxable: "Y"
				            	},
				            	{
				            		hdr_description: "Total Additional Charges",
				            		hdr_type: "T",
				            		specialcharges: "15.00",
				            		taxable: ""
				            	},
				            	{
				            		hdr_description: "Total of Line Items",
				            		hdr_type: "T",
				            		specialcharges: "1172.00",
				            		taxable: ""
				            	},
				            	{
				            		hdr_description: "Order Grand Total",
				            		hdr_type: "T",
				            		specialcharges: "1187.00",
				            		taxable: ""
				            	}
				            ];
				*/
				if(json.results.length==0) {
					new Dancik_ConfirmWindow({
						content:$M("om.noAdditionalCharges"),
						showAsInfoOnly: true,
						modal:true,
						destroyOnClose: true
					}).open();
					return;
				}
				
				var template = new EJS({url: "additionalCharges.ejs"});
				var html = template.render(json);
				
				var buttons = {};
				if(json.info.allowadd=="Y" && Main.settings.editMode) {
					buttons.add="Add to Order";
				}
				
				this.win = new Dancik_ConfirmWindow({
					color:"blue",
					showAsPopup:true,
					popupTitle: "Additional Charges",
					message: html,
					modal:true,
					buttons: buttons,
					destroyOnClose: true,
					closeAfterButton:false,
					onAdd: this.add,
					zIndexModal:9000
				});
				this.win.open();
			
			}.bind(this),
			onFailure: Dancik.ajaxOnFailure,
			onException: Dancik.ajaxOnException,
			onComplete: function() {
				Dancik.Blanket.InProcess.kill()
			}
		})
	},
	_add: function() {
		Dancik.Blanket.InProcess.show({ message : 'Updating Additional Charges', sizeByStretch : true, zIndex : 10000 });
		
		var params = {
				parm_ReferenceId: this.options.referenceid,
				parm_OrderId: this.options.orderid
		};
		new Ajax.Request("../api/specialChargesUpdate",{
			parameters: params,
			onSuccess: function(res) {
				var json = res.responseJSON || {};
				if(json.errors) {
					var errors = json.errors.pluck("errmsg");
					var content= "The following error"+ (errors.length>1?'s':'') +" occurred:"
					var extra = "<div>- "+errors.join("</div><div>- ")+"</div>";
					
					Main.open_ErrorWdw({
						contentHTML : content,
						extraContentHTML : extra
					});
					return;
				}
				
				Main.getOrder.defer();
				this.win.close();
			}.bind(this),
			onFailure: Dancik.ajaxOnFailure,
			onException: Dancik.ajaxOnException,
			onComplete: function() {
				Dancik.Blanket.InProcess.kill()
			}
		});
	}
});