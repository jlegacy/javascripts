/*globals $ Form Dancik Ajax Element*/
// ***************************************************************************************************
// - Main
// ***************************************************************************************************
var Main = Object.extend( OM_Main, {
    ajax: null,
    timeoutId: -1,
    timeoutId2: -1,        	

    
    // ---------------------------------------------------------------------------------------------------
    // - Function    : Main.initialize()
    // ---------------------------------------------------------------------------------------------------
    initialize: function(){
		setTimeout(function(){
			$j('input#parm_CCS_Wdw_Filter').focus();
		},500);


    },
    
    // ---------------------------------------------------------------------------------------------------
    // - Function    : Main.create(Additional Params)
    // ---------------------------------------------------------------------------------------------------
    create: function(addlParams){
		//console.log('Main.create', addlParams);
    	// -- Build parameters...
        var params = Form.serialize('Mgr_OESearch_Form', true);
        if (addlParams) {
            params = Object.extend(params, addlParams);
        }
        
        // -- Avoid multi-loading...
        Dancik.abortAjax(Main.ajax);
        Main.ajax = new Ajax.Request('../jsonservice/OrderManager_WebService/newOrder_VnB', {
            method: 'post',
            parameters: params,
            evalJSON: "force",
            onSuccess: function(res){
                try {
                    var json = res.responseJSON;
                    if (!json) {
                        throw 'EmptyResult';
                    }
                    if (json.errors) {
                        throw 'ErrorCaught';
                    }
                    if (!json.mode) {
                        throw 'NoMode';
                    }
                    
                    Element.hide('CCS_Wdw');
                    Element.hide('BS_Wdw');
                    Element.hide('RS_Wdw');
                    
                    if ($('parm_NewOrder_Type').value=='D'){
                    	var directOrder = 'Y';
                    }
                    else{
                    	var directOrder = 'N';
                    }
                    // -- B -> A Retail# was selected, but a Billto is needed, so goto Billto Search...
                    if (json.mode.equals("B")) {
                        Main.BilltoSearch.openWindow(json);
                        
                        // -- R -> A Billto# was selected, but a Retail is needed, so goto Retail Search...
                    }
                    else 
                        if (json.mode.equals("R")) {
                            Main.RetailSearch.openWindow(json);
                            
                        // -- N -> Order was loaded...
                        }
                        else 
                            if (json.mode.equals("N")) {
                            
                                if (parent.Main && parent.Main.Orders) {
                                    if (parent.Main.Orders.openOrder) {
                                        parent.Main.Orders.openOrder({
                                            parm_ReferenceId: json.reference,
                                            parm_directOrder: directOrder,
                                            parm_AccountNum: params.parm_AccountNum,
											parm_OrderType: params.parm_NewOrder_Type
                                        });
                                    }
                                    if (parent.Main.Orders.closeNewCustomerOrderWindow) {
                                        parent.Main.Orders.closeNewCustomerOrderWindow();
                                    }
                                }
                                
                            // -- C/' ' -> Nothing was selected, go goto Combined Customer Search...
                            }
                            else {
                                Element.show('CCS_Wdw');
                            }
                    $('parm_NewOrder_Type').value='2';
                    
                } 
                catch (e) {
                    Dancik.Log.add("error " + e);
                    if (e == 'ErrorCaught') {
                        var html = [];
                        json.errors.each(function(msg){
                            html.push("<li> - " + msg + "</li>")
                        });
                        new Dancik_ConfirmWindow({
                            color: "red",
                            showAsInfoOnly: true,
                            modal: true,
                            destroyOnClose: true,
                            contentHTML: "The following errors occurred:",
                            extraContentHTML: '<ul class="error-list">' + html.join('') + '</ul>'
                        }).open();
                    }
                    else 
                        if (e == 'EmptyResult') {
                        }
                        else 
                            if (e == 'NoMode') {
                            }
                            else {
                                alert("Main.submitSearch() : " + e.message);
                            }
                }
                finally {
                }
                
            },
            onFailure: Dancik.catchAjaxError
        });
    },
	// ***********************************************************************************************
	//	Main.Options 
	// ***********************************************************************************************
	Options : {
		i : -1,	
		/** -------------------------------------------------------------------------
		*	Main.Options.open : 
		*   ------------------------------------------------------------------------- */
	 	open : function (element) {
			var parentElement = Element.up(element, 'TR'); 
			parentElement.addClassName("selected");			
			
			this.i = parentElement.rowIndex;
			//var o = Main.records[this.i];
			
			
			Main.build_OptionsWdw();
			Main.optionsWdw.removeOptions();		
			
			Main.optionsWdw.addOption({ title : "Display", icon : '../../dws/images/page_go.png', action : function () { Main.Options.displayRecord(element); } } );
			Main.optionsWdw.addOption({ title : 'Update', icon : '../../dws/images/viewDisplay.png', action : function() { Main.Options.updateRecord(element); } });
			//Main.optionsWdw.addOption({ title : 'Select', icon : '../../dws/images/page_go.png', action : function() { Main.RetailSearch.select(this); } });
			

			Main.optionsWdw.open(element);		

	 	},
	 	updateRecord : function(lineSelected) { 
	 		var reatilid="";
			//console.log("lineselected - ",lineSelected);
			//console.log("retailID", $j(lineSelected).closest('td').find(".retailID").val());
			retailid = $j(lineSelected).closest('td').find(".retailID").val();
			$App.Fire("new-retail-customer", {
        		mode: 'update',
				keys: {
					file: "rtlcust",
					id:retailid
				}
			});
			
		},	
		displayRecord : function(lineSelected) { 		
			var retailid = "";
		//	console.log("lineselected - ",lineSelected);
		//	console.log("retailID", $j(lineSelected).closest('td').find(".retailID").val())
			retailid = $j(lineSelected).closest('td').find(".retailID").val();
			$App.Fire("new-retail-customer", {
        		mode: 'inquire',
				keys: {
					file: "rtlcust",
					id:retailid
				}
			});
			
			
		}	
	 },
    
    // ---------------------------------------------------------------------------------------------------
    // - Function    : Main.CustomerSearch
    // ---------------------------------------------------------------------------------------------------
    CustomerSearch: {
        records: [],
        keywordSearch: '',
        
        // ---------------------------------------------------------------------------------------------------
        // - Function    : Main.CustomerSearch.openWindow()
        // ---------------------------------------------------------------------------------------------------
        openWindow: function(opts){
            // -- Construct 'options'...
            var options = Object.extend({
                avoidReset: false // -- Indicates to not execute function "this.reset()"..
            }, opts || {});
            
            // -- Populate/Reset form variables...
            $('parm_RetailId').value = '';
            $('parm_BilltoId').value = '';
            
            // -- Reset everything...
            if (!options.avoidReset) {
                this.reset();
            }
            
            Element.show('CCS_Wdw');
            Element.hide('BS_Wdw');
            Element.hide('RS_Wdw');
            
            // -- Position cursor on Fitler input...
            //			$('parm_CCS_Wdw_Filter').focus();	-- May cause IE Dissappearing act
            (function(){
                $('parm_CCS_Wdw_Filter').focus()
            }
.bind(this)).defer();
        },
        
        
        /** -------------------------------------------------------------------------
         * -- Function   : Main.CustomerSearch.reset
         *   ------------------------------------------------------------------------- */
        reset: function(){
            Main.clearAjax();
            
            this.keywordSearch = '';
            this.records = [];
            
            // -- Re-initialze variables...
            $('parm_CCS_Wdw_Filter').value = '';
            $('CCS_Wdw_SearchData_tbody').update();
            $('CCS_Wdw_QuerySize').innerHTML = '&nbsp;';
            Element.hide('CCS_Wdw_MoreBttn');
        },
        
        /** -------------------------------------------------------------------------
         * -- Function   :  Main.CustomerSearch.newSearch_InDelay()
         *   ------------------------------------------------------------------------- */
        newSearch_InDelay: function(e){
            // -- Determine the key stroke#...
            var key = window.event ? window.event.keyCode : e ? e.which : 0;
//            var keywords = [], activateSearch = false;
            
            // -- If the ENTER key was pressed, then cancel populate() and do not continue.  Form has been submitted...
            if (key == Event.KEY_RETURN) {
                Main.clearAjax();
                
                var tr = Element.down('CCS_Wdw_SearchData_tbody', 'tr.mouseOver');
                // -- If a row is selected in the Auto-Suggest, then submit that...
                if (tr) {
                    Main.CustomerSearch.select(tr);
                    // -- Else, submit the search...
                }
                else {
                    Main.CustomerSearch.newSearch();
                }
                return;
            }
            
            
            // -- Search field is empty...
            if ($F('parm_CCS_Wdw_Filter').isEmpty()) {
                Main.CustomerSearch.reset();
                return;
            }
            
            // -- If the ENTER key was pressed, then cancel populate() and do not continue.  Form has been submitted...
            if (key == Event.KEY_UP || key == Event.KEY_DOWN) {
                Main.keyUpDown(key, $('CCS_Wdw_SearchData_tbody'));
                return;
            }
            
            
            // -- Only continue on certain keys...
            if ((key >= 32 && key < 127) || (key == Event.KEY_BACKSPACE) || (key == 222)) { // -- 222 = quotes
                // -- But, avoid pointless keys...
                if ((key != Event.KEY_LEFT) &&
                (key != Event.KEY_UP) &&
                (key != Event.KEY_RIGHT) &&
                (key != Event.KEY_DOWN) &&
                (key != Event.KEY_HOME) &&
                (key != Event.KEY_END) &&
                (key != Event.KEY_PAGEUP) &&
                (key != Event.KEY_PAGEDOWN) &&
                (key != Event.KEY_INSERT)) {
                
//               		if (!$('parm_ExactMatch_CS').checked) {
//               			activateSearch = false;
//               			keywords = $F('parm_CCS_Wdw_Filter').split(" ");
//               			keywords.each(function(elem){
//               				if (elem.length > 1) {
//               					activateSearch = true;
//               					$break;
//               				}
//               			});
//               		}

               		
//                	//search only if: 
//               		// 1. Exact match is NOT selected and at least one keywords contains 2 or more char 
//               		//                                   -OR-
//               		// 2. Exact match is selected and the keyword contains 2 or more char
//                	if ( !($('parm_ExactMatch_CS').checked)  && activateSearch || 
//                		$('parm_ExactMatch_CS').checked && $F('parm_CCS_Wdw_Filter').strip().length > 1 ) {
                	
                	if ($F('parm_CCS_Wdw_Filter').strip().length > 1 ) {
                	
	                	var newSearchFunction = function(){
	                        Main.CustomerSearch.newSearch();
	                    };
	                    
	                    if (Main.timeoutId > -1) {
	                        clearTimeout(Main.timeoutId);
	                    }
	                    Main.timeoutId = setTimeout(newSearchFunction, 400);
	                    //console.log("In Customer Search");
	                    
	                    if (Main.timeoutId2 > -1) {
	                        clearTimeout(Main.timeoutId2);
	                    }
                	}
                }
            }
        },
        
        
        /** -------------------------------------------------------------------------
         * -- Function   : Main.CustomerSearch.newSearch
         *   ------------------------------------------------------------------------- */
        newSearch: function(){
            this.keywordSearch = $F('parm_CCS_Wdw_Filter').valueOf();
            this.keywordSearch = this.keywordSearch.toUpperCase();
            //if (this.keywordSearch.isEmpty() || this.keywordSearch.strip().length == 1) {
            if (this.keywordSearch.isEmpty()) {
                return;
            }
            
       		this.reload();
        },
        /** -------------------------------------------------------------------------
         * -- Function   : Main.CustomerSearch.reload()	- Reloads contents, because Filter has changed...
         *   ------------------------------------------------------------------------- */
        reload: function(){
            // -- Re-initialze variables...
            $('CCS_Wdw_SearchData_tbody').update();
            Main.CustomerSearch.records = [];
            $('CCS_Wdw_QuerySize').innerHTML = '&nbsp;';
            
            this.populate();
        },
        /** -------------------------------------------------------------------------
         * -- Function   : Main.CustomerSearch.moreRecords()
         *   ------------------------------------------------------------------------- */
        moreRecords: function(){
            $('parm_CCS_Wdw_Filter').value = this.keywordSearch;
            
            this.populate();
        },
        
        /** -------------------------------------------------------------------------
         * -- Function   :  Main.CustomerSearch.populate()	- Reloads contents, because Filter has changed...
         *   ------------------------------------------------------------------------- */
        populate: function(){
            // -- Avoid multi-loading...
            Dancik.abortAjax(Main.ajax);
            
            $('CCS_Wdw_LoadImg').src = '../../dws/images/loading.gif';
            $('CCS_Wdw_QuerySize').update();
            Element.hide('CCS_Wdw_MoreBttn');
            
            // -- Build parameters...
            var p = this.params == null ? {} : this.params;
            p = Object.extend(p, {
                parm_StartingRecord: (Main.CustomerSearch.records.length == 0) ? 0 : (Main.CustomerSearch.records.length + 1),
                parm_FilterKeyWord: this.keywordSearch,
                parm_FilterType: ($('CCS_Wdw_FilterSearchType').checked ? "B" : ""),
                parm_ExactMatch: ($('parm_ExactMatch_CS').checked ? "Y" : "")
            });
            
            
           
            Main.ajax = new Ajax.Request('../jsonservice/OrderManager_WebService/newOrder_CustomerSearch', {
                method: 'get',
                parameters: p,
                evalJSON: "force",
                onSuccess: function(res){
                    try {
                        var json = res.responseJSON;
                        if (json == null) {
                            throw 'EmptyResult';
                        }
                        if (json.errors != null) {
                            throw 'ErrorCaught';
                        }
                        
                        var html = [];
                        
                        if (!json.records) {
                            html.push("<tr>");
                            html.push("<td class='dws-NoRecsFound ccs-col-norecs'> No records found. </td>");
                            html.push("</tr>");
                        }
                        else {
                            var len = json.records.length;
                            
                            // -- If one record is returned,            skip the selection list and go straight to order entry.
                            // -- AND BillTo Account match    - then: 
                            if (len == 1 && json.records[0].accountmatch != null) {
                                if (Main.timeoutId2 > -1) {
                                    clearTimeout(Main.timeoutId2);
                                }
                                
                            	Main.timeoutId2 = 
                            		setTimeout(	function() {
                            						Main.CustomerSearch.records.push(json.records[0]);
                            						Main.CustomerSearch.select_data(json.records[0]);
                            					} , 1500 );
                            }
                            else {
                            	var searchString = $('parm_CCS_Wdw_Filter').value;
                                for (var i = 0; i < len; i++) {
                                    Main.CustomerSearch.records[Main.CustomerSearch.records.length] = json.records[i];
                                    
                                    html.push("<tr class='selectableRows' onclick='Main.CustomerSearch.select(this);'>");
                                    html.push("<td class='EXCEL-Cell'><div class='ccs-col0'>" + Main.CustomerSearch.highlight(json.records[i].dsp_acct,  searchString)  + "</div></td>");
                                    html.push("<td class='EXCEL-Cell'><div class='ccs-col1' style='text-align:left;'>" + Main.CustomerSearch.highlight(json.records[i].name, searchString) + "</div></td>");
                                    html.push("<td class='EXCEL-Cell'><div class='ccs-col2' style='text-align:left;'>" + Main.CustomerSearch.highlight(json.records[i].dba, searchString) + "</div></td>");
                                    html.push("<td class='EXCEL-Cell'><div class='ccs-col3' style='text-align:left;'>" + Main.CustomerSearch.highlight(json.records[i].city, searchString) + "</div></td>");
                                    html.push("<td class='EXCEL-Cell'><div class='ccs-col4'>" + Main.CustomerSearch.highlight(json.records[i].state, searchString) + "</div></td>");
                                    html.push("<td class='EXCEL-Cell'><div class='ccs-col4a'>" + Main.CustomerSearch.highlight(json.records[i].zipcode, searchString) + "</div></td>");
                                    html.push("<td class='EXCEL-Cell'><div class='ccs-col5'>" + Main.CustomerSearch.phoneHighlight(json.records[i].phoneb, searchString) + "</div></td>");
                                    html.push("</tr>");
                                }
                                
                                $('CCS_Wdw_QuerySize').innerHTML = Main.CustomerSearch.records.length + " of " + json.querysize;
                                
                                // -- Determine if the Query has maxed out, and the More button needs to be disabled...
                                if (Main.CustomerSearch.records.length < json.querysize) {
                                    Element.show('CCS_Wdw_MoreBttn');
                                }
                            }
                        }
                        $('CCS_Wdw_SearchData_tbody').insert({
                            bottom: html.join("")
                        });
                        
                        
                        
                    } 
                    catch (e) {
                        if (e == 'ErrorCaught') {
                            var html = [];
                            json.errors.each(function(msg){
                                html.push("<li> - " + msg + "</li>")
                            });
                            new Dancik_ConfirmWindow({
                                color: "red",
                                showAsInfoOnly: true,
                                modal: true,
                                destroyOnClose: true,
                                contentHTML: "The following errors occurred:",
                                extraContentHTML: '<ul class="error-list">' + html.join('') + '</ul>'
                            }).open();
                        }
                        else 
                            if (e == 'EmptyResult') {
                            }
                            else {
                                alert(" Main.reload() : " + e.message);
                            }
                    }
                    finally {
                        //						$('parm_CCS_Wdw_Filter').focus();	-- May cause IE Dissappearing act
                        (function(){
                            $('parm_CCS_Wdw_Filter').focus()
                        }
.bind(this)).defer();
                        $('CCS_Wdw_LoadImg').src = '../../dws/images/refresh.png';
                    }
                    
                },
                onFailure: Dancik.catchAjaxError
            });
        },
        
        /** ----------------------------------------------------------------------------------------
         *  -- Function   : Main.CustomerSearch.highlight(searchThis, searchKeyword)
         *  ----------------------------------------------------------------------------------------  */
        highlight: function(searchThis, searchKeyword) {
        	var uppercaseSearch = searchKeyword.valueOf();
        	uppercaseSearch = uppercaseSearch.toUpperCase();
    	    var dataBegins = searchThis.indexOf(uppercaseSearch);
    	    var dataEnds   = dataBegins + searchKeyword.length;
    	    var beginString;
    	    var endString;
    	    var newSearchThis;
    	    if (dataBegins >= 0) {
    	    	beginString = searchThis.substring(0, dataBegins);
    	    	if (searchThis.length == dataEnds) {
    	    		endString = "";
    	    	}
    	    	else {
    	    		endString = searchThis.substring(dataEnds);
    	    	}
    	    	newSearchThis = beginString + Main.CustomerSearch.highlightSearchText(uppercaseSearch, 'highlight-search-text') + endString;  
    	    	return newSearchThis;
    	    }
    	    else {
    	    	return searchThis;
    	    }
        },
        
        /** ----------------------------------------------------------------------------------------
         *  -- Function   : Main.CustomerSearch.phoneHighlight(searchThis, searchKeyword)
         *  ----------------------------------------------------------------------------------------  */
        phoneHighlight: function(searchThis, searchKeyword) {
        	var strippedPhone = searchThis;
        	strippedPhone = strippedPhone.replace(/[^0-9]+/g,'');
    	    var dataBegins = strippedPhone.indexOf(searchKeyword); 
    	    var dataEnds   = dataBegins + searchKeyword.length;
    	    var newSearchThis;
    	    if (searchKeyword.length == 7 || searchKeyword.length == 10) {
	    	    if (dataBegins >= 0) {
	        	    if (searchKeyword.length == 7) {
	        	    	newSearchThis = searchThis.substring(0, 5) + " " + Main.CustomerSearch.highlightSearchText(searchThis.substring(6), 'highlight-search-text');  
	        	    } 
	        	    else {
	        	    	newSearchThis = Main.CustomerSearch.highlightSearchText(searchThis, 'highlight-search-text');  
	        	    }	    	    	
	    	    	return newSearchThis;
	    	    }
	    	    else {
	    	    	return searchThis;
	    	    }
    	    }
    	    else {
    	    	return searchThis;
    	    }
        },
        
        /** ----------------------------------------------------------------------------------------
         *  -- Function   : Main.CustomerSearch.highlightSearchText(str, classname)
         *  ----------------------------------------------------------------------------------------  */
        highlightSearchText: function(str, classname) {
    	    var regex = new RegExp(str, "g");

    	    return "<span class=\"" + classname + "\">" + str + "</span>";
        },
        
        /** ----------------------------------------------------------------------------------------
         * -- Function   :  Main.CustomerSearch.select() -
         *   ---------------------------------------------------------------------------------------- */
        select: function(tr){
            var record = Main.CustomerSearch.records[tr.rowIndex];
            this.select_data(record);
        },
        
        /** ----------------------------------------------------------------------------------------
         * -- Function   :  Main.CustomerSearch.select_data() -
         *   ---------------------------------------------------------------------------------------- */
        select_data: function(record){
            var params = {
                parm_NewOrder_RRN: record.rrn,
                parm_NewOrder_FileType: record.filetype,
                parm_AccountNum: record.dsp_acct
            };
            Main.create(params);
        },
        
        /** ----------------------------------------------------------------------------------------
         * -- Function   :  Main.CustomerSearch.createCustomer() -
         *   ---------------------------------------------------------------------------------------- */
        createCustomer: function(){
        	
        	$App.Fire("new-retail-customer", {
        		mode: 'create',
				keys: {
					file: "rtlcust"
				}
			});
//            new CreateRetailCustomer_Popup({}, {
//                afterCreate: function(record){
//                    if (record) {
//                        $('parm_CCS_Wdw_Filter').value = record.firstname + ' ' + record.lastname;
//                        Main.CustomerSearch.newSearch();
//                    }
//                }
//            }).open();
        }
        
    },
    
    
    // ---------------------------------------------------------------------------------------------------
    // - Function    : Main.BilltoSearch
    // ---------------------------------------------------------------------------------------------------
    BilltoSearch: {
        records: [],
        keywordSearch: '',
        
        // ---------------------------------------------------------------------------------------------------
        // - Function    : Main.BilltoSearch.openWindow()
        // ---------------------------------------------------------------------------------------------------
        openWindow: function(json){
        
            // -- Load the selected Retail Customer information...
            if (json && json.records) {
                // -- Populate/Reset form variables...
                $('parm_RetailId').value = json.records[0].id;
                $('parm_BilltoId').value = '';
                
                // -- Load Retail information to view...
                var html = [];
                html.push('<div class="oe-greyBox-Address">' + json.records[0].fullname + '</div>');
                html.push('<div class="oe-greyBox-Address">' + json.records[0].address1 + '</div>');
                if (!json.records[0].address2.isEmpty()) {
                    html.push('<div class="oe-greyBox-Address">' + json.records[0].address2 + '</div>');
                }
                html.push('<div class="oe-greyBox-Address">' + json.records[0].citystate + '</div>');
                html.push('<div class="oe-greyBox-Address">' + json.records[0].phone + '</div>');
                $('BS_Wdw_CustomerInfo').innerHTML = html.join('');
            }
            
            // -- Reset everything...
            this.reset();
            
            // -- Open and show window...
            Element.hide('CCS_Wdw');
            Element.hide('RS_Wdw');
            Element.show('BS_Wdw');
            
            // -- Position cursor on Fitler input...
            //			$('parm_BS_Wdw_Filter').focus();	-- May cause IE Dissappearing act
            (function(){
                $('parm_BS_Wdw_Filter').focus()
            }
.bind(this)).defer();
            
        },
                
        /** -------------------------------------------------------------------------
         * -- Function   :  Main.BilltoSearch.reset()
         *   ------------------------------------------------------------------------- */
        reset: function(opts){
            // -- Construct 'options'...
            var options = Object.extend({
                avoidClearingKeyword: false // -- Indicates to not execute function "this.reset()"..
            }, opts || {});
            
            Main.clearAjax();
            
            // -- Re-initialze variables...
            this.records = [];
            $('BS_Wdw_SearchData_tbody').update();
            $('BS_Wdw_QuerySize').update();
            Element.hide('BS_Wdw_MoreBttn');
            
            if (!options.avoidClearingKeyword) {
                this.keywordSearch = '';
                $('parm_BS_Wdw_Filter').value = '';
            }
        },
        
        /** -------------------------------------------------------------------------
         * -- Function   :  Main.BilltoSearch.newSearch_InDelay()
         *   ------------------------------------------------------------------------- */
        newSearch_InDelay: function(e){
            // -- Determine the key stroke#...
            var key = window.event ? window.event.keyCode : e ? e.which : 0;
            
            
            // -- If the ENTER key was pressed, then cancel populate() and do not continue.  Form has been submitted...
            if (key == Event.KEY_RETURN) {
                Main.clearAjax();
                
                var tr = Element.down($('BS_Wdw_SearchData_tbody'), 'tr.mouseOver');
                // -- If a row is selected in the Auto-Suggest, then submit that...
                if (tr) {
                    Main.BilltoSearch.select(tr);
                    // -- Else, submit the search...
                }
                else {
                    Main.BilltoSearch.newSearch();
                }
                return;
            }
            
            // -- Search field is empty...
            if ($F('parm_BS_Wdw_Filter').isEmpty()) {
                Main.BilltoSearch.reset();
                return;
            }
            
            // -- If the ENTER key was pressed, then cancel populate() and do not continue.  Form has been submitted...
            if (key == Event.KEY_UP || key == Event.KEY_DOWN) {
                Main.keyUpDown(key, $('BS_Wdw_SearchData_tbody'));
                return;
            }
            
            
            // -- Only continue on certain keys...
            if ((key >= 32 && key < 127) || (key == Event.KEY_BACKSPACE) || (key == 222)) { // -- 222 = quotes
                // -- But, avoid pointless keys...
                if ((key != Event.KEY_LEFT) &&
                (key != Event.KEY_UP) &&
                (key != Event.KEY_RIGHT) &&
                (key != Event.KEY_DOWN) &&
                (key != Event.KEY_HOME) &&
                (key != Event.KEY_END) &&
                (key != Event.KEY_PAGEUP) &&
                (key != Event.KEY_PAGEDOWN) &&
                (key != Event.KEY_INSERT)) {
                
                	//search only for keywords with 2 or more char  
                	if ($F('parm_BS_Wdw_Filter').strip().length > 1) {
                	
	                    var newSearchFunction = function(){
	                        Main.BilltoSearch.newSearch();
	                    };
	                    
	                    if (Main.timeoutId > -1) {
	                        clearTimeout(Main.timeoutId);
	                    }
	                    Main.timeoutId = setTimeout(newSearchFunction, 400);
                    
                	}
                }
            }
        },
        
        /** -------------------------------------------------------------------------
         * -- Function   : Main.BilltoSearch.newSearch
         *   ------------------------------------------------------------------------- */
        newSearch: function(){
            this.keywordSearch = $F('parm_BS_Wdw_Filter').valueOf();
            this.keywordSearch = this.keywordSearch.toUpperCase();
            this.reload();
        },
        /** -------------------------------------------------------------------------
         * -- Function   : Main.BilltoSearch.reload() - Reloads contents, because Filter/Sort has changed...
         *   ------------------------------------------------------------------------- */
        reload: function(){
            Main.BilltoSearch.reset({
                avoidClearingKeyword: true
            });
            
            this.populate();
        },
        /** -------------------------------------------------------------------------
         * -- Function   : Main.BilltoSearch.moreRecords()
         *   ------------------------------------------------------------------------- */
        moreRecords: function(){
            $('parm_BS_Wdw_Filter').value = this.keywordSearch;
            
            this.populate();
        },
        
        /** -------------------------------------------------------------------------
         * -- Function   :  Main.BilltoSearch.populate()	- Reloads contents, because Filter has changed...
         *   ------------------------------------------------------------------------- */
        populate: function(){
            // -- Avoid multi-loading...
            Dancik.abortAjax(Main.ajax);
            
            // -- Prepare to start search...
            $('BS_Wdw_LoadImg').src = '../../dws/images/loading.gif';
            $('BS_Wdw_QuerySize').update();
            Element.hide('BS_Wdw_MoreBttn');
            
            
            // -- Build parameters...
            var p = this.params == null ? {} : this.params;
            p = Object.extend(p, {
                parm_StartingRecord: (Main.BilltoSearch.records.length == 0) ? 0 : (Main.BilltoSearch.records.length + 1),
                parm_FilterKeyWord: this.keywordSearch,
                parm_ExactMatch: ($('parm_ExactMatch_BS').checked ? "Y" : "")
            });
            
            
            
            // -- Execute search...	
            Main.BilltoSearch.ajax = new Ajax.Request('../jsonservice/OrderManager_WebService/newOrder_BilltoSearch', {
                method: 'get',
                parameters: p,
                onSuccess: function(res){
                    try {
                        if (res.responseText.isEmpty()) {
                            throw 'EmptyResult';
                        }
                        json = res.responseText.evalJSON(true);
                        if (json == null) {
                            throw 'EmptyResult';
                        }
                        if (json.errors != null) {
                            throw 'ErrorCaught';
                        }
                        
                        var html = [];
                        if (!json.records) {
                            html.push("<tr>");
                            html.push("<td class='dws-NoRecsFound ccs-col-norecs'> No records found. </td>");
                            html.push("</tr>");
                        }
                        else {
                        	var searchString = $('parm_BS_Wdw_Filter').value;
                            var len = json.records.length;
                            for (var i = 0; i < len; i++) {
                                Main.BilltoSearch.records[Main.BilltoSearch.records.length] = json.records[i];
                                
                                html.push("<tr class='selectableRows' onclick='Main.BilltoSearch.select(this);'>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col0'>" + Main.BilltoSearch.highlight(json.records[i].dsp_acct, searchString) + "</div></td>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col1' style='text-align:left;'>" + Main.BilltoSearch.highlight(json.records[i].name, searchString) + "</div></td>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col2' style='text-align:left;'>" + Main.BilltoSearch.highlight(json.records[i].dba, searchString) + "</div></td>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col3' style='text-align:left;'>" + Main.BilltoSearch.highlight(json.records[i].city, searchString) + "</div></td>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col4'>" + Main.BilltoSearch.highlight(json.records[i].state, searchString) + "</div></td>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col4a'>" + Main.BilltoSearch.highlight(json.records[i].zipcode, searchString) + "</div></td>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col5'>" + Main.BilltoSearch.phoneHighlight(json.records[i].phoneb, searchString) + "</div></td>");
                                html.push("</tr>");
                            }
                            
                            $('BS_Wdw_QuerySize').innerHTML = Main.BilltoSearch.records.length + " of " + json.querysize;
                            
                            // -- Determine if the Query has maxed out, and the More button needs to be disabled...
                            if (Main.BilltoSearch.records.length < json.querysize) {
                                Element.show('BS_Wdw_MoreBttn');
                            }
                        }
                        $('BS_Wdw_SearchData_tbody').insert({
                            bottom: html.join("")
                        });
                        
                    } 
                    catch (e) {
                        if (e == 'ErrorCaught') {
                            var html = [];
                            json.errors.each(function(msg){
                                html.push("<li> - " + msg + "</li>")
                            });
                            new Dancik_ConfirmWindow({
                                color: "red",
                                showAsInfoOnly: true,
                                modal: true,
                                destroyOnClose: true,
                                contentHTML: "The following errors occurred:",
                                extraContentHTML: '<ul class="error-list">' + html.join('') + '</ul>'
                            }).open();
                        }
                        else 
                            if (e == 'EmptyResult') {
                            }
                            else {
                                alert(" Main.BilltoSearch.reload() : " + e.message);
                            }
                    }
                    finally {
                        //						$('parm_BS_Wdw_Filter').focus();	-- May cause IE Dissappearing act
                        (function(){
                            $('parm_BS_Wdw_Filter').focus()
                        }
.bind(this)).defer();
                        $('BS_Wdw_LoadImg').src = '../../dws/images/refresh.png';
                    }
                    
                },
                onFailure: Dancik.catchAjaxError
            });
        },
        
        /** ----------------------------------------------------------------------------------------
         *  -- Function   : Main.BilltoSearch.highlight(searchThis, searchKeyword)
         *  ----------------------------------------------------------------------------------------  */
        highlight: function(searchThis, searchKeyword) {
        	var uppercaseSearch = searchKeyword.valueOf();
        	uppercaseSearch = uppercaseSearch.toUpperCase();
    	    var dataBegins = searchThis.indexOf(uppercaseSearch);
    	    var dataEnds   = dataBegins + searchKeyword.length;
    	    var beginString;
    	    var endString;
    	    var newSearchThis;
    	    if (dataBegins >= 0) {
    	    	beginString = searchThis.substring(0, dataBegins);
    	    	if (searchThis.length == dataEnds) {
    	    		endString = "";
    	    	}
    	    	else {
    	    		endString = searchThis.substring(dataEnds);
    	    	}
    	    	newSearchThis = beginString + Main.BilltoSearch.highlightSearchText(uppercaseSearch, 'highlight-search-text') + endString;  
    	    	return newSearchThis;
    	    }
    	    else {
    	    	return searchThis;
    	    }
        },
        /** ----------------------------------------------------------------------------------------
         *  -- Function   : Main.BilltoSearch.phoneHighlight(searchThis, searchKeyword)
         *  ----------------------------------------------------------------------------------------  */
        phoneHighlight: function(searchThis, searchKeyword) {
        	var strippedPhone = searchThis;
        	strippedPhone = strippedPhone.replace(/[^0-9]+/g,'');
    	    var dataBegins = strippedPhone.indexOf(searchKeyword);
    	    var dataEnds   = dataBegins + searchKeyword.length;
    	    var newSearchThis;
    	    if (searchKeyword.length == 7 || searchKeyword.length == 10) {
	    	    if (dataBegins >= 0) {
	        	    if (searchKeyword.length == 7) {
	        	    	newSearchThis = searchThis.substring(0, 5) + " " + Main.CustomerSearch.highlightSearchText(searchThis.substring(6), 'highlight-search-text');  
	        	    } 
	        	    else {
	        	    	newSearchThis = Main.CustomerSearch.highlightSearchText(searchThis, 'highlight-search-text');  
	        	    }	    	    	
	    	    	return newSearchThis;
	    	    }
	    	    else {
	    	    	return searchThis;
	    	    }
    	    }
    	    else {
    	    	return searchThis;
    	    }
        },
/**
        /** ----------------------------------------------------------------------------------------
         *  -- Function   : Main.CustomerSearch.highlightSearchText(str, classname)
         *  ----------------------------------------------------------------------------------------  */
        highlightSearchText: function(str, classname) {
    	    var regex = new RegExp(str, "g");

    	    return "<span class=\"" + classname + "\">" + str + "</span>";
        },

        /** ----------------------------------------------------------------------------------------
         * -- Function   :  Main.BilltoSearch.select() -
         *   ---------------------------------------------------------------------------------------- */
        select: function(tr){
            var record = Main.BilltoSearch.records[tr.rowIndex];
            
            var params = {
                parm_NewOrder_BilltoId: record.dsp_acct,
                parm_NewOrder_RetailId: $F('parm_RetailId')
            };
            
            Main.create(params);
        }
    },
    
    // ---------------------------------------------------------------------------------------------------
    // - Function    : Main.RetailSearch
    // ---------------------------------------------------------------------------------------------------
    RetailSearch: {
    	
        records: [],
        keywordSearch: '',
        
        // ---------------------------------------------------------------------------------------------------
        // - Function    : Main.RetailSearch.openWindow()
        // ---------------------------------------------------------------------------------------------------
        openWindow: function(json){
            // -- Load the selected Retail Customer information...
            if (json && json.records) {
                // -- Populate/Reset form variables...
                $('parm_BilltoId').value = json.records[0].id;
                $('parm_RetailId').value = '';
                
                // -- Load Retail information to view...
                var html = [];
                html.push('<div class="oe-greyBox-Address">' + json.records[0].id + " - " + json.records[0].name + '</div>');
                html.push('<div class="oe-greyBox-Address">' + json.records[0].address1 + '</div>');
                if (!json.records[0].address2.isEmpty()) {
                    html.push('<div class="oe-greyBox-Address">' + json.records[0].address2 + '</div>');
                }
                html.push('<div class="oe-greyBox-Address">' + json.records[0].citystate + '</div>');
                html.push('<div class="oe-greyBox-Address">' + json.records[0].phone + '</div>');
                $('RS_Wdw_BillingAccountInfo').innerHTML = html.join('');
            }
            
            // -- Reset everything...
            this.reset();
            
            // -- Open and show window...
            Element.hide('BS_Wdw');
            Element.hide('CCS_Wdw');
            Element.show('RS_Wdw');
            // -- Position cursor on Fitler input...
            //			$('parm_RS_Wdw_Filter').focus();	-- May cause IE Dissappearing act
            (function(){
                $('parm_RS_Wdw_Filter').focus()
            }
.bind(this)).defer();
            
            
            
        },
        
        /** -------------------------------------------------------------------------
         * -- Function   :  Main.RetailSearch.reset()
         *   ------------------------------------------------------------------------- */
        reset: function(opts){
            // -- Construct 'options'...
            var options = Object.extend({
                avoidClearingKeyword: false // -- Indicates to not execute function "this.reset()"..
            }, opts || {});
            
            Main.clearAjax();
            
            // -- Re-initialze variables...
            this.records = [];
            $('RS_Wdw_SearchData_tbody').update();
            $('RS_Wdw_QuerySize').update();
            Element.hide('RS_Wdw_MoreBttn');
            
            if (!options.avoidClearingKeyword) {
                this.keywordSearch = '';
                $('parm_RS_Wdw_Filter').value = '';
            }
            
        },
        
        /** -------------------------------------------------------------------------
         * -- Function   :  Main.RetailSearch.newSearch_InDelay()
         *   ------------------------------------------------------------------------- */
        newSearch_InDelay: function(e){
            // -- Determine the key stroke#...
            var key = window.event ? window.event.keyCode : e ? e.which : 0;
            
            // -- If the ENTER key was pressed, then cancel populate() and do not continue.  Form has been submitted...
            if (key == Event.KEY_RETURN) {
                Main.clearAjax();
                
                var tr = Element.down($('RS_Wdw_SearchData_tbody'), 'tr.mouseOver');
                // -- If a row is selected in the Auto-Suggest, then submit that...
                if (tr) {
                    Main.RetailSearch.select(tr);
                    // -- Else, submit the search...
                }
                else {
                    Main.RetailSearch.newSearch();
                }
                return;
            }
            
            
            // -- Search field is empty...
            if ($F('parm_RS_Wdw_Filter').isEmpty()) {
                Main.RetailSearch.reset();
                return;
            }
            
            // -- If the ENTER key was pressed, then cancel populate() and do not continue.  Form has been submitted...
            if (key == Event.KEY_UP || key == Event.KEY_DOWN) {
                Main.keyUpDown(key, $('RS_Wdw_SearchData_tbody'));
                return;
            }
            
            
            // -- Only continue on certain keys...
            if ((key >= 32 && key < 127) || (key == Event.KEY_BACKSPACE) || (key == 222)) { // -- 222 = quotes
                // -- But, avoid pointless keys...
                if ((key != Event.KEY_LEFT) &&
                (key != Event.KEY_UP) &&
                (key != Event.KEY_RIGHT) &&
                (key != Event.KEY_DOWN) &&
                (key != Event.KEY_HOME) &&
                (key != Event.KEY_END) &&
                (key != Event.KEY_PAGEUP) &&
                (key != Event.KEY_PAGEDOWN) &&
                (key != Event.KEY_INSERT)) {
                
                	//search only for keywords with 2 or more char  
                	if ($F('parm_RS_Wdw_Filter').strip().length > 1) {
                	
	                    var newSearchFunction = function(){
	                        Main.RetailSearch.newSearch();
	                    };
	                    
	                    if (Main.timeoutId > -1) {
	                        clearTimeout(Main.timeoutId);
	                    }
	                    Main.timeoutId = setTimeout(newSearchFunction, 400);
                	}
                }
            }
        },
        
        /** -------------------------------------------------------------------------
         * -- Function   : Main.RetailSearch.newSearch
         *   ------------------------------------------------------------------------- */
        newSearch: function(){
            this.keywordSearch = $F('parm_RS_Wdw_Filter').valueOf();
            this.keywordSearch = this.keywordSearch.toUpperCase();
            this.reload();
        },
        /** -------------------------------------------------------------------------
         * -- Function   : Main.RetailSearch.reload()	- Reloads contents, because Filter has changed...
         *   ------------------------------------------------------------------------- */
        reload: function(){
            // -- Re-initialze variables...
            $('RS_Wdw_SearchData_tbody').update();
            Main.RetailSearch.records = [];
            $('RS_Wdw_QuerySize').innerHTML = '';
            
            this.populate();
        },
        /** -------------------------------------------------------------------------
         * -- Function   : Main.RetailSearch.moreRecords()
         *   ------------------------------------------------------------------------- */
        moreRecords: function(){
            $('parm_RS_Wdw_Filter').value = this.keywordSearch;
            
            this.populate();
        },
        
        /** -------------------------------------------------------------------------
         * -- Function   :  Main.RetailSearch.populate()	- Reloads contents, because Filter has changed...
         *   ------------------------------------------------------------------------- */
        populate: function(){
            // -- Prepare to start search...
            $('RS_Wdw_LoadImg').src = '../../dws/images/loading.gif';
            $('RS_Wdw_QuerySize').update();
            Element.hide('RS_Wdw_MoreBttn');
            
            
            // -- Build parameters...
            var p = this.params == null ? {} : this.params;
            p = Object.extend(p, {
                parm_StartingRecord: (Main.RetailSearch.records.length == 0) ? 0 : (Main.RetailSearch.records.length + 1),
                parm_FilterKeyWord: this.keywordSearch,
                parm_ExactMatch: ($('parm_ExactMatch_RS').checked ? "Y" : "")
            });
            
            
            // -- Avoid multi-loading...
            Dancik.abortAjax(Main.ajax);
            Main.ajax = new Ajax.Request('../jsonservice/OrderManager_WebService/newOrder_RetailSearch', {
                method: 'get',
                parameters: p,
                evalJSON: "force",
                onSuccess: function(res){
                    try {
                        var json = res.responseJSON;
                        if (json == null) {
                            throw 'EmptyResult';
                        }
                        if (json.errors != null) {
                            throw 'ErrorCaught';
                        }
                        
                        var html = [];
                        if (!json.records) {
                            html.push("<tr>");
                            html.push("<td class='dws-NoRecsFound ccs-col-norecs'> No records found. </td>");
                            html.push("</tr>");
                        }
                        else {
                        	var searchString = $('parm_RS_Wdw_Filter').value;
                            var len = json.records.length;
                            for (var i = 0; i < len; i++) {
                                Main.RetailSearch.records[Main.RetailSearch.records.length] = json.records[i];
                                
                                html.push("<tr class='selectableRows' ondblclick='Main.RetailSearch.select(this);'>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col4'><img class='loneOption' src='../../dws/images/option_arrow.png' class='img' alt='Available Options' onclick='Main.Options.open(this);'><input type='hidden' name='retailID' value='"+ Main.RetailSearch.highlight(json.records[i].id, searchString) + "</div></td>");
                                html.push("<td class='EXCEL-Cell'><input type='hidden' name='retailID' class='retailID' value='"+ Main.RetailSearch.highlight(json.records[i].id, searchString) + "'></td>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col1a' style='text-align:left;'>" + Main.RetailSearch.highlight(json.records[i].name, searchString) + "</div></td>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col3' style='text-align:left;'>" + Main.RetailSearch.highlight(json.records[i].city, searchString) + "</div></td>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col4'>" + Main.RetailSearch.highlight(json.records[i].state, searchString) + "</div></td>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col4a'>" + Main.RetailSearch.highlight(json.records[i].zipcode, searchString) + "</div></td>");
                                html.push("<td class='EXCEL-Cell'><div class='ccs-col5'>" + Main.RetailSearch.phoneHighlight(json.records[i].phoneb, searchString) + "</div></td>");                              
                                
                                html.push("</tr>");
                            }
                            
                            $('RS_Wdw_QuerySize').innerHTML = Main.RetailSearch.records.length + " of " + json.querysize;
                            
                            // -- Determine if the Query has maxed out, and the More button needs to be disabled...
                            if (Main.RetailSearch.records.length < json.querysize) {
                                Element.show('RS_Wdw_MoreBttn');
                            }
                        }
                        $('RS_Wdw_SearchData_tbody').insert({
                            bottom: html.join("")
                        });
                        
                        
                    } 
                    catch (e) {
                        if (e == 'ErrorCaught') {
                            var html = [];
                            json.errors.each(function(msg){
                                html.push("<li> - " + msg + "</li>")
                            });
                            new Dancik_ConfirmWindow({
                                color: "red",
                                showAsInfoOnly: true,
                                modal: true,
                                destroyOnClose: true,
                                contentHTML: "The following errors occurred:",
                                extraContentHTML: '<ul class="error-list">' + html.join('') + '</ul>'
                            }).open();
                        }
                        else 
                            if (e == 'EmptyResult') {
                            }
                            else {
                                alert(" Main.RetailSearch.populate() : " + e.message);
                            }
                    }
                    finally {
                        //						$('parm_RS_Wdw_Filter').focus();	-- May cause IE Dissappearing act
                        (function(){
                            $('parm_RS_Wdw_Filter').focus()
                        }
.bind(this)).defer();
                        $('RS_Wdw_LoadImg').src = '../../dws/images/refresh.png';
                    }
                    
                },
                onFailure: Dancik.catchAjaxError
            });
        },
        
        /** ----------------------------------------------------------------------------------------
         * -- Function   :  Main.RetailSearch.select() -
         *   ---------------------------------------------------------------------------------------- */
        select: function(tr){
            var record, params;
            if (tr) {
                record = Main.RetailSearch.records[tr.rowIndex];
            }
            else {
                record = {
                    id: 0
                };
            }
            
            params = {
                parm_NewOrder_RetailId: record.id,
                parm_NewOrder_BilltoId: $F('parm_BilltoId')
            };
            
            Main.create(params);
        },

        /** ----------------------------------------------------------------------------------------
         *  -- Function   : Main.RetailSearch.highlight(searchThis, searchKeyword)
         *  ----------------------------------------------------------------------------------------  */
        highlight: function(searchThis, searchKeyword) {
        	var uppercaseSearch = searchKeyword.valueOf();
        	uppercaseSearch = uppercaseSearch.toUpperCase();
    	    var dataBegins = searchThis.indexOf(uppercaseSearch);
    	    var dataEnds   = dataBegins + searchKeyword.length;
    	    var beginString;
    	    var endString;
    	    var newSearchThis;
    	    if (dataBegins >= 0) {
    	    	beginString = searchThis.substring(0, dataBegins);
    	    	if (searchThis.length == dataEnds) {
    	    		endString = "";
    	    	}
    	    	else {
    	    		endString = searchThis.substring(dataEnds);
    	    	}
    	    	newSearchThis = beginString + Main.RetailSearch.highlightSearchText(uppercaseSearch, 'highlight-search-text') + endString;  
    	    	return newSearchThis;
    	    }
    	    else {
    	    	return searchThis;
    	    }
        },
        
        /** ----------------------------------------------------------------------------------------
         *  -- Function   : Main.RetailSearch.phoneHighlight(searchThis, searchKeyword)
         *  ----------------------------------------------------------------------------------------  */
        phoneHighlight: function(searchThis, searchKeyword) {
        	var strippedPhone = searchThis;
        	strippedPhone = strippedPhone.replace(/[^0-9]+/g,'');
    	    var dataBegins = strippedPhone.indexOf(searchKeyword); 
    	    var dataEnds   = dataBegins + searchKeyword.length;
    	    var newSearchThis;
    	    if (searchKeyword.length == 7 || searchKeyword.length == 10) {
	    	    if (dataBegins >= 0) {
	        	    if (searchKeyword.length == 7) {
	        	    	newSearchThis = searchThis.substring(0, 5) + " " + Main.CustomerSearch.highlightSearchText(searchThis.substring(6), 'highlight-search-text');  
	        	    } 
	        	    else {
	        	    	newSearchThis = Main.CustomerSearch.highlightSearchText(searchThis, 'highlight-search-text');  
	        	    }	    	    	 
	    	    	return newSearchThis;
	    	    }
	    	    else {
	    	    	return searchThis;
	    	    }
    	    }
    	    else {
    	    	return searchThis;
    	    }
        },
     
        /** ----------------------------------------------------------------------------------------
         *  -- Function   : Main.CustomerSearch.highlightSearchText(str, classname)
         *  ----------------------------------------------------------------------------------------  */
        highlightSearchText: function(str, classname) {
    	    var regex = new RegExp(str, "g");

    	    return "<span class=\"" + classname + "\">" + str + "</span>";
        },
        
        /** ----------------------------------------------------------------------------------------
         * -- Function   :  Main.RetailSearch.createCustomer() -
         *   ---------------------------------------------------------------------------------------- */
        createCustomer: function(){
        	$App.Fire("new-retail-customer", {
        		mode: 'create',
				keys: {
					file: "rtlcust"
				}
			});
//        	console.log("test");
//            new CreateRetailCustomer_Popup({}, {
//                afterCreate: function(record){
//                    if (record) {
//                        $('parm_RS_Wdw_Filter').value = record.firstname + ' ' + record.lastname;
//                        Main.RetailSearch.newSearch();
//                    }
//                }
//            }).open();
        }
    },
    // ---------------------------------------------------------------------------------------------------
    // - Function    : Main.clearAjax()
    // ---------------------------------------------------------------------------------------------------
    clearAjax: function(){
        // -- Abort any ongoing search...
        clearTimeout(Main.timeoutId);
        Dancik.abortAjax(Main.ajax);
    },
    
    
    /** ----------------------------------------------------------------------------------------
     * -- Function   :  Main.keyUpDown(key) -
     *   ---------------------------------------------------------------------------------------- */
    keyUpDown: function(key, tbody){
    
        var tr = Element.down(tbody, 'tr.mouseOver');
        
        if (key == Event.KEY_UP) {
            if (tr) {
                var prevTr = tr.previous();
                if (prevTr) {
                    Element.addClassName(prevTr, "mouseOver");
                    Element.removeClassName(tr, "mouseOver");
                }
            }
            else {
                var children = Element.childElements(tbody);
                if (children && children.length > 0) {
                    Element.addClassName(children[children.length - 1], "mouseOver");
                }
            }
        }
        else 
            if (key == Event.KEY_DOWN) {
                if (tr) {
                    var nextTr = tr.next();
                    if (nextTr) {
                        Element.addClassName(nextTr, "mouseOver");
                        Element.removeClassName(tr, "mouseOver");
                    }
                }
                else {
                    var children = Element.childElements(tbody);
                    if (children && children.length > 0) {
                        Element.addClassName(children[0], "mouseOver");
                    }
                }
            }
    }
});
