Validation.add('validate-addItemR', 'Received is invalid.', {
	pattern: /^[BTYN]$/
})
Validation.add('num5_2neg', '%T format is (-)99999.99.', {
	pattern: /^-?(\d{1,5}|\d{0,5}\.\d{1,2})$/
})
Validation.add('num4_3neg', '%T format is (-)9999.999.', {
	pattern: /^-?(\d{1,4}|\d{0,4}\.\d{1,3})$/
})
Validation.add('num6_3', '%T format is 999999.999.', {
	pattern: /^-?(\d{0,6}|\d{0,6}\.\d{0,3})$/
})
Validation.add('num7_2neg', '%T format is (-)9999999.99.', {
	pattern: /^-?(\d{0,7}|\d{0,7}\.\d{0,2})$/
})
Validation.add('num0_2', '%T format is (-).99.', {
	pattern: /^\.\d{0,2}$/
})
Validation.add('num1_2', '%T format is (-)9999999.99.', {
	pattern: /^\.\d{0,2}$/
})

var AddItem = Class.create({
	isOrder: null, //json object to be populated by AddItem.flag
	isItem: null, //json object to be populated by AddItem.flag
	initialize: function (json, opts) {
		var container;
		var containerOM_HiddenFields = $j('#om-order-hidden-fields');

		this.options = Object.extend({
			actionButtonText: "Add Line",
			actionButtonAction: this.addLine.bind(this),
			windowTitle: "Add Line",
			name: "Add Line",
			actionButtonText2: "Add Line",
			actionButtonAction2: this.addLine2.bind(this),
			windowTitle2: "Add Line"
		}, opts || {});

		var template = new EJS({url: "addItem.ejs"});

		this.flag(json.info);
		json.isOrder = this.isOrder;
		json.isItem = this.isItem;
		json.isLine = this.isLine;

		var dims = document.viewport.getDimensions();
		json.height = dims.height - 90;

		this.id = new Date().getTime();
		json.id = this.id;

		var html = template.render(json);

		this.win = new Dancik_ConfirmWindow({
			color: "blue",
			showAsPopup: true,
			popupTitle: this.options.windowTitle,
			message: html,
			modal: true,
			buttons: {action: this.options.actionButtonText, action2: this.options.actionButtonText2},
			onAction: this.options.actionButtonAction,
			onAction2: this.options.actionButtonAction2,
			closeAfterButton: false,
			destroyOnClose: true,
			zIndexModal: 9000
		});

		this.restrictForm();

		this.win.open();
		if (json.info.msg_warn && !json.info.msg_warn.blank()) {
			new Dancik_ConfirmWindow({
				content: json.info.msg_warn,
				showAsInfoOnly: true,
				modal: true
			}).open();

		}

		//we will flag qty and um as changed first time around.  either the user will change them,
		//or they were pre populated and should trigger the first redisplay calculation
		if (!this.isLine.edit) {		//pp: EVNT 1XOV
			this.updateQuantity();
			this.updateUM();
		}

		//initially set add line button for inventory analysis to hide, show default add line button
		container = $j('.dws-Confirm-Buttons');
		container.find("[id$=Button_action2]").hide();

		//if no inventory disable checkbox
		$j('#clickableAnalysisLabel').find('label:first').removeClass('disabled');
		$j('#inventoryAnalysis_ID_CheckBox').attr('disabled', false);

		if (json.inventory.length === 0)
		{
			$j('#inventoryAnalysis_ID_CheckBox').attr('disabled', true);
			$j('#clickableAnalysisLabel').find('label:first').addClass('disabled');
		}

		//if edit mode disable checkbox//
		if ($j('#om-hidden-line').val().trim() !== "")
		{
			$j('#inventoryAnalysis_ID_CheckBox').attr('disabled', true);
			$j('#clickableAnalysisLabel').find('label:first').addClass('disabled');
		}


		this.register();
		this.setUpClicks(json);
		this.setUPDropDowns();

          //set on inventory analysis flag if back end requests it//
          if (json.info.inventory_analysis_checked === 'Y')
          {
              //known issue with jquery when using trigger, it fires signal then changes the state of
              // the checkbox.  Thats why have to put extra checked at bottom.  Other people online
              // having same issue.
               $j('#inventoryAnalysis_ID_CheckBox').attr('checked', true);
               $j('#inventoryAnalysis_ID_CheckBox').trigger('click');
               $j('#inventoryAnalysis_ID_CheckBox').attr('checked', true);  
          }


	},
	register: function () {
		AddItem.register(this);
	},
	flag: function (info) {
		this.isOrder = {
			PO: /^\d00001$/.test(Main.record.header.billingaccount),
			transfer: /^\d00002$/.test(Main.record.header.billingaccount),
			direct: Main.record.header.warehouseid == "DIR",
			quote: Main.record.header.order_type_description == "Quote",
			stock: Main.record.header.order_type_description == "Stock to Stock Order",
			processed: (Main.record.header.orderid && !(Main.record.header.orderid.isEmpty()))
		};
		//regular order if all others are false
		this.isOrder.regular = !($H(this.isOrder).values().any());

		this.isItem = {
			roll: info.flag_roll == "Y",
			slab: info.flag_slab == "Y",
			serial: info.flag_serial == "Y",
			fund: info.flag_fund == "Y",
			labor: info.flag_labor == "Y",
			changeCost: info.change_cost == "Y",
			requireMessage: info.force_msg == "Y",
			specialOrderItem: info.special_order_item == "Y"
		}

		this.isLine = {
			edit: /^\d*$/.test(info.line)
		}

		this.isItem.lockout = !this.isLine.edit && info.price == "99999.990";
	},
	restrictForm: function () {
		//is user allowed to see costs?
		if (Main.record.settings.allow_to_viewcosts != "Y") {
			$("costRow" + this.id, "costLabel" + this.id, "extcostRow" + this.id, "extcostLabel" + this.id).invoke("setStyle", {visibility: "hidden"});
		}

		//message lines visible and require a message?
		if (this.isItem.requireMessage && $("parm_message_1")) {
			$("parm_message_1").addClassName("required");
		}


		if ((this.isItem.fund) || (this.isLine.edit)) {
			//fund can have zero price
			$("price" + this.id).removeClassName("validate-non-zero");
			$("extprice" + this.id).removeClassName("validate-non-zero");
			//points, program, fund$, terms, price allow, and cost allow modifiable
			this.readonlyFields([
				"points", "program", "fund",
				"terms", "priceallowance", "costallowance"
			], false)

		} else {
			//points, program, fund$, terms, price allow, and cost allow not modifiable
			this.readonlyFields([
				"points", "program", "fund",
				"terms", "priceallowance", "costallowance"
			], true)
		}

		//extended cost always read only
		this.readonlyFields([
			"extcost"
		], true)

		//If this is a special order item then check the special order box
		if (this.isItem.specialOrderItem) {
			$("specialOrder" + this.id).checked = true;
		}

		//update special order fields (for edit mode mainly)
		this.updateSpecialOrder();

		var specialOrderTest = $F("lot" + this.id);
		if (specialOrderTest.substring(0, 1) == "S") {
			$("specialOrder" + this.id).checked = true;
		}

		//special order only allowed on regular orders
		if (!this.isOrder.regular && !this.isItem.specialOrderItem) {
			this.disableFields([
				"supplier", "shipvia",
				"fob", "directship", "directshipY", "directshipN",
				"specialOrder"
			], true)
		}

		//Cost modifiable?
		// uncommenting the line below will make cost not editable
		//this.readonlyFields(["cost"],!this.isItem.changeCost);

		if (this.isLine.edit) {

			if (this.isOrder.processed) {   //a02 5421 - protect these flds only when order processed
				this.readonlyFields([
					"lot", "ware", "serial", "location"
				], true)
			}
			// Removing per A02 6567, DPeters 12/10/2012.
			//this.disableFields([
			//    				"specialOrder"
			//    			], true)
		} else {
			//no lot number for labor item
			if (this.isItem.labor) {
				this.disableFields("lot", true);
			}
			//serial and location not on direct, po, or labor item
			if (this.isOrder.direct ||
				this.isOrder.PO ||
				this.isItem.labor
				) {
				this.disableFields(["serial", "location"], true)
			}
		}

		//no iso on quotes, direct ships, POs, or credits, lockout pricing, or edit line
		if (this.isOrder.quote ||
			this.isOrder.PO ||
			this.isOrder.direct ||
			this.isOrder.stock ||
			this.isLine.edit ||
			this.isItem.lockout) {
			$("isoButton" + this.id).hide();
		}

		//no messages on edit line
		if (this.isLine.edit) {
			$("addItemTabMessagesTab" + this.id, "addItemTabMessages" + this.id).invoke("remove");
		}
		//no inventory for labor or fund items, or purchase items, or special orders...
		//EVNT22XW per Mitch: should show inventory for special orders unless it is PO
		if ((this.isItem.labor || this.isItem.fund || this.isOrder.PO)) {
			$("addItemTabInventoryTab" + this.id, "addItemTabInventory" + this.id).invoke("remove");
		}

		this.tabset = new TabSet("addItemTabs" + this.id, {style: "small"})

		this.validator = new Validation("addItem" + this.id, {
			fieldNames: {
				qty: "Quantity",
				um: "UM",
				shipdate: "Ship Date",
				unitprc: "Price",
				extprc: "Extended Price",
				rstk: "Restock%",
				warehouse: "Warehouse",
				unitcost: "Cost",
				extcost: "Extended Cost",
				points: "Points",
				priceallowance: "Price Allowance",
				costallowance: "Cost Allowance",
				fund: "Fund$",
				parm_messageprice_1: "Message Line 1 Price",
				parm_messageprice_2: "Message Line 2 Price",
				parm_messageprice_3: "Message Line 3 Price",
				parm_messageprice_4: "Message Line 4 Price",
				parm_messageprice_5: "Message Line 5 Price",
				parm_messageprice_6: "Message Line 6 Price",
				parm_messageprice_7: "Message Line 7 Price",
				parm_messageprice_8: "Message Line 8 Price",
				parm_messageprice_9: "Message Line 9 Price",
				parm_messagecost_1: "Message Line 1 Cost",
				parm_messagecost_2: "Message Line 2 Cost",
				parm_messagecost_3: "Message Line 3 Cost",
				parm_messagecost_4: "Message Line 4 Cost",
				parm_messagecost_5: "Message Line 5 Cost",
				parm_messagecost_6: "Message Line 6 Cost",
				parm_messagecost_7: "Message Line 7 Cost",
				parm_messagecost_8: "Message Line 8 Cost",
				parm_messagecost_9: "Message Line 9 Cost",
				parm_messageglid_1: "Message Line 1 GL Acct#",
				parm_messageglid_2: "Message Line 2 GL Acct#",
				parm_messageglid_3: "Message Line 3 GL Acct#",
				parm_messageglid_4: "Message Line 4 GL Acct#",
				parm_messageglid_5: "Message Line 5 GL Acct#",
				parm_messageglid_6: "Message Line 6 GL Acct#",
				parm_messageglid_7: "Message Line 7 GL Acct#",
				parm_messageglid_8: "Message Line 8 GL Acct#",
				parm_messageglid_9: "Message Line 9 GL Acct#",
				parm_message_1: "Message Line 1"
			},
			errorMessageKeys: {
				qty: {
					num5_2neg: "format5_2neg"
				},
				unitprc: {
					num6_3: "format6_3"
				},
				extprc: {
					num7_2neg: "format7_2neg"
				},
				unitcost: {
					num6_3: "format6_3"
				},
				extcost: {
					num7_2neg: "format7_2neg"
				},
				fund: {
					num5_2neg: "format5_2neg"
				},
				priceallowance: {
					num5_2neg: "format5_2neg"
				},
				costallowance: {
					num4_3neg: "format4_3neg"
				}

			}
		});
	},
	addLine2: function () {


		var data = {}, recordCount, lineData = [], j, cutQty, rollDrop, UOM, submitObject = {},
			invLineNumber = [], counter = 0, container, invItemNumber = [], containerRow, invWarehouse = [],
			invSerialNumber = [], invWarehouse = [], invQtyAvail = [], invQtyAvailUm = [],
			invQtyOrdered = [], invReference = [], invAccount = [], _this, invUser = [], invCompany = [], invPrice = [],
			invQtyOrderedUM = [], invRollCut = [], invShade = [], invLocation = [],
			invLotNumber = [], inRecord = {}, invOrder = [], invQtyRequest = [], invQtyRequestUm = [];

		this.config = $App.Controller('Config').getConfig();
		var _this = this;

		//determine how many details to search//
		recordCount = $j('[id^=cutQty]').length;

		container = $j('.addItem');

		//package up data//
		for (j = 1; j <= recordCount; j++)
		{
			//get all records that have cutQty//
			cutQty = $j('#cutQty_' + j).val();
			rollDrop = $j('#rollCutDropDown_' + j).val();
			UOM = $j('#UOM_' + j).val();
			// if any of three fields changes
			if (($j.trim(cutQty) !== "") || ($j.trim(rollDrop) !== "") || ($j.trim(UOM) !== ""))
			{
				//line number
				invLineNumber[counter] = j;

				//item number
				invItemNumber[counter] = container.find('[name="item"]').val();

				//serial number
				containerRow = $j('#rowNumber_' + j);
				invSerialNumber[counter] = containerRow.find('[name="ser_array"]').val();

				//warehouse
				invWarehouse[counter] = containerRow.find('[name="ware_array"]').val();

				//shade
				invShade[counter] = containerRow.find('[name="shade_array"]').val();

				//qtyAvail
				invQtyAvail[counter] = container.find('#dspItQty_' + j).html().trim();

				//qtyAvailUOM
				invQtyAvailUm[counter] = containerRow.find('[name="um"]').val();

				//qtyOrderedUOM
				invQtyOrderedUM[counter] = container.find('#UOM_' + j).val();
				if (invQtyOrderedUM[counter].trim() === "")

				{
					invQtyOrderedUM[counter] = '@';
				}

				//Roll or Cut
				if (container.find('#rollCutDropDown_' + j).val() !== undefined)
				{
					invRollCut[counter] = container.find('#rollCutDropDown_' + j).val();
					if (invRollCut[counter] === 'B')
					{
						invRollCut[counter] = 'R';
					}
					if (invRollCut[counter].trim() !== undefined)
					{
						if (invRollCut[counter].trim() === "")
						{
							invRollCut[counter] = '@';
						}
					}
				}


				//qtyOrdered
				//if roll or balance
				if (invRollCut[counter] === 'B' || invRollCut[counter] === 'R')
				{
					invQtyOrdered[counter] = invQtyAvail[counter];
				}
				else
				{
					invQtyOrdered[counter] = container.find('#cutQty_' + j).val().trim();
				}

				//referenceNumber
				invReference[counter] = container.find('[name="ref7"]').val();

				//accountNumber
				invAccount[counter] = (container.find('[name="account"]').val()).substring(1, 6);

				//company
				invCompany[counter] = (container.find('[name="account"]').val()).substring(0, 1);

				//user
				invUser[counter] = _this.config.user.user;

				//price
				invPrice[counter] = container.find('[name="unitprc"]').val();

				//location
				invLocation[counter] = containerRow.find('[name="loc_array"]').val();

				//lot
				invLotNumber[counter] = container.find('[name="lot"]').val();

				//Order
				invOrder[counter] = container.find('[name="orderid"]').val();

				//Request Qty
				invQtyRequest[counter] = container.find('[name="qty"]').val();

				//Request UM
				invQtyRequestUm[counter] = container.find('[name="um"]').val();

				++counter;
			}
		}

		//build submit objects//
		$j.extend(submitObject, {
			invLineNumber: invLineNumber
		});

		$j.extend(submitObject, {
			invLocation: invLocation
		});

		$j.extend(submitObject, {
			invItemNumber: invItemNumber
		});

		$j.extend(submitObject, {
			invShade: invShade
		});


		$j.extend(submitObject, {
			invSerialNumber: invSerialNumber
		});

		$j.extend(submitObject, {
			invWarehouse: invWarehouse
		});

		$j.extend(submitObject, {
			invQtyAvail: invQtyAvail
		});

		$j.extend(submitObject, {
			invQtyAvailUm: invQtyAvailUm
		});

		$j.extend(submitObject, {
			invQtyOrdered: invQtyOrdered
		});

		$j.extend(submitObject, {
			invQtyOrderedUM: invQtyOrderedUM
		});

		$j.extend(submitObject, {
			invRollCut: invRollCut
		});

		$j.extend(submitObject, {
			invReference: invReference
		});

		$j.extend(submitObject, {
			invAccount: invAccount
		});

		$j.extend(submitObject, {
			invCompany: invCompany
		});

		$j.extend(submitObject, {
			invUser: invUser
		});

		$j.extend(submitObject, {
			invPrice: invPrice
		});

		$j.extend(submitObject, {
			invLotNumber: invLotNumber
		});

		//do not send order if not yet an order
		if (container.find('[name="orderid"]').val().trim() !== "")
		{
			$j.extend(submitObject, {
				invOrder: invOrder
			});
		}

		//do not Request Qty if blanks
		if (container.find('[name="qty"]').val().trim() !== "")
		{
			$j.extend(submitObject, {
				invQtyRequest: invQtyRequest
			});
		}

		//do not send order if not yet an order
		if (container.find('[name="um"]').val().trim() !== "")
		{
			$j.extend(submitObject, {
				invQtyRequestUm: invQtyRequestUm
			});
		}

		_this.submitIt(submitObject);

	},
	submitIt: function (submitObject) {
		var params = {};
		var msgArray = [], container, _this;
		_this = this;

		container = $j('.dws-Confirm');

		container.dancikBusy({
			message: 'Checking Inventory Lines'
		});

		_this.model = new Dancik_Model('../../dancik-aws/inventory/getInventorySummaryInformation');
		_this.model.get(Object.extend(
			submitObject
			, params || {}),
			function (is_success, json) {
				try {
					if (json.summary)
					{
						container.dancikBusy("close");
						_this.reviewAnalysis(json);
					}

					if (json.errors)
					{
						container.dancikBusy("close");
						msgArray = [];

						$j(json.errors).each(function (index, field) {

							if (typeof (field.inv_errormessage) !== 'undefined')
							{
								if ($j.inArray(field.inv_errormessage, msgArray) === -1)
								{
									msgArray.push(field.inv_errormessage);
								}
								;

							}
							;

							if (typeof (field.errmsg) !== 'undefined')
							{
								if ($j.inArray(field.errmsg, msgArray) === -1)
								{
									msgArray.push(field.errmsg);
								}
								;

							}
							;
						});

						parent.$App.Fire("ajax_errors2", {message: msgArray});
						_this.reviewAnalysisErrors(json);
						_this.setUpErrorHovers(json);
					}

				} catch (e) {
					alert(e.message);
				}
			});
	},
	reviewAnalysisErrors: function (json)
	{
		var _this = this;

		//Clear All Errors//
		_this.clearErrors();

		//Mark the line with an error//
		$j(json.errors).each(function (index, field) {

			$j('#Msg_' + field.inv_line).addClass('iErrorIcon');
			$j('#Msg_' + field.inv_line).prop('disabled', false);


			//set field for error
			switch (field.inv_errorfield)
			{
				case 'Q':
					$j('#cutQty_' + field.inv_line).addClass('iErrorBorder');
					break;
				case 'R':
					$j('#rollCutDropDown_' + field.inv_line).addClass('iErrorBorder');
					break;
				case 'U':
					$j('#UOM_' + field.inv_line).addClass('iErrorBorder');
					break;

			}

		});

		_this.showErrorColumn(true);

		//Flag the specific field//

	},
	reviewAnalysis: function (json)
	{
		var _this = this;
		//clear previous screen errors
		_this.clearErrors();

		var _this = this, container, action,
			template = new EJS({url: "analysisConfirmBase.ejs"});

		container = $j(template.render());

		container.dialog({
			title: 'Confirm Selections',
			height: 370,
			width: 422,
			modal: 'true',
			dialogClass: 'dancik-dialog',
			zIndex: 9002,
			focus: function () {
				$j('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
			},
			open: function () {
				//remove button css to match accounting button standards
				$j('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
				//prevent ui-state-hover form formatting buttons
				$j('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
				$j('.ui-dialog-buttonpane').find('button').hover(function () {
					$j(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
				});
				$j('.ui-dialog-buttonpane').find('button').focus(function () {
					$j(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
				});
			},
			close: function () {
				action = 'C';
				_this.packageAndSubmitInventory(json, action);
				container.remove();
			},
			buttons: {
				'Add Line': function () {
					action = 'U';

					container.dancikBusy({
						message: 'Submitting Lines'
					});

					_this.packageAndSubmitInventory(json, action);
				}
			}
		});


		_this.populateConfirmDetails(json);
		_this.showErrorColumn(false);

	},
	showErrorColumn: function (action)
	{

		switch (this.isItem.roll)
		{
			case true:
				if (action)
				{
					$j('.iaTableRight').css("left", "670px");
					$j('.inventoryAnalysisTableHeader').find('td:nth-child(11)').show();
					$j('.inventoryAnalysisTableBody').find('td:nth-child(11)').show();
				}
				else
				{
					$j('.iaTableRight').css("left", "632px");
					$j('.inventoryAnalysisTableHeader').find('td:nth-child(11)').hide();
					$j('.inventoryAnalysisTableBody').find('td:nth-child(11)').hide();
				}
				break;
			case false:
				if (action)
				{
					$j('.iaTableRight').css("left", "608px");
					$j('.inventoryAnalysisTableHeader').find('td:nth-child(10)').show();
					$j('.inventoryAnalysisTableBody').find('td:nth-child(10)').show();
				}
				else
				{
					$j('.iaTableRight').css("left", "570px");
					$j('.inventoryAnalysisTableHeader').find('td:nth-child(10)').hide();
					$j('.inventoryAnalysisTableBody').find('td:nth-child(10)').hide();
				}
				break;

		}



	},
	clearErrors: function ()
	{
		var container = $j('.dws-Confirm');
		container.find('.iErrorBorder').removeClass('iErrorBorder');
		container.find('.iErrorIcon').removeClass('iErrorIcon');
		container.find("[id^=Msg_]").prop('disabled', true);
		//	container.find("[id^=Msg_]").unbind('mouseenter mouseleave');
		container.find("[id^=Msg_]").die();

	},
	packageAndSubmitInventory: function (json, action)
	{
		var _this = this, container, dialogContainer;
		var submitObject = {}, params = {}, records = {};
		container = $j('.dws-Confirm');
		dialogContainer = $j('.analysis-confirm-div');
		var priceOverride = $j('#footer-price-override').val();


		var submitObject = {
			orderNum: $j('#parm_orderid').val(),
			refNum: $j('#parm_referenceid').val(),
			company: json.summary[0].company,
			account: json.summary[0].account,
			mfgr: json.summary[0].mfgr,
			color: json.summary[0].color,
			pattern: json.summary[0].pattern,
			itemShade: json.summary[0].itemShade,
			itemLot: json.summary[0].itemLot,
			price: container.find('[name="unitprc"]').val(),
			priceOverride: priceOverride,
			action: action,
			inRecords: {
				rec: []
			}

		};

		//package details//
		$j.each(json.summary, function (x, y) {

			submitObject.inRecords.rec.push({
				lineNum: y.linenum,
				serialNum: y.serialnum,
				shade: y.shade,
				warehouse: y.warehouse,
				roll_cut: y.roll_cut,
				uom: y.rollqtyum,
				quantity: y.rollqty,
				nativeUOM: y.uom,
				nativeQuantity: y.quantity,
				location: y.location
			});

		});

		$App.Model("DWS.Ajax").post(submitObject, '../../dancik-aws/om/addManualInvOrderLines',
			function (results) {
				if (results.success)
				{

					dialogContainer.remove();
					dialogContainer.dancikBusy("close");
					if (submitObject.action === 'U')
					{
						_this.win.close();
						AddItem.getOrder();
					}
				}

				//populate header fields
				// -- Get the Order...

			},
			function (errors) {
				//stop processing modal
				dialogContainer.dancikBusy("close");
				//only show errors if updating//
				if (submitObject.action === 'U')
				{
					//stop processing modal
					dialogContainer.dancikBusy("close");
					//show errors
					$App.Controller("DWS.Messaging").error(errors);
				}

			});

	},
	populateConfirmDetails: function (json)
	{
		var _this = this, container, bodyContainer, template, difference, tableContainer;

		//populate detail rows//
		template = new EJS({url: "analysisConfirmDetails.ejs"});
		container = $j(template.render(json));
		bodyContainer = $j('.analysis-confirm-row');
		bodyContainer.append(container);

		//now for footer//
		template = new EJS({url: "analysisConfirmDetailsFooter.ejs"});
		container = $j(template.render(json));
		bodyContainer = $j('.analysis-confirm-footer');
		bodyContainer.append(container);

		tableContainer = $j('#analysisConfirmWindowId');

		//
		if (parseInt(json.summarytot[0].inv_total_requested) === 0)
		{
			tableContainer.find('#requestQtyTotal').closest("tr").remove();
			tableContainer.find('#requestBalance').closest("tr").remove();
		}
		else
		{
			difference = parseFloat(json.summarytot[0].inv_total_qty_ordered) - parseFloat(json.summarytot[0].inv_total_requested);
			tableContainer.find('#requestBalance').html(Format.prettyNumberN(difference, 2));
		}

	},
	addLine: function () {

		var isvalid = this.validator.validate();
		if (!isvalid) {
			return;
		}

		//check message 1 validation separately because it is not validated if it is hidden.
		var messageIn = $("parm_message_1");
		if (messageIn && messageIn.hasClassName("required") && messageIn.value.blank()) {
			Main.open_ErrorWdw({
				contentHTML: "The following error occurred:",
				extraContentHTML: $M("errorRequired", "Message Line 1")
			});

			//toggle to messages when in error
			this.tabset.showTab(1);

			return;
		}

		var data = $H($("addItem" + this.id).serialize(true));
		data.set("shipdate", data.get("shipdate").replace(/[^\d]/g, ""));

		var arrays = [];
		var counts = [];
		$H(data).each(function (pair) {
			if (pair.key.endsWith("_array")) {
				data.set(pair.key, [data.get(pair.key)].flatten().compact());
				arrays.push(pair.key);
				counts.push(data.get(pair.key).length);
			}
		})

		//extract out items from inventory analysis
		var inv_items = [];
		for (var i = 0; i < counts.max(); i++) {
			var item = {};
			arrays.each(function (key) {
				var key2 = key.replace(/_array$/, "");
				item[key2] = data.get(key)[i];
			})
			inv_items.push(item)
		}

		//remove inventory analysis arrays after items are assembled
		arrays.each(function (key) {
			data.unset(key);
		})

		//select items that were entered via inventory analysis
		var items = inv_items.findAll(function (r) {
			return !r.qty.blank() || !r.um.blank() || (r.rc && !r.rc.blank());
		})

		//create the items structure
		var structure = {
			addItems: {
				addItem: items
			}
		};

		//put messages in to root structure
		var messages = {};
		$H(data).each(function (pair) {
			if (pair.key.startsWith("parm_")) {
				messages[pair.key] = pair.value;
				data.unset(pair.key);
			}
		})

		structure.messages = messages;


		if (structure.addItems.addItem.length > 0) {
			//if inventory analysis form was used.
			this.inventoryAnalysis(structure)
			return;
		} else {
			//no inventory analysis, proceed with add item detail.
			var item = {};
			$H(data).each(function (pair) {
				item[pair.key] = pair.value;
			})
			structure.addItems.addItem.push(item);
		}


		AddItem.addItemsToOrder(structure, {
			onAdded: function (items, res) {
				this.allocated = false;
				this.win.close();
			}.bind(this),
			onNotAdded: function (res) {
				var json = res.responseJSON;
				if (json.redisplay) {
					this.redisplay(json);
				} else {
					var html = [];
					var contentHTML = "An error occurred while attempting to access the server or network, please try again.<br>If the problem persists, contact your system administrator.";
					html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see response.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>" + res.responseText + "</textarea></div>");
					var extraContentHTML = html.join('');
					new Dancik_ConfirmWindow({
						color: "red",
						showAsInfoOnly: true,
						contentHTML: contentHTML,
						extraContentHTML: extraContentHTML,
						modal: true
					}).open();
				}

			}.bind(this),
			onError: function (errors, res) {
				var html = '<div>- ' + errors.pluck("errmsg").join('</div><div>- ') + '</div>';
				var content = "The following error" + (errors.length > 1 ? "s" : "") + " occurred:";

				Main.open_ErrorWdw({
					contentHTML: content,
					extraContentHTML: html
				});
			}.bind(this)
		});

	},
	redisplay: function (json) {
		var costs = {};
		for (var i = 0; i < json.redisplay.length; i++) {
			var record = json.redisplay[i];
			this.setField(record.field, record.value);
		}

		var postMessage = [];
		var notEnough = json.redisplay.find(function (e) {
			return e.field == "msg_not_enough"
		});
		var checkStock = json.redisplay.find(function (e) {
			return e.field == "check_stock"
		});
		var underMinimum = json.redisplay.find(function (e) {
			return e.field == "msg_under_min"
		});
		if (notEnough && notEnough.value == "Y") {
			postMessage.push($M("om.notEnoughAvailable"));
		}
		if (checkStock && checkStock.value == "Y") {
			postMessage.push($M("om.checkStock"));
		}
		if (underMinimum && underMinimum.value == "Y") {
			postMessage.push($M("om.underMinimumQty"));
		}
		$("postMessage" + this.id).update(postMessage.join(" "));

		var changeCost = json.redisplay.find(function (e) {
			return e.field == "change_cost"
		});
		this.readonlyFields(["cost"], !(changeCost && changeCost.value == "Y"));

		$("redisplayMessage" + this.id).update("Please confirm selections and click " + this.options.actionButtonText + ".");

		//$("changePrice"+this.id).value="";
		$("changeExtPrice" + this.id).value = "";
		$("changeCost" + this.id).value = "";
		$("changeExtCost" + this.id).value = "";
		$("changeWare" + this.id).value = "";
		$("changeRC" + this.id).value = "";
		$("changeUM" + this.id).value = "";
		$("changeQty" + this.id).value = "";

		var nbMsg = json.redisplay.find(function (e) {
			return e.field == "nobreak_extension"
		});
		$("preMessage" + this.id).update(nbMsg ? nbMsg.value : '');

	},
	inventoryAnalysis: function (items) {
		var errors = [];
		items.each(function (r) {
			if (r.rc && ["R", "C"].indexOf(r.rc) < 0) {
				errors.push("Serial " + r.ser + ": Invalid roll/cut code.");
			} else {
				if (r.qty.blank()) {
					errors.push("Serial " + r.ser + ": Quantity required.");
				}
				if (r.um.blank()) {
					errors.push("Serial " + r.ser + ": UM required.");
				}
			}

		})

		if (errors.length > 0) {
			var html = '<div>- ' + errors.pluck("errmsg").join('</div><div>- ') + '</div>';
			var content = "The following error" + (errors.length > 1 ? "s" : "") + " occurred:";

			Main.open_ErrorWdw({
				contentHTML: content,
				extraContentHTML: html
			});
			return;
		}
		alert("use inventory analysis. not done yet.");

	},
	putOnBackOrder: function () {
		var fields = ["serial", "location"];
		this.disableFields(fields, true);
	},
	notBackOrder: function () {
		var fields = ["serial", "location"];
		this.disableFields(fields, false);

		if ($("receive" + this.id).value == "B") {
			$("receive" + this.id).value = "";
		}
	},
	setInventory: function (jsonString, e) {
		// ignore if inventory analysis is checked
		if ($j('#inventoryAnalysis_ID_CheckBox').is(':checked'))
		{
			return;
		}

		var event = e || window.event;
		var element = Event.element(event);
		if ((element.tagName.toLowerCase() == "input" && !element.disabled) || element.hasClassName("picker")) {
			return;
		}
		var tr = event.findElement("tr");
		if (!tr.hasClassName("clickable")) {
			return;
		}

		var json = jsonString.evalJSON();
		$("serial" + this.id).value = json.serialnumber;
		$("location" + this.id).value = json.location;
		$("ware" + this.id).value = json.warehouse;
		$("lot" + this.id).value = json.lotnumber;

		this.notBackOrder();
		this.updateLot();
	},
	loadInventory: function () {
		$("inventoryAnalysisTableBody" + this.id).update();

		var data = {
			hdr_ware: Main.record.header.warehouseid,
			dtl_ware: $("ware" + this.id).value,
			account: Main.record.header.billingaccount,
			ref7: Main.record.header.reference,
			orderid: Main.record.header.orderid,
			item: $("item" + this.id).value,
			qty: $("qty" + this.id).value,
			um: $("um" + this.id).value,
			flag_inv: "Y",
			flag_po_supplier_warning: "Y",
			inv_sort: $("inventoryAnalysisSort" + this.id).value,
			inv_um: $("inventoryAnalysisUM" + this.id).value
		}
		if (this.ajax) {
			this.ajax.abort();
		}
		Dancik.Blanket.InProcess.show({message: 'Retrieving Inventory', sizeByStretch: true, zIndex: 100000});
		this.ajax = new Ajax.Request("../api/ai/getItem", {
			parameters: data,
			onSuccess: function (res) {
				var json = res.responseJSON;
				if (json.errors) {
					var html = '<div>- ' + json.errors.pluck("errmsg").join('</div><div>- ') + '</div>';
					var content = "The following error" + (json.errors.length > 1 ? "s" : "") + " occurred:";

					Main.open_ErrorWdw({
						contentHTML: content,
						extraContentHTML: html
					});
					return;
				}

				var template = new EJS({url: "inventoryAnalysisTable.ejs"});
				json.id = this.id;
				json.isOrder = this.isOrder;
				json.isItem = this.isItem;

				var html = template.render(json);
				$("inventoryAnalysisTableBody" + this.id).update(html);

			}.bind(this),
			onComplete: function () {
				this.ajax = null;
				Dancik.Blanket.InProcess.kill();
			}.bind(this),
			onFailure: Dancik.ajaxOnFailure,
			onException: Dancik.ajaxOnException
		})
	},
	futureInventory: function () {
		var h = ((Dancik.getDocumentHeight() - 50) >= 400) ? 400 : (Dancik.getDocumentHeight() - 75);
		var w = ((Dancik.getDocumentWidth() - 50) >= 930) ? 930 : (Dancik.getDocumentWidth() - 75);
		var url = '../../dws/exec/ItemPOsBOs?parm_Item=' + $("item" + this.id).value;

		new Dancik_ConfirmWindow({
			color: "blue",
			showAsPopup: true,
			popupTitle: 'Future Inventory (Purchase Orders and Back Orders)',
			destroyOnClose: true,
			modal: true,
			message: '<div><iframe src="' + url + '" frameborder="0" width="' + (w) + 'px" height="' + (h) + 'px"></iframe></div>',
			buttons: {}
		}).open();
	},
	updateSpecialOrder: function () {
		var specialOrder = $("specialOrder" + this.id);
		var isSpecial = specialOrder.checked;

		if (isSpecial) {
			$("lot" + this.id).value = "S";
			$("receive" + this.id).value = "B";
		} else {
			if ($("lot" + this.id).value == "S") {
				$("lot" + this.id).value = "";
			}
		}

		this.updateReceive();

		var fields = ["supplier", "shipvia", "fob", "directship", "directshipY", "directshipN"];
		this.disableFields(fields, !isSpecial);
	},
	updateLot: function () {
		if ($("lot" + this.id).value.toUpperCase() == "S" && !this.isOrder.regular) {
			Main.open_ErrorWdw({
				contentHTML: "Special orders are only for regular customer orders."
			});
			$("lot" + this.id).value = "";
			return;
		}
		$("specialOrder" + this.id).checked = ($("lot" + this.id).value.toUpperCase() == "S");
		this.updateSpecialOrder();
	},
	updateQuantity: function () {
		this.changeField("changeQty");
	},
	updateUM: function () {
		this.changeField("changeUM");
	},
	updatePrice: function (e) {
		this.changeField("changePrice");
	},
	updateExtPrice: function (e) {
		this.changeField("changeExtPrice");
	},
	updateCost: function (e) {
		this.changeField("changeCost");
	},
	updateExtCost: function (e) {
		this.changeField("changeExtCost");
	},
		updateRC: function () {
		this.changeField("changeRC");
	},
	updateWarehouse: function () {
		this.changeField("changeWare");
	},
	updateReceive: function () {
		if ($("receive" + this.id).value.toUpperCase() == "B") {
			this.putOnBackOrder();
		} else {
			this.notBackOrder();
		}
	},
	changeField: function (field) {
		$("redisplayMessage" + this.id).update();
		$(field + this.id).value = "Y";
	},
	setField: function (field, value) {
		value = value || "";
		if ($(field + this.id)) {
			$(field + this.id).value = value;
		}
		if ($(field + "Display" + this.id)) {
			$(field + "Display" + this.id).update(value);
		}
	},
	runISO: function () {
		if (!this.validator.validate(false, {validationSelector: "input[name=qty], input[name=um]"})) {
			return;
		}

		var data = {
			qty: $("qty" + this.id).value,
			um: $("um" + this.id).value,
			flag_iso: "Y"
		}

		Main.handleAddItemForm(data);
		this.win.close();
	},
	disableFields: function (fieldArray, disable) {
		fieldArray = [fieldArray].flatten().compact();
		disable = disable || false;

		fieldArray.each(function (f) {
			if ($(f + this.id)) {
				//disable input
				$(f + this.id).disabled = disable;
				//disable drop down if it is one
				if ($(f + this.id).up().hasClassName("dws-drop")) {
					$(f + this.id).up()[disable ? "addClassName" : "removeClassName"]("disabled");
				}
			}
			if ($(f + "Label" + this.id)) {
				//disable label
				$(f + "Label" + this.id)[disable ? "addClassName" : "removeClassName"]("disabled");
			}
		}.bind(this));
	},
	readonlyFields: function (fieldArray, readonly) {
		fieldArray = [fieldArray].flatten().compact();
		readonly = readonly || false;

		fieldArray.each(function (f) {
			//if there is an input and a display
			if ($(f + this.id) && $(f + "Display" + this.id)) {
				//show/hide the element/input wrapper
				if ($(f + this.id).up().hasClassName("dws-drop")) {
					$(f + this.id).up()[readonly ? "hide" : "show"]();
				} else {
					$(f + this.id)[readonly ? "hide" : "show"]();
				}

				//show/hide the display
				$(f + "Display" + this.id)[readonly ? "show" : "hide"]();
			}
		}.bind(this));
	},
	toggleInventoryTotals: function () {
		$("IATableBL" + this.id).up().select("tr.totals").invoke("toggle");
	},
	setUpErrorHovers: function (json) {
		var container, id, rowNumber, _this;
		_this = this;


		container = $j('.dws-Confirm');
		container.find("[id^=Msg_]").live({
			mouseenter:
				function () {
					if ($j(this).hasClass('iErrorIcon'))
					{
						id = ($j(this).attr('id'));
						rowNumber = id.split("_");
						_this.showErrors(json, rowNumber[1]);
					}
				}
		});

	},
	showErrors: function (json, rowNumber) {
		var msgArray = [];
		var messages = {};

		$j(json.errors).each(function (index, field) {
			if (field.inv_line === rowNumber)
			{
				msgArray.push(field.inv_errormessage);
			}
		});

		messages = {message: msgArray};

		parent.$App.Fire("errors", messages);

	},
	setUpClicks: function (json) {
		var dropDowns, UOMs, rollQtys, _this, row, id, value, container;

		_this = this;

		//default
		_this.hideShowFields("show", true);
		_this.showErrorColumn(false);

		dropDowns = $j('.rollCutDropDowns');
		UOMs = $j('.UOMs');
		rollQtys = $j('.rollQtys');

		$j('#inventoryAnalysis_ID_CheckBox').off();
		$j('#inventoryAnalysis_ID_CheckBox').on('click', function () {
			//
			if ($j(this).is(':checked'))
			{
				dropDowns.closest('span').removeClass('disabled');
				_this.checkForEnteredSerial();


			}
			else
			{
				dropDowns.closest('span').addClass('disabled');
				_this.hideShowFields("show", true);
				_this.checkForEnteredInventory();
			}


			$j("[id^=rollCutDropDown]").off();
			$j("[id^=rollCutDropDown]").change(function () {
				//get id number of clicked element
				id = $j(this)[0].id.split("_");
				row = id[1];

				_this.setRowValue(row, $j(this)[0].value);
			});

			//find all elements
			if ($j('#inventoryAnalysis_ID_CheckBox').is(':checked'))
			{
				var elements = $j('.inventoryAnalysisTableBody').find('td');
				$j('.inventoryAnalysisTableBody').find('td').off();

				//apply click to all non input tds
				$j(elements).each(function () {
					$j(this).on('click', function ()
					{

						if ($j(this).find('input:first').attr('id') === undefined)
						{

							id = $j(this).closest('tr').attr('id').split("_");
							row = id[1];

							// if all three fields blank//
							if (json.isItem.roll)
							{
								if (
									($j('#rollCutDropDown_' + row).val()).trim() === ""
									&& (($j('#cutQty_' + row).val()).trim() === "")
									&& (($j('#UOM_' + row).val()).trim() === ""))
								{
									_this.setRowValue(row, 'R');
								}
							}
							else
							{
								//avoid cut items//
								if (
									(($j('#cutQty_' + row).val()).trim() === "")
									&& (($j('#UOM_' + row).val()).trim() === ""))
								{
									_this.setRowValue(row, 'N');
								}

							}


						}
					});

				});
			}


			$j("#clickableAnalysisLabel").off();
			$j("#clickableAnalysisLabel").on('click', function ()
			{
				$j('#inventoryAnalysis_ID_CheckBox').trigger('click');
			});


		});
	},
	checkForEnteredSerial: function ()
	{
		var container = $j('.dws-Confirm-ContinueMessage');
		var _this = this;
		// if serials have been clicked in normal mode//

		if (
			container.find('[name="ser"]').val().trim() !== '')
		{
			parent.$App.Fire('confirm', {
				message: 'You are switching inventory selection modes.  The changes you have made will be lost. Continue?',
				details: 'Do you want to continue?',
				callback: function (confirmed) {
					if (confirmed) {
						$j('#inventoryAnalysis_ID_CheckBox').attr('checked', true);
						_this.hideShowFields("hide", false);
						$j(this).remove();

					}
					else {
						$j('#inventoryAnalysis_ID_CheckBox').attr('checked', false);
						$j(this).remove();
					}
				}
			});

		}
		else
		{
			_this.hideShowFields("hide", false);
		}

	},
	checkForEnteredInventory: function ()
	{
		var haveRollCuts = false, haveUOMs = false, haveQtys = false, _this;
		var rollCutDropDown, cutQty, UOM;
		var container = $j('.dws-Confirm-ContinueMessage');

		_this = this;

		//test rollCutDropDown
		rollCutDropDown = $j('[id^=rollCutDropDown_]');
		$j(rollCutDropDown).each(function () {
			if (($j(this).val()).trim() !== '')
				haveRollCuts = true;
		});

		//test cutQtys
		cutQty = $j('[id^=cutQty_]');
		$j(cutQty).each(function () {
			if (($j(this).val()).trim() !== '')
				haveQtys = true;
		});

		//test UOMS
		UOM = $j('[id^=UOM_]');
		$j(UOM).each(function () {
			if (($j(this).val()).trim() !== '')
				haveUOMs = true;
		});

		// analysis has been entered//
		if (
			haveRollCuts === true ||
			haveQtys === true ||
			haveUOMs === true)
		{
			parent.$App.Fire('confirm', {
				message: 'You are switching inventory selection modes.  The changes you have made will be lost. Continue?',
				details: 'Do you want to continue?',
				callback: function (confirmed) {
					if (confirmed) {
						$j('[id^=rollCutDropDown_]').val('');

						$j(rollCutDropDown).each(function () {
							$j(this).val('');

						});

						$j(cutQty).each(function () {
							$j(this).val('');
						});

						$j(UOM).each(function () {
							$j(this).val('');
						});

						$j('.inventoryAnalysisTableBody').find('td').off();

						$j(this).remove();

					}
					else {
						$j('#inventoryAnalysis_ID_CheckBox').attr('checked', true);
						_this.hideShowFields("hide", false);
						$j(this).remove();

					}
				}
			});

		}

	},
	hideShowFields: function (tag, enable) {

		var container = $j('.dws-Confirm-Buttons');
		var containerTabs = $j('.addItemTabs');
		var dialogContainer = $j('.dws-Confirm-ContinueMessage');
		var expansion1 = $j('.expansion1');
		var expansion2 = $j('.expansion2');

		var dropDowns = $j('.rollCutDropDowns');
		var UOMs = $j('.UOMs');
		var rollQtys = $j('.rollQtys');

		//expansion1//

		tag === "show" ? dialogContainer.find('.horizontalExpander').show() : dialogContainer.find('.horizontalExpander').hide();
		tag === "show" ? dialogContainer.find('[name="lot"]').prop('disabled', false) : dialogContainer.find('[name="lot"]').prop('disabled', true);
		tag === "show" ? dialogContainer.find('[name="lot"]').closest('span').prev('label').removeClass('disabled') : dialogContainer.find('[name="lot"]').closest('span').prev('label').addClass('disabled');
		tag === "show" ? dialogContainer.find('[name="ware"]').prop('disabled', false) : dialogContainer.find('[name="ware"]').prop('disabled', true);
		tag === "show" ? dialogContainer.find('[name="ware"]').closest('div').find('label').removeClass('disabled') : dialogContainer.find('[name="ware"]').closest('div').find('label').addClass('disabled');
		tag === "show" ? dialogContainer.find('[name="ware"]').closest('span').removeClass('disabled') : dialogContainer.find('[name="ware"]').closest('span').addClass('disabled');
		tag === "show" ? dialogContainer.find('[name="ser"]').prop('disabled', false) : dialogContainer.find('[name="ser"]').prop('disabled', true);
		tag === "show" ? dialogContainer.find('[name="ser"]').closest('span').prev('label').removeClass('disabled') : dialogContainer.find('[name="ser"]').closest('span').prev('label').addClass('disabled');
		tag === "show" ? dialogContainer.find('[name="loc"]').prop('disabled', false) : dialogContainer.find('[name="loc"]').prop('disabled', true);
		tag === "show" ? dialogContainer.find('[name="loc"]').closest('span').prev('label').removeClass('disabled') : dialogContainer.find('[name="loc"]').closest('span').prev('label').addClass('disabled');
		tag === "show" ? dialogContainer.find('[name="extprc"]').prop('disabled', false) : dialogContainer.find('[name="extprc"]').prop('disabled', true);
		tag === "show" ? dialogContainer.find('[name="extprc"]').closest('span').prev('label').removeClass('disabled') : dialogContainer.find('[name="extprc"]').closest('span').prev('label').addClass('disabled');
		tag === "show" ? dialogContainer.find('[name="specOrder"]').prop('disabled', false) : dialogContainer.find('[name="specOrder"]').prop('disabled', true);
		tag === "show" ? dialogContainer.find('[name="qty"]').prop('disabled', false) : dialogContainer.find('[name="qty"]').prop('disabled', true);
		tag === "show" ? dialogContainer.find('[name="qty"]').closest('span').prev('label').removeClass('disabled') : dialogContainer.find('[name="qty"]').closest('span').prev('label').addClass('disabled');
		tag === "show" ? dialogContainer.find('[name="warePicker"]').show() : dialogContainer.find('[name="warePicker"]').hide();
		tag === "show" ? container.find("[id$=Button_action2]").hide() : container.find("[id$=Button_action]").hide();
		tag === "show" ? container.find("[id$=Button_action]").show() : container.find("[id$=Button_action2]").show();
		tag === "show" ? dialogContainer.find('[name="iso_button"]').prop('disabled', false) : dialogContainer.find('[name="iso_button"]').prop('disabled', true);
		tag === "show" ? dialogContainer.find('[name="um"]').prop('disabled', false) : dialogContainer.find('[name="um"]').prop('disabled', true);
		tag === "show" ? dialogContainer.find('[name="um"]').closest('div').find('label').removeClass('disabled') : dialogContainer.find('[name="um"]').closest('div').find('label').addClass('disabled');
		tag === "show" ? dialogContainer.find('[name="um"]').closest('span').removeClass('disabled') : dialogContainer.find('[name="um"]').closest('span').addClass('disabled');
		tag === "show" ? dialogContainer.find('.addItem').addClass('expand') : dialogContainer.find('.addItem').removeClass('expand');
		//	tag === "show" ? dialogContainer.find('.expansion1').show() : dialogContainer.find('.expansion1').hide();
		//	tag === "show" ? dialogContainer.find('.expansion2').show() : dialogContainer.find('.expansion2').hide();

//expansion 2//
		tag === "show" ? expansion1.show() : expansion1.hide();
		tag === "show" ? expansion2.show() : expansion2.hide();
		tag === "show" ? $j('.addItem.showBig .addItemTabs').removeAttr("style") : $j('.addItem.showBig .addItemTabs').css("top", "142px");



		dialogContainer.find('#inventoryAnalysisId').removeAttr("style");

		dropDowns.prop('disabled', enable);
		UOMs.prop('disabled', enable);
		rollQtys.prop('disabled', enable);

		//set expander to unexpanded if analysis checkbox selected
		if (tag === 'show')
		{
			if (dialogContainer.find('.addItem').hasClass('expand'))
			{
				dialogContainer.find('.addItem').removeClass('expand');
			}

		}

		if (tag === 'hide')
		{
			dialogContainer.find('[name="ser"]').val('');
			dialogContainer.find('[name="loc"]').val('');
			dialogContainer.find('[name="extprc"]').val('');
			dialogContainer.find('[id^=qty_fiDisplay]').html('');
			dialogContainer.find('[id^=postMessage]').html('');
			dialogContainer.find('[id^=redisplayMessage]').html('');
		}

		//set css style based on error column 


	},
	setRowValue: function (n, value) {


		//determine of Cut or Roll
		//get values of from display fields and populate input fields//
		if ($j('#inventoryAnalysis_ID_CheckBox').is(':checked'))
		{
			if (value.toUpperCase() === 'R')
			{
				{
					$j('#rollCutDropDown_' + n).val('R');
				}
			}

			if (value.toUpperCase() === 'B')
			{
				{
					$j('#rollCutDropDown_' + n).val('B');
				}
			}

			$j('#' + 'UOM_' + n).val($j('#' + 'dspUOM_' + n).html().trim());
			if (($j('#' + 'cutQty_' + n).val()).trim().length === 0)
			{
				if (value.toUpperCase() === 'R' || value.toUpperCase() === 'N' || value.toUpperCase() === 'B')
				{
					$j('#' + 'cutQty_' + n).val($j('#' + 'dspItQty_' + n).html().trim());
				}
			}

		}
	},
	setUPDropDowns: function () {

		var dropDowns, row, id, ary, n, _this;

		_this = this;

		//setup roll/cut drop down
		dropDowns = $j('.rollCutDropDowns');

		$App.Utils.dropdown_CutRoll(dropDowns, {
			appendTo: document.body

		});

		//setup uom drop down
		dropDowns = $j('.UOMs');

		$App.Utils.dropdown_uom_all(dropDowns, {
			appendTo: document.body
		});
	}
});


AddItem.register = function (addItem) {
	if (!this.objects) {
		this.objects = $H();
	}
	this.objects.set(addItem.id, addItem);
}
AddItem.get = function (id) {
	if (this.objects) {
		return this.objects.get(id);
	}
	return null;
}
AddItem.invoke = function (id, method) {
	var args = $A(arguments).slice(2);
	var addItem = this.get(id);
	if (addItem) {
		addItem[method].apply(addItem, args);
	}
}

AddItem.addItemsFromForm = function (form, opts) {
	var data = $H(form.serialize(true));

	//put messages in to root structure
	var messages = {};
	$H(data).each(function (pair) {
		if (pair.key.startsWith("parm_")) {
			messages[pair.key] = pair.value;
			data.unset(pair.key);
		}
	})
	data.set("messages", messages);


	var arrays = [];
	var counts = [];
	$H(data).each(function (pair) {
		if (pair.key.endsWith("_array")) {
			data.set(pair.key, [data.get(pair.key)].flatten().compact());
			arrays.push(pair.key);
			counts.push(data.get(pair.key).length);
		}
	})

	var items = [];
	for (var i = 0; i < counts.max(); i++) {
		var item = {};
		arrays.each(function (key) {
			var key2 = key.replace(/_array$/, "");
			item[key2] = data.get(key)[i];
		})
		items.push(item)
	}

	arrays.each(function (key) {
		data.unset(key);
	})

	data.set("addItems", {addItem: items});

	AddItem.addItemsToOrder(data, opts);
}

AddItem.addItemsToOrder = function (itemStructure, opts) {
	// Backlog 570
	var specialItem = " ";
	var supplierMessages = $("supplierMessage").value;
	var timessubmitted = parseInt($j("#submitCount").val());  // EVNT 29W2
	
	if (itemStructure.addItems) {
		specialItem = itemStructure.addItems.addItem[0].lot;
	}

	if (specialItem == "S" && supplierMessages == "") {
		if (timessubmitted < 2) {  // EVNT 29W2
			AddItem.specialItem(itemStructure, opts);
		}
	}
	else {
				
		itemStructure = $H(itemStructure).toObject();
		var options = Object.extend({
			onAdded: Prototype.K,
			onError: Prototype.K,
			onNotAdded: Prototype.K
		}, opts || {});

		var json = Object.toJSON(Object.extend(itemStructure, {
			hdr_ware: Main.record.header.warehouseid,
			account: Main.record.header.billingaccount,
			ref7: Main.record.header.reference,
			orderid: Main.record.header.orderid,
			ordertype: Main.record.header.order_type,
			po_supplier_warning: "N"
		}));

		if (timessubmitted < 2) {  // EVNT 29W2
			timessubmitted = parseInt(timessubmitted)+1;              // EVNT 29W2
			$j('#submitCount').val(timessubmitted)                    // EVNT 29W2

			new Ajax.Request("../api/ai/addItems", {
				method: "post",
				contentType: "application/json",
				postBody: json,
				onSuccess: function (res) {
					var error = false;
					var errors = [];
					var json = res.responseJSON || {};
					if (json.errors) {
						$j('#submitCount').val(1)                    // EVNT 29W2
						errors.push(json.errors);
					}
					if (json.items && json.items.length == 0) {
						errors.push({
							errid: "NONE",
							errmsg: "No items added."
						});
					}
					errors = errors.flatten().compact();
	
					if (errors.length > 0) {
						if (typeof(options.onError) == "function") {
							options.onError(errors, res);
						}
						return;
					}
	
					if (json.redisplay) {
						if (typeof(options.onNotAdded) == "function") {
							$j('#submitCount').val(1)                    // EVNT 29W2
							options.onNotAdded(res);
						}
						return;
					}
	
					if (typeof(options.onAdded) == "function") { 
						$j('#submitCount').val(3)                    // EVNT 29W2
						options.onAdded(itemStructure.addItems.addItem, res);
					}
	
					Main.handleAddItemISO(res.responseJSON);
					Dancik.Blanket.InProcess.show({message: 'Validating', sizeByStretch: true, zIndex: 100000});
				},
				onFailure: function (res) {
					if (typeof(options.onError) == "function") {
						$j('#submitCount').val(1)                    // EVNT 29W2
						options.onError(res);
					}
				},
				onException: Dancik.ajaxOnException,
				onComplete: function () {
					Dancik.Blanket.InProcess.kill();
					$j("#addItem_item").focus();
				}
			});
		}
	}
}


AddItem.specialItem = function (itemStructure, opts) {
	$('supplierMessage').value = "Y";
	var timessubmitted = parseInt($j("#submitCount").val());  // EVNT 29W2
	// Backlog 570

	//Dancik.Blanket.InProcess.show({ message : 'Validating', sizeByStretch : true, zIndex : 100000 });
	itemStructure = $H(itemStructure).toObject();
	var options = Object.extend({
		onAdded: Prototype.K,
		onError: Prototype.K,
		onNotAdded: Prototype.K,
		secondPass: "Y"
	}, opts || {});
	var json = Object.toJSON(Object.extend(itemStructure, {
		hdr_ware: Main.record.header.warehouseid,
		account: Main.record.header.billingaccount,
		ref7: Main.record.header.reference,
		orderid: Main.record.header.orderid,
		ordertype: Main.record.header.order_type,
		po_supplier_warning: "N"
	}));



	AddItem.poWarningWindow = new Dancik_ConfirmWindow({
		color: "yellow",
		content: "Warning: Supplier " + itemStructure.addItems.addItem[0].supplier + " is not a regular supplier of this item.",
		modal: true,
		destroyOnClose: true,
		buttons: {yes: "Yes", no: "No"},
		onYes: function () {
			Dancik.Blanket.InProcess.show({message: 'Validating', sizeByStretch: true, zIndex: 100000});
			new Ajax.Request("../api/ai/addItems", {
				method: "post",
				contentType: "application/json",
				postBody: json,
				onSuccess: function (res) {
					var error = false;
					var errors = [];
					var json = res.responseJSON || {};
					if (json.errors) {
						$j('#submitCount').val(1)                    // EVNT 29W2
						errors.push(json.errors);
					}
					if (json.items && json.items.length == 0) {
						errors.push({
							errid: "NONE",
							errmsg: "No items added."
						});
					}
					errors = errors.flatten().compact();

					if (errors.length > 0) {
						if (typeof(options.onError) == "function") {
							$j('#submitCount').val(1)                    // EVNT 29W2
							options.onError(errors, res);
						}
						return;
					}

					if (json.redisplay) {
						if (typeof(options.onNotAdded) == "function") {
							$j('#submitCount').val(1)                    // EVNT 29W2
							options.onNotAdded(res);
						}
						return;
					}

					if (typeof(options.onAdded) == "function") {
						$j('#submitCount').val(3)                    // EVNT 29W2
						options.onAdded(itemStructure.addItems.addItem, res);
					}

					Main.handleAddItemISO(res.responseJSON);

				},
				onFailure: function (res) {
					if (typeof(options.onError) == "function") {
						$j('#submitCount').val(1)                    // EVNT 29W2
						options.onError(res);
					}
				},
				onException: Dancik.ajaxOnException,
				onComplete: function () {
					Dancik.Blanket.InProcess.kill();
				}
			});

		},
		onNo: function () {  // BKLG 570
			$('supplierMessage').value = "";
		},
		defaultAction: "no"
	});
	AddItem.poWarningWindow.open();

}

AddItem.searchCalendar = function (e) {
	var event = e || window.event;
	var element = Event.element(event);
	var parent = element.up();
	var input = parent.down("input");

	new CalendarObject({
		toElements: [input],
		toFormats: ['M/D/Y'],
		positionElement: parent,
		offsetTop: -1,
		zIndex: 100000
	});
}
AddItem.dropR = function (e) {
	var event = e || window.event;
	var element = Event.element(event);
	var parent = element.up();
	var input = parent.down("input");

	var opts = [
		{id: "B", description: "Back order"},
		{id: "T", description: "Transfer"},
		{id: "Y", description: "Credit with return"},
		{id: "N", description: "Credit without return"}
	];
	Popup_Search.open(event, {
		title: "Received?",
		preloadedContents: opts,
		toElements: [input],
		positionElement: parent,
		parentZindex: this.getZindexElement(100000),
		bufferLeft: 2,
		bufferTop: -3,
		heightOverride: 102,
		widthOverride: 175
	})
}
AddItem.searchFile = function (e, fileOpts) {
	var event = e || window.event;
	var element = Event.element(event);
	var parent = element.up();
	var input = parent.down("input");

	var params = Object.extend({
		file: null,
		title: null,
		toElements: [input],
		positionElement: parent,
		bufferTop: 4,
		preload: true
	}, fileOpts || {});

	Popup2Search.open(event, params)

}
AddItem.searchWarehouse = function (e, id) {
	var ai = AddItem.get(id);
	var ff = null;
	if (ai) {
		ff = ai.updateWarehouse.bind(ai);
	}

	AddItem.searchFile(e, {
		file: 'warehouse',
		title: 'Warehouse',
		finalFunction: ff,
		finalFuncOnClear: true
	});
}
AddItem.searchSupplier = function (e) {
	AddItem.searchFile(e, {file: "supplier", title: "Supplier"});
}
AddItem.searchShipVia = function (e) {
	AddItem.searchFile(e, {file: "classes_sv", title: "Ship Via"});
}
AddItem.searchMarketingProgram = function (e) {
	AddItem.searchFile(e, {file: "classes_mp", title: "Marketing Program"});
}
AddItem.searchFOB = function (e) {
	AddItem.searchFile(e, {file: "classes_fb", title: "FOB"});
}

AddItem.searchRestriction = function (e, id) {
	var ai = AddItem.get(id);
	var ff = null;
	if (ai) {
		ff = ai.updateRC.bind(ai);
	}
	AddItem.searchFile(e, {
		file: 'classes_rn',
		title: 'Restriction Code',
		finalFunction: ff,
		finalFuncOnClear: true
	});
}
AddItem.searchCreditCode = function (e) {
	AddItem.searchFile(e, {file: 'classes_cc', title: 'Credit/Commission Code'});
}
AddItem.searchUM = function (e, id, item) {
	var event = e || window.event;
	var element = Event.element(event);
	var parent = element.up();
	var input = parent.down("input");

	var ai = AddItem.get(id);
	var ff = null;
	if (ai) {
		ff = ai.updateUM.bind(ai);
	}

	Popup_Search.open(event, {
		title: 'Available UM',
		url: '../../dws/jsonservice/Item_WebService/getUOMList_JSON',
		params: {
			parm_Item: item
		},
		positionElement: parent,
		toElements: [input],
		omitIdInDescription: true,
		preload: true,
		hideHeader: true,
		showIdInTable: false,
		bufferLeft: 2,
		bufferTop: -3,
		widthOverride: 50,
		heightOverride: 80,
		parentZindex: this.getZindexElement(100000),
		finalFunction: ff,
		finalFuncOnClear: true
	});
}
AddItem.getOrder = function ()
{
	Main.getOrder({});
}

AddItem.searchUM_inv = function (e, id, item) {
	var event = e || window.event;
	var element = Event.element(event);
	var parent = element.up();
	var input = parent.down("input");

	var ai = AddItem.get(id);
	var ff = null;
	//if(ai) {
	//	ff = ai.loadInventory.bind(ai);
	//}

	Popup_Search.open(event, {
		title: 'Available UM',
		url: '../../dws/jsonservice/Item_WebService/getUOMList_JSON',
		params: {
			parm_Item: item
		},
		positionElement: parent,
		toElements: [input],
		omitIdInDescription: true,
		preload: true,
		hideHeader: true,
		showIdInTable: false,
		bufferLeft: 2,
		bufferTop: -3,
		widthOverride: 50,
		heightOverride: 80,
		parentZindex: this.getZindexElement(100000),
		finalFunction: ff
	});
}

AddItem.getZindexElement = function (zIndex) {
	var id = new Date().getTime();
	$$("body")[0].insert('<div id="' + id + '" style="z-index:' + zIndex + ';display:none;"></div>');
	Element.remove.defer(id.toString());
	return $(id.toString());
}


AddItem.macro = function () {
	new MacroMessages_Popup(
		{parm_referenceid: Main.record.header.reference, parm_orderid: Main.record.header.orderid},
	{references: {
			startline: 0,
			msg: 'parm_message_',
			price: 'parm_messageprice_',
			cost: 'parm_messagecost_',
			glid: 'parm_messageglid_',
			cstctr: 'parm_messagecostctr_',
			taxable: 'parm_messagetaxable_'
		}}
	).open();
};