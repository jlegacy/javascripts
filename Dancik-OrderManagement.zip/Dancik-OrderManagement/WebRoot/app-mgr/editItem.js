var EditItem = Class.create(AddItem,{
	isOrder: null,	//json object to be populated by AddItem.flag
	isItem: null,	//json object to be populated by AddItem.flag
	initialize: function($super,json) {
		$super(json,{
			actionButtonText: "Update",
			actionButtonAction: this.updateLine.bind(this),
			windowTitle: "Edit Line "+json.info.line
		});
	},
	updateLine: function() {
		var isvalid = this.validator.validate();
		if(!isvalid) {
			return;
		}
		
		Dancik.Blanket.InProcess.show({ message : 'Updating Line', sizeByStretch : true, zIndex : 100000 });
		
		var data = $("addItem"+this.id).serialize(true);
		data.shipdate = data.shipdate.replace(/[^\d]/g,"");
		
		
		new Ajax.Request("../api/updateLineDetail",{
			parameters: data,
			onSuccess: function(res) {
				var json = res.responseJSON || {};
				if (json.errors) {
					var errors = json.errors.pluck("errmsg");
					var content = "The following error"+(errors.length>1?'s':'')+" occurred:";
					var extra = "<div>- "+errors.join("</div><div>- ")+"</div>";
					new Dancik_ConfirmWindow({
						color:"red",
						showAsInfoOnly:true,
						contentHTML: content,
						extraContentHTML: extra,
						modal:true
					}).open();
				} else if (json.redisplay) {
					// -- If a record is returned, then re-display for verification...
					this.redisplay(json);
				} else {
					//check for ok message?
					this.win.close();
					Main.getOrder();
				}
			}.bind(this),
			onFailure: function(res) {
					alert("Update FAIL: "+res.responseText);
			},
			onComplete: function() {
				Dancik.Blanket.InProcess.kill();
			},
			onException: function(req,e) {
				var html = [];
				var contentHTML = "An error occurred while attempting to access the server or network, please try again.<br>If the problem persists, contact your system administrator.";
				html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see response.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+req.transport.responseText+"</textarea></div>");
				html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see exception.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+e+"</textarea></div>");
				var extraContentHTML = html.join('');
				new Dancik_ConfirmWindow({
					color:"red",
					showAsInfoOnly:true,
					contentHTML: contentHTML,
					extraContentHTML: extraContentHTML,
					modal:true
				}).open();
			}
		});
	}
});