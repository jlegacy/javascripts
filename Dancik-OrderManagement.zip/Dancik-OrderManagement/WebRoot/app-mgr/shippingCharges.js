Validation.add('num6_2','%T format is 9999999.99.',{
	pattern: /^(\d{0,6}|\d{0,6}\.\d{0,2})$/
})
var ShippingCharges = Class.create({
	initialize: function(opts) {
		this.options = Object.extend({
			referenceid: 0,
			orderid: 0,
			line: ""
		},opts || {});
		
		this.id = new Date().getTime();
		
		this.get();
	},
	get: function() {
		Dancik.Blanket.InProcess.show({ message : 'Retrieving Shipping Charges', sizeByStretch : true, zIndex : 1000 });
		
		var params = {
				referenceid: this.options.referenceid,
				orderid: this.options.orderid,
				line: this.options.line
		};
		
		new Ajax.Request("../api/shippingCharges",{
			parameters: params,
			onSuccess: function(res) {
				var json = res.responseJSON;
				json.line = this.options.line;
				json.editMode = Main.settings.editMode;
				
				var template = new EJS({url: "shippingCharges.ejs"});
				json.id = this.id;
				var html = template.render(json);
				
				var buttons = {};
				if(Main.settings.editMode) {
					buttons.sel = "Add Shipping";
				}
				
				this.win = new Dancik_ConfirmWindow({
					color:"blue",
					showAsPopup:true,
					popupTitle: "Shipping Charges",
					message: html,
					modal:true,
					buttons: buttons,
					onSel: this.selectCharge.bind(this),
					destroyOnClose: true,
					zIndexModal:9000,
					closeAfterButton: false
				});
				this.win.open();
				
				this.validator = new Validation("sc_searchForm"+this.id,{
					onValidSubmit: this.search.bindAsEventListener(this),
					fieldNames: {
						warehouse: "Warehouse",
						zip: "Zip Code",
						weight: "Weight",
						units: "Units",
						dollars: "Value"
					},
					errorMessageKeys: {
						dollars: {
							num6_2: "format6_2"
						}
					}
				})
			
			}.bind(this),
			onComplete: function() {
				Dancik.Blanket.InProcess.kill()
			},
			onFailure: Dancik.ajaxOnFailure,
			onException: Dancik.ajaxOnException
		})
	},
	search: function(event) {
		Event.stop(event);
		Dancik.Blanket.InProcess.show({ message : 'Retrieving Shipping Charges', sizeByStretch : true, zIndex : 10000 });
		var form = Event.element(event);
		
		var params = form.serialize(true);
		
		new Ajax.Request("../api/shippingCharges",{
			parameters: params,
			onSuccess: function(res) {
				var json = res.responseJSON;
				json.editMode = Main.settings.editMode;
				
				var template = new EJS({url: "shippingChargesTable.ejs"});
				var html = template.render(json);
				
				$("sc_selectTableContainer"+this.id).update(html);
			
			}.bind(this),
			onComplete: function() {
				Dancik.Blanket.InProcess.kill()
			},
			onFailure: Dancik.ajaxOnFailure,
			onException: Dancik.ajaxOnException
		})
	},
	selectCharge: function() {
		var params = $("sc_selectForm"+this.id).serialize(true);
		if(!params.selected) {
			Main.open_ErrorWdw({
				contentHTML : $M("errorValidateSelection","Shipping Charges"), 
				extraContentHTML : "" 
			});
			return;
		}
		var data = params.selected.evalJSON();
		data.nextline = params.nextline;
		data.supplier = params.supplier;
		data.account = params.account;
		data.datep = params.datep;
		data.dateo = params.dateo;
		data.id = this.id;
		
		var template = new EJS({url: "shippingChargesConfirm.ejs"});
		var html = template.render(data);
		this.confirm = new Dancik_ConfirmWindow({
			content: $M("om.confirmShipping"),
			extraContent: html,
			modal: true,
			buttons: {confirm: "Confirm", cancel: "Cancel"},
			closeAfterButton: false,
			defaultAction: "confirm",
			onCancel: function(win) {
				win.close();
			},
			onConfirm: this.confirmCharge.bind(this)
		});
		this.confirm.open();
		
		//alert(params.selected+"\n - show window with options for line and change ship via.");
	},
	confirmCharge: function() {
		Dancik.Blanket.InProcess.show({ message : 'Updating Shipping Charges', sizeByStretch : true, zIndex : 10000 });
		
		var params = $("shipConfirm"+this.id).serialize(true);
		
		new Ajax.Request("../api/updateShippingCharges",{
			parameters: params,
			onSuccess: function(res) {
				var json = res.responseJSON;
				
				if(json.errors) {
					var html = '<div>- '+json.errors.pluck("errmsg").join('</div><div>- ')+'</div>';
					var content = "The following error"+(json.errors.length>1?"s":"")+" occurred:";
					
					Main.open_ErrorWdw({
						contentHTML : content, 
						extraContentHTML : html 
					});

					return;
				}
				
				Main.getOrder.defer();
				
				this.confirm.close();
				this.win.close();

			}.bind(this),
			onComplete: function() {
				Dancik.Blanket.InProcess.kill()
			},
			onFailure: Dancik.ajaxOnFailure,
			onException: Dancik.ajaxOnException
		})
	}
});

ShippingCharges.searchFile = function(e,fileOpts) {
	var event = e || window.event;
	var element = Event.element(event);
	var parent = element.up();
	var input = parent.down("input");
	
	var params = Object.extend({
		file:null,
		title:null,
		toElements: [input],
		positionElement: parent,
		bufferTop: 4,
		preload: true
	},fileOpts || {});
	
	Popup2Search.open(event,params)
	
}

ShippingCharges.searchWarehouse = function(e) {
	ShippingCharges.searchFile(e,{file:"warehouse",title:"Warehouse"});
}

ShippingCharges.searchShipVia = function(e, id) {
	ShippingCharges.searchFile(e,{file:"ship_via",title:"Ship Via"});
	
}
ShippingCharges.searchService = function(e,id) {
	var shipVia = $("filterShipVia"+id).value;
	if(shipVia.blank()) {
		Main.open_ErrorWdw({
			contentHTML : $M("errorRequired","Shipvia"), 
			extraContentHTML : "" 
		});
		return;
	}
	
}