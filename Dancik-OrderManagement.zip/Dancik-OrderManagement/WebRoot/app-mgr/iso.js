var ISO = Class.create({
	initialize: function(opts) {
		var options = opts || {};
		options.iso = [options.iso].flatten().compact();
		if(options.iso.length>0) {
			this.displaySingleISO(options);
		} else {
			new Dancik_ConfirmWindow({
				color:"red",
				destroyOnClose:true,
				showAsInfoOnly:true,
				content: "Items or ISO information not supplied to ISO.",
				modal:true
			}).open();
		}
	},
	displaySingleISO: function(json) {
		var _this = this;
		this.id = new Date().getTime();
		this.allocated = true
		var template = new EJS({url:"isoSingle.ejs"});
		var dims = document.viewport.getDimensions();
		json.height = dims.height-80;
		json.id = this.id;
		
		this.price = (json.iso[0]||{}).unitprc || 0;
		
		var html = template.render(json);
		this.isoWin = new Dancik_ConfirmWindow({
			color:"blue",
			showAsPopup:true,
			popupTitle: "Add Line: ISO Selected Inventory",
			message: html,
			modal:true,
			destroyOnClose:true,
			closeAfterButton: false,
			buttons: {add: "Add Selected Inventory",inventory: "Manual Inventory Selection"},
			onAdd: this.addItems.bind(this),
			onInventory: function() {
				if (this.allocated) {
					this.deallocateMe();
				}

				//Main.handleAddItemForm({flag_inv:"Y",isounitprice:this.price});
				Main.handleAddItemForm({flag_inv:"Y",isounitprice:this.price,item:json.info.item});
				this.isoWin.close();
			}.bind(this),
			onClose: function(win) {
				if (this.allocated) {
					this.deallocateMe();
				}
				win.close();
			}.bind(this),
			defaultAction: "add"
		});

		this.tabset = new TabSet("isoSingleTabs"+this.id, {style: "small"} );
		
		// -- If a message MUST be entered in Line 1, set as 'required'...
		if (json.info.force_msg=="Y") {
			$("parm_message_1").addClassName("required");
		}
		
		this.validator = new Validation("isoForm"+this.id,{
			onValidSubmit: this.addItemsEvent.bind(this),
			fieldNames: {
				priceover: "Price Override",
				parm_messageprice_1: "Message Line 1 Price",
				parm_messageprice_2: "Message Line 2 Price",
				parm_messageprice_3: "Message Line 3 Price",
				parm_messageprice_4: "Message Line 4 Price",
				parm_messageprice_5: "Message Line 5 Price",
				parm_messageprice_6: "Message Line 6 Price",
				parm_messageprice_7: "Message Line 7 Price",
				parm_messageprice_8: "Message Line 8 Price",
				parm_messageprice_9: "Message Line 9 Price",
				parm_messagecost_1: "Message Line 1 Cost",
				parm_messagecost_2: "Message Line 2 Cost",
				parm_messagecost_3: "Message Line 3 Cost",
				parm_messagecost_4: "Message Line 4 Cost",
				parm_messagecost_5: "Message Line 5 Cost",
				parm_messagecost_6: "Message Line 6 Cost",
				parm_messagecost_7: "Message Line 7 Cost",
				parm_messagecost_8: "Message Line 8 Cost",
				parm_messagecost_9: "Message Line 9 Cost",
				parm_messageglid_1: "Message Line 1 GL Acct#",
				parm_messageglid_2: "Message Line 2 GL Acct#",
				parm_messageglid_3: "Message Line 3 GL Acct#",
				parm_messageglid_4: "Message Line 4 GL Acct#",
				parm_messageglid_5: "Message Line 5 GL Acct#",
				parm_messageglid_6: "Message Line 6 GL Acct#",
				parm_messageglid_7: "Message Line 7 GL Acct#",
				parm_messageglid_8: "Message Line 8 GL Acct#",
				parm_messageglid_9: "Message Line 9 GL Acct#",
				parm_message_1: "Message Line 1"
			},
			errorMessageKeys: {
				priceover: {
					num6_3: "format6_3"
				}
			}
		});
		
		
		this.isoWin.open();
	},
	deallocateMe: function() {
		ISO.deallocateForm("isoForm"+this.id);
	},
	addItemsEvent: function(event) {
		Event.stop(event);
		this.addItems();
	},
	addItems: function() {
		if(!this.validator.validate()) {
			return;
		}
		
		//check message 1 validation separately because it is not validated if it is hidden.
		var messageIn = $("parm_message_1");
		if(messageIn && messageIn.hasClassName("required") && messageIn.value.blank()) {
			Main.open_ErrorWdw({
				contentHTML : "The following error occurred:", 
				extraContentHTML : $M("errorRequired","Message Line 1")
			});
			
			//toggle to messages when in error
			this.tabset.showTab(1);
			return;
		}

		
		AddItem.addItemsFromForm($("isoForm"+this.id),{
			onAdded: function(items,res) {
				this.allocated = false;
				this.isoWin.close();
				if(res.responseJSON.bom) {
					//order will not refresh to show iso added item if next step is bom, 
					//so refresh order here to show that iso line in case they cancel bom 
					//and don't refresh order.
					Main.getOrder.defer();
				}
			}.bind(this),
			onError: function(errors,res) {
				var msgs = errors.pluck("errmsg");
				var extraContentHTML = "<div>- "+msgs.join("</div><div>- ")+"</div>";
				var contentHTML = "The following error"+(msgs.length>1?"s":"")+" occurred:";
				new Dancik_ConfirmWindow({
					color:"red",
					showAsInfoOnly:true,
					contentHTML: contentHTML,
					extraContentHTML: extraContentHTML,
					modal:true
				}).open();
			}.bind(this)	
		});
	}
});

ISO.deallocateForm = function(addItemFormId,opts) {
	var data = $(addItemFormId).serialize(true);
		
	var arrays = [];
	var counts = [];
	$H(data).each(function(pair) {
		if(pair.key.endsWith("_array")) {
			data[pair.key] = [data[pair.key]].flatten().compact();
			arrays.push(pair.key);
			counts.push(data[pair.key].length);
		}
	})
	
	var items = [];
	for(var i=0;i<counts.max();i++) {
		var item = {};
		arrays.each(function(key) {
			var key2 = key.replace(/_array$/,"");
			item[key2] = data[key][i];
		})
		items.push(item)
	}
	
	ISO.deallocateItems(items,opts);
}
ISO.deallocateItems = function(itemsArray,opts) {
	//var options = Object.extend({
	//	onAdded: Prototype.K,
	//	onError: Prototype.K
	//},opts||{});
	itemsArray = [itemsArray].flatten().compact();
	var json = Object.toJSON({
		addItems: {
			addItem: itemsArray
		},
		hdr_ware: Main.record.header.warehouseid,
		account: Main.record.header.billingaccount,
		ref7: Main.record.header.reference,
		orderid: Main.record.header.orderid
	});
	
	new Ajax.Request("../api/ai/deallocate",{
		method: "post",
		contentType: "application/json",
		postBody:json,
		onSuccess: function(res) {
			var json = res.responseJSON;
			if(json.errors) {
				var errors = [json.errors].flatten().compact();
				var html = errors.pluck("errmsg");
				var content = "An error occurred while deallocating ISO inventory."
				if(html.length>0) {
					content = "The following error"+(html.length>1?"s":"")+" occurred while deallocating ISO inventory:";
					var message = '<div style="text-align:left;"><div>- '+html.join('</div><div>- ')+'</div>';
				}
				var err = new Dancik_ConfirmWindow({
					color:"red",
					showAsInfoOnly:true,
					content: content,
					message: message,
					modal:true,
					zIndexModal:100000
				}).open();
				
			}
		},
		onFailure: function(res) {
			alert("deallocate FAILURE:\n\n"+res.responseText);
		},
		onException: function(req,e) {
			var html = [];
			var contentHTML = "An error occurred while attempting to access the server or network, please try again.<br>If the problem persists, contact your system administrator.";
			html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see response.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+req.transport.responseText+"</textarea></div>");
			html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see exception.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+e+"</textarea></div>");
			var extraContentHTML = html.join('');
			new Dancik_ConfirmWindow({
				color:"red",
				showAsInfoOnly:true,
				contentHTML: contentHTML,
				extraContentHTML: extraContentHTML,
				modal:true
			}).open();
		}
	});

}

ISO.runISO = function(opts) {
	opts = opts || {};
	var itemArray = opts.items;
	var target = $(opts.target);
	Dancik.Blanket.InProcess.show({ message : 'Retrieving Inventory Information', sizeByStretch : true, zIndex : 100000 });
	var json = Object.toJSON({
			isoItems: {
				isoItem: itemArray
			},
			hdr_ware: Main.record.header.warehouseid,
			account: Main.record.header.billingaccount,
			ref7: Main.record.header.reference,
			orderid: Main.record.header.orderid,
			hdr_ship: Main.record.header.shipdate.replace(/[^\d]/g,"")
		});
	new Ajax.Request("../api/ai/runISO",{
		method: "post",
		contentType: "application/json",
		postBody:json,
		onSuccess: function(res) {
			var json = res.responseJSON;
			json = Object.extend(json,document.viewport.getDimensions());
			if(json.errors) {
				if(typeof(opts.onError)=="function") {
					opts.onError(json.errors);
				}
				return;
			}
			var template = new EJS({url: "isoTable.ejs"});
			var html = template.render(json);
			
			if($(target)) {
				$(target).update(html);
			}
		},
		onFailure: function(res) {
			alert("runiso FAILURE:\n\n"+res.responseText);
		},
		onException: function(req,e) {
			var html = [];
			var contentHTML = "An error occurred while attempting to access the server or network, please try again.<br>If the problem persists, contact your system administrator.";
			html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see response.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+req.transport.responseText+"</textarea></div>");
			html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see exception.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+e+"</textarea></div>");
			var extraContentHTML = html.join('');
			new Dancik_ConfirmWindow({
				color:"red",
				showAsInfoOnly:true,
				contentHTML: contentHTML,
				extraContentHTML: extraContentHTML,
				modal:true
			}).open();
		},
		onComplete: function() {
			Dancik.Blanket.InProcess.kill();
	
		}
	});
}
