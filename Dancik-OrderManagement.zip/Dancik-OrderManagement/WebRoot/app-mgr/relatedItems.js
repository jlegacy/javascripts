var RelatedItems = Class.create({
	initialize: function(opts) {
		this.id = new Date().getTime();
		
		var viewDims = document.viewport.getDimensions();
		this.options = Object.extend({
			height: viewDims.height-80,	//default height of related items box
			initSelect: "",				//initial search selection for item
			item: "",					//the item number to find related items for
			desc1: "",					//item desc1 for item
			desc2: "",					//item desc2 for item
			entry: null					//reference to the Multi Line order entry object that called this related items
		}, opts || {});
		
		if(this.options.item.blank()) {
			new Dancik_ConfirmWindow({
				content: "Item number not specified for related items.",
				destroyOnClose: true,
				showAsInfoOnly: true,
				color: "red",
				modal:true
			}).open();
			return;
		}
		
		var template = new EJS({url: "relatedItems.ejs"});
		var data = {
			id: this.id,
			item: this.options.item,
			height: this.options.height,
			desc1: this.options.desc1,
			desc2: this.options.desc2
		}
		var html = template.render(data);
		
		this.win = new Dancik_ConfirmWindow({
			showAsPopup: true,
			popupTitle: "Related Items",
			message: html,
			modal: true,
			color:this.options.entry?"grey":"blue",
			buttons: {}
		});
		this.win.open();
		
		this.selectValidator = new Validation("relatedItemsSelect"+this.id);
		this.itemsValidator = new Validation("relatedItems"+this.id,{
			onValidSubmit: this.handleItems.bindAsEventListener(this)
		})
		//$("relatedItemsScrollBody"+this.id).observe("scroll",this.scrollItems.bindAsEventListener(this));
		$("relatedItemsMore"+this.id).observe("click",this.getRelated.bind(this));
		
		RelatedItems.register(this);
	},
	/**
	 * event handler for 'related items for' form
	 * @param {Object} event
	 */
	handleSelect: function(element) {
		$("relatedItemsTbody"+this.id).update();
		$("showRelatedDesc"+this.id).update("&nbsp;");
		$("relatedItemsQuery"+this.id).update();
		$("relatedItemsMore"+this.id).setStyle({visibility:"hidden"});
		
		var form = $("relatedItemsSelect"+this.id);
		var valid = this.selectValidator.validate(true);
		if(!valid) {
			return;
		}
		this.ajaxData = form.serialize(true);
		this.ajaxData.account = Main.record.header.billingaccount;
		this.ajaxData.hdr_ware = Main.record.header.warehouseid;
		this.ajaxData.meta_starting_record = 0;
		this.ajaxData.meta_max_records = 50;

		if(this.scrollAjax) {
			this.scrollAjax.abort();
		}
		
		this.getRelated();
	},
	scrollItems: function() {
		var scrollHeight = $("relatedItemsScrollBody"+this.id).scrollHeight;
		var scrollTop = $("relatedItemsScrollBody"+this.id).scrollTop;
		var height = $("relatedItemsScrollBody"+this.id).getHeight();
		var modScrollHeight = scrollHeight - height;
		
		var scrollPercent = scrollTop/modScrollHeight;
		
		if(scrollPercent>.75 && !this.scrollAjax && this.ajaxData.meta_starting_record<this.ajaxData.querySize) {
			$("relatedItemsLoading"+this.id).show();
			this.getRelated();
		}
	},
	getRelated: function() {
		if(this.scrollAjax) {
			return;
		}
		Dancik.Blanket.InProcess.show({ message : 'Retrieving Related Items', sizeByStretch : true, zIndex : 100000 });
		
		this.ajaxData.meta_max_records = $("relatedItemsRecords"+this.id).value;
		
		this.scrollAjax = new Ajax.Request("../api/ai/relatedItems",{
			method:"post",
			parameters: this.ajaxData,
			onSuccess: function(res) {
				var text = res.responseText;
				var json = text.evalJSON();
				//var json = res.responseJSON || {};
				
				if(json.errors) {
					var html = [];
					var errors = [json.errors].flatten();
					errors.each( function(msg) { html.push("<div>- " + msg.errmsg + "</div>") } );
					var extraContentHTML = html.join('');
					var contentHTML = "The following error"+(html.length>1?'s':'')+" occurred:";
					Main.open_ErrorWdw({
						contentHTML : contentHTML, 
						extraContentHTML : extraContentHTML 
					});
					return;
				}
				var template = new EJS({url:"relatedItemsLine.ejs"});
				var html = [];
				
				for(var i=0;i<json.related.length;i++) {
					html.push(template.render({record:json.related[i]}));
				}
				if(json.message.querysize==0) {
					html.push('<tr><td colspan="6">No records found.</td></tr>');
				}
				
				$("relatedItemsTbody"+this.id).insert(html.join(""));
				
				var message = "";
				var join = ", and ";
				for(var i=1;i<=3;i++) {
					var type = json.message["type"+i].trim();
					var typeDesc = "";
					var code = json.message["code"+i].trim();
					var desc = json.message["desc"+i].trim();
					if(code.blank() && desc.blank()) {
						desc = "value not populated";
					}
					
					switch(type) {
						case "PL":
							typeDesc="Product line";
							break;
						case "MF":
							typeDesc="Manufacturer";
							break;
						case "CN":
							typeDesc="Color name";
							break;
						case "PN":
							typeDesc="Pattern name";
							break;
						case "I1":
						case "I2":
						case "I3":
							typeDesc=type.replace("I","Item class ");
							break;
						default:
							type="";
					}
					
					
					if(!type.blank()) {
						if(!message.blank()) {
							message+=join+"<br/>";
						}
						message += typeDesc + " ";
						if(!code.blank()) {
							if(desc.blank()) {
								desc = "description not populated";
							}
							message+=code + ", "+desc;
						} else {
							message+=desc;
						}
					} else {
						message+="&nbsp;<br/>&nbsp;";
					}
				}
				
				//no related items for blank item class 1
				if(json.message["type1"].trim()=="I1" && json.message["code1"].trim().blank()) {
					message = $M("om.blankI1NoRelated")+"<br/>&nbsp;<br/>&nbsp;";
				}
				
				$("showRelatedDesc"+this.id).update(message);
				this.ajaxData.querySize = json.message.querysize;
				this.ajaxData.meta_starting_record += json.related.length;
				if(this.ajaxData.querySize>0) {
					$("relatedItemsQuery"+this.id).update(this.ajaxData.meta_starting_record+" of "+this.ajaxData.querySize);
				} else {
					$("relatedItemsQuery"+this.id).update();
				}
			}.bind(this),
			onComplete: function() {
				this.scrollAjax = null;
				Dancik.Blanket.InProcess.kill();
				$("relatedItemsLoading"+this.id).hide();
				
				if(this.ajaxData.meta_starting_record>=this.ajaxData.querySize) {
					$("relatedItemsMore"+this.id).setStyle({visibility:"hidden"})
				} else {
					$("relatedItemsMore"+this.id).setStyle({visibility:"visible"})
				}
				
			}.bind(this),
			onException: function(req,e) {
				var html = [];
				var contentHTML = "An error occurred while attempting to access the server or network, please try again.<br>If the problem persists, contact your system administrator.";
				html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see response.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+req.transport.responseText+"</textarea></div>");
				html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see exception.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+e+"</textarea></div>");
				var extraContentHTML = html.join('');
				new Dancik_ConfirmWindow({
					color:"red",
					showAsInfoOnly:true,
					contentHTML: contentHTML,
					extraContentHTML: extraContentHTML,
					modal:true
				}).open();
			}
		});		
	},
	/**
	 * event handler for checked related items
	 * @param {Object} event
	 */
	handleItems: function(event) {
		Event.stop(event);
		var form = Event.element(event);
		var data = form.serialize(true);
		
		var items = [data.relatedItem].flatten().compact();
		for(var i=0;i<items.length;i++) {
			items[i] = items[i].evalJSON();
		}
		
		if(items.length==0) {
			var warn = new Dancik_ConfirmWindow({
				content: "You must select an item.",
				destroyOnClose: true,
				showAsInfoOnly: true,
				color: "red"
			});
			$(warn.id).setStyle({zIndex:10001});
			warn.open();
			return;
		}
		
		
		if(this.options.entry) {
			this.options.entry.addItems(items);
		} else {
			new MultiEntry({
				items: items
			});
		}
		
		this.win.close();
		
	}
})


RelatedItems.register = function(relatedItem) {
	if(!this.objects) {
		this.objects = $H();
	}
	this.objects.set(relatedItem.id,relatedItem);
}
RelatedItems.get = function(id) {
	if(this.objects) {
		return this.objects.get(id);
	}
	return null;
}
RelatedItems.invoke = function(id,method) {
	var args = $A(arguments).slice(2);
	var relatedItem = this.get(id);
	if(relatedItem) {
		relatedItem[method].apply(relatedItem,args);
	}
}
