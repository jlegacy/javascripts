$App.Controller("PrintMessage", {
	initialize: function () {
		this.view = $App.View("PrintMessage");
		this.model = $App.Model("PrintMessage");
	},
	open: function () {
		var _this = this, userdata={};
		userID = $App.Controller('Config').getConfig().user.user;
		//console.log(userID);
		userdata={
				senderID:userID
		}
		target = _this.view.open_message_window(userdata);
		_this.populate(target, userdata);
		
	},
	populate: function (target, userID) {
		//console.log("populate - target", target);
		//console.log("populate - target", userID);
		var _this = this;
		$App.Fire('overlay', 'Retrieving Records');
		_this.model.getPrintMessage(userID, function (results) {
			//console.log("results -", results);
			_this.view.populate(target, results);
			$App.Fire('clear_overlay')
		});
	},
	update: function (data) {
		
	},
	sendprint: function(lines){
		var _this = this;
		$App.Fire('overlay', 'Sending to Printer');
		_this.model.sendPrintMessage(lines, function(results){
			$App.Fire('clear_overlay')
			$j("#print_messages_form").dialog('close');
			$App.Fire('info_message', 'Message Sent');
		},
		function(errors){
			$App.Fire('clear_overlay')
			$App.Fire('ajax_errors', errors);
		});
		
		
	}
});