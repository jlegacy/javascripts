/*globals $App jQuery Main CashRegister_Popup OrderNotepad_Popup MultiEntry*/
(function ($) {
    $App.Controller("MultiUnit", {
        initialize: function () {
            this.view = $App.View("MultiUnit");
            this.model = $App.Model("MultiUnit");
        },
        //--------------------------------------------------------
        // for backend developers to test web service
        //--------------------------------------------------------
//        test_details: function (data) {
//            var _this = this;
//            
//            _this.model.get_std_order_details(data, 
//                function (results) {
//                    console.log('details results ', results);
//                },
//                function (errors) {
//                    $App.Fire("ajax_errors", errors);
//            });
//        },
        //----------------------------------------------------------
        // open the multiunit modal window and populate with details
        //----------------------------------------------------------
        open: function (data) {
        //console.log('CONTROLLER - open - multi_unit.js', data);
            var _this = this, container, header_row, prev_order_number;
            
            //open modal window and fill with html
            _this.view.open(data);
            
            //get container
            container = _this.view.get_container();

            //show processing modal
            container.dancikBusy({message: 'Retrieving Data'});

            //get detail data
            _this.model.get_std_order_details(data, 
                function (results) {
                    //if results exist
                    if (results.details) {
                        $.each(results.details, function (index, row) {
                            //get previous order number
                            if (results.details[index - 1]) {
                                prev_order_number = results.details[index - 1].order_number;
                            }
                            //new order number, create header row
                            if (prev_order_number != row.order_number) {
                                header_row = {
                                    header: true,
                                    order_number: row.order_number,
                                    order_description: row.order_description,
                                    ordered_quantity: '-',
                                    unit_of_measure: '-',
                                    price: '-'
                                };

                                //add header row to table
                                container.find('.body tbody').append(_this.view.get_row(header_row));
                                
                                //add account number to result data
                                $.extend(row, data);

                                //add functionality to a row
                                _this.view.decorate_detail_row(row);
                            }
                            
                            //add header to row obj
                            $.extend(row, {header: false});
                            
                            //add detail row to table
                            container.find('.body tbody').append(_this.view.get_row(row));

                        });
                        
                        //collapse row details
                        _this.view.collapse_row_details(container);
                        
                    }
                    
                    //stop processing modal
                    container.dancikBusy("close");
                },
                function (errors) {
                    //stop processing modal
                    container.dancikBusy("close");
                    //show errors
                    $App.Fire("ajax_errors", errors);
                });
        },
        //------------------------------------------------
        // update the header when an item list is selected
        //------------------------------------------------
        update_header: function (data) {
        //console.log('CONTROLLER - update_header - multi_unit.js', data);  
       
            var _this = this,
                container = _this.view.get_container();

            //show processing modal
            container.dancikBusy({message: 'Retrieving Data'});
		
            _this.model.get_std_order_header(data,
                function (results) {
                    //if header is returned
                    if (results.header) {
                        //populate header fields
                        _this.view.update_header_fields(results.header);
                    }
                    
                    //stop processing modal
                    container.dancikBusy("close");
                },
                function (errors) {
                    //stop processing modal
                    container.dancikBusy("close");
                    //show errors
                    $App.Controller("DWS.Messaging").error(errors);
                });
        },
        //------------------------------------------
        // update multi unit then get order details
        // and hand off dta to non MVC OM code 
        //------------------------------------------
        update_multi_unit: function (data) {
        //console.log('CONTROLLER - update_multi_unit - multi_unit.js', data);    
            var _this = this, detail_obj,
                container = _this.view.get_container();
            
            //show processing modal
            container.dancikBusy({message: 'Retrieving Data'});
            
            _this.model.update_multi_unit_header(data, 
                function (results) {
                    
                    //create array
                    if (data.omChain) {
                        if (data.omChain.match(',')) {
                            data.omChain = data.omChain.split(',');
                        } else {
                            data.omChain = [data.omChain];
                        }
                    }
                    
                    //create array
                    if (data.omOrderNumber) {
                        if (data.omOrderNumber.match(',')) {
                            data.omOrderNumber = data.omOrderNumber.split(',');
                        } else {
                            data.omOrderNumber = [data.omOrderNumber];
                        }
                    }
                    
                    detail_obj = {
                        omAccount: data.omAccount,
                        omChainCode: data.omChain,//array
                        omOrderId: data.omOrderNumber//array
                    };
                    
                    _this.model.get_std_order_details(detail_obj, 
                        function (results) {
                            //add results to data
                            $.extend(data, results);
                            //call multi entry pop up
                            _this.send_to_multi_entry(data);
                        },
                        function (errors) {
                            //stop processing modal
                            container.dancikBusy("close");
                            //show errors
                            $App.Controller("DWS.Messaging").error(errors);
                        }
                    );

                    //close dialog modal
                    container.dialog('close');

                    //stop processing modal
                    container.dancikBusy("close");
                },
                function (errors) {
                    //stop processing modal
                    container.dancikBusy("close");
                    //show errors
                    $App.Controller("DWS.Messaging").error(errors);
                }
            );
        },
        //---------------------------------------------
        // Hand off items to multi-line entry popup 
        //---------------------------------------------
        send_to_multi_entry: function (data) {
        //console.log('CONTROLLER - send_to_multi_entry - multi_unit.js', data);
            var _this = this, css;
            
            //add order css to head
            $("head").append("<link>");
            css = $("head").children(":last");
            css.attr({
                rel:  "stylesheet",
                type: "text/css",
                href: "order.css"
            });
            //set variables for display in MultiEntry pop-up
            Main.record = {};
            Main.record.header = {};
            Main.settings.BOMOP = {};
            Main.record.header.items = _this.create_item_list(data.details);
            Main.record.header.reference = data.omRefNumber;
            Main.record.header.orderid = '';
            Main.record.header.shipdate = '';
            Main.record.header.billingaccount = data.omAccount;
            Main.record.header.warehouseid = data.omWareNumber;
            //open multiline entry, push in results
            new MultiEntry();
        },
        //------------------------------------------
        // create an array of objects for items
        //------------------------------------------
        create_item_list: function (item_array) {
            var out_array  = [];
            $.each(item_array, function (index, value) {
                out_array.push({
                    //bomrule1: "Y", //?
                    //bomrule2: "1", //?
                    //bomrule3: "1", //?
                    color: value.color,
                    //comment: "test comment",
                    //compo: "S", //?
                    desc1: value.item_number,
                    //desc2: "test desc2",
                    //disc: "test disc",
                    //icomm1: "test icomm1",
                    //invent: "691",//?
                    //isoadd: "test isoadd",
                    //iunits: value.unit_of_measure,
                    //kitflag: "N", //?
                    //mainflag: "Y", //?
                    //manflag: "test manflag",
                    //me_id: 1343854777886,
                    mfgr: value.manufacturer,
                    patt: value.pattern,
                    price1: value.price,
                    //price2: "0.000",
                    qty: value.ordered_quantity,
                    //qtyadj: "test qtyadj",
                    //rccode: "test rccode",
                    uom1: value.unit_of_measure 
//                    uom10: "",
//                    uom2: "EA",
//                    uom3: "",
//                    uom4: "CT",
//                    uom5: "LB",
//                    uom6: "PL",
//                    uom7: "",
//                    uom8: "",
//                    uom9: ""
                });
            });
            return out_array;
        }
    });
})(jQuery);
/*globals $App jQuery Main CashRegister_Popup OrderNotepad_Popup MultiEntry*/
(function ($) {
    $App.Controller("MultiUnit", {
        initialize: function () {
            this.view = $App.View("MultiUnit");
            this.model = $App.Model("MultiUnit");
        },
        //--------------------------------------------------------
        // for backend developers to test web service
        //--------------------------------------------------------
//        test_details: function (data) {
//            var _this = this;
//            
//            _this.model.get_std_order_details(data, 
//                function (results) {
//                    console.log('details results ', results);
//                },
//                function (errors) {
//                    $App.Fire("ajax_errors", errors);
//            });
//        },
        //----------------------------------------------------------
        // open the multiunit modal window and populate with details
        //----------------------------------------------------------
        open: function (data) {
        //console.log('CONTROLLER - open - multi_unit.js', data);
            var _this = this, container, header_row, prev_order_number;
            
            //open modal window and fill with html
            _this.view.open(data);
            
            //get container
            container = _this.view.get_container();

            //show processing modal
            container.dancikBusy({message: 'Retrieving Data'});

            //get detail data
            _this.model.get_std_order_details(data, 
                function (results) {
                    //if results exist
                    if (results.details) {
                        $.each(results.details, function (index, row) {
                            //get previous order number
                            if (results.details[index - 1]) {
                                prev_order_number = results.details[index - 1].order_number;
                            }
                            //new order number, create header row
                            if (prev_order_number != row.order_number) {
                                header_row = {
                                    header: true,
                                    order_number: row.order_number,
                                    order_description: row.order_description,
                                    ordered_quantity: '-',
                                    unit_of_measure: '-',
                                    price: '-'
                                };

                                //add header row to table
                                container.find('.body tbody').append(_this.view.get_row(header_row));
                                
                                //add account number to result data
                                $.extend(row, data);

                                //add functionality to a row
                                _this.view.decorate_detail_row(row);
                            }
                            
                            //add header to row obj
                            $.extend(row, {header: false});
                            
                            //add detail row to table
                            container.find('.body tbody').append(_this.view.get_row(row));

                        });
                        
                        //collapse row details
                        _this.view.collapse_row_details(container);
                        
                    }
                    
                    //stop processing modal
                    container.dancikBusy("close");
                },
                function (errors) {
                    //stop processing modal
                    container.dancikBusy("close");
                    //show errors
                    $App.Fire("ajax_errors", errors);
                });
        },
        //------------------------------------------------
        // update the header when an item list is selected
        //------------------------------------------------
        update_header: function (data) {
        //console.log('CONTROLLER - update_header - multi_unit.js', data);  
       
            var _this = this,
                container = _this.view.get_container();

            //show processing modal
            container.dancikBusy({message: 'Retrieving Data'});
		
            _this.model.get_std_order_header(data,
                function (results) {
                    //if header is returned
                    if (results.header) {
                        //populate header fields
                        _this.view.update_header_fields(results.header);
                    }
                    
                    //stop processing modal
                    container.dancikBusy("close");
                },
                function (errors) {
                    //stop processing modal
                    container.dancikBusy("close");
                    //show errors
                    $App.Controller("DWS.Messaging").error(errors);
                });
        },
        //------------------------------------------
        // update multi unit then get order details
        // and hand off dta to non MVC OM code 
        //------------------------------------------
        update_multi_unit: function (data) {
        //console.log('CONTROLLER - update_multi_unit - multi_unit.js', data);    
            var _this = this, detail_obj,
                container = _this.view.get_container();
            
            //show processing modal
            container.dancikBusy({message: 'Retrieving Data'});
            
            //clean dates
            data.omDtereqt = _this._clean_date(data.omDtereqt);
            data.order_date = _this._clean_date(data.order_date);
            
            _this.model.update_multi_unit_header(data, 
                function (results) {
                    
                    //create array
                    if (data.omChain) {
                        if (data.omChain.match(',')) {
                            data.omChain = data.omChain.split(',');
                        } else {
                            data.omChain = [data.omChain];
                        }
                    }
                    
                    //create array
                    if (data.omOrderNumber) {
                        if (data.omOrderNumber.match(',')) {
                            data.omOrderNumber = data.omOrderNumber.split(',');
                        } else {
                            data.omOrderNumber = [data.omOrderNumber];
                        }
                    }
                    
                    detail_obj = {
                        omAccount: data.omAccount,
                        omChainCode: data.omChain,//array
                        omOrderId: data.omOrderNumber//array
                    };
                    
                    _this.model.get_std_order_details(detail_obj, 
                        function (results) {
                            //add results to data
                            $.extend(data, results);
                            //call multi entry pop up
                            _this.send_to_multi_entry(data);
                        },
                        function (errors) {
                            //stop processing modal
                            container.dancikBusy("close");
                            //show errors
                            $App.Controller("DWS.Messaging").error(errors);
                        }
                    );

                    //close dialog modal
                    container.dialog('close');

                    //stop processing modal
                    container.dancikBusy("close");
                },
                function (errors) {
                    //stop processing modal
                    container.dancikBusy("close");
                    //show errors
                    $App.Controller("DWS.Messaging").error(errors);
                }
            );
        },
        //---------------------------------------------
        // Hand off items to multi-line entry popup 
        //---------------------------------------------
        send_to_multi_entry: function (data) {
        //console.log('CONTROLLER - send_to_multi_entry - multi_unit.js', data);
            var _this = this, css;
            
            //add order css to head
            $("head").append("<link>");
            css = $("head").children(":last");
            css.attr({
                rel:  "stylesheet",
                type: "text/css",
                href: "order.css"
            });
            //set variables for display in MultiEntry pop-up
            Main.record = {};
            Main.record.header = {};
            Main.settings.BOMOP = {};
            Main.record.header.items = _this.create_item_list(data.details);
            Main.record.header.reference = data.omRefNumber;
            Main.record.header.orderid = '';
            Main.record.header.shipdate = '';
            Main.record.header.billingaccount = data.omAccount;
            Main.record.header.warehouseid = data.omWareNumber;
            //open multiline entry, push in results
            new MultiEntry();
        },
        //------------------------------------------
        // create an array of objects for items
        //------------------------------------------
        create_item_list: function (item_array) {
            var out_array  = [];
            $.each(item_array, function (index, value) {
                out_array.push({
                    //bomrule1: "Y", //?
                    //bomrule2: "1", //?
                    //bomrule3: "1", //?
                    color: value.color,
                    //comment: "test comment",
                    //compo: "S", //?
                    desc1: value.item_number,
                    //desc2: "test desc2",
                    //disc: "test disc",
                    //icomm1: "test icomm1",
                    //invent: "691",//?
                    //isoadd: "test isoadd",
                    //iunits: value.unit_of_measure,
                    //kitflag: "N", //?
                    //mainflag: "Y", //?
                    //manflag: "test manflag",
                    //me_id: 1343854777886,
                    mfgr: value.manufacturer,
                    patt: value.pattern,
                    price1: value.price,
                    //price2: "0.000",
                    qty: value.ordered_quantity,
                    //qtyadj: "test qtyadj",
                    //rccode: "test rccode",
                    uom1: value.unit_of_measure 
//                    uom10: "",
//                    uom2: "EA",
//                    uom3: "",
//                    uom4: "CT",
//                    uom5: "LB",
//                    uom6: "PL",
//                    uom7: "",
//                    uom8: "",
//                    uom9: ""
                });
            });
            return out_array;
        },
        _clean_date: function (date) {
            if (date) {
                date = date.replace(/\//g, '');
            }
            return date;
        }
    });
})(jQuery);