$App.Controller("Retail", {
	initialize: function () {
		this.view = $App.View("Retail");
		this.model = $App.Model("Retail");
	},
	open: function(data){
		 var _this = this;
			_this.view.open(data.mode, data.keys.file, data.keys.id); 
	}
});