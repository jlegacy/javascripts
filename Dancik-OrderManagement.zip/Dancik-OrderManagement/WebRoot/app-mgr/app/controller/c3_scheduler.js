/*globals $App jQuery Main CashRegister_Popup OrderNotepad_Popup MultiEntry*/
(function ($) {
     $App.Controller("c3scheduler", {
          initialize: function () {
               this.view = $App.View("c3scheduler");
               this.model = $App.Model("c3scheduler");
          },
          //----------------------------------------------------------
          // open the c3scheduler modal window and populate with details
          //----------------------------------------------------------
          init: function (data) {
            
               var _this = this, container, header_row, prev_order_number;
               var strDate = new Date();
               var today = new Date();
               var dd = today.getDate();
               var mm = today.getMonth()+1; 
               var yy = today.getFullYear() %100;
            
               var parms = {};
          
               //open modal window and fill with html
               _this.view.init(parms);
            
               //get container
               container = _this.view.get_container();

               //show processing modal
               container.dancikBusy({
                    message: 'Retrieving Data'
               });
            
               //initially set to todays date//
               parms.omInstallDate = $App.Utils.cvtDateIso((mm)+'/'+(dd)+'/'+(yy));
          
               _this.model.get_entries_by_account_date(parms, 
                    function(results) {
                         //populate header fields
                         _this.view.show_job_schedule_entries(parms,results);
                    
                         //stop processing modal
                         container.dancikBusy("close");
                    },
                    function(errors) {
                         //stop processing modal
                         container.dancikBusy("close");
                         //show errors
                         $App.Controller("DWS.Messaging").error(errors);

                    });
                  
          },
        
        
          c3_schedule_edit: function (data) {
               _this = this;
               //edit record//
               _this.view.c3_schedule_edit(data);
         
          },
        
        
        
          c3_schedule_multi_edit: function (data) {
               _this = this;
               //edit record//
               $.extend(data, {
                    multi_edit: 'Y'
               })
               _this.view.c3_schedule_edit(data);
          },
        
          rules_file_edit: function (data) {
               _this = this;
               //edit record//
               _this.view.rules_file_edit(data);
         
          },
          
            rules_file_delete: function (data) {
               _this = this;
               //edit record//
               _this.view.rules_file_delete(data);
         
          },
        
          reload_c3_scheduler_by_account: function (data) {
               _this = this;
               var container;
            
               //get container
               container = _this.view.get_container();
            
               container.dancikBusy({
                    message: 'Retrieving Data'
               });
            
               _this.model.get_entries_by_account(data, 
                    function(results) {
                         //populate header fields
                         _this.view.show_job_schedule_entries(data,results);
                    
                         //stop processing modal
                         container.dancikBusy("close");
                    },
                    function(errors) {
                         //stop processing modal
                         container.dancikBusy("close");
                         //show errors
                         $App.Controller("DWS.Messaging").error(errors);

                    });
            
          },
        
          reload_c3_scheduler_by_account_date: function (data) {
               _this = this;
               var container;
            
               //get container
               container = _this.view.get_container();
            
               container.dancikBusy({
                    message: 'Retrieving Data'
               });
            
               _this.model.get_entries_by_account_date(data, 
                    function(results) {
                         //populate header fields
                         _this.view.show_job_schedule_entries(data,results);
                    
                         //stop processing modal
                         container.dancikBusy("close");
                    },
                    function(errors) {
                         //stop processing modal
                         container.dancikBusy("close");
                         //show errors
                         $App.Controller("DWS.Messaging").error(errors);

                    });
            
          },
        
          reload_c3_scheduler_by_date: function (data) {
               _this = this;
            
               container.dancikBusy({
                    message: 'Retrieving Data'
               });
            
               _this.model.get_entries_by_date(data, 
                    function(results) {
                         //populate header fields
                         _this.view.show_job_schedule_entries(data,results);
                    
                         //stop processing modal
                         container.dancikBusy("close");
                    },
                    function(errors) {
                         //stop processing modal
                         container.dancikBusy("close");
                         //show errors
                         $App.Controller("DWS.Messaging").error(errors);

                    });
            
          },
         
          update_c3_scheduler_header: function (data) {
               _this = this;
            
               _this.model.update_c3_scheduler_header(data, 
                    function(results) {
                
                         _this.view.update_c3_scheduler_header(data);
                
                    },
                    function(errors) {
                         //stop processing modal
                         container.dancikBusy("close");
                         //show errors
                         $App.Controller("DWS.Messaging").error(errors);
                    });
          },
        
          update_c3_scheduler_detail: function (data) {
               _this = this;
            
               _this.model.update_c3_scheduler_detail(data, 
                    function(results) {
                    //   _this.view.update_c3_scheduler_detail(data);
                
                    },
                    function(errors) {
                         //stop processing modal
                         container.dancikBusy("close");
                         //show errors
                         $App.Controller("DWS.Messaging").error(errors);
                    });
          }
     });
    
    
})(jQuery);