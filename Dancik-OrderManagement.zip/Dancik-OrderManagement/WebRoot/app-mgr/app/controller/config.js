/*globals $App*/
$App.Controller('Config', {
    initialize: function () {
        this.model = $App.Model('Config');
        //user configuration propeties to lookup
        this.userConfig = [
            "allowAccessToTheUpdateOrderStatusAndShippingDataProgram",
            'user',
            'dft_Warehouse'
        ];


        //system config properties
        //this.sysConfig = ['APSET.*'];
        //application config properties
        this.appConfig = [];
    },
    //modify this to manipulate the returned data if needed
    //for example, changing Y/N values to true/false
    parseConfig: function (configData) {
        this.convertBools(configData.user);
        //this.convertBools(configData.system.APSET);

        this.config = configData; //no changes by default
    },
    getConfig: function (callback) {
        var configData, filesData,
            reportsData;
        //load and store configuration info if we don't have it already.
        if (!this.config) {
            configData = this.model.getConfig({
                user: this.userConfig,
                system: this.sysConfig,
                appConfig: this.appConfig
            });


            this.model.get_files({},
                function (results) {

                    $j.extend(configData, {security: results});
                    //populate header field//

                },
                function (errors) {

                    //show errors
                    $App.Controller("DWS.Messaging").error(errors);

                });

            this.parseConfig(configData);

        }

        //call files model in FM to get File Access Authorities//
        return this.config;
    },
    convertBools: function (config) {
        for (var prop in config) {
            if (config[prop] == 'Y') {
                config[prop] = true;
            } else if (config[prop] == 'N') {
                config[prop] = false;
            }
        }
    }
});
