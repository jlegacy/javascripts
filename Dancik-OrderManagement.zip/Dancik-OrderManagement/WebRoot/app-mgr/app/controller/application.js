/*globals $App */
(function ($) {
$App.Controller('Application', {
	initialize: function () {
		this.view = $App.View('Application');
	},
	//Initialize and render the initial application
	init: function () {
		//var _this = this;
		$App.Controller("DWS.Growler").start('om_growler');
	},
	block_screen: function (data) {
		if (!$.isPlainObject(data)) {
			data = {
				message: data
			};
		}
		$('<div></div>').dancikOverlay(data);
	},
	unblock_screen: function (data) {
		$('<div></div>').dancikOverlay('close');
	}
});
})(jQuery);
