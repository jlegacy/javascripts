(function ($) {
$App.Controller("SplitLine", {
	initialize: function () {
		this.view = $App.View("SplitLine");
		this.model = $App.Model("SplitLine");
	},
	openWindow: function(data, uom_results){
		//console.log("controller - splitline - openWindow - data", data);
		
		//change the UOM return to fit in the select box properly
		var uomChoices =[];
		$(uom_results).each(function( index ) {
			uomChoices[index] = {value:uom_results[index].uom, text:uom_results[index].uom}
		});

		splitInfo = {
				account: data.order.billingaccount,
				order: data.order.orderid,
				line: data.line.line,
				item_16: data.line.item_16,
				qtyOrdered: data.line.quantity_open,
				uom: data.line.uom,
				purchase_order:data.purchase_order,
				uom_choices:uomChoices,
				referenceid:data.order.reference
			};		
		
		var _this = this,				
		callback = function (results) {
			$j.extend(results,splitInfo);
			results.status_codes.unshift({value:"", text: ""});
			_this.view.splitPopup(results);
			$App.Fire('clear_overlay');
		},
		errorCallback = function (errorResults) {
			$App.Fire("ajax_errors2", errorResults);
			$App.Fire('clear_overlay');
		};
	   _this.model.getSplitInfo(splitInfo, callback, errorCallback);
	},
	getUOM: function(data){
		//console.log("controller - splitline - getUOM - data", data);
		var itemSent={item:data.line.item_16};
		var _this = this,				
		callback = function (results) {
			_this.openWindow(data, results.uoms);
			$App.Fire('clear_overlay');
		},
		errorCallback = function (errorResults) {
			$App.Fire("ajax_errors2", errorResults);
			$App.Fire('clear_overlay');
		};
		$App.Fire('overlay', 'Retrieving');
	   _this.model.getUOM(itemSent, callback, errorCallback);
	},
	execute_split: function(data){
		//console.log("controller - splitline - data", data);
		var _this = this;
//		_this.orderRefresh()		
		var _this = this;
				
		callback = function (results) {
			$(".ui-dialog-content").dialog("close");
			parent.Main.Options.gotoOrderSplit(data.referenceid, data.order_number);
			$App.Fire('clear_overlay');
		},
		errorCallback = function (errorResults) {
			$App.Fire("ajax_errors2", errorResults);
			$App.Fire('clear_overlay');
		};
		$App.Fire('overlay', 'Executing');
	   _this.model.execute_split_line(data, callback, errorCallback);
	}
});
})(jQuery);