(function ($) {
$App.Controller("OrderViews", {
	initialize: function () {
		this.view = $App.View("OrderViews");
		this.model = $App.Model("OrderViews");
		this.last_view = {};
	},
	openWindow: function (data) {
		var columnHeaders=["Order Date","Order#","Reference#", "Name", "Account#", "Ship Date", "Customer PO#", "Branch", "Warehouse", "Salesperson 1"],
		selectedView="",
		defaultFlag = false;
		_this=this;
		if (Main.useDetailLevel) {
			selectedView = "ordermanagerd";
		}
		else{
			selectedView = "ordermanagerh";
		}
		var naj = new Ajax.Request("../../fm/service/FM_Service/getFilters",{	
			method: "get",
			parameters: {
				output: "JSON",
				parm_FileName: selectedView
			},
			evalJSON: "force",
			onSuccess: function(res) {
				if (res.responseJSON){
					var json = res.responseJSON;
					var recordsNum = json.records, 
						filterParsed ={}, newdata={};
					$.each(recordsNum, function (index, val) {
						filterParsed = $.parseJSON(val.filter_values);
						
						if (filterParsed.isDefault == true){
							//console.log("index", index);
							if (val.user !=="DANCIK"){
									newdata=json.records[index];
									defaultFlag=true;
									return false
							}
							else{
								if (defaultFlag==false){
								//	console.log(json.records[index]);
									newdata=json.records[index];
									//return false;
								}
							}
						}
					});			
			//	console.log("json.records", json.records);
				//console.log("newdata", newdata);
				_this.view.viewOrderPop(columnHeaders, newdata, json.records);
				}
				else{
					//console.log("no views");
					var json = {
							records:[]
					},
					filters = {
							isDefault:true,
							set:[],
							sort:["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18"]
					}
							
					json.records[0]={
						keyid:"0000",
						//filter_values:'{"set":[],"sort":["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18"],"isDefault":true',
						filter_values:filters,
						description:"Default view",
						file_name:"ordermanagerh",
						user:"DANCIK",
						private:""
					}
				//	console.log(json);
					
					newdata={
						description:"Default View",
						file_name:"ordermangerh",
						filter_values:'{"set":[],"sort":["0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18"],"isDefault":true',
						keyid:"0000",
						private:"",
						user:"DANCIK"
					}
				//	console.log("newdata - ", newdata);
					_this.view.viewOrderPop(columnHeaders, newdata, json.records);
				}
			}, 
			onFailure: function(res) {
			}				
		});
		var _this=this;
		//html body div.ui-dialog form#manage_order_view.app-orderview
	},
	remove: function (view) {
		$App.Fire('overlay', 'Deleting View');
		var _this = this;
		_this.model.delete_view(view, function (results) {
			//nothing is returned
		});
	},
	save_view: function (data) {
		var _this = this,
		sort_arr = [],
		tr_arr = [],
		filter_arr = [],
		user_view = $.extend(true, {fm_file: data.fm_file}, _this.last_view[data.fm_file]);
		container = $('html body div.ui-dialog');	
	tr_arr = container.find('.sort-fields tr');	
//	//build sort and filter array
	tr_arr.each( function (i) {
		
		//if check box is checked, add to sort array
		if ($(this).find("input[type=checkbox]").prop("checked")){
			sort_arr.push($(this).attr('id'));	
		}
	});

//	//set sort and filters in view object

	user_view.sort = sort_arr;
	this.view.save_view(user_view);

	},
	apply: function(data){
		//console.log('controller - apply');
		var _this = this,
		sort_arr = [],
		tr_arr = [],
		filter_arr = [],
		user_view = $.extend(true, {fm_file: data.fm_file}, _this.last_view[data.fm_file]);
		container = $('html body div.ui-dialog');
		tr_arr = container.find('.sort-fields tr');
		
		//build sort and filter array
		tr_arr.each( function (i) {
		//if check box is checked, add to sort array
			if ($(this).find("input[type=checkbox]").prop("checked")){
				sort_arr.push($(this).attr('id'));	
			}
		});
		//console.log("apply", sort_arr);
		if (Main.useDetailLevel) {
			Main.currentDetailView = sort_arr;
		}
		else{
			Main.currentHeaderView = sort_arr;
		}
		/////
		if (Main.savedParams) { 
			//console.log("inside apply - ", Main.currentDetailView);
			Main.submitNewSearch();
		}
		else{
			Main.loadHeadings();
		}
	//this.view.save_view(user_view);
	},
	save_view_description: function (data, form) {
		var _this = this,
			view_collision,
			name_collision = [],
			default_view_collision = [];
			save_flag = true;

		//if is_default is not checked in form, it returns a true value. We set is_default it to false
		if (data.is_default === true) {
			data.is_default = false;
		}
		_this.model.get_views({file: data.fm_file}, function (results) {
			//check for duplicate names
			name_collision = $.grep(results, function (view) {
				return view.description.toLowerCase() == data.description.toLowerCase() && view.id.toString() != data.id.toString();
			});
			//check if default view exists  
			default_view_collision = $.grep(results, function (view) {
				
				if (view.is_Dancik !== true) { //skip the default Dancik defined view
					if (data.is_default == "Y" && view.is_default == true && view.id.toString() != data.id.toString()) {
						return true;
					}
				}
				else{
					return false;
				}
			});
			if (default_view_collision.length) {
				$App.Fire('errors', 'A default filter already exists.');
				save_flag = false;
				return;
			}		
			
			if (name_collision.length) {
				//expecting only one name collision
				name_collision = name_collision[0];
				
				//check for name collisions
				if (name_collision.user == $App.Controller('Config').getConfig().user.user) {
					data.id = name_collision.id;
					//$App.Fire('errors', 'A view by that name already exists. Delete current view or rename.');
					_this.view.prompt_overwrite(data, form);
				}
				else {
					$App.Fire('errors', 'A view by that name already exists.');
				}
				
				return;
			}
			
			if (save_flag) {
				$App.Fire('overlay', 'Saving View');
				_this.model.save(data, function (view) {
					$(form).dialog('close');
					results.push(view);
					$App.Fire('info_message', 'View saved.');
					//$App.Controller('Search_' + view.fm_file).store_views([view]);
					_this.view.store_views([view]); //update filter views
					//_this.last_view[view.fm_file] = view;
					$('#manage_order_view').submit();
					
					$App.Fire('clear_overlay');
				});
				save_flag = false;
			}
		});
	},
	load_filter: function(data){
	//	console.log('load_filter- data', data);
		var _this = this,
			container = _this.view.getContainer(),
			headers=[]; 
			search_view = "";	
		//clear table
			if (Main.useDetailLevel) {
				headers = Main.defaultDetailList;
			}
			else{
				headers = Main.defaultHeaderList;
			}
		_this.view.clear_table_view();
		 data.filter_values = $.parseJSON(data.filter_values),
		 sort={};
		 // = data.filter_values.sort;
		 
		 if (data.sort){
			 sort = data.sort;
		 }
		 else{
			 sort = data.filter_values.sort;
		 }
		//set columns in table with proper sort order
		 if (Main.useDetailLevel) {
			 Main.loadedDetailView = sort;
		 }
			else{
				 Main.loadedHeaderView = sort;
			};
		 //Main.loadedView = true;
		_this.view.set_columns(sort, search_view,container,headers);
		
	},
	resetToStart: function (data) {
		var _this = this;
		
		_this.view.reset_filter_view(data);

	},
	reset: function (data) {
		var _this = this;

		_this.view.reset_filter_view(data);
	},
	load: function (view) {
		var _this = this;
			//search_controller = $App.Controller("Search_" + view.fm_file);
		
		//_this.last_view[view.fm_file] = view;
		
		search_controller.set_columns(view.sort);
		search_controller.set_filters(view.filters);
		search_controller.refresh();
	}
	
	
	});
})(jQuery);