$App.Controller('UpdateDelivery', {
     initialize: function () {
          //this.view = $App.View("UpdateDelivery");
          this.model = $App.Model("UpdateDelivery");
     },
     updateDeliveryDay: function (data) {
          var _this = this;
          parent.$App.Fire('overlay', 'Updating Records');
          _this.model.update_delivery_day(data, function (results) {
               data.window.close();
               parent.$App.Fire('clear_overlay');
          },
                  function (errors) {
                       parent.$App.Fire('clear_overlay');
                       //stop processing modal
                       parent.$App.Fire("ajax_errors2", errors);
                  });

     }
});