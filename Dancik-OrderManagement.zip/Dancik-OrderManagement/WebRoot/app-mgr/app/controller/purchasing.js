/*globals $App jQuery Main CashRegister_Popup OrderNotepad_Popup MultiEntry*/
(function ($) {
	$App.Controller("purchasing", {
		initialize: function () {
			this.view = $App.View("purchasing");
			this.model = $App.Model("purchasing");
			this.config = $App.Controller('Config').getConfig();
		},
		//----------------------------------------------------------
		// open the purchasing modal window and populate with details
		//----------------------------------------------------------
		purchasing_rules_init: function (data) {
			var _this;
			_this = this;

			_this.view.purchasing_rules_init();

},
		purchasing_discontinued_popup: function () {
			var _this;
			_this = this;
			_this.view.purchasing_discontinued_popup();
		},
		purchasing_reorder_calc_init: function (data) {
			var _this;
			_this = this;

			_this.view.purchasing_reorder_calc_init(_this.config, data);

		},
		get_purchasing_rules: function (data) {
			var _this = this, container;

			container = _this.view.get_main_container();
			container.dancikBusy({
				message: 'Retrieving Data'
			});

			_this.model.get_purchasing_rules(data,
				function (results) {

					_this.view.get_purchasing_rules(data, results, _this.config);

					//stop processing modal
					container.dancikBusy("close");
				},
				function (errors) {
					//stop processing modal
					container.dancikBusy("close");
					//show errors
					$App.Controller("DWS.Messaging").error(errors);

				});
		},
		get_purchasing_reorder_info: function (data) {
			var _this = this, container1, container2;

			//  container = _this.view.get_po_container();
			container1 = $j('#Popup_Search_ForITEM');
			container1.dancikBusy({
				message: 'Retrieving Data'
			});
		
			container2 = $j('#PO_Canvas');
			container2.dancikBusy({
				message: 'Retrieving Data'
			});

			_this.model.get_reorder_calcs(data,
				function (results) {

					_this.view.get_purchasing_reorder_info(data, results, _this.config);

					//stop processing modal
					container1.dancikBusy("close");
					container2.dancikBusy("close");
				},
				function (errors) {
					//stop processing modal
					container1.dancikBusy("close");
					container2.dancikBusy("close");
					//show errors
					$App.Controller("DWS.Messaging").error(errors);

				});
		},
		get_reorder_calcs: function (data) {
			var _this = this, container;

			container = _this.view.get_po_container();
			container.dancikBusy({
				message: 'Retrieving Data'
			});

			_this.model.get_reorder_calcs(data,
				function (results) {

					_this.view.get_reorder_calcs(data, results, _this.config);

					//stop processing modal
					container.dancikBusy("close");
				},
				function (errors) {
					//stop processing modal
					container.dancikBusy("close");
					//show errors
					$App.Controller("DWS.Messaging").error(errors);

				});
		},
		get_purchasing_rules_filter: function (data) {
			var _this = this, container;

			container = _this.view.get_po_container();
			container.dancikBusy({
				message: 'Retrieving Data'
			});

			_this.model.get_purchasing_rules(data,
				function (results) {
					if (results.records.length > 0)

					{
						_this.view.get_purchasing_rules(data, results, _this.config);
					}
					else
					{
						_this.view.no_purchasing_rules(data, results, _this.config);
					}

					//stop processing modal
					container.dancikBusy("close");
				},
				function (errors) {
					//stop processing modal
					container.dancikBusy("close");
					//show errors
					$App.Controller("DWS.Messaging").error(errors);

				});
		},
		get_purchasing_rules_more: function (data) {
			var _this = this, container;

			container = _this.view.get_po_container();
			container.dancikBusy({
				message: 'Retrieving Data'
			});

			_this.model.get_purchasing_rules(data,
				function (results) {
					//populate header fields

					_this.view.get_purchasing_rules_more(data, results);

					//stop processing modal
					container.dancikBusy("close");
				},
				function (errors) {
					//stop processing modal
					container.dancikBusy("close");
					//show errors
					$App.Controller("DWS.Messaging").error(errors);

				});
		},
		purchasing_rules_screen_edit: function (data) {
			var _this;
			_this = this;

			_this.view.purchasing_rules_screen_edit(data);

		},
		purchasing_rules_screen_delete: function (data) {
			var _this;
			_this = this;

			_this.view.purchasing_rules_screen_delete(data);

		},
		purchasing_rules_screen_insert: function (data) {
			var _this;
			_this = this;

			_this.view.purchasing_rules_screen_insert(data);

		},
		purchasing_rules_file_delete: function (data) {
			var _this, container;
			_this = this;

			container = _this.view.get_po_container();
			container.dancikBusy({
				message: 'Deleting Data'
			});

			_this.model.purchasing_rules_file_delete(data,
				function (results) {
					//populate header fields

					_this.view.purchasing_rules_file_delete(data, results);

					//stop processing modal
					container.dancikBusy("close");
				},
				function (errors) {
					//stop processing modal
					container.dancikBusy("close");
					//show errors
					$App.Controller("DWS.Messaging").error(errors);

				});

		},
		purchasing_rules_file_delete_confirm: function (data) {
			var _this;
			_this = this;

			_this.view.purchasing_rules_file_delete_confirm(data);

		},
		purchasing_rules_file_update: function (data) {
			var _this, container;
			_this = this;

			container = _this.view.get_po_container();
			container.dancikBusy({
				message: 'Updating Data'
			});

			_this.model.purchasing_rules_file_update(data,
				function (results) {
					//populate header fields

					_this.view.purchasing_rules_file_update(data, results);

					//stop processing modal
					container.dancikBusy("close");
				},
				function (errors) {
					//stop processing modal
					container.dancikBusy("close");
					//show errors
					$App.Controller("DWS.Messaging").error(errors);

				});

		},
		purchasing_rules_file_insert: function (data) {
			var _this, container;
			_this = this;

			container = _this.view.get_po_container();
			container.dancikBusy({
				message: 'Inserting Data'
			});

			_this.model.purchasing_rules_file_insert(data,
				function (results) {
					//populate header fields

					_this.view.purchasing_rules_file_insert(data, results);

					//stop processing modal
					container.dancikBusy("close");
				},
				function (errors) {
					//stop processing modal
					container.dancikBusy("close");
					//show errors
					$App.Controller("DWS.Messaging").error(errors);

				});


		}
	})

})(jQuery);