$App.Controller("OrderStatus", {
	initialize: function () {
		this.view = $App.View("OrderStatus");
		this.model = $App.Model("OrderStatus");
	},
	open: function (data) {
		var _this = this;
		_this.view.open(data);
		_this.view.busy(data, "Loading");
		
		_this.model.getOrderStatus(data, 
			function (results) {
				_this.view.update(results);
				_this.view.process_flags(results);
				_this.view.unbusy(data);
			},
			function (errors) {
				$App.Fire("ajax_errors", errors);
				_this.view.close(data);
				_this.view.unbusy(data);
			}
		);
	},
	update: function (data) {
		var _this = this;
		_this.view.busy(data, "Updating");
		
		_this.model.updateOrderStatus(data,
			function (results) {
				//refresh order if we are in one
				if (Main && Main.getOrder) {
					Main.getOrder({avoidToggle:true});
				}
				
				if (results.flags.flag_goto_cashregister) {
					data.win.close();
					new CashRegister_Popup({ 
							parm_OrderId: data.orderid, 
							parm_ReferenceId: data.referenceid
						}, {
							afterSubmit : function() {
								if (Main && Main.close) {
									Main.close();
								}
							}
						}						
					);
				} else {
					_this.view.update(results);
					_this.view.unbusy(data);
				}
			},
			function (errors) {
				$App.Controller("DWS.Messaging").error(errors);
				_this.view.unbusy(data);
			}
		);
	},
	notepad: function (data) {
		var notepad = new OrderNotepad_Popup({
				parm_orderid: data.orderid,
				parm_referenceid: data.referenceid
			}, {
				editmode: true
			}
		);
		notepad.open();
	}
});