/*globals jQuery $App*/
(function ($) {
	$App.Controller('Messaging', {
		initialize: function () {
			this.view = $App.View('Messaging');
		},
		clearMessages: function () {
			var _this = this;
			_this.view.clearAll();
		},
		clearBlanket: function () {
			var _this = this;
			_this.view.clearBlanket();
		},
		blanketMessage: function (message) {
			var _this = this;
			_this.clearMessages();
			_this.view.blanketMessage(message);
		},
		info: function (data) {
			var _this = this;
			_this.view.info(data.message);
		},
		warn: function (data) {
			var _this = this;
			_this.view.warn(data.message);
		},
		error: function (data) {
			var _this = this;
			_this.view.errors(data.message, data.details, data.options);
		},
		backendWarnings: function (warnings) {
			var message, details,
				_this = this;
	
			_this.clearMessages();
			message = warnings.message;
			details = warnings.map(function (warning) {
				return warning.message;
			});
			_this.view.warn(message, details);
		},
		backendErrors: function (errors) {
			var message, details,
				_this = this;
	
			_this.clearMessages();
			message = errors.message;
			if ($.isArray(errors)) {
				details = errors.map(function (error) {
					return error.errmsg;
				});	
			} else {
				details = errors.errmsg;
			}	
			_this.view.errors(message, details);
		},
		confirmation: function (data) {
			var _this = this;
			_this.view.confirmation(data.message, data.details, data.callback);
		}
	});
})(jQuery);