/*globals $App jQuery $M Dancik_ConfirmWindow Dancik FormFormatter Validation Dancik_RightClicks Popup2Search CalendarObject*/
(function ($) {
    $App.View("c3scheduler", {
        //--------------------------------------------------------
        // open the dialog window and populate with html
        //--------------------------------------------------------
        init: function (data) {
            var _this = this, container, template, summary_inline;
            var route;
            var strDate = new Date();
            var dateIso;
            var checkboxes;
            var payload;
            var arr;
            
          
            template = $App.Template('c3_scheduler/base.ejs');
            
            //summary_inline = $App.Template('c3_scheduler/inline_actions.ejs');
                
            container = $(template.render());

            container.dialog({
                title: 'C3 Job Scheduler',
                height: 550,
                width: 1250,
                modal: 'false',
                dialogClass: 'dancik-dialog',
                open: function () {
                    //remove button css to match accounting button standards
                    $('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
                    //prevent ui-state-hover form formatting buttons
                    $('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
                    $('.ui-dialog-buttonpane').find('button').hover(function () {
                        $(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
                    });
                },
                close: function () {
                    $(this).remove();
                },
                buttons: {
                   
            }
            });
            
            //decorate container
            container.find(".drop-cal")
            .addClass("format-date2")
            .each(function (index, input) {
                CalendarObject.buildDateWidget(input, {
                    zIndex: 10000
                });
            });
            //add drop downs
            $App.Utils.dropdown_billto(container.find('input[name=omAccountLastFive]'), {
                appendTo: document.body
            });
            
            //add drop downs
            $App.Utils.dropdown_billto(container.find('input[name=parm_FilterAccount]'), {
                appendTo: document.body
            });
            
            //add drop downs
            $App.Utils.dropdown_company(container.find('input[name=omCompany]'), {
                descriptionElement: container.find('span.company-name'),
                appendTo: document.body
            });

            //set reference number
            container.find('input[name=omRefNumber]').val(data.omReference);
           
            //add account num to html
            container.find('.multi-unit-header span.acct-num').html(data.omAccount);
            
            // Take current date, derive offsets to get start week/end week day
            strDate.setDate(strDate.getDate());
            
            todayMDY = ((strDate.getMonth() + 1) + '/' + strDate.getDate() + '/' + (strDate.getFullYear() % 100));
            today = ((strDate.getFullYear()) + '' + (strDate.getMonth() + 1) + '' + strDate.getDate());
            $('input[name=omInstallDate]').val(today);
            $('input[name=omInstallDateMDY]').val(todayMDY);
            
            $("#c3-scheduler-container").find(".dws-mouseover1").off();
            
            //Setup Hovers//
            $("#c3-scheduler-container").find(".dws-mouseover1").hover(
                function () {
                    $(this).find('.Mgr_Filter_Clear').find('img:first').show();
                }, 
                function () {
                    $(this).find('.Mgr_Filter_Clear').find('img:first').hide();
                }
                );
                    
            //Setup Clear Clicks//
            $("#c3-scheduler-container").find(".Mgr_Filter_Clear").on('click', function () {
                $(this).prev('td').find('input').val('');
                $(this).prev('td').find('span.company-name').html('');
            //
            //   $('#c3-search-filters').find('span.company-name').html('');
            });
            
          
            $("#c3-popup-filter-graphic").off();  
            $("#c3-popup-filter-graphic").click(function() {
                $("#c3-search-filters").toggle();
                $("#c3-search-filter-buttons").toggle();
                $(".c3-update_buttons").toggleClass('expand');
                $("#c3-popup-filter-graphic").toggleClass('c3-ExpandImg').toggleClass('c3-CollapseImg');
                $("#c3-scrolltable").toggleClass('short').toggleClass('long');
            });
            
            //Setup Submit Button//
            container.find('#c3-Submit').off();
            container.find('#c3-Submit').on('click', function () {
             
                //Check for valid fields//
             
                arr = [];
                
                $.each($('#c3-search-filters').find('input:visible'), function (index, value) {
                    if ($(value).val()) {
                        arr.push(index)
                    }
                });
            
                if (arr.length === 0) {
                    // $App.Fire("errors", 'No Search Criterial Selected');
                    new Dancik_ConfirmWindow({
                        showAsInfoOnly: true,
                        content: '<div style="text-align:left;"> Must Select At Least One Filter Criteria </div>',
                        destroyOnClose: true,
                        color:"red",
                        modal:true
                    }).open();
                    return;
                } 
          
                
                
                //reset hidden fields//
                container.find('input[name=omInstaller]').val(container.find('input[name=omInstallerFilter]').val());
                container.find('input[name=omInstallTeam]').val(container.find('input[name=omInstallTeamFilter]').val());
                container.find('input[name=omInstallDate]').val('');
                container.find('input[name=omRequiredDate]').val('');
                container.find('input[name=omAccount]').val('');
                //    container.find('input[name=omCompany]').val('');
                container.find('span.company-name').html('');
                
                route = '#reload_c3_scheduler_by_account_date';
                if ($('input[name=omInstallDateMDY]').val() != '')
                {
                    dateIso = $App.Utils.cvtDateIso(container.find('input[name=omInstallDateMDY]').val());
                    container.find('input[name=omInstallDate]').val(dateIso);
                    container.find('input[name=omDate]').val(dateIso);
                }
                
                if ($('input[name=omAccountLastFive]').val() != '')
                {
                    container.find('input[name=omAccount]').val(container.find('input[name=omAccountLastFive]').val());
                }
                
                if ($('input[name=omRequiredDateMDY]').val() != '')
                {
                    dateIso = $App.Utils.cvtDateIso(container.find('input[name=omRequiredDateMDY]').val());
                    container.find('input[name=omRequiredDate]').val(dateIso);
                }
                
                
                $('#c3-scheduler_form').attr("action", route);
                $('#c3-scheduler_form').submit();
               
                 
            // date only
            /*  if ($('input[name=omRequestDateMDY]').val() != '' && $('input[name=omAccountLastFive]').val() == ''){
                route = '#reload_c3_scheduler_by_date';
                dateIso = $App.Utils.cvtDateIso(container.find('input[name=omRequestDateMDY]').val());
                container.find('input[name=omRequestDate]').val(dateIso);
                $('#c3-scheduler_form').attr("action", route);
                $('#c3-scheduler_form').submit();
            }
                        
            // Account only
            if ($('input[name=omRequestDateMDY]').val() == '' && $('input[name=omAccountLastFive]').val() != ''){
                route = '#reload_c3_scheduler_by_account';
                container.find('input[name=omAccount]').val() + container.find('input[name=omAccountLastFive]').val());
                $('#c3-scheduler_form').attr("action", route);
                $('#c3-scheduler_form').submit();
            }
            // // Account and Date
            if ($('input[name=omRequestDateMDY]').val() != '' && $('input[name=omAccountLastFive]').val() != ''){
                route = '#reload_c3_scheduler_by_account_date';
                container.find('input[name=omAccount]').val() + container.find('input[name=omAccountLastFive]').val());
                dateIso = $App.Utils.cvtDateIso(container.find('input[name=omRequestDateMDY]').val());
                container.find('input[name=omDate]').val(dateIso);
                $('#c3-scheduler_form').attr("action", route);
                $('#c3-scheduler_form').submit();
                            
            } */
                
               
                        
            /*    if ($('input[name=omRequestDateMDY]').val() == '' && $('input[name=omAccountLastFive]').val() == ''){
                var errors = [{
                    errid:"xxx", 
                    errmsg:"Enter Search Criteria and Press Continue"
                }]
                $App.Controller("DWS.Messaging").error(errors);
            }*/
                        
            });
            
            //Setup Submit Button//
            container.find('#c3-Clear').off();
            container.find('#c3-Clear').on('click', function () {
                $('#c3-search-filters').find('input:visible').val('');
                //clear company name text
                $('#c3-search-filters').find('span.company-name').html('');
            });
            
            //Setup Update Button//
            container.find('#c3-Update').off();
            container.find('#c3-Update').on('click', function () {
                
                checkboxes = container.find('.c3-update-checkbox');
                $.each(checkboxes, function(x) {
                    if ($(this).prop('checked')){              
                        payload  = $('#row_' + x).find('.c3-update-checkbox:first');
                        $App.Fire("c3_schedule_edit", payload.data('payload'));
                        return false;
                    }
                //app fire update on other checked boxes//
                });
               
              
            });
            
            //setup dropdowns
            $App.Utils.dropdown_installCompany(container.find('input[name=omInstallerFilter]'), {
                appendTo: document.body
            });
        
            $App.Utils.dropdown_installTeamFilter(container.find('input[name=omInstallTeamFilter]'), {
                appendTo: document.body,
                install_Company: data.omInstaller
            }); 
            
        //set company number in popup using company from main order//
        //  container.find('input[name=parm_FilterCompany]').val($('#Main_Canvas').find('input[name=parm_FilterCompany]').val());
        //  container.find('input[name=parm_FilterCompany]').next('span:first').html($('#Main_Canvas').find('input[name=parm_FilterCompany]').next('span:first').html());
          
          
          
     
        },
        
        c3_schedule_edit: function (data) {
           
            var template;
            var container;
            var enteredData;
            var parms;
            var n;
            var id;
            var payload;
            var checkboxes;
             
            //get record//
            template = $App.Template('c3_scheduler/edit_schedule.ejs');
            
            container = $(template.render());

            container.dialog({
                title: 'Edit Job Schedule Record',
                height: 250,
                width: 395,
                modal: 'true',
                dialogClass: 'dancik-dialog',
                open: function () {
                    //remove button css to match accounting button standards
                    $('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
                    //prevent ui-state-hover form formatting buttons
                    $('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
                    $('.ui-dialog-buttonpane').find('button').hover(function () {
                        $(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
                    });
                },
                close: function () {
                    $(this).remove();
                },
                buttons: {
                    'Continue': function () {
                      
                        //show processing modal//
                         
                        container.dancikBusy({
                            message: 'Saving Data'
                        });
                        
                        enteredData = {};
                        parms={};
                        parms = [];
                        
                        //save entered data//
                        enteredData.omInstaller = container.find('input[name=omInstaller]').val();
                        enteredData.omInstallTeam = container.find('input[name=omInstallTeam]').val();
                        enteredData.omInstallStatus = container.find('input[name=omInstallStatus]').val();
                        enteredData.omInstallDateDisplay = container.find('input[name=omInstallDateDisplay]').val();
                        enteredData.omInstallDate = '';
                       
                        if (container.find('input[name=omInstallDateDisplay]').val())
                        {
                            enteredData.omInstallDate = $App.Utils.cvtDateIso(container.find('input[name=omInstallDateDisplay]').val());
                        }
      
                        //  
                        //loop through check boxes and build array of objects//  
                        checkboxes = $('#c3-scrolltable').find('.c3-update-checkbox');
                        $.each(checkboxes, function(x) {
                            if ($(this).prop('checked')){
                                id = $(this).attr('id');
                                n = id.split("_");
                                //retrieve payload of row to display as edit//
                               
                                payload  = $('#row_' + n[1]).find('.c3-update-checkbox:first');

                                parms.push({
                                    omInstaller:enteredData.omInstaller, 
                                    omInstallTeam:enteredData.omInstallTeam,
                                    omInstallStatus:enteredData.omInstallStatus,
                                    omOrder:payload.data('payload').omOrder,
                                    omLine:payload.data('payload').omLine,
                                    omInstallDate:enteredData.omInstallDate,
                                    omInstallDateDisplay: enteredData.omInstallDateDisplay,
                                    omRow:n[1] 
                                });
                            }
                        });
                         
                             
                        $App.Fire("update_c3_scheduler_header", {
                            omlines :parms
                        });
                        $App.Fire("update_c3_scheduler_detail", {
                            omdetails :parms
                        });
                    
                    },
                    'Cancel': function () {
                        $(this).remove();
                    }
                }
            });
            
            //decorate container
            container.find(".drop-cal")
            .addClass("format-date2")
            .each(function (index, input) {
                CalendarObject.buildDateWidget(input, {
                    zIndex: 10000
                });
            });
            
            //decorate edit fields//
            container.find('input[name=omInstaller]').val(data.omInstaller);
            container.find('input[name=omInstallStatus]').val(data.omInstallStatus);
            container.find('input[name=omInstallDateDisplay]').val(data.omInstallDateDisplay);
            container.find('input[name=omInstallDate]').val(data.omInstallDate);
            container.find('input[name=omInstallTeam]').val(data.omInstallTeam);
            container.find('input[name=omOrder]').val(data.omOrder);
            container.find('input[name=omLine]').val(data.omLine);
            container.find('input[name=omRow]').val(data.omRow);
            
            
            $App.Utils.dropdown_installCompany(container.find('input[name=omInstaller]'), {
                appendTo: document.body
            });
        
            $App.Utils.dropdown_installTeam(container.find('input[name=omInstallTeam]'), {
                appendTo: document.body,
                install_Company: data.omInstaller
            }); 
            
            //add drop downs
            $App.Utils.dropdown_status(container.find('input[name=omInstallStatus]'), {
                appendTo: document.body
            }); 
           
        },

        show_job_schedule_entries: function (parms ,results, data) {
            var _this = this;
            
            var today, todayMDY;
            var link;
            var rowContainer;
            var container;
            
            //clear table//
            $('#c3_schedule_details').find('tbody#multi-unit-row').remove();
           
            var summary_inline = $App.Template('c3_scheduler/inline_actions.ejs');
            
            if (results != null)
            {
                var rows = $App.Template('c3_scheduler/row.ejs').render(results);
            }
            
            $('#c3_schedule_details').append(rows);
             
            //Slide data table header with data table body on horizontal slide
            container = $('div#c3-scheduler-container');
            
            var body_right = container.find(".c3-table-results-div .body.right");
            var body_left = container.find(".c3-table-results-div .body.left");
            var header_right = container.find(".c3-table-results-div .header.right");
            
            //set scroll top
            body_right.scrollTop(0);
            body_left.scrollTop(0);

            body_right.scroll(function () {
                
                header_right.scrollLeft(body_right.scrollLeft());
                body_left.scrollTop(body_right.scrollTop());
            });
            
            body_left.scroll(function () {
                body_right.scrollTop(body_left.scrollTop());
            });
            
            //payload data to href//
           
            rowContainer = $('#c3-scheduler-container').find('.c3-update-checkbox');
            $.each(rowContainer,function(x,y){
           
                $(this).data('payload', {
                    omInstaller: results.details[x].installer,
                    omInstallTeam: results.details[x].installation_team,
                    omInstallDate: results.details[x].install_date,
                    omInstallDateDisplay: results.details[x].install_date_display,
                    omInstallStatus: results.details[x].installation_status,
                    omOrder: results.details[x].customer_order_number,
                    omLine: results.details[x].customer_line_number,
                    omRow:x
                });
            });
               
            //add inline menu functionality to deposit summary row
            $('#c3-scheduler-container').delegate('a.inline-menu', 'click', _this.inlineActionOpen);
            
        },
       
        update_c3_scheduler_header: function (data) {
      
            var container;
            var link;
            _this = this;
            $('#c3-scheduler-update_form').dialog('close');
            
            container = _this.get_container();
            
            //update visual display with updated record//
            $.each(data.omlines, function(x,y) {
             
                container.find('#omInstaller_' + y.omRow).html(y.omInstaller);
                container.find('#omInstallStatus_' + y.omRow).html(y.omInstallStatus);
                container.find('#omInstallDateDisplay_' + y.omRow).html(y.omInstallDateDisplay);
                container.find('#omInstallTeam_' + y.omRow).html(y.omInstallTeam);
            
                // reset payload for this record
            
                //     link = container.find('#row_' + data.omRow).find('a[href="#c3_schedule_edit"]:first');
                link = container.find('#row_' + y.omRow).find('.c3-update-checkbox:first');
                link.data('payload', {
                    omInstaller: y.omInstaller,
                    omInstallTeam: y.omInstallTeam,
                    omInstallDate: y.omInstallDate,
                    omInstallDateDisplay: y.omInstallDateDisplay,
                    omInstallStatus: y.omInstallStatus,
                    omOrder: y.omOrder,
                    omLine: y.omLine,
                    omRow:y.omRow
                });
            });
            
        },
        
        update_c3_scheduler_detail: function (data) {
      
            
        },
        
        //-----------------------------------------------
        // Gets the current form   
        //-----------------------------------------------
        get_container: function () {
            var _this = this, container;
            container = $("#c3-scheduler_form");
            return container;
        },
       
       
        //------------------------------------------
        // opens the inline menu for deposit summary
        // Note: this works in comjunction with CSS 
        //------------------------------------------
        inlineActionOpen: function (event) {
         
            var _this = this, menu_top, menu_bottom, container_top, container_bottom, 
            menu_ul, hideFun,
            row = $(event.currentTarget).closest('tr'),
            container = row.closest('tbody').closest('div'),
            menu_div = $(event.currentTarget).closest('td.line-actions div.inline-actions');
           
            //get menu ul container
            menu_ul = menu_div.find('ul');

            event.preventDefault();

            //adds open class to div.inline-actions on selected row
            menu_div.addClass('open'); //IE7 z-index fix

            //show menu
            menu_ul.show();

            menu_top = menu_ul.offset().top;
            menu_bottom = menu_top + menu_ul.outerHeight();
            container_top = container.offset().top;
            container_bottom = container_top + container.innerHeight();
            
            //if menu extends above div
            if (menu_bottom > container_bottom) {
                menu_ul.addClass('up').removeClass('down');
            }
            //if menu extends below div
            if (menu_top < container_top) {
                menu_ul.addClass('down').removeClass('up');
            }

            hideFun = function () {
                menu_ul
                .hide()
                .removeClass('up')
                .removeClass('down');
                menu_div
                .removeClass('open'); //IE7 z-index fix
            };
            setTimeout(function () {
                $(document).one('click', hideFun);
            }, 0);
        }
        
    });
})(jQuery);