(function ($) {
		$App.View("SplitLine", {
			initialize: function () {
	
		},
		splitPopup: function (data) {
			//console.log("Split Popup - data - ", data);
			var _this = this, container,
			template = $App.Template("splitLine/base.ejs");
			container = $(template.render(data));
			container.dialog({
				title: 'Split Order Line',
				height: 420,
				width: 600,
				modal: 'true',
				open: function () {
					 //remove button css to match accounting button standards
	                $('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
	                //prevent ui-state-hover form formatting buttons
	                $('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
	                $('.ui-dialog-buttonpane').find('button').hover(function () {
	                    $(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
	                });
	                $('.ui-dialog-buttonpane').find('button').focus(function () {
	                    $(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
	                });
                },
				dialogClass: 'dancik-dialog',
				close: function () {
					$(this).remove();
				},
				buttons: {
					"Split Line": function () {
						$(this).submit();
						//$(this).remove();
					}
				}
			});
			
			
			//Add help button to dialog
			var dialog1 = container.dialog();
			var titlebar = dialog1.parents('.ui-dialog').find('.ui-dialog-titlebar');
			$('<span class="helpButton"> </span>').appendTo(titlebar).click(function() {
				window.open('http://www.dancik.com/ca/SecDoc/DIS/Dancik%20Information%20System/!SSL!/WebHelp/Splitting_Navigator_Order_Lines.htm');
		    });
			
			
			//Disable ETA field if PO
			if (data.line_number.purchase_order=="N"){
				$j("#eta-date").attr('disabled', 'disabled');
				$j("#eta-date-text").toggleClass("disable");
			}
			//decorate fields
			 container.find(".drop_cal")
             .addClass("format-date2")
             .each(function (index, input) {
                 CalendarObject.buildDateWidget(input, {zIndex: 10000});
             });
			 
			 //$App.Utils.dropdown_shipVia(container.find('input[name=unit_of_measure]'), {appendTo: document.body});
			 $App.Utils.dropdown_status_codes(container.find('input[name=status_new]'), {appendTo: document.body});
			 $App.Utils.dropdown_status_codes(container.find('input[name=status_existing]'), {appendTo: document.body});
			 $App.Fire('clear_overlay');
		}
	});
})(jQuery);