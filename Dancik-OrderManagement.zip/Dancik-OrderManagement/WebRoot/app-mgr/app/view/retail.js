(function ($) {
	$App.View("Retail", {
		open: function (mode, file, fileID) {

		$App.Fire('info_message2', {message: "You left Order Manager into another application.  Click OK to continue in Order Manager."});
		if (fileID){
			var openlink = '../../fm/app-fm/#new-retail#'+mode+"#"+fileID
		//	console.log('fileID found-', fileID);
		//	console.log(openlink)
			top.$App.Fire('openURL', {
		          url: openlink,
		          title: "File Management" 
		});
		}
		else{
			top.$App.Fire('openURL', {
			          url: '../../fm/app-fm/#new-retail',
			          title: "File Management" 
			});
		}
	}
	});
})(jQuery);