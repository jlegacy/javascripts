/*globals $App jQuery $M Dancik_ConfirmWindow Dancik FormFormatter Validation Dancik_RightClicks Popup2Search CalendarObject*/
(function ($) {
    $App.View("MultiUnit", {
        //--------------------------------------------------------
        // open the dialog window and populate with html
        //--------------------------------------------------------
        open: function (data) {
        //console.log('VIEW - open - multi_unit.js ', data);    
            var _this = this, container,
                template = $App.Template('multi_unit/base.ejs');
                
            container = $(template.render());

            container.dialog({
                title: 'Multi-Unit Order ENTRY',
                height: 500,
                width: 980,
                modal: 'true',
                dialogClass: 'dancik-dialog',
                open: function () {
                    //remove button css to match accounting button standards
                    $('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
                    //prevent ui-state-hover form formatting buttons
                    $('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
                    $('.ui-dialog-buttonpane').find('button').hover(function () {
                        $(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
                    });
                },
                close: function () {
                    $(this).remove();
                },
                buttons: {
                    'Continue': function () {
                        $(this).submit();
                    },
                    'Cancel': function () {
                        $(this).remove();
                    }
                }
            });
            
            //radio button selection swap
            container.find('input[name=omOccupy]').not(this).removeAttr("checked");
            container.find('input[name=omFurnish]').not(this).removeAttr("checked");

            //decorate container
            container.find(".drop-cal")
                .addClass("format-date2")
                .each(function (index, input) {
                    CalendarObject.buildDateWidget(input, {zIndex: 10000});
                });
            //add drop downs
            $App.Utils.dropdown_shipVia(container.find('input[name=omShipVia]'), {appendTo: document.body});
            $App.Utils.dropdown_salesman(container.find('input[name=omSlmdNumber1]'), {appendTo: document.body});
//            container.find('input[name=omUnit]').dropdownSearch({
//                preloadedContent: [
//                    {id: "S", description: "Small"},
//                    {id: "M", description: "Medium"},
//                    {id: "L", description: "Large"}
//                ],
//                appendTo: document.body
//            });
            //disable continue button
            $($('div.ui-dialog div.ui-dialog-buttonpane div.ui-dialog-buttonset button')[0]).attr('disabled', '');
            
            //set reference number
            container.find('input[name=omRefNumber]').val(data.omReference);
           
            //add account num to html
            container.find('.multi-unit-header span.acct-num').html(data.omAccount);
            
        },
        //-----------------------------------------------
        // Gets the current form   
        //-----------------------------------------------
        get_container: function () {
            var _this = this, container;
            container = $("#multi_unit_form");

            return container;
        },
        //-----------------------------------------------
        // Create individual row and return html string   
        //-----------------------------------------------
        get_row: function (data) {
        //console.log('VIEW - get_row - multi_unit.js', data);
            var template = $App.Template('multi_unit/row.ejs');

            return template.render(data);
        },
        //-----------------------------------------------
        // add functionality to a row 
        //-----------------------------------------------
        decorate_detail_row: function (data) {
        //console.log('VIEW - decorate_detail_row - multi_unit.js', data);    
            var _this = this, header_obj,
                container = _this.get_container(),
                button = $($('div.ui-dialog div.ui-dialog-buttonpane div.ui-dialog-buttonset button')[0]),
                last_check_box_arr = container.find('tbody.multi-unit-row tr:last input[type=checkbox]'),
                last_show_hide_anchor = container.find('tbody.multi-unit-row tr:last td.short a.show_hide');
            
            //add click functionality to checkbox
            last_check_box_arr.click(function () {
                var _this = $App.View("MultiUnit"),
                    container = _this.get_container(),
                    current_chain_codes = container.find('input[name=omChain]').val(),
                    current_order_ids = container.find('input[name=omOrderNumber]').val();

                //set header object
                header_obj = {
                    omAccount: data.omAccount,
                    omChain: data.customer_chain_code,
                    omOrderId: data.order_number
                };
                //if check mark applied
                if (this.checked) {
                    //update the header fields
                    $App.Fire('update_header', header_obj);
                } else {
                    if (current_chain_codes) {
                        //if more than one value
                        if (current_chain_codes.match(',')) {
                            //remove selection from list
                            current_chain_codes = $.grep(current_chain_codes.split(','), function (value) {
                                return value != data.customer_chain_code;
                            });
                            //update field value
                            container.find('input[name=omChain]').val(current_chain_codes.join(','));
                        } else {
                            container.find('input[name=omChain]').val('');
                        }
                    }
                    
                    if (current_order_ids) {
                        //if more than one value
                        if (current_order_ids.match(',')) {
                            //remove selection from list
                            current_order_ids = $.grep(current_order_ids.split(','), function (value) {
                                return value != data.order_number;
                            });
                            //update field value
                            container.find('input[name=omOrderNumber]').val(current_order_ids.join(','));
                        } else {
                            container.find('input[name=omOrderNumber]').val('');
                        }
                    }
                }
                
                //enable continue button
                if (button.is(':disabled')) {
                    button.removeAttr('disabled');
                }
            });
            
            //add functionality to show hide detials 
            last_show_hide_anchor.click(function () {
                var _this = $App.View("MultiUnit"),
                    container = _this.get_container(),
                    row = $(this).parent().parent(),
                    row_num = row.attr('class'),
                    grouped_rows = container.find('div.multi-unit-div tbody.multi-unit-row tr.' + row_num);
                
                //hide and show rows
                if ($(this).find('span').hasClass('ui-icon-dancik-minus')) {
                    //hide rows
                    grouped_rows.not(row).hide();
                    //swap icon
                    $(this).find('span').removeClass('ui-icon-dancik-minus').addClass('ui-icon-dancik-plus');
                } else if ($(this).find('span').hasClass('ui-icon-dancik-plus')) {
                    //show rows
                    grouped_rows.not(row).show();
                    //swap icon
                    $(this).find('span').removeClass('ui-icon-dancik-plus').addClass('ui-icon-dancik-minus');
                }
            });
            
        },
        //----------------------
        // hide the row detials 
        //----------------------
        collapse_row_details: function (container) {
            var rows = container.find('div.multi-unit-div tbody.multi-unit-row tr');
                
            $.each(rows, function (index, row) {
                //if row is a header, change the icon, else hide the row
                if ($(row).find('a.show_hide').length !== 0) {
                    $(row).find('span').removeClass('ui-icon-dancik-minus').addClass('ui-icon-dancik-plus');
                } else {
                    $(row).hide();
                }
            });
        },
        //---------------------------------------------------------
        // update the header data each time a new selection is made
        //---------------------------------------------------------
        update_header_fields: function (data) {
       // console.log('VIEW - update_header_fields - multi_unit.js', data);
            var _this = this,
                container = _this.get_container(),
                current_chain_code = container.find('input[name=omChain]').val(),
                current_order_num = container.find('input[name=omOrderNumber]').val();
            //set comments    
            container.find('input[name=omCommnt1]').val(data.comments);
            container.find('input[name=omCommnt2]').val(data.comments_2);
            
            //set hidden fields
            container.find('input[name=omAccount]').val(data.account_number);
            //if chain code has a value, add to new selection
            if (current_chain_code) {
                data.customer_chain_code = current_chain_code + ',' + data.customer_chain_code;
            }
            container.find('input[name=omChain]').val(data.customer_chain_code);
            //if order id has a value, add to new selection
            if (current_order_num) {
                data.order_number = current_order_num + ',' +  data.order_number;
            }
            container.find('input[name=omOrderNumber]').val(data.order_number);
            container.find('input[name=omOrdDesc]').val(data.order_description);
            container.find('input[name=omOrdHnd]').val(data.order_handling_code);
            container.find('input[name=omType]').val(data.type_code);
            container.find('input[name=omShipNumberP]').val(data.shipto_number);
            container.find('input[name=omWareNumber]').val(data.warehouse);
            container.find('input[name=omBranch]').val(data.branch);
               
            //narrow container
            container = container.find('div.multi-unit-header');
            
            //populate fields
            container.find('.acct-num').html(data.account_number + "<br/>" + data.customer_name);
            container.find('input[name=order_date]').val(data.display_date_requested);
            container.find('input[name=omOrderBy]').val(data.ordered_by);
            container.find('input[name=omCstPONumber]').val(data.customer_po);
            container.find('input[name=omJobName]').val(data.job_name);
            container.find('input[name=omBuildingNumber]').val(data.building_number);
            container.find('input[name=omAptd]').val(data.apartment_description);
            container.find('input[name=omUnit]').val(data.unit_size_type);
            container.find('input[name=omDateMov]').val(data.move_in_date_display);
            //set check box value
            if (data.occupied_y_n == 'Y') {
                container.find('input[name=omOccupy][value=Y]').attr('checked', true);
            } else {
                container.find('input[name=omOccupy][value=N]').attr('checked', true);
            }
            //set check box value
            if (data.furnished_y_n == 'Y') {
                container.find('input[name=omFurnish][value=Y]').attr('checked', true);
            } else {
                container.find('input[name=omFurnish][value=N]').attr('checked', true);
            }
            container.find('input[name=omMoveIn]').val(data.who_will_move_in);
            container.find('input[name=omShipVia]').val(data.ship_via);
            container.find('input[name=omDtereqt]').val(data.display_date_requested);
            container.find('input[name=omSlmdNumber1]').val(data.salesperson_number);
        }
    });
})(jQuery);