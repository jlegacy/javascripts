(function ($) {
	$App.View("OrderStatus", {
		open: function (data) {
			var win = new Dancik_ConfirmWindow({
					color: "blue",
					buttons: {},
					showAsPopup: true,
					popupTitle: "Order Status Update",
					message: $App.Template("orderStatus/base.ejs").render(data),
					destroyOnClose: true,
					zIndexModal: 500,
					onClose: function (win) {
						if ($(win.o).find("form").hasClass("dirty")) {
							var c = new Dancik_ConfirmWindow({
								content: $M("unsavedChanges"),
								onConfirm: function () {
									win.close();
								},
								modal: true
							});
							c.open();
						} else {
							win.close();
						}
					},
					modal: true
				}),
				form, format, validation;
		
			form = $("#orderStatus_" + data.referenceid + "_" + data.orderid).closest("form");
			form.data("payload", {win: win, changed_lines: {}});
			$("#orderStatus_" + data.referenceid + "_" + data.orderid).closest(".orderStatus").css({
				width: 800 + "px",
				height: (Dancik.getDocumentHeight() - 100) + "px"
			});
			format = new FormFormatter(form[0]);
			validation = new Validation(form[0], {
				fieldNames: {
					shipdate: "Ship Date",
					orderdate: "Order Date",
					shipdate_all: "Update All Ship Date",
					orderdate_all: "Update All Order Date"
				}
			});
			
			form.delegate("span.dws-contextlink", "click", function (event) {
						//item right clicks
						var element = $(event.target),
							item = element.html(),
							rc;
						
						rc = new Dancik_RightClicks({ 
								dataKey: 'item',
								key: item
							}, 
							{ 
								style: {
									width:'175px', 
									zIndex:'15000'
								}
							}
						).open(element[0]);
					})
				.delegate("input[type='checkbox'].update_all", "change", function (event) {
						//disable detail inputs and enable mass update fields or vice versa
						//based on update all checkbox
						var box = $(event.target);
						form.find("input[name='shipdate'], input[name='orderdate'], input[name='status']").attr("disabled", box.attr("checked") ? "disabled" : null);
						form.find("input[name='shipdate_all'], input[name='orderdate_all'], input[name='status_all']").attr("disabled", box.attr("checked") ? null : "disabled");
					})
				.delegate("input[type='text']", "change", function (event) {
						//keep track of lines that are changed on the form so that we can send only the changed lines
						var input = $(event.target),
							row = input.closest("tr"),
							line = row.find("input[name='line']");
						
						form.addClass("dirty");
						
						if (line.length > 0) {
							//record lines that have changed
							//does not account for lines that are changed, then changed back to original value
							form.data("payload").changed_lines[line.val()] = true;
						}
					});
			
			win.open();
		},
		close: function (data) {
			form = $("#orderStatus_" + data.referenceid + "_" + data.orderid).closest("form");
			form.data("payload").win.close();
		},
		update: function (data) {

			var template = $App.Template("orderStatus/status.ejs"),
				html = template.render(data),
				orderid = data.header.orderid,
				referenceid = data.header.referenceid,
				status_all, shipdate_all, orderdate_all,
				container = $("#orderStatus_" + referenceid + "_" + orderid);
			//show the order lines
			container.html(html);
			
			//clear changed lines and dirty indicator
			container.closest("form")
				.removeClass("dirty")
				.data("payload").changed_lines = {};

			
			//create status drop downs
			container.find("input[type='text'].status").each(function (index, input) {
				Popup2Search.buildDropdown(input, { 
					title: 'Order Status', 
					file: 'orstat_o',
					descriptionElement: $(input).next(),
					omitIdInDescription: true,
					onSelect: function () {
						$(input).change();
					}
				});
			});
			var accountNum=data.header.accountid;
			if (accountNum.substring(2)== 00001){
				$("#orderDate").html("ETA Date");
			};
			//create date drop downs
			container.find("input.format-date2").each(function (index, input) {
				CalendarObject.buildDateWidget(input, {
					zIndex: 10000,
					onSelect: function () {
						$(input).change();
					}
				});
			});
		},
		process_flags: function (data) {
			var orderid = data.header.orderid,
				referenceid = data.header.referenceid,
				container = $("#orderStatus_" + referenceid + "_" + orderid);
			
			//show/hide notepad
			if (data.flags.flag_show_notepad) {
				container.closest(".orderStatus").find("a.notepad").show();
			} else {
				container.closest(".orderStatus").find("a.notepad").hide();
			}
		
		},
		busy: function (data, message) {
			$("#orderStatus_" + data.referenceid + "_" + data.orderid).closest(".orderStatus").dancikBusy({message: message});
		},
		unbusy: function (data) {
			$("#orderStatus_" + data.referenceid + "_" + data.orderid).closest(".orderStatus").dancikBusy("close");
		}
	});
})(jQuery);