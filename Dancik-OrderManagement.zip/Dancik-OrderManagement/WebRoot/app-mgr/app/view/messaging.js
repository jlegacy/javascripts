/*globals $App $M Dancik Dancik_ConfirmWindow */
$App.View('Messaging', {
	initialize: function () {
		this.errorWindows = [];
	},
	blanketMessage: function (message) {
		Dancik.Blanket.InProcess.show({
			message: message,
			sizeByStretch: true,
			zIndex: 10100
		});
	},
	errors: function (message, details, options) {
		var error_msg, wdw,
			_this = this,
			error_details = '';

		if (Object.isArray(message)) {
			details = message;
			message = null;
		}
		message = message || $M('global.errorGenericHeader');
		error_msg = '<div class="dws-form-error-title">' + message + '</div>';
		if (details) {
			error_details += '<ul class="dws-form-error-list">';
			details.each(function (detail) {
				error_details += '<li>- ' + detail + '</li>';
			});
			error_details += '</ul>';
		}
		//show the error popup

		options = Object.extend({
			contentHTML: error_msg,
			extraContentHTML: error_details,
			message: '',
			defaultAction: 'ok',
			buttons: {ok: 'OK'},
			color: 'red',
			modal: true,
			destroyOnClose: true,
			zIndexModal: 11000
		}, options);
		wdw = new Dancik_ConfirmWindow(options);
		_this.errorWindows.push(wdw);
		wdw.open();
	},
	info: function (message) {
		var
			_this = this,
			wdw = new Dancik_ConfirmWindow({
				contentHTML: message,
				message: '',
				defaultAction: 'ok',
				buttons: {ok: 'OK'},
				color: 'blue',
				modal: true,
				destroyOnClose: true,
				zIndexModal: 11000
			});
		wdw.open();
	},
	warn: function (message, details) {
		var error_msg, wdw,
			_this = this,
			warn_details = '';
		if (Object.isArray(message)) {
			details = message;
			message = null;
		}
		message = message || $M('global.warningGenericHeader');
		error_msg = '<div class="dws-form-error-title">' + message + '</div>';
		if (details) {
			warn_details += '<ul class="dws-form-error-list">';
			details.each(function (detail) {
				warn_details += '<li>- ' + detail + '</li>';
			});
			warn_details += '</ul>';
		}
		//show the popup
		wdw = new Dancik_ConfirmWindow({
			contentHTML: message,
			extraContentHTML: warn_details,
			message: '',
			defaultAction: 'ok',
			buttons: {ok: 'OK'},
			color: 'yellow',
			modal: true,
			destroyOnClose: true,
			zIndexModal: 11000
		});
		wdw.open();
	},
	confirmation: function (message, details, callback) {
		var wdw,
			_this = this;
		if (Object.isArray(message)) {
			details = message;
			message = null;
		}
		details = details || $M('global.confirmDefaultMsg');
		wdw = new Dancik_ConfirmWindow({
			contentHTML: message,
			extraContentHTML: details,
			message: '',
			color: 'yellow',
			onConfirm: function () {
				callback(true);
			},
			onNo: function () {
				callback(false);
			},
			onClose: function () {
				callback(false);
			},
			modal: true,
			destroyOnClose: true,
			zIndexModal: 11000
		});
		wdw.open();
	},
	clearAll: function () {
		var _this = this;
		_this.clearBlanket();
		_this.clearErrors();
	},
	clearBlanket: function () {
		Dancik.Blanket.InProcess.kill();
	},
	clearErrors: function () {
		var _this = this;
		_this.errorWindows.each(function (errwdw) {
			try {
				errwdw.close();
			} catch (e) {
				//don't care
			}
		});
		_this.errorWindows = [];
	}
});
