/*global $App jQuery Element OptionsDropdown TabSet Dancik*/
(function ($) {
	$App.View('Application', {
		initialize: function () {
		
	}
		//renders the initial application layout
		
	});
})(jQuery);
