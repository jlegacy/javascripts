(function ($) {
	$App.View("purchasing", {
		//--------------------------------------------------------
		// open the dialog window and populate with html
		//--------------------------------------------------------
		purchasing_rules_init: function (data) {

			var container, code, template, idElement, description;
			template = $App.Template('purchasing/base.ejs');
			container = $(template.render());

			container.dialog({
				title: 'Purchasing Rules Table',
				height: 120,
				width: 317,
				modal: 'false',
				dialogClass: 'dancik-dialog',
				open: function () {
					//remove button css to match accounting button standards
					$('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
					//prevent ui-state-hover form formatting buttons
					$('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
					$('.ui-dialog-buttonpane').find('button').hover(function () {
						$(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
					});

				},
				close: function () {
					$(this).remove();
				},
				buttons: {
					Submit: function () {
						code = $App.Utils.getRulesDescriptionCode($j('#rules_table_group').find('[name = "rules_record_description"]').val());
						$j('#rules_table_group').find('[name = "recordType"]').val(code);
						$(this).submit();
					}
				}

			});

			idElement = $j('#rules_table_group').find('[name = "recordType"]');
			description = $j('#rules_table_group').find('[name = "rules_record_description"]');

			$App.Utils.dropdown_purchasing_rules_types(container.find('input[name=rules_record_description]'), {
				appendTo: document.body,
				hideId: true,
				idElement: idElement,
				descriptionElement: description
			});
		},
		purchasing_reorder_calc_init: function (config, data) {
			var container, template, _this;
			template = $App.Template('purchasing/reorder_calc_dialog.ejs');
			container = $(template.render());

			_this = this;

			container.dialog({
				title: 'Suggested Reorder Calculator',
				height: 190,
				width: 500,
				resizeable: 'false',
				modal: 'true',
				dialogClass: 'dancik-dialog reorder-calculator-class',
				open: function () {
					$j('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
					//prevent ui-state-hover form formatting buttons
					$j('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
					$j('.ui-dialog-buttonpane').find('button').hover(function () {
						$(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
					});
					$j('.ui-dialog-buttonpane').find('button').focus(function () {
						$(this).removeClass('ui-state-active ui-state-focus ui-state-hover');
					});
				},
				close: function () {
					$(this).remove();
				},
				buttons: {
					Submit: function () {
						_this.setupReorderCalcParms(config, data);
						$(this).submit();
					}
				}

			});

			_this.decorateInitReorderCalcDialog(container, data, config);

			$("#submit_reorder_calc_table").keypress(function (e) {
				if (e.which === 13) {
					_this.setupReorderCalcParms(config, data);
					$(this).submit();
				}

			});

			//set up field validation/formatting//

			var rif = new RestrictedInputForm('submit_reorder_calc_table');
			var frm = new FormFormatter('submit_reorder_calc_table');
			new Validation('submit_reorder_calc_table', {
				onValidSubmit: function (event) {
					event.stop();
				},
				fieldNames: {
					parm_reorder_calc_from_date_MDY: "Reorder Calc From Date",
					parm_reorder_calc_to_date_MDY: "Reorder Calc To Date",
					in_growth: "Growth Factor"
				}
			});

		},
		setupReorderCalcParms: function (config, data) {
			var isoDate;

			//Set hidden fields in form//
			isoDate = $App.Utils.cvtDateIso($j('#submit_reorder_calc_table').find('[name=parm_reorder_calc_from_date_MDY]').val());
			$j('#submit_reorder_calc_table').find('[name=in_fromdate]').val(isoDate);
			//  $j('#submit_reorder_calc_table').find('[name=in_fromdate]').val($j('#submit_reorder_calc_table').find('[name=parm_reorder_calc_from_date_MDY]').val());

			isoDate = $App.Utils.cvtDateIso($j('#submit_reorder_calc_table').find('[name=parm_reorder_calc_to_date_MDY]').val());
			$j('#submit_reorder_calc_table').find('[name=in_todate]').val(isoDate);
			//    $j('#submit_reorder_calc_table').find('[name=in_todate]').val($j('#submit_reorder_calc_table').find('[name=parm_reorder_calc_to_date_MDY]').val());

			$j('#submit_reorder_calc_table').find('[name=in_user]').val(config.user.user);
			$j('#submit_reorder_calc_table').find('[name=in_company]').val($j('#Mgr_FilterSection').find('#parm_FilterCompany').val());
		},
		decorateInitReorderCalcDialog: function (container, data, config) {

			var curr_date, curr_dd, curr_mm, curr_ccyy, curr_mdy_date;
			var prev_date, prev_dd, prev_mm, prev_ccyy, prev_mdy_date;

			//   $App.Utils.dropdown_item(container.find('input[name=in_item]'), {
			//     appendTo: document.body
			//  });

			$App.Utils.dropdown_warehouse(container.find('input[name=in_warehouse]'), {
				appendTo: document.body
			});

			//get one day prior to today//
			curr_date = new Date();
			curr_date.setDate(curr_date.getDate() - 1);

			curr_dd = (curr_date.getDate());
			curr_mm = curr_date.getMonth() + 1; //January is 0!
			curr_ccyy = curr_date.getFullYear();

			//get one day prior to today//
			prev_date = new Date();
			prev_date.setDate(prev_date.getDate());
			prev_date.setMonth(prev_date.getMonth() - 6);

			prev_dd = (prev_date.getDate());
			prev_mm = prev_date.getMonth() + 1; //January is 0!
			prev_ccyy = prev_date.getFullYear();

			curr_mdy_date = ($App.Utils.pad3(curr_mm)) + '/' + $App.Utils.pad3(curr_dd) + '/' + (curr_ccyy % 100);
			prev_mdy_date = ($App.Utils.pad3(prev_mm)) + '/' + $App.Utils.pad3(prev_dd) + '/' + (prev_ccyy % 100);

			//test//
			//    container.find('input[name=in_item]').val('ABCJSG1');

			container.find('input[name=in_warehouse]').val(config.user.dft_Warehouse);

			container.find('input[name=parm_reorder_calc_from_date_MDY]').val(prev_mdy_date);
			container.find('input[name=parm_reorder_calc_to_date_MDY]').val(curr_mdy_date);

		},
		no_purchasing_rules: function (data, results, config) {
			var html;
			var resultsContainer;

			resultsContainer = $j('#Mgr_SearchRulesFileData');

			html = "<tr><td class='purhasing_no_records'>No records matched your search criteria.</td></tr>";

			resultsContainer.html(html);

			$j('#Mgr_RulesFileQuerySize').html(0 + " of " + 0);

		},
		get_purchasing_rules: function (data, results, config) {
			var template, html, _this, purchasingContainer;

			_this = this;
			purchasingContainer = _this.get_purchasing_container();


			//close dialog if open//
			$j('#submit_rules_table').dialog('close');

			$j('#Main_Canvas').hide();
			$j('#po_options').hide();

			purchasingContainer = $j('#PO_Canvas');
			template = $App.Template('purchasing/rules_details.ejs');
			html = template.render(results);
			purchasingContainer.html(html);

			_this.decorate_rule_file_results(results, config, data);
		},
		get_purchasing_rules_more: function (data, results, config) {
			var template, html, _this, purchasingContainer, lastRecId, n, numId, summary_inline, rowContainer,
				link;

			_this = this;

			//get last record number in table//
			lastRecId = $j("[id^=results_detail-]:last").attr('id');
			n = lastRecId.split("-");
			numId = parseInt(n[1]) + 1;

			//pass new starting record number to ejs//
			$.extend(results, {
				startNumber: numId
			});

			purchasingContainer = $j('#Mgr_SearchRulesFileData_TBODY');
			template = $App.Template('purchasing/rules_details_more.ejs');
			html = template.render(results);
			purchasingContainer.append(html);

			//append inline actions to new details//

			summary_inline = $App.Template('purchasing/inline_actions.ejs');

			rowContainer = $j('#Mgr_SearchRulesFileData').find('td.line-actions.raw');

			$j.each(rowContainer, function (x, y) {
				counterObject = {
					rowNumber: numId++
				};

				$j(this).removeClass('raw');

				$j(this).append(summary_inline.render(counterObject));
				//attach payload to each href for future use//
				link = $j(this).find('a:first');
				link.data('payload', {
					recordtype: results.records[x].recordtype,
					minorder_um: results.records[x].minorder_um,
					maxorder_qty: results.records[x].maxorder_qty,
					orderinmulti_um: results.records[x].orderinmulti_um,
					recordkey: results.records[x].recordkey,
					minorder_qty: results.records[x].minorder_qty,
					orderinmulti_qty: results.records[x].orderinmulti_qty,
					maxorder_um: results.records[x].maxorder_um,
					row: (numId - 1)
				});

			});

			_this.handleResultDataDecoration(results);

		},
		get_reorder_calcs: function (data, results, config) {
			var template, html, _this, purchasingContainer, reorderFilterSection;

			_this = this;
			purchasingContainer = _this.get_purchasing_container();

			//close dialog if open//
			$j('#submit_reorder_calc_table').dialog('close');
			$j('#PO_Canvas').show();
			$j('#Main_Canvas').hide();
			$j('#po_options').hide();

			purchasingContainer = $j('#PO_Canvas');
			template = $App.Template('purchasing/reorder_calc_page_static.ejs');
			html = template.render(results);
			purchasingContainer.html(html);

			_this.decorate_reorder_calc_static(results, config, data);

			_this.decorate_reorder_calc_details(results, config, data);

			// Set input fields with initial values //
			reorderFilterSection = $j('#Mgr_ReorderFilterSection');
			reorderFilterSection.find('[name=parm_FilterDateReorder_From_MDY]').val(data.parm_reorder_calc_from_date_MDY);
			reorderFilterSection.find('[name=parm_FilterDateReorder_To_MDY]').val(data.parm_reorder_calc_to_date_MDY);
			reorderFilterSection.find('[name=in_warehouse]').val(data.in_warehouse);
			reorderFilterSection.find('[name=in_unitofmeasure]').val(data.in_unitofmeasure);
			reorderFilterSection.find('[name=parm_FilterDateReorder_From_CYMD]').val(data.in_fromdate);
			reorderFilterSection.find('[name=parm_FilterDateReorder_To_CYMD]').val(data.in_todate);
		},
		get_purchasing_container: function () {
			var container;
			container = $j('#PO_Canvas');
			return container;
		},
		get_dialog_container: function () {
			var container;
			container = $j('#submit_reorder_calc_table');
			return container;
		},
		get_main_container: function () {
			var container;
			container = $j('#Main_Canvas');
			return container;
		},
		get_po_container: function () {
			var container;
			container = $j('#PO_Canvas');
			return container;
		},
		decorate_rule_file_results: function (results, config, data) {
			// append inline actions //

			var accessLevel = 0, recordType, recordKey, description, recordDescription, code;

			var rowContainer, summary_inline, _this, link, detailsContainer, headerContainer, counterObject,
				idElement, ruleFileSection;

			_this = this;

			ruleFileSection = $j('#Mgr_GotoRulesFileSection');

			summary_inline = $App.Template('purchasing/inline_actions.ejs');

			detailsContainer = $j('#Mgr_SearchRulesFileData');
			headerContainer = $j('#Mgr_SearchRulesFileHeaders');
			rowContainer = $j('#Mgr_SearchRulesFileData').find('td.line-actions');

			$j.each(rowContainer, function (x, y) {
				counterObject = {
					rowNumber: x
				};

				$j(this).append(summary_inline.render(counterObject));
				//attach payload to each href for future use//
				link = $j(this).find('a:first');
				link.data('payload', {
					recordtype: results.records[x].recordtype,
					minorder_um: results.records[x].minorder_um,
					maxorder_qty: results.records[x].maxorder_qty,
					orderinmulti_um: results.records[x].orderinmulti_um,
					recordkey: results.records[x].recordkey,
					minorder_qty: results.records[x].minorder_qty,
					orderinmulti_qty: results.records[x].orderinmulti_qty,
					maxorder_um: results.records[x].maxorder_um,
					row: x
				});

			});

			_this.handleResultDataDecoration(results);

			idElement = ruleFileSection.find('#rules_table_group2').find('[name = "recordType"]');
			description = ruleFileSection.find('#rules_table_group2').find('[name = "rules_record_description"]');

			//dropdown filter type//
			$App.Utils.dropdown_purchasing_rules_types(ruleFileSection.find('input[name=rules_record_description]'), {
				appendTo: document.body,
				hideId: true,
				idElement: idElement,
				descriptionElement: description
			});

			//set hidden field with record type every time screen is redisplayed
			ruleFileSection.find('#rules_table_group2').find('[name = "recordType"]').val(data.recordType);

			$j('#purchasing-rules-table-go-button').off();
			$j('#purchasing-rules-table-go-button').on('click', function () {

				code = $App.Utils.getRulesDescriptionCode($j('#rules_table_group2').find('[name = "rules_record_description"]').val());
				$j('#rules_table_group2').find('[name = "recordType"]').val(code);

				//   rules-record-type
				recordType = ruleFileSection.find('#rules_table_group2').find('[name = "recordType"]').val();
				recordKey = ruleFileSection.find('#rules-position').val();
				recordDescription = ruleFileSection.find('#rules_table_group2').find('[name = "rules_record_description"]').val();

				var data = {
					recordType: recordType,
					recordKey: recordKey,
					rules_record_description: recordDescription

				};
				$App.Fire('get_purchasing_rules_filter', data);
			});

			accessLevel = 0;
			$j.each(config.security, function (j, item) {
				for (var i = 0; i < item.items.length; i++)
				{
					if (item.items[i].name === 'Purchasing Rules Table')
					{
						accessLevel = (item.items[i].access);
						return false;
					}

				}

			});

			// if user does not have update/mass update capabilities hide update stuff//

			if ((accessLevel !== 2) && (accessLevel !== 3))
			{
				headerContainer.find('#insert_rules_shortcut').addClass('hide');
				detailsContainer.find('.line-actions').addClass('hide');
			}

			description = $App.Utils.getRulesDescription(data.recordType);

			headerContainer.find('#price_class_rules').html(description);
			//set record key dropdown to what was passed//
			$j('#rules-record-type').val(data.rules_record_description);

		},
		decorate_reorder_calc_details: function (results, config, data) {

			var detailContainer, template, html;

			detailContainer = $j('#ReorderCalculator_SearchResults');
			template = $App.Template('purchasing/reorder_calc_page_details.ejs');
			html = template.render(results);
			detailContainer.html(html);

			//set discontinued message//
			//depending on item//
			//look for any word characters//

			//	if (!(/^\s/).test(results.reorderquantity[0].discontinuedmessage))
			if (results.reorderquantity[0].discontinuedmessage > "") {
				var text = {};
				//text.message = 'Item is discontinued! (See discontinue date in the item file.) You can not order this item anymore!';
				text.message = 'Item is discontinued, please see Discontinue Date in the Item file.';
				$App.Fire('warn_message', text);

			}


		},
		purchasing_discontinued_popup: function () {


		},
		decorate_reorder_calc_static: function (results, config, data) {

			var reorderFilterSection, reorderFilterSectionInfo, reorderFooterButtons, reorderStockMessageContainer, submitContainer, availableOptions3, links, reorderFooterOptions;
			var _this, idElement, description, params, payload, form, container;

			_this = this;

			submitContainer = $j('#suggested_reorder_calculator_form_submit');
			availableOptions3 = $j('#available-options-container3');

			reorderFilterSection = $j('#Mgr_ReorderFilterSection');
			reorderFilterSectionInfo = $j('#Mgr_ReorderCalculatorFileSectionInfo');

			reorderFooterOptions = $j('#Reorder_Calculator_Footer_Options');


			reorderFooterButtons = $j('#Reorder_Calculator_Footer_Buttons');
			reorderStockMessageContainer = $j('#Reorder_Calculator_Stock_Message');

			//  $App.Utils.dropdown_item(reorderFilterSectionInfo.find('input[name=in_item]'), {
			//      appendTo: document.body
			//  });

			idElement = reorderFooterButtons.find('[name = "in_scrollDirecionCode"]');
			description = reorderFooterButtons.find('[name = "in_scrollDirecionText"]');
			$App.Utils.dropdown_scrollDirection(reorderFooterButtons.find('input[name=in_scrollDirecionText]'), {
				appendTo: document.body,
				hideId: true,
				idElement: idElement,
				descriptionElement: description
			});

			$App.Utils.dropdown_warehouse(reorderFilterSection.find('input[name=in_warehouse]'), {
				appendTo: document.body
			});

			// populate static fields //
			_this.populateStaticFields(results);

			// set hidden fields//
			reorderFilterSectionInfo.find('[name=hidden_company]').val(data.in_company);
			reorderFilterSectionInfo.find('[name=hidden_user]').val(data.in_user);

			//setup clicks on divs//
			reorderFooterButtons.find('#id-prev-pos').off();
			reorderFooterButtons.find('#id-prev-pos').on('click', function () {
				_this.setPrevSubmit(data);
			});

			reorderFooterButtons.find('#id-next-pos').off();
			reorderFooterButtons.find('#id-next-pos').on('click', function () {
				_this.setNextSubmit(data);
			});

			// set default scroll direction
			reorderFooterButtons.find('[name = "in_scrollDirecionText"]').val('ITEM');

			submitContainer.find('#submitReorderCalcs').off();
			submitContainer.find('#submitReorderCalcs').on('click', function () {
				params = _this.scrapeScreenValues();

				//get form results payload//
				payload = _this.getPurchasingFormTotalsPayload();
				$.extend(params, {
					pdata: payload
				});

				$App.Fire('get_reorder_calcs_submit', params);
			});

			//    //Set up Clicks on PO Available Options//
			availableOptions3.find('.dws-options-handle').off();
			availableOptions3.find('.dws-options-handle').on('click', function () {
				availableOptions3.toggleClass('dws-options-open');
				links = availableOptions3.find('a');
				//Dynamically remove menu if no options//
				if (links.length === 0)
				{
					availableOptions3.removeClass('dws-options-open');
				}
			});

			//Set up Clicks on PO Available Options//
			availableOptions3.find('.dws-options-title').off();
			availableOptions3.find('.dws-options-title').on('click', function () {
				availableOptions3.toggleClass('dws-options-open');
				links = availableOptions3.find('a');
				//Dynamically remove menu if no options//
				if (links.length === 0)
				{
					availableOptions3.removeClass('dws-options-open');
				}
			});

			$j('body').click(function (event) {
				if (!$j(event.target).closest('#available-options-container3').length) {
					$j('#available-options-container3').removeClass('dws-options-open');
				}
			});

			//check for links//
			links = $j('#available-options-container3').find('a');
			$j.each(links, function () {
				$j(this).on('click', function () {
					$j('#available-options-container3').removeClass('dws-options-open');
					$j(this).attr('href');
					switch ($j(this).attr('href')) {
						//call create new PO//
						case '#option-1':
							$App.Fire("purchasing_reorder_calc_init", {});
							//      Main.Orders.createAltOrder('po');
							break;
						case '#option-2':
							$App.Fire("purchasing_rules_init", {});
							//      Main.Orders.createAltOrder('po');
							break;
						default:
							break;
					}

				});
			});

			//redisplay main search display//
			reorderFooterOptions.find('#reorder_return_main_image_id').off();
			reorderFooterOptions.find('#reorder_return_main_image_id').on('click', function () {
				$j('#PO_Canvas').hide();
				$j('#Main_Canvas').show();
				$j('#po_options').show();
			});

			reorderFooterOptions.find('#reorder_return_main_id').off();
			reorderFooterOptions.find('#reorder_return_main_id').on('click', function () {
				$j('#PO_Canvas').hide();
				$j('#Main_Canvas').show();
				$j('#po_options').show();
			});

			reorderFilterSection.find(".dws-mouseover1").off();

			//Setup Hovers//
			reorderFilterSection.find(".dws-mouseover1").hover(
				function () {
					$(this).find('.Mgr_Filter_Clear').find('img:first').show();
				},
				function () {
					$(this).find('.Mgr_Filter_Clear').find('img:first').hide();
				}
			);

			//Setup Clear Clicks//
			reorderFilterSection.find(".Mgr_Filter_Clear").on('click', function () {
				$(this).prev('td').find('input').val('');
				$(this).prev('td').find('span.company-name').html('');
			});

			//Setup Submit Button//
			submitContainer.find('#clearAll').off();
			submitContainer.find('#clearAll').on('click', function () {
				reorderFilterSection.find('input[type=text]:visible').val('');

				//clear company name text
				reorderFilterSection.find('span.company-name').html('');

				//clear hidden fields//
				reorderFilterSection.find('[name=parm_FilterDateReorder_From_CYMD]').val('');
				reorderFilterSection.find('[name=parm_FilterDateReorder_To_CYMD]').val('');
				reorderFilterSection.find('[name=parm_FilterDateBackorder_CYMD]').val('');
			});

			// if user keys in date fields//
			reorderFilterSection.find('#parm_FilterDateReorder_To_MDY').off();
			reorderFilterSection.find('#parm_FilterDateReorder_To_MDY').on('blur', function () {
				reorderFilterSection.find('[name=parm_FilterDateReorder_To_CYMD]').val($App.Utils.cvtDateIso($j(this).val()));
			});

			reorderFilterSection.find('#parm_FilterDateReorder_From_MDY').off();
			reorderFilterSection.find('#parm_FilterDateReorder_From_MDY').on('blur', function () {
				reorderFilterSection.find('[name=parm_FilterDateReorder_From_CYMD]').val($App.Utils.cvtDateIso($j(this).val()));
			});

			reorderFilterSection.find('#parm_FilterDateBackorder_MDY').off();
			reorderFilterSection.find('#parm_FilterDateBackorder_MDY').on('blur', function () {
				reorderFilterSection.find('[name=parm_FilterDateBackorder_CYMD]').val($App.Utils.cvtDateIso($j(this).val()));
			});

			//set up date formatter//
			var rif = new RestrictedInputForm('set_reorder_calc_filters');
			var frm = new FormFormatter('set_reorder_calc_filters');
			new Validation('set_reorder_calc_filters', {
				onValidSubmit: function (event) {
					event.stop();
				},
				fieldNames: {
					parm_FilterDateReorder_From_MDY: "Reorder Calc From Date",
					parm_FilterDateReorder_From_CYMD: "Reorder Calc To Date"
				}
			});


		},
		getPurchasingFormTotalsPayload: function () {
			var container, form, test, _this;
			_this = this;
			form = $j('#set_reorder_calc_filters');
			test = form.data('payload');
			return test.pdata;
		},
		populateStaticFields: function (results) {
			var reorderFilterSectionInfo, reorderStockMessageContainer, reorderFilterSection, form;

			reorderFilterSection = $j('#Mgr_ReorderFilterSection');
			reorderFilterSectionInfo = $j('#Mgr_ReorderCalculatorFileSectionInfo');
			reorderStockMessageContainer = $j('#Reorder_Calculator_Stock_Message');

			reorderFilterSectionInfo.find('[name=in_description1]').html(results.reorderquantity[0].itemdescription);
			reorderFilterSectionInfo.find('[name=in_description2]').html(results.reorderquantity[0].itemdescription2);

			reorderFilterSectionInfo.find('[name=in_supplier]').html(results.reorderquantity[0].suppliercode);
			reorderFilterSectionInfo.find('[name=in_ABC_Code]').html(results.reorderquantity[0].abccode);
			reorderStockMessageContainer.find('[name=in_stockMessages]').html(results.reorderquantity[0].stockoutmessage);
			reorderFilterSectionInfo.find('[name=in_item]').val(results.reorderquantity[0].item);
			reorderFilterSectionInfo.find('[name=in_unitofmeasure]').html(results.reorderquantity[0].unitofmeasure);

			reorderFilterSectionInfo.find('#id_non-stocked').hide();
			if (results.reorderquantity[0].nonstock === 'Y')
			{
				reorderFilterSectionInfo.find('#id_non-stocked').show();
			}

			//save p-data to form//
			form = $j('#set_reorder_calc_filters');
			form.data('payload', {
				pdata: results.reorderquantity[0].pdata
			});
		},
		setPrevSubmit: function (data) {
			var params, _this, payload;
			_this = this;

			var reorderFooterButtons = $j('#Reorder_Calculator_Footer_Buttons');

			params = _this.scrapeScreenValues();

			switch ((reorderFooterButtons.find('input[name=in_scrollDirecionText]').val().toUpperCase()))
			{
				case 'ITEM':
					params.in_previtem = 'Y';
					params.in_nextitem = 'N';
					params.in_previdsc = 'N';
					params.in_nextidsc = 'N';
					break;

				case 'DESCRIPTION':
					params.in_previtem = 'N';
					params.in_nextitem = 'N';
					params.in_previdsc = 'Y';
					params.in_nextidsc = 'N';
					break;

				default:
					params.in_previtem = 'N';
					params.in_nextitem = 'N';
					params.in_previdsc = 'N';
					params.in_nextidsc = 'N';
					break;
			}

			//get form results payload//
			payload = _this.getPurchasingFormTotalsPayload();
			$.extend(params, {pdata: payload});

			$App.Fire('get_purchasing_reorder_info', params);

		},
		setNextSubmit: function (data) {
			var params, _this, payload;
			_this = this;
			var reorderFooterButtons = $j('#Reorder_Calculator_Footer_Buttons');

			params = _this.scrapeScreenValues();

			switch ((reorderFooterButtons.find('input[name=in_scrollDirecionText]').val().toUpperCase()))
			{
				case 'ITEM':
					params.in_previtem = 'N';
					params.in_nextitem = 'Y';
					params.in_previdsc = 'N';
					params.in_nextidsc = 'N';
					break;

				case 'DESCRIPTION':
					params.in_previtem = 'N';
					params.in_nextitem = 'N';
					params.in_previdsc = 'N';
					params.in_nextidsc = 'Y';
					break;

				default:
					params.in_previtem = 'N';
					params.in_nextitem = 'N';
					params.in_previdsc = 'N';
					params.in_nextidsc = 'N';
					break;
			}

			//get form results payload//
			payload = _this.getPurchasingFormTotalsPayload();
			$.extend(params, {pdata: payload});

			$App.Fire('get_purchasing_reorder_info', params);
		},
		scrapeScreenValues: function () {
			var params = {};
			var reorderFilterSection, reorderFilterSectionInfo, reorderFooterButtons;

			reorderFilterSection = $j('#Mgr_ReorderFilterSection');
			reorderFilterSectionInfo = $j('#Mgr_ReorderCalculatorFileSectionInfo');
			reorderFooterButtons = $j('#Reorder_Calculator_Footer_Buttons');

			reorderFooterButtons.find('input[name=in_scrollDirecionText]').val();

			params = {
				in_user: reorderFilterSectionInfo.find('[name=hidden_user]').val(),
				in_company: reorderFilterSectionInfo.find('[name=hidden_company]').val(),
				in_item: reorderFilterSectionInfo.find('[name=in_item]').val(),
				in_warehouse: reorderFilterSection.find('input[name=in_warehouse]').val(),
				in_unitofmeasure: reorderFilterSection.find('input[name=in_unitofmeasure]').val(),
				in_fromdate: reorderFilterSection.find('input[name=parm_FilterDateReorder_From_CYMD]').val(),
				in_todate: reorderFilterSection.find('input[name=parm_FilterDateReorder_To_CYMD]').val(),
				in_growth: reorderFilterSection.find('input[name=in_growth]').val(),
				in_matrix: reorderFilterSection.find('#id_stocking_matrix_Y').is(':checked') ? 'Y' : 'N',
				in_rems: reorderFilterSection.find('#id_omit_remnants_Y').is(':checked') ? 'Y' : 'N',
				in_bodate: reorderFilterSection.find('input[name=parm_FilterDateBackorder_CYMD]').val(),
				in_fillbo: reorderFilterSection.find('#id_fill_back_Y').is(':checked') ? 'Y' : 'N',
				in_activity: reorderFilterSection.find('#id_view_sales').is(':checked') ? 'S' : 'A'
			};

			return params;
		},
		get_purchasing_reorder_info: function (data, results, config) {
			var _this, form, test;
			_this = this;

			// populate detail fields //
			_this.decorate_reorder_calc_details(results, config, data);

			// update static fields //
			_this.populateStaticFields(results);

		},
		handleResultDataDecoration: function (results) {
			var _this, fileDataContainer, lastRecId, rowCount, param,
				rowId, rowNumber, payLoadRow, fileHeaderContainer, n, numId, ruleFileSection, fileFooterContainer;

			_this = this;

			ruleFileSection = $j('#Mgr_GotoRulesFileSection');

			fileDataContainer = $j('#Mgr_SearchRulesFileData');
			fileHeaderContainer = $j('#Mgr_SearchRulesFileHeaders');
			fileFooterContainer = $j('#Purchase_Rules_Footer_Options');

			//add inline menu functionality to deposit summary row
			$j('#Mgr_SearchRulesFileData').off();
			$j('#Mgr_SearchRulesFileData').delegate('a.inline-menu', 'click', _this.inlineActionOpen);

			//add click to inline menus//
			fileDataContainer.find('.update_rules_record').off();
			fileDataContainer.find('.update_rules_record').on('click', function () {
				//retrieve payload based on shared row number//
				rowId = $j(this).attr('id').split('-');
				rowNumber = rowId[1];
				payLoadRow = $j('#update_row-' + rowNumber);
				$App.Fire('purchasing_rules_screen_edit', payLoadRow.data('payload'));
			});

			//add click to inline menus//
			fileDataContainer.find('.insert_rules_record').off();
			fileDataContainer.find('.insert_rules_record').on('click', function () {
				var param = {
					recordType: results.records[0].recordtype
				};
				$App.Fire('purchasing_rules_screen_insert', param);
			});

			//add click to inline menus//
			fileDataContainer.find('.delete_rules_record').off();
			fileDataContainer.find('.delete_rules_record').on('click', function () {
				//retrieve payload based on shared row number//
				rowId = $j(this).attr('id').split('-');
				rowNumber = rowId[1];
				payLoadRow = $j('#update_row-' + rowNumber);
				$App.Fire('purchasing_rules_screen_delete', payLoadRow.data('payload'));
			});

			//add click to inline menus//
			fileHeaderContainer.find('#insert_rules_shortcut').off();
			fileHeaderContainer.find('#insert_rules_shortcut').on('click', function () {
				var param = {
					recordType: ruleFileSection.find('#rules_table_group2').find('[name = "recordType"]').val()
				};
				$App.Fire('purchasing_rules_screen_insert', param);
			});

			rowCount = fileDataContainer.find("[id^=results_detail-]").length;

			$j('#Mgr_RulesFileQuerySize').html(rowCount + " of " + results.info.querysize);

			lastRecId = $j("[id^=results_detail-]:last").attr('id');
			n = lastRecId.split("-");
			numId = parseInt(n[1]) + 1;


			$j('#Mgr_RulesFileMoreBttn').hide();
			if (numId < results.info.querysize) {
				$j('#Mgr_RulesFileMoreBttn').show();
			}

			//Set up More Clicks//
			$j('#Mgr_RulesFileMoreBttn').off();
			$j('#Mgr_RulesFileMoreBttn').on('click', function () {

				var data = {
					startingrec: results.records.length,
					recordType: results.records[0].recordtype
				};

				$App.Fire("get_purchasing_rules_more", data);
			});

			//reset canvas//
			$j('#PO_Canvas').show();
			$j('#Main_Canvas').hide();
			$j('#po_options').hide();

			//redisplay main search display//
			fileFooterContainer.find('#return_main_image_id').off();
			fileFooterContainer.find('#return_main_image_id').on('click', function () {
				$j('#PO_Canvas').hide();
				$j('#Main_Canvas').show();
				$j('#po_options').show();
			});

			fileFooterContainer.find('#return_main_id').off();
			fileFooterContainer.find('#return_main_id').on('click', function () {
				$j('#PO_Canvas').hide();
				$j('#Main_Canvas').show();
				$j('#po_options').show();
			});

		},
		//------------------------------------------
		// opens the inline menu for deposit summary
		// Note: this works in comjunction with CSS 
		//------------------------------------------
		inlineActionOpen: function (event) {

			var _this = this, menu_top, menu_bottom, container_top, container_bottom,
				menu_ul, hideFun,
				row = $j(event.currentTarget).closest('tr'),
				container = row.closest('tbody').closest('div'),
				menu_div = $j(event.currentTarget).closest('td.line-actions div.inline-actions');

			//get menu ul container
			menu_ul = menu_div.find('ul');

			event.preventDefault();

			//adds open class to div.inline-actions on selected row
			menu_div.addClass('open'); //IE7 z-index fix

			//show menu
			menu_ul.show();

			menu_top = menu_ul.offset().top;
			menu_bottom = menu_top + menu_ul.outerHeight();
			container_top = container.offset().top;
			container_bottom = container_top + container.innerHeight();

			//if menu extends above div
			if (menu_bottom > container_bottom) {
				menu_ul.addClass('up').removeClass('down');
			}
			//if menu extends below div
			if (menu_top < container_top) {
				menu_ul.addClass('down').removeClass('up');
			}

			hideFun = function () {
				menu_ul
					.hide()
					.removeClass('up')
					.removeClass('down');
				menu_div
					.removeClass('open'); //IE7 z-index fix
			};
			setTimeout(function () {
				$(document).one('click', hideFun);
			}, 0);
		},
		purchasing_rules_screen_edit: function (data) {
			var template;
			var container;
			var enteredData;
			var description;
			var containerSearchRuleHeaders;

			//get record//
			template = $App.Template('purchasing/edit_rules_file.ejs');

			container = $j(template.render(data));
			containerSearchRuleHeaders = $j('#Mgr_SearchRulesFileHeaders');

			container.dialog({
				title: 'Edit Purchasing Rules',
				height: 175,
				width: 690,
				modal: 'true',
				dialogClass: 'dancik-dialog',
				open: function () {
					//remove button css to match accounting button standards
					$j('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
					//prevent ui-state-hover form formatting buttons
					$j('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
					$j('.ui-dialog-buttonpane').find('button').hover(function () {
						$(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
					});
				},
				close: function () {
					$j(this).remove();
				},
				buttons: {
					'Continue': function () {

						//show processing modal//

						enteredData = {};

						//save entered data//
						enteredData.recordkey = container.find('input[name=recordkey]').val();
						enteredData.maxorder_qty = container.find('input[name=maxorder_qty]').val();
						enteredData.maxorder_um = container.find('input[name=maxorder_um]').val();
						enteredData.minorder_qty = container.find('input[name=minorder_qty]').val();
						enteredData.minorder_um = container.find('input[name=minorder_um]').val();
						enteredData.orderinmulti_qty = container.find('input[name=orderinmulti_qty]').val();
						enteredData.orderinmulti_um = container.find('input[name=orderinmulti_um]').val();
						enteredData.recordtype = container.find('input[name=recordtype]').val();
						enteredData.row = data.row;

						$App.Fire("purchasing_rules_file_update", enteredData);

					}
				}

			});


			$App.Utils.dropdown_uom_all(container.find('input[name=minorder_um]'),
				{
					appendTo: document.body
				});

			$App.Utils.dropdown_uom_all(container.find('input[name=maxorder_um]'),
				{
					appendTo: document.body
				});

			$App.Utils.dropdown_uom_all(container.find('input[name=orderinmulti_um]'),
				{
					appendTo: document.body
				});


			description = $App.Utils.getRulesDescription(data.recordtype);
			container.find('#col-1').find('.mgr-col-recordkey').html(description);

		},
		purchasing_rules_screen_delete: function (data) {
			var template;
			var container;
			var description;

			//get record//
			template = $App.Template('purchasing/delete_rules_file.ejs');

			container = $j(template.render(data));

			container.dialog({
				title: 'Delete Purchasing Rules',
				height: 175,
				width: 690,
				modal: 'true',
				dialogClass: 'dancik-dialog',
				open: function () {
					//remove button css to match accounting button standards
					$j('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
					//prevent ui-state-hover form formatting buttons
					$j('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
					$j('.ui-dialog-buttonpane').find('button').hover(function () {
						$(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
					});
				},
				close: function () {
					$j(this).remove();
				},
				buttons: {
					'Continue': function () {

						enteredData = {};

						//save entered data//
						enteredData.recordkey = container.find('input[name=recordkey]').val();
						enteredData.maxorder_qty = container.find('input[name=maxorder_qty]').val();
						enteredData.maxorder_um = container.find('input[name=maxorder_um]').val();
						enteredData.minorder_qty = container.find('input[name=minorder_qty]').val();
						enteredData.minorder_um = container.find('input[name=minorder_um]').val();
						enteredData.orderinmulti_qty = container.find('input[name=orderinmulti_qty]').val();
						enteredData.orderinmulti_um = container.find('input[name=orderinmulti_um]').val();
						enteredData.recordtype = container.find('input[name=recordtype]').val();
						enteredData.row = data.row;

						$App.Fire("purchasing_rules_file_delete_confirm", enteredData);
						$j(this).remove();
					}
				}
			});

			description = $App.Utils.getRulesDescription(data.recordtype);
			container.find('#col-1').find('.mgr-col-recordkey').html(description);
		},
		purchasing_rules_file_delete_confirm: function (data) {
			var template;
			var container;
			var enteredData;
			var parms;

			//get record//
			template = $App.Template('purchasing/delete_rules_file_confirm.ejs');

			container = $j(template.render(data));

			container.dialog({
				title: 'Delete Purchasing Rules Confirm',
				height: 150,
				width: 690,
				modal: 'true',
				dialogClass: 'dancik-dialog',
				open: function () {
					//remove button css to match accounting button standards
					$j('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
					//prevent ui-state-hover form formatting buttons
					$j('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
					$j('.ui-dialog-buttonpane').find('button').hover(function () {
						$(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
					});
				},
				close: function () {
					$j(this).remove();
				},
				buttons: {
					'Continue': function () {
						$App.Fire("purchasing_rules_file_delete", data);
					}

				}
			});

		},
		purchasing_rules_screen_insert: function (data) {
			var template;
			var container;
			var enteredData;
			var description;

			//get record//
			template = $App.Template('purchasing/insert_rules_file.ejs');

			container = $j(template.render(data));

			container.dialog({
				title: 'Add Purchasing Rules',
				height: 175,
				width: 690,
				modal: 'true',
				dialogClass: 'dancik-dialog',
				open: function () {
					//remove button css to match accounting button standards
					$j('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
					//prevent ui-state-hover form formatting buttons
					$j('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
					$j('.ui-dialog-buttonpane').find('button').hover(function () {
						$(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
					});
				},
				close: function () {

					$j(this).remove();
					var data = {
						recordType: $j('#rules_table_group2').find('[name = "recordType"]').val()
					};

					$App.Fire('get_purchasing_rules_filter', data);
				},
				buttons: {
					'Continue': function () {

						enteredData = {};

						//save entered data//
						enteredData.recordkey = container.find('input[name=recordkey]').val();
						enteredData.maxorder_qty = container.find('input[name=maxorder_qty]').val();
						enteredData.maxorder_um = container.find('input[name=maxorder_um]').val();
						enteredData.minorder_qty = container.find('input[name=minorder_qty]').val();
						enteredData.minorder_um = container.find('input[name=minorder_um]').val();
						enteredData.orderinmulti_qty = container.find('input[name=orderinmulti_qty]').val();
						enteredData.orderinmulti_um = container.find('input[name=orderinmulti_um]').val();
						enteredData.recordtype = data.recordType;

						container.find('input[name=recordtype]');

						$App.Fire("purchasing_rules_file_insert", enteredData);

					}
				}
			});

			switch (data.recordType)
			{
				case 'C':
					$App.Utils.dropdown_itemClass1(container.find('input[name=recordkey]'), {
						appendTo: document.body
					});
					break;

				case 'M':
					$App.Utils.dropdown_manufacturer(container.find('input[name=recordkey]'),
						{
							appendTo: document.body
						});
					break;

				case 'L':
					$App.Utils.dropdown_productLine(container.find('input[name=recordkey]'),
						{
							appendTo: document.body
						});
					break;

				case 'P':
					$App.Utils.dropdown_priceClass(container.find('input[name=recordkey]'),
						{
							appendTo: document.body
						});
					break;

				case 'I':
					$App.Utils.dropdown_item(container.find('input[name=recordkey]'),
						{
							appendTo: document.body
						});
					break;

				default:
					break;
			}


			$App.Utils.dropdown_uom_all(container.find('input[name=minorder_um]'),
				{
					appendTo: document.body
				});

			$App.Utils.dropdown_uom_all(container.find('input[name=maxorder_um]'),
				{
					appendTo: document.body
				});

			$App.Utils.dropdown_uom_all(container.find('input[name=orderinmulti_um]'),
				{
					appendTo: document.body
				});

			description = $App.Utils.getRulesDescription(data.recordType);
			container.find('#col-1').find('.mgr-col-recordkey').html(description);

		},
		purchasing_rules_file_update: function (data, results) {
			var container, containerResults, link;

			container = $j('#purchasing-rules-file-update_form');
			containerResults = $j('#Mgr_SearchRulesFileData');

			container.dialog('close');

			$App.Controller("DWS.Growler").info({
				message: "Update Successful"
			});

			//update row with data//
			containerResults.find('#results_minorder_um-' + data.row).html(data.minorder_um);
			containerResults.find('#results_maxorder_qty-' + data.row).html(data.maxorder_qty);
			containerResults.find('#results_orderinmulti_um-' + data.row).html(data.orderinmulti_um);
			containerResults.find('#results_minorder_qty-' + data.row).html(data.minorder_qty);
			containerResults.find('#results_orderinmulti_qty-' + data.row).html(data.orderinmulti_qty);
			containerResults.find('#results_maxorder_um-' + data.row).html(data.maxorder_um);
			containerResults.find('#results_recordtype-' + data.row).html(data.recordtype);
			containerResults.find('#results_recordkey-' + data.row).html(data.recordkey);

			//reset payload//
			link = containerResults.find('#results_detail-' + data.row).find('a:first');

			link.data('payload', {
				minorder_um: data.minorder_um,
				maxorder_qty: data.maxorder_qty,
				orderinmulti_um: data.orderinmulti_um,
				minorder_qty: data.minorder_qty,
				orderinmulti_qty: data.orderinmulti_qty,
				maxorder_um: data.maxorder_um,
				recordtype: data.recordtype,
				recordkey: data.recordkey,
				row: data.row
			});

		},
		purchasing_rules_file_insert: function (data) {
			var container;

			$App.Controller("DWS.Growler").info({
				message: "Insert Successful"
			});

			//clear input fields//
			container = $j('#purchasing-rules-file-insert_form');

			container.find('[name=maxorder_qty]').val('');
			container.find('[name=maxorder_qty]').val('');
			container.find('[name=orderinmulti_um]').val('');
			container.find('[name=minorder_qty]').val('');
			container.find('[name=orderinmulti_qty]').val('');
			container.find('[name=maxorder_um]').val('');
			container.find('[name=recordkey]').val('');
			container.find('[name=minorder_um]').val('');
		},
		purchasing_rules_file_delete: function (data) {

			var container, param;

			container = $j('#purchasing-rules-file-delete_form');
			container.dialog('close');

			container = $j('#purchasing-rules-file-delete-confirm_form');
			container.dialog('close');

			param = {
				recordType: $j('#rules_table_group2').find('[name = "recordType"]').val()
			};

			$App.Fire('get_purchasing_rules_filter', param);

			//remove row from view//
			//  containerResults.find('#results_detail-' + data.row).remove();

			$App.Controller("DWS.Growler").info({
				message: "Delete Successful"
			});

		}

	});




})(jQuery);