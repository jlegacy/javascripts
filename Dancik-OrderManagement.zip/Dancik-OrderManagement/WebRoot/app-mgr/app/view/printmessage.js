(function ($) {
	$App.View("PrintMessage", {
		open_message_window: function (messages) {
		//console.log("view - open_message_window - message -",messages);
		userID = $App.Controller('Config').getConfig().user.user;
			var _this = this,
				container = $($App.Template('printmessage/base.ejs').render(messages, userID));
			container
				.dialog({
					title: 'Send Printed Messages',
					modal: true,
					width: 586,
					height: 450,
					draggable: false,
					resizable: false,
					open: function () {
	                    //remove button css to match accounting button standards
	                    $('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
	                    //prevent ui-state-hover form formatting buttons
	                    $('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
	                    $('.ui-dialog-buttonpane').find('button').hover(function () {
	                        $(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
	                    });
	                    $('.ui-dialog-buttonpane').find('button').focus(function () {
	                        $(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
	                    });
	                },
					close: function () {
						$(this).remove();
					},
					buttons:{
						Send: function () {
							$(this).submit();
						}
					}
				})
				//console.log(container.('.notes input[type=text]'));
				container.delegate('input[type=text]', 'keyup', function (event) {
					_this._break_long_lines(event);
				});
			return container;
		},
		toggle_info: function (event) {
			event.preventDefault();
			$(event.liveFired).toggleClass('show-info');
		},
		populate: function (container, results) {
			//console.log("populate - container", container);
			//console.log("populate - results", results);
			//console.log("populate - results.length", results.length);
			var _this = this,
				rowCounter=0,
				currentLine,
				maxRow = results.length,
				i, html = [], blank_row = {}, record;
			$.each(results, function (index, row) {
				currentLine = "line"+ row.line_number;
				//console.log(currentLine);
				$("#"+currentLine).val(row.message_text);
			});
			container.find('input[type=text]:visible:first').focus();
		},
		insert_line: function (row) {
			var _this = this,
				template = $App.Template('printmessage/note.ejs'),
				new_line = $(template.render({row: {text: 'Please wait while we insert this line.'}}));
			
			row.before(new_line);
			new_line.find('input').first().change();
			return new_line;
		},
		renumber: function (container) {
		//	console.log('renumber - container', container);
			var _this = this,
				rows = container.find('.row'),
				inputs,
				blanks, blank = /^\s*$/, remove_index, removes;
			
			//check for too many rows
			if (rows.length > 9999) {
				inputs = rows.find('input.rowText');
				blanks = inputs.filter(function (index) {
					return blank.test(this.value);
				});
				remove_index = blanks.length - (inputs.length - 9999);
				removes = blanks.filter(function (index) {
					return index >= remove_index; 
				});
				
				removes.closest('.row').remove();
				rows = container.find('.row');
			}
			
			$.each(rows, function (index, row) {
				var $row = $(row),
					line = 10 + index * 10,
					inputs = $row.find('input'),
					r_display = $row.find('.row-number'),
					r_input = inputs.filter('.rowNum'),
					o_input = inputs.filter('.origRowNum');
				
				r_display.html(line);
				r_input.val(line);
				if (r_input.val() != o_input.val() && o_input.val() != '0') {
					r_input.change();
				}
			});
		},
		_break_long_lines: function (event) {
			var lineID = event.target.id
			if (event.target.value.length > 69){
				//console.log("over 69");
				$("#"+lineID).closest('div').next('div').find('input[type=text]').focus();
			}
//			var _this = this,
//				element = $(event.target),
//				container = element.closest('.notes'),
//				blank = /^\s*$/,
//				rtrim = /\s*$/,
//				text = element.val(),
//				template = $App.Template('printmessage/note.ejs'),
//				row = element.closest('.row'), i;
//			
//			if (blank.test(text)) {
//				text = [''];
//			} else {
//				text += ' ';  //if the text does not end in whitespace, then the last word is lost
//
//				//break 70+ character strings at 70 characters
//				//put a space on blank lines to allow them to be parsed out as a blank line
//				text = text.replace(/(\S{70})(?=\S)/g, '$1\n').replace(/\n\n/g, '\n \n');
//
//				//break in to lines of 70 characters, breaking at whitespace
//				text = text.match(/(.{1,70}(?=[\s])[ \t]?)/g);
//				//remove trailing whitespace
//				$.each(text, function (i, row_text) {
//					text[i] = row_text.replace(rtrim, '');
//				});
//			}
//			
//			element.val(text[0]);
//			for (i = text.length - 1; i > 0; i -= 1) {
//				row
//					.after(template.render({row: {text: text[i]}}))
//					.next()
//						.find('input').first().change();
//				_this.renumber(container);
//			}
		},
		prompt_copy: function (notepad) {
		//	console.log("prompt_copy")
			var _this = this,
				template = $App.Template('printmessage/copy.ejs'),
				options = notepad.data('notepad500Options'),
				container = $(template.render(options)),
				payload = {},
				validate_message = '';
				
			switch (options.type) {
			case 'price':
				payload.to = options.keys.dol_cprcc;
				container.find('.from-label').prepend('From Price Class');
				$App.Utils.dropdown_priceClass(container.find('input[name=from]').attr('maxlength', 6));
				validate_message = 'From Price Class is required.';
				break;
			case 'branch':
				payload.co_num = options.keys.c2co_num;
				payload.to = options.keys.c2brn_num;
				container.find('.from-label').prepend('From Branch');
				$App.Utils.dropdown_branch(container.find('input[name=from]').attr('maxlength', 3), {
					onDrop: function (opts) {
						opts.queryParams.filterCompany = options.keys.c2co_num;
					}
				});
				validate_message = 'From Branch is required.';
				break;
			case 'company':
				payload.to = options.keys.c1co_num;
				container.find('.from-label').prepend('From Company');
				$App.Utils.dropdown_company(container.find('input[name=from]').attr('maxlength', 1));
				validate_message = 'From Company is required.';
				break;
			}
			
			
			
			container
				.data('notepad', notepad)
				.data('payload', payload)
				.dialog({
					title: 'Copy From Notepad',
					modal: true,
					width: 'auto',
					height: 'auto',
					draggable: false,
					resizable: false,
					close: function () {
						$(this).remove();
					},
					buttons: {
						Copy: function () {
							$(this).submit();
						}
					}
				})
				.validate({
					messages: {
						from: {
							required: validate_message
						}
					},
					//we only want to validate on form submit, not keyup or blur
					onkeyup: false,
					onfocusout: false,
					//don't show inline errors
					errorPlacement: $.noop,
					//show errors when they exist
					showErrors: function (error_map, error_array) {
						$App.Fire("errors", $.map(error_array, function (error, index) {
								return error.message;
							})
						);
					}
				});
		}
		
		
	});
})(jQuery);