(function ($) {
$App.View("OrderViews", {
	initialize: function () {
//		this.controller = $App.Controller("OrderViews");
//		this.model = $App.Model("OrderViews");
	},
		viewOrderPop: function (headers, data, allViews) {
		//console.log("headers", headers);
		//console.log("data", data);
		//console.log("allviews",allViews);
			var _this = this, container,
			template = $App.Template("orderViews/base.ejs");
			
			container = $(template.render(data));
			//build field_names array			
			if (Main.useDetailLevel) {
				headers = Main.defaultDetailList;
			}
			else{
				headers = Main.defaultHeaderList;
			}
			var new_records = [];
			var new_recordsAll = [];
			//console.log("allviews",allViews);
			$.each(allViews, function (index, data1) {
				//data.filter_values = $.parseJSON(data.filter_values);
				var new_viewAll = {
						id: data1.keyid,
						description: data1.description,
						is_default: (data1.filter_values.isDefault === true || data1.filter_values.isDefault == 'Y'),
						is_private: data1['private'] == 'Y',
						user: data1.user,
						filter_values: data1.filter_values,
						filters: data1.filter_values.set,
						fm_file: data1.file_name,
						is_Dancik: data1['private'] == '',  //pp1
						is_public: data1['private'] == 'N'  //pp1
					};
				new_recordsAll.push(new_viewAll);
			//console.log("new_recordsALL - ", new_recordsAll);
			});
				//parse out the filter_values to objects
			// creates the column order
			//console.log("data - ",data)
				data.filter_values = $.parseJSON(data.filter_values);
		//	console.log("data.filter_values - ",data.filter_values)
				var new_view = {
						id: data.keyid,
						description: data.description,
						is_default: (data.filter_values.isDefault === true || data.filter_values.isDefault == 'Y'),
						is_private: data['private'] == 'Y',
						user: data.user,
						sort: data.filter_values.sort,
						filters: data.filter_values.set,
						fm_file: data.file_name,
						is_Dancik: data['private'] == '',  //pp1
						is_public: data['private'] == 'N'  //pp1
					};
				new_records.push(new_view);
			//	console.log("new_records2 - ",new_records);
			//console.log("new records",new_records);
			var sorted_list = new_records[0].sort, 
				header_or_detail = data.file_name;
			//load the column sort order and checked columns
			_this.set_columns(sorted_list, header_or_detail, container, headers);
			container.dialog({
				title: 'Display Options',
				height: 420,
				width: 560,
				modal: 'true',
				open: function () {
                    //remove button css to match accounting button standards
                    $('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
                    //prevent ui-state-hover form formatting buttons
                    $('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
                    $('.ui-dialog-buttonpane').find('button').hover(function () {
                        $(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
                    });
                },
				dialogClass: 'dancik-dialog',
				close: function () {
					$(this).remove();
				},
				buttons: {
					Apply: function () {
						$(this).submit();
						$(this).remove();
					}
				}
			});
			
			
			//_this.decorate();
			container.find("tbody.sort-fields").sortable();
			_this.store_views(new_recordsAll);
			$('#check_all_box').change(function(){
				if(this.checked)
				      _this.check_all_checkboxes($("#manage_order_view"));
				   else
					   $("#manage_order_view").find(".chk_bx").prop("checked", false);
			});
		},
		clear_table_view: function () {
			var _this = this,
				container = _this.getContainer(),
			table_container = container.find('.sort-fields');
			
			//clear table row data
			return table_container.find('tr').remove();
		},
		
		set_columns: function (sort_list, search_view, container, headers) {
			var _this = this,
			viewToUse=[], 
			defaultViewToUse=[];
		//	console.log("Current Detail View", Main.currentDetailView);
		//	console.log("Current Header View", Main.currentHeaderView);
			if (Main.useDetailLevel) {
				viewToUse = Main.currentDetailView;
				defaultViewToUse = Main.defaultDetailView;
				loadedViewToUse = Main.loadedDetailView;
			}
			else{
				viewToUse = Main.currentHeaderView;
				defaultViewToUse = Main.defaultHeaderView;
				loadedViewToUse = Main.loadedHeaderView;
			}
		
			if (sort_list.length != 0) {	
				//console.log('sort_list', sort_list);
				//console.log('viewToUse', viewToUse);
				//console.log('defaultViewToUse', defaultViewToUse)
				$.each(sort_list, function (index, val) {
					container.find('.sort-fields').append(_this.populate_row(val, headers[val]));
					currentRow = container.find('tr#'+val+'');
					currentRow.find(".chk_bx").prop("checked", true);				
				});
				//loop through list and compare to current view.  Add other fields at the bottom
				$.each(defaultViewToUse, function (index, val) {
					if ($.inArray(val, sort_list) == -1) {
						container.find('.sort-fields').append(_this.populate_row(val, headers[val]));
					}			
				});
	
				Main.loadedView = true;
				//_this.check_all_checkboxes(container);
			} else {
				//append results to list
				$.each(headers, function (index, val) {
					//container.find('.sort-fields').append(_this.populate_row(index, search_view.fields[val]));
				});
			}
			
		},
		reset_filter_view: function (data) {
		//	console.log("reset_filer_view -", data);
			var _this = this,
				field_index_arr = [],
				defaulListToUse=[],
				container = _this.getContainer(),
				table_body = container.find('.sort-fields');

			
			//clear table
			_this.clear_table_view();
			if (Main.useDetailLevel) {
				defaultListToUse = Main.defaultDetailList;
				//defaultListToUse = Main.currentDetailView;
			}
			else{
				defaultListToUse = Main.defaultHeaderList;
				//defaultListToUse = Main.currentHeaderList;
			}
			//rebuild filter table
			$.each(defaultListToUse, function (i, field) {
				//add row to container
				table_body.append( _this.populate_row(i, field) );
				//take into consideration the available fields.
				if (!field.available) { //field is available
					//check ckeck box
					table_body.find('tr#' + i).find("input[type=checkbox]").prop("checked", true);
				}
			});
			
		},
		decorate: function () {
			
		},
		populate_row: function (i, field) {
			var _this = this,
				template = $App.Template("orderViews/views_row.ejs");
			return template.render({i: i, field: field});
		},
		check_all_checkboxes: function (container) {
			var _this = this;				
			//check check boxes
			container.find(".chk_bx").prop("checked", true);
		},
		save_view:function (data){
			var _this = this, container,
			template = $App.Template("orderViews/view_save.ejs");
			
			container = $(template.render(data));
			
			container
			.data('payload', data)
			.dialog({
				title: 'Save View',
				modal: true,
				dialogClass: 'dancik-dialog',
				minHeight: 0,
				height: 150,
				open: function () {
                    //remove button css to match accounting button standards
                    $('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
                    //prevent ui-state-hover form formatting buttons
                    $('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
                    $('.ui-dialog-buttonpane').find('button').hover(function () {
                        $(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
                    });
                },
				close: function () {
					$(this).remove();
				},
				buttons: {
					Save: function () {
						$(this).submit();
					}
				}
			})
			.validate({
				//we only want to validate on form submit, not keyup or blur
				onkeyup: false,
				onfocusout: false,
				//don't show inline errors
				errorPlacement: $.noop,
				//show errors when they exist
				showErrors: function (error_map, error_array) {
					$App.Fire("errors", $.map(error_array, function (error, index) {
							return error.message;
						})
					);
				},
				messages: {
					description: {
						required: 'Description is required'
					}
				}
			});
			//focus to description field
			container.find('[name=description]').focus();
			
			////Hide Default checkbox if public filter is selected.
			container.delegate('#public_save', "click", function(){
				$('#default_save').hide();
				
			});
			container.delegate('#private_save', "click", function(){
				$('#default_save').show();				
			});
		},
		getContainer: function () {
			var _this = this,
				container = $("#manage_order_view");
			return container;
		},
		addView: function (view) {
			//console.log("view-addView - ",view);
			var _this = this,
				container = _this.getContainer(),
				view_container = container.find('.om-saved-views'),
				private_view_container,
				private_cnt_container = view_container.find('.private-count'),
				private_count = 0,
				public_view_container,
				public_cnt_container = view_container.find('.public-count'),
				public_count = 0,
				view_li = view_container.find("#" + view.id),
				new_li = $('<li id="' + view.id + '" class="select-view"></li>'),
				new_a = $('<a href="#load_filter_view">' + view.description + '</a>').appendTo(new_li);
				//access = User.access['FILE_' + view.fm_file.toUpperCase()];	
			
			if (view.is_private) {
				
				filterParsed = $.parseJSON(view.filter_values);
			//	console.log("filterParsed",filterParsed.isDefault);
				private_view_container = view_container.find('.private-filters');
				new_a.prepend('<span class="ui-icon ui-icon-dancik-door p-icon">Private</span>');
//				if (filterParsed.isDefault == true){
//					$(new_a).closest('li').css('font-weight', 'bold');
//				}
			} else {
				public_view_container = view_container.find('.public-filters');
				new_a.prepend('<span class="ui-icon ui-icon-dancik-door-open p-icon">Public</span>');
			}
			if (view.user == $App.Controller('Config').getConfig().user.user) {
				new_li.append('<a href="#delete_view" class="delete"><span class="ui-icon ui-icon-closethick">delete</span></a>');
			}
			
			if (view_li.length === 0) {
				
				//add menu option if it doesn't already exist
				if (private_view_container) {
					private_view_container.append(new_li);	
				} else {
					public_view_container.append(new_li);
				}
			} else {
				//replace existing option
				view_li.replaceWith(new_li);
			}
			
			public_count = view_container.find('.public-filters li').length;
			private_count = view_container.find('.private-filters li').length;
			
			public_cnt_container.html(public_count);
			private_cnt_container.html(private_count);
			new_li.find("a").data("payload", view);
		},
		prompt_overwrite: function (data, description_form) {
			var confirm;
			description_form = $(description_form);
			$App.Utils.confirm({
				title:'Name Already Exist',
				message:  'Overwrite existing filter?',
				onConfirm: function () {
					description_form.find('input[name=id]').val(data.id);
					description_form.submit();
				$App.Fire('clear_blanket');
				}
			});
		},
		store_views: function (views) {
		
			var _this = this;
				//container = _this.getContainer();
				$.each(views, function (index, view) {
		
					if (view.user !="DANCIK") { //Don't show Dancik default filters
						_this.addView(view);
					
					}
				});
		}
	});
})(jQuery);