(function ($) {
	$App.Model.Extend("DWS.Ajax", "OrderStatus", {
		initialize: function () {
			this._super();
		},
		getOrderStatus: function (data, callback, errorCallback) {
			var _this = this
			_this.post(data, '../api/order-status/retrieve', callback, errorCallback);
		},
		updateOrderStatus: function (obj, callback, errorCallback) {
			var _this = this,
			postData = {
				orderid: obj.orderid,
				referenceid: obj.referenceid,
				flag_all: obj.flag_all
			};
			/*
			<params>
				<orderid>
				<referenceid>
				<flag_all>
				<shipdate_all>
				<orderdate_all>
				<status_all>
				<line>
					<number>
					<shipdate>
					<orderdate>
					<status>
				</line>
			</params>
			*/
			if (postData.flag_all == "Y") {
				//send the update all fields if checked
				postData.shipdate_all = obj.shipdate_all;
				postData.orderdate_all = obj.orderdate_all;
				postData.status_all = obj.status_all;
			} else {
				//send line array if update all not checked
				postData.line = [];
				
				//make sure line, orderdate, shipdate, and status are all arrays
				obj.line = [obj.line].flatten().compact();
				obj.orderdate = [obj.orderdate].flatten().compact();
				obj.shipdate = [obj.shipdate].flatten().compact();
				obj.status = [obj.status].flatten().compact();
				
				obj.line.each(function (n, i) {
					//only submit changed lines
					if (obj.changed_lines[n]) {
						//combine line, orderdate, shipdate, and status in to an object in the line array.
						postData.line.push({
							number: n,
							orderdate: obj.orderdate[i],
							shipdate: obj.shipdate[i],
							status: obj.status[i]
						});
					}
				});
			}
			
			_this.post(postData, '../api/order-status/update', callback, errorCallback);
		},
		in_filter: function (obj) {
			
			//make sure detail is an array
			if (obj.detail) {
				if (!$.isArray(obj.detail)) {
					obj.detail = [obj.detail];
				}
			} else {
				obj.detail = [];
			}
			$.each(obj.detail, function (index, d) {
				//convert y/n to true/false
				d.locked = d.locked == "Y";
				d.lock_status = d.lock_status == "Y";
			});
	
			//make sure flags is an object
			obj.flags = obj.flags || {};
			$.each(obj.flags, function (f, value) {
				obj.flags[f] = value == "Y";
			});
			
			return obj;
		}
	});
})(jQuery);