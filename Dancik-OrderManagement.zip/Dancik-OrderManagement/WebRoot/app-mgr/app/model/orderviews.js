(function ($) {
	$App.Model.Extend("DWS.Ajax", "OrderViews", {
		initialize: function () {
			this._super();
			this.cached_views = {};
		},
		get_views: function (data, callback) {
			var _this = this;
			
			if (Main.cached_views[data.file]) {
				callback(Main.cached_views[data.file]);
				return;
			}
			
			$App.Model("FM.Ajax").get({output:"JSON", parm_FileName: data.file}, "../../fm/service/FM_Service/getFilters", function (results) {
				if (results && results.records) {
					_this._parse_views(results);
					_this._sort_views(results.records);

					Main.cached_views[data.file] = results.records;

				} else {
					Main.cached_views[data.file] = [];
				}
				callback(Main.cached_views[data.file]);
			});
		},
		
		_parse_views: function (views) {
			var new_records = [];
			
			$.each(views.records, function (index, view) {
				//parse out the filter_values to objects
				view.filter_values = $.parseJSON(view.filter_values);
				
				var new_view = {
					id: view.keyid,
					description: view.description,
					is_default: (view.filter_values.isDefault === true || view.filter_values.isDefault == 'Y'),
					is_private: view['private'] == 'Y',
					user: view.user,
					sort: view.filter_values.sort,
					filters: view.filter_values.set,
					fm_file: view.file_name,
					is_Dancik: view['private'] == '',  //pp1
					is_public: view['private'] == 'N'  //pp1
				};
				new_records.push(new_view);
			});
			views.records = new_records;
		},
		_sort_views: function (view_array) {
			//sort filters by description
			view_array.sort(function (one, two) {
				var oned = one.description.toLowerCase(), twod = two.description.toLowerCase();
				if (oned < twod) { //sort string ascending
					return -1;
				}
				if (oned > twod) { //sort string descending
					return 1;
				}
				return 0; //default return value (no sorting)
			});
		},
		save: function (view, callback, errorCallback) {
			var _this = this,
				save_data = {};
			view.is_private = view.is_private !== false && view.is_private !== '';
			
			save_data.description = view.description;
			save_data.filename = view.fm_file;
			save_data.filterId = view.id;
			save_data.isPrivate = view.is_private ? 'Y' : 'N';
			save_data.filterValue = JSON.stringify({
				set: [], 
				sort: view.sort, 
				isDefault: ((view.is_default === true || view.is_default == 'Y') && save_data.isPrivate == 'Y')
			});
		
			$App.Model("FM.Ajax").post(save_data, '../../fm/service/FM_Service/saveFilter', function (data) {
					if (data && data.records && data.records.length) {
						_this._parse_views(data);
						_this._add_or_update_view(data.records[0]);
						callback(data.records[0]);
					}
				}, 
				errorCallback
			);
		},
		delete_view: function (view, callback, errorCallback) {
			var _this = this,
			container = $("#manage_order_view"),
			view_container = container.find('.om-saved-views'),
			private_view_container,
			private_cnt_container = view_container.find('.private-count'),
			private_count = 0,
			public_view_container,
			public_cnt_container = view_container.find('.public-count'),
			public_count = 0,
			ajax_data = {filterId: view.id};
			_this.update_cache(ajax_data);
			$App.Model("FM.Ajax").post(ajax_data, '../../fm/service/FM_Service/delFilter', function (data) {
					_this._remove_view(view);
						$App.Fire('clear_overlay');
						$App.Fire('info_message', 'View deleted.');			
						public_count = view_container.find('.public-filters li').length;
						private_count = view_container.find('.private-filters li').length;
						
						public_cnt_container.html(public_count);
						private_cnt_container.html(private_count);
					callback(data);
				},
				errorCallback
			);
			
			
		},
		update_cache: function(view_to_delete){
			if (Main.useDetailLevel) {
				if (Main.cached_views.ordermanagerd !== undefined){
					$.each(Main.cached_views.ordermanagerd, function (index, view) {
						Main.cached_views.ordermanagerd = $.grep(Main.cached_views.ordermanagerd, function(a){
							return a.id != view_to_delete.filterId;
						});
						
					});
				}
			}
			else{
				if (Main.cached_views.ordermanagerh !== undefined){
					$.each(Main.cached_views.ordermanagerh, function (index, view) {
						Main.cached_views.ordermanagerh = $.grep(Main.cached_views.ordermanagerh, function(a){
							return a.id != view_to_delete.filterId;
						});
					});
				}

			}
		},
		_add_or_update_view: function (view) {

			var _this = this;
			//_this._remove_view(view);
			//Main.cached_views[view.fm_file].push(view);
			//_this._sort_views(Main.cached_views[view.fm_file]);
		},
		_remove_view: function (view) {

			var _this = this,
			deletedRow;
			deletedRow = view.id;
			$("#"+deletedRow).remove();
		}
	});
})(jQuery);