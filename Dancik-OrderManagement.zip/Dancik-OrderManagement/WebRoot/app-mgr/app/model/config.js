/*globals $App jQuery*/
(function ($) {
     $App.Model.Extend('DWS.Ajax', 'Config', {
          initialize: function () {
          },
          getConfig: function (configList) {
               var data;
               $.ajax({
                    url: '../config',
                    async: false,
                    data: configList,
                    traditional: true,
                    method: 'get',
                    success: function (config) {
                         data = config;
                    }
               });
               return data;
          },

          get_files: function (data, callback, errorCallback) {
               var _this = this;
               //  _this.get(data, "../../fm-A026429/service/FM_Service/getFiles", callback, errorCallback);
               _this.get(data, "../../fm/service/FM_Service/getFiles", callback, errorCallback);
          }
     });
})(jQuery);
