/*globals $App jQuery*/
(function ($) {
    $App.Model.Extend("DWS.Ajax", "MultiUnit", {
        initialize: function () { },
        get_std_order_details: function (data, callback, errorCallback) {
            var _this = this,
                url = "../../dancik-aws/om/getStandardOrderDetails";

            _this.post(data, url, callback, errorCallback);
        },
        get_std_order_header: function (data, callback, errorCallback) {
            var _this = this,
                url = "../../dancik-aws/om/getStandardOrderheader";

            _this.post(data, url, callback, errorCallback);
        },
        update_multi_unit_header: function (data, callback, errorCallback) {
            var _this = this,
                url = "../../dancik-aws/om/updateMultiUnitHeader";

            _this.post(data, url, callback, errorCallback);
        }
    });
})(jQuery);