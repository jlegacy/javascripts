(function ($) {
	$App.Model.Extend("DWS.Ajax", "SplitLine", {
		initialize: function () {
			this._super();
	},
	getSplitInfo: function(data, callback, errorCallback){
		var _this = this,
		url = "../../dancik-aws/om/omDisplaySplitLineInformation";
		_this.post(data, url, callback, errorCallback);
	},
	execute_split_line: function(data, callback, errorCallback){
		var _this = this,
		url = "../../dancik-aws/om/omSplitlines";
		_this.post(data, url, callback, errorCallback);
	},
	getUOM: function(data, callback, errorCallback){
		var _this = this,
		url = "../../dancik-aws/des/getItemUOMListing";
		_this.post(data, url, callback, errorCallback);
	}
	
	});
})(jQuery);