/*global $App jQuery*/
(function ($) {
	$App.Model.Extend('DWS.Ajax', 'FM.Ajax', {
		post: function (obj, url, callback, errorCallback) {
			var _this = this;
			
			obj = _this.out_filter(obj);
			
			errorCallback = errorCallback || _this.handleErrors;
			$.ajax({
				url: url,
				type: "post",
				data: obj,
				traditional: true,
				success: function (data) {
					if (!$.isPlainObject(data)) {
						data = $.parseJSON(data);
					}
				
					if (data && data.errors) {
						errorCallback(data.errors);
					} else {
						try {
							callback(_this.in_filter(data || {}));
						} catch (exception) {
							$App.Log.exception(exception);
							errorCallback([
								{errmsg: 'Error communicating with server.'}
							]);
						}
					}
				},
				error: function (response) {
					//Don't do anything if this was a manual abort.
					if (!response.aborted) {
						errorCallback([
							{errmsg: 'Error communicating with server.'}
						]);
					}
				}
			});
		},
		handleErrors: function (errors) {
			var modified_errors = $.map(errors, function (error) {
				if ($.isPlainObject(error)) {
					return error;
				} else {
					return {errmsg: error};
				}
			});
			$App.Fire('ajax_errors', modified_errors);
			$App.Fire('clear_overlay');
		}
	});
})(jQuery);