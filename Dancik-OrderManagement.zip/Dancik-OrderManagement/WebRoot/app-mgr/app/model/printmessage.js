(function ($) {
	$App.Model.Extend("DWS.Ajax", "PrintMessage", {
		initialize: function () {
			this._super();
		},
		getPrintMessage: function(data, callback, errorCallback){
			var _this = this,
			url = "../../dancik-aws/ods/getMessage";
			_this.post(data, url, callback, errorCallback);
		},
		sendPrintMessage: function(data, callback, errorCallback){
			var _this = this;
			url = "../../dancik-aws/ods/printMessage";
			_this.post(data, url, callback, errorCallback);
		}
	});
})(jQuery);