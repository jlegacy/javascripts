(function ($) {
	$App.Model.Extend("DWS.Ajax", "UpdateDelivery", {
		initialize: function () {
			//this._super();
		},
		update_delivery_day: function(data, callback, errorCallback){
			var _this = this,
			url = "../../dancik-aws/om/updateDeliveryInfo";
			_this.get(data, url, callback, errorCallback);
		}
	});
})(jQuery);