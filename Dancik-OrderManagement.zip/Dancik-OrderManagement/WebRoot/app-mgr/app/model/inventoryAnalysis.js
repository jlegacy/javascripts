(function ($) {
    $App.Model.Extend('DWS.Ajax', 'inventoryAnalysis', {
        initialize: function () {
            this._super();
        },
        addOrderLines: function (data, callback, errorCallback) {
            var _this = this;
            _this.post(data, "../../dancik-aws/om/addManualInvOrderLines", callback, errorCallback);
        }
    });
})(jQuery);