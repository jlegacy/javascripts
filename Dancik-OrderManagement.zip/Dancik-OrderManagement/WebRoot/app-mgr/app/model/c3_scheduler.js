(function ($) {
    $App.Model.Extend('DWS.Ajax', 'c3scheduler', {
        initialize: function () {
            this._super();
        },
        get_entries_by_date: function (data, callback, errorCallback) {
            var _this = this;
            _this.post(data, "../../dancik-aws/om/getJobScheduleByDate", callback, errorCallback);
        },
        get_entries_by_account: function (data, callback, errorCallback) {
            var _this = this;
            _this.post(data, "../../dancik-aws/om/getJobScheduleByAccount", callback, errorCallback);
        },
        get_entries_by_account_date: function (data, callback, errorCallback) {
            var _this = this;
            _this.post(data, "../../dancik-aws/om/getJobScheduleByAccountDate", callback, errorCallback);
        },
        update_c3_scheduler_header: function (data, callback, errorCallback) {
            var _this = this;
            _this.post(data, "../../dancik-aws/om/updateInstallationSchedulerHeader", callback, errorCallback);
        },
        update_c3_scheduler_detail: function (data, callback, errorCallback) {
            var _this = this;
            _this.post(data, "../../dancik-aws/om/updateInstallationSchedulerDetail", callback, errorCallback);
        }
    });
})(jQuery);