(function ($) {
	$App.Model.Extend("DWS.Ajax", "Retail", {
		initialize: function () {
			this._super();
		}
	});
})(jQuery);