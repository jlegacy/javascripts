(function ($) {
     $App.Model.Extend('DWS.Ajax', 'purchasing', {
          initialize: function () {
               this._super();
          },
        
          get_purchasing_rules: function (data, callback, errorCallback) {
               var _this = this;
               _this.get(data, '../../dancik-aws/purchasing/getPurchasingRules', callback, errorCallback);
          },
          
          purchasing_rules_file_insert: function (data, callback, errorCallback) {
               var _this = this;
               _this.get(data, '../../dancik-aws/purchasing/addPurchasingRule', callback, errorCallback);
          },
          
          purchasing_rules_file_delete: function (data, callback, errorCallback) {
               var _this = this;
               _this.get(data, '../../dancik-aws/purchasing/rmvPurchasingRule', callback, errorCallback);
          },
          
          purchasing_rules_file_update: function (data, callback, errorCallback) {
               var _this = this;
               _this.get(data, '../../dancik-aws/purchasing/updPurchasingRule', callback, errorCallback);
          },
          
          get_reorder_calcs: function (data, callback, errorCallback) {
               var _this = this;
               _this.get(data, '../../dancik-aws/purchasing/getSuggestedReorderQuantity', callback, errorCallback);
          }
          
     });
})(jQuery);