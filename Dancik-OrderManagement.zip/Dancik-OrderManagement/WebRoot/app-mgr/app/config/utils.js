///*global $App jQuery $M*///
(function ($) {
	$App.Utils({
		confirm: function (opts) {
			var options = $.extend(
				{
					message: $M("confirmDefaultMsg"),
					title: $M("unsavedChanges"),
					confirmText: 'Yes',
					declineText: 'No',
					onConfirm: $.noop,
					onDecline: $.noop
				}, opts || {}),
				conf = $("<div>" + options.message + "</div>"),
				buttons = {};

			buttons[options.confirmText] = function () {
				options.onConfirm();
				$(this).remove();
			};
			buttons[options.declineText] = function () {
				options.onDecline();
				$(this).remove();
			};

			conf.dialog({
				title: options.title,
				modal: true,
				width: 'auto',
				dialogClass: 'dancik-dialog dancik-confirm',
				buttons: buttons,
				open: function () {
					//remove button css to match accounting button standards
					$('.ui-dialog-buttonpane').find('button').removeClass('ui-button ui-widget ui-state-default ui-corner-all ui-button-text-only');
					//prevent ui-state-hover form formatting buttons
					$('.ui-dialog-buttonpane').find('button').removeClass('ui-state-focus ui-state-hover ui-state-active');
					$('.ui-dialog-buttonpane').find('button').hover(function () {
						$(this).removeClass('ui-state-focus ui-state-hover ui-state-active');
					});
				},
				close: function () {
					options.onDecline();
					$(this).remove();
				}
			});
		},
		dropdown_uom_all: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				preloadedContent: [
					{
						id: 'CT',
						description: 'Cartons'
					},
					{
						id: 'CO',
						description: 'Container'
					},
					{
						id: 'CB',
						description: 'Cubes'
					},
					{
						id: 'EA',
						description: 'Each'
					},
					{
						id: 'IN',
						description: 'Inches'
					},
					{
						id: 'KG',
						description: 'Kilogram'
					},
					{
						id: 'LF',
						description: 'Linear Feet'
					},
					{
						id: 'PA',
						description: 'Pallets'
					},
					{
						id: 'PC',
						description: 'Pieces'
					},
					{
						id: 'LB',
						description: 'Pounds'
					},
					{
						id: 'RL',
						description: 'Rolls'
					},
					{
						id: 'ST',
						description: 'Sets'
					},
					{
						id: 'SH',
						description: 'Sheets'
					},
					{
						id: 'SF',
						description: 'Square Feet'
					},
					{
						id: 'M2',
						description: 'Square Meters'
					},
					{
						id: 'SY',
						description: 'Square Yards'
					},
					{
						id: 'TL',
						description: 'Truckload'
					}
				],
				width: 100
			}, opts));
		},
		dropdown_scrollDirection: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				preloadedContent: [
					{
						id: 'I',
						description: 'Item'
					},
					{
						id: 'D',
						description: 'Description'
					}
				],
				width: 100
			}, opts));
		},
		//convert m/d/y display date to ISO format
		cvtDateIso: function (inputDate)
		{
			_this = this;
			var n;
			var isodate;
			n = inputDate.split("/");
			if (typeof n[2] !== 'undefined')
			{
				isodate = '20' + _this.pad2(n[2]) + _this.pad2(n[0]) + _this.pad2(n[1]);
			}

			return isodate;
		},
		pad2: function (number) {
			return (number.length < 2 ? '0' : '') + number;
		},
		pad3: function (number) {
			return (number < 10 ? '0' : '') + number;
		},
		dropdown_salesman: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: "salesman",
				title: "Salesperson"
			}, opts));
		},
		dropdown_shipVia: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				title: 'ShipVia',
				file: 'classes_sv'
			}, opts));
		},
		dropdown_billto: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: "billto",
				title: "Account"
			}, opts));
		},
		dropdown_installCompany: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: "iscdinst",
				title: "Install Company"
			}, opts));
		},
		dropdown_company: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: "company",
				title: "Company"
			}, opts));
		},
		dropdown_installTeam: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: "iscdteam",
				title: "Install Team",
				onDrop: function (opts) {
					opts.queryParams.addlFilterValue = $('#c3-scheduler-update_form').find('input[name=omInstaller]').val();
				},
				queryParams: {
					addlFilterField: 'ISCDEINST',
					addlFilterValue: opts.install_Company
				}
			}, opts));
		},
		dropdown_manufacturer: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: "manufacturer",
				title: "Manufacturer"
			}, opts));
		},
		dropdown_priceClass: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: "priceLookup",
				title: "Price Class"
			}, opts));
		},
		dropdown_itemClass1: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: "classes_i1",
				title: "Item Class 1"
			}, opts));
		},
		dropdown_itemClass2: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: "classes_i2",
				title: "Item Class 2"
			}, opts));
		},
		dropdown_itemClass3: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: "classes_i3",
				title: "Item Class 3"
			}, opts));
		},
		dropdown_productLine: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				title: 'Product Line',
				file: 'prodline'
			}, opts));
		},
		getRulesDescription: function (rule) {
			var description;
			// set header title for variable column //
			switch (rule)
			{
				case 'C':
					description = 'Item Class';
					break;
				case 'M':
					description = 'Manufacturer';
					break;
				case 'L':
					description = 'Product Line';
					break;
				case 'P':
					description = 'Price Class';
					break;
				case 'I':
					description = 'Item';
					break;
				default:
					break;
			}
			return description;
		},
		getRulesDescriptionCode: function (description) {
			var code;
			description = description.toUpperCase();
			// set header title for variable column //
			switch (description)
			{
				case 'ITEM CLASS':
					code = 'C';
					break;
				case 'MANUFACTURER':
					code = 'M';
					break;
				case 'PRODUCT LINE':
					code = 'L';
					break;
				case 'PRICE CLASS':
					code = 'P';
					break;
				case 'ITEM':
					code = 'I';
					break;
				default:
					code = 'Z';
					break;
			}
			return code
		},
		dropdown_item: function (inputs, opts) {
			inputs.itemSearch($.extend({}, opts));
		},
		dropdown_installTeamFilter: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: "iscdteam",
				title: "Install Team",
				onDrop: function (opts) {
					opts.queryParams.addlFilterValue = $('input[name=omInstallerFilter]').val();
					if (!($('input[name=omInstallerFilter]').val()))
					{

						new Dancik_ConfirmWindow({
							showAsInfoOnly: true,
							content: '<div style="text-align:left;"> Must Select Installer First </div>',
							destroyOnClose: true,
							color: "red",
							modal: true
						}).open();

						return false;
					}

				},
				queryParams: {
					addlFilterField: 'ISCDEINST',
					addlFilterValue: opts.install_Company
				}
			}, opts));
		},
		dropdown_status: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				preloadedContent: [
					{
						id: "S",
						description: "Scheduled"
					},
					{
						id: "I",
						description: "Installed"
					},
					{
						id: "U",
						description: "Unscheduled"
					},
					{
						id: "D",
						description: "Delete"
					},
				]
			}, opts));
		},
		dropdown_status_codes: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: 'orstat_o',
				title: 'Order Status'
			}, opts));

		},
		dropdown_purchasing_rules_types: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				preloadedContent: [
					{
						id: "C",
						description: "Item Class"
					},
					{
						id: "M",
						description: "Manufacturer"
					},
					{
						id: "L",
						description: "Product Line"
					},
					{
						id: "P",
						description: "Price Class"
					},
					{
						id: "I",
						description: "Item"
					},
				]
			}, opts));
		},
		po_dropDown: function (inputs, opts, container) {
			var _this = this;
			var title = inputs.find('div');
			var options = inputs.find('ul');

			inputs.prepend('<div class="dws-options-handle"></div>');

			inputs.addClass('dws-options-dropdown');
			title.addClass('dws-options-title');
			options.addClass('dws-options-list');
		},
		dropdown_warehouse: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				file: "warehouse",
				title: "Warehouse"
			}, opts));
		},
		searchItem: function (e) {
			var event = e || window.event;
			var element = Event.element(e);
			var parent = element.up();
			var input = parent.down("input");

			Popup_Search_ForITEM.open(event, {
				blanketStretchBySize: true,
				toElements: [input]
			});
		
			//set z-indexes because of being invoked by popup box//
			$('#Popup_Search_ForITEM').css('zIndex', 99999);
			$('#Popup_Search_ForITEM').children('div:first').css('zIndex', 99999);

		},
		dropdown_CutRoll: function (inputs, opts) {
			inputs.dropdownSearch($.extend({
				preloadedContent: [
					{
						id: 'R',
						description: 'Roll'
					},
					{
						id: 'B',
						description: 'Balance'
					},
					{
						id: 'C',
						description: 'Cut'
					}
				],
			width: 30
			}, opts));
		}
	});
})(jQuery);