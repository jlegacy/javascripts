/*globals $App*/
$App.Routes({
	events: [
	     //messaging events
		{event: 'info_message', controller: 'DWS.Growler', method: 'info'},
		{event: 'errors', controller: 'DWS.Growler', method: 'error'},
		{event: 'ajax_errors', controller: 'DWS.Growler', method: 'backendErrors'},
		{event: 'confirm', controller: 'Messaging', method: 'confirmation'},
		{event: 'info_message2', controller: 'Messaging', method: 'info'},
		{event: 'blanket_message', controller: 'Messaging', method: 'blanketMessage'},
		{event: 'warn_message', controller: 'Messaging', method: 'warn'},
		{event: 'error_message', controller: 'Messaging', method: 'error'},
		{event: 'ajax_errors2', controller: 'Messaging', method: 'backendErrors'},
		
		//overlay/blanket event
		{event: 'overlay', controller: 'Application', method: 'block_screen'},
		{event: 'clear_overlay', controller: 'Application', method: 'unblock_screen'},
		
        {event: "multi_unit", controller: "MultiUnit", method: "open"},
        {event: "update_header", controller: "MultiUnit", method: "update_header"},
        {event: "order-status", controller: "OrderStatus", method: "open"},
		{event: "open-view-window", controller: "OrderViews", method: 'openWindow'},
		{event: "update_delivery", controller: "UpdateDelivery", method: 'updateDeliveryDay'},
		{event: "new-retail-customer", controller: "Retail", method: "open"},                
          //carpet 3//
        {event: "c3_scheduler", controller: "c3scheduler", method: "init"},
        {event: "c3_schedule_edit", controller: "c3scheduler", method: "c3_schedule_edit"},
        {event: "update_c3_scheduler_header", controller: "c3scheduler", method: "update_c3_scheduler_header"},
        {event: "update_c3_scheduler_detail", controller: "c3scheduler", method: "update_c3_scheduler_detail"},
        //purchasing//
        {event: "purchasing_rules_init", controller: "purchasing", method: "purchasing_rules_init"},
        {event: "purchasing_reorder_calc_init", controller: "purchasing", method: "purchasing_reorder_calc_init"},
        {event: "purchasing_rules_screen_edit", controller: "purchasing", method: "purchasing_rules_screen_edit"},
        {event: "purchasing_rules_screen_insert", controller: "purchasing", method: "purchasing_rules_screen_insert"},
        {event: "purchasing_rules_screen_delete", controller: "purchasing", method: "purchasing_rules_screen_delete"},
        {event: "purchasing_rules_file_delete_confirm", controller: "purchasing", method: "purchasing_rules_file_delete_confirm"},
        {event: "purchasing_rules_file_insert", controller: "purchasing", method: "purchasing_rules_file_insert"},
        {event: "purchasing_rules_file_delete", controller: "purchasing", method: "purchasing_rules_file_delete"},
        {event: "purchasing_rules_file_update", controller: "purchasing", method: "purchasing_rules_file_update"},
        {event: "get_purchasing_rules_more", controller: "purchasing", method: "get_purchasing_rules_more"},
        {event: "get_purchasing_rules_filter", controller: "purchasing", method: "get_purchasing_rules_filter"},
        {event: "get_files", controller: "purchasing", method: "get_files"},
        {event: "get_purchasing_reorder_info", controller: "purchasing", method: "get_purchasing_reorder_info"},
        {event: "get_reorder_calcs_submit", controller: "purchasing", method: "get_purchasing_reorder_info"},
	    {event: "purchasing_discontinued_popup", controller: "purchasing", method: "purchasing_discontinued_popup"},
        //Split Line
        //{event: "open_split_window", controller: "SplitLine", method: 'openWindow'}
	    {event: "open_split_window", controller: "SplitLine", method: 'getUOM'}
	],
	forms: [
		//{action: '#voucher-entry', controller: 'EntryNav', method: 'newVoucher'},
        {action: "#order-status-update", controller: "OrderStatus", method: "update"},
        {action: "#apply_orderview", controller: "OrderViews", method: "apply"},
        {action: "#save_view", controller: "OrderViews", method: "save_view_description"},
        {action: "#update_multi_unit", controller: "MultiUnit", method: "update_multi_unit"},
        {action: "#print_messages_form", controller: "PrintMessage", method: "sendprint"},
        {action: "#save_view", controller: "OrderViews", method: "save_view_description"},
        {action: "#reload_c3_scheduler_by_date", controller: "c3scheduler", method: "reload_c3_scheduler_by_date"},
        {action: "#reload_c3_scheduler_by_account", controller: "c3scheduler", method: "reload_c3_scheduler_by_account"},
        {action: "#reload_c3_scheduler_by_account_date", controller: "c3scheduler", method: "reload_c3_scheduler_by_account_date"},
        {action: "#update_multi_unit", controller: "MultiUnit", method: "update_multi_unit"},
        {action: "#get_purchasing_rules", controller: "purchasing", method: "get_purchasing_rules"},
        {action: "#get_reorder_calcs", controller: "purchasing", method: "get_reorder_calcs"},
        {action: "#execute_split_line", controller: "SplitLine", method: "execute_split"}
	],
	links: [
		{href: '#order_status_notepad/:orderid/:referenceid', controller: 'OrderStatus', method: 'notepad'},
		//views/filters/columns
		{href: '#save_column_view/:fm_file', controller: "OrderViews", method: "save_view"},
		//{href: '#load_view', controller: "View", method: "load"},
		{href: '#load_filter_view', controller: "OrderViews", method: "load_filter"},
		//{href: '#save_filter_view/:fm_file', controller: "Filter", method: "save_filter"},
		{href: '#load_default_view/:fm_file', controller: "OrderViews", method: "reset"},
		{href: '#delete_view', controller: "OrderViews", method: "remove"},
        {href: "#c3_schedule_edit", controller: "c3scheduler", method: "c3_schedule_edit"},
        {href: '#send_print_message', controller: "PrintMessage", method: "open"}
		//{href: '#clear_view/:fm_file', controller: "View", method: "reset"},
        //{href: '#modify_filter/:fm_file', controller: "Filter", method: "modify"},
		//{href: '#modify_columns/:fm_file', controller: "Columns", method: "modify"}
	]
});
