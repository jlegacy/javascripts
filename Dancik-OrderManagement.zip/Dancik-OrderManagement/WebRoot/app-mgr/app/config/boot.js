/*globals $App jQuery*/
(function ($) {
    $App.Boot(function () {
        //load app
        $App.Controller('Application').init();
        //???
        //$App.Controller("DWS.Growler").start(om_growler);
        //set dialog defaults
        $.extend($.ui.dialog.prototype.options, {
            dialogClass: 'dancik-dialog',
            resizable: false,
            draggable: false,
            minHeight: 0
        });
    });
})(jQuery);
