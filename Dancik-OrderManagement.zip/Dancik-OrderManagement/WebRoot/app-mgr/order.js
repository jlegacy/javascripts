/*globals $ $$ $App $F $H OM_Main Dancik_Model Messaging window OptionsDropdown
  AdditionalCharges ShippingCharges Dancik Element Form Ajax CashRegister_Popup
 PrintOrderOptions_Popup EditReason_Popup Dancik_ConfirmWindow OrderShipto_Popup
 MessageLines_Popup Dancik_OptionsWindow alert Popup_Search_ForITEM frameElement
 MultiEntry Event EJS AddItem ISO Popup_Search Dancik_RightClicks*/
// ***************************************************************************************************
var Main = Object.extend( OM_Main, {
	record : {},
	ajax : null,	
	config : null,
	
	optsWdw_Deleted : null,
	detailLines : [],
	
	hdrOptions : null,
	addItemWdw : null,
	hdrWdw : null,
		
	mode : { unprocessed : false, processed : false, rolledover : false },

	extendedview : false,
	
	model : null,
	
	user : '',
	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.initialize()
	// --------------------------------------------------------------------------------------------------- 
	initialize: function(usr) {
          var show_multi_unit;
		this.user = usr;
		Messaging.init("../../dws/");
		this.model = new Dancik_Model('../jsonservice/OM_WebService/execute');
                
                var url_params = window.location.search.toQueryParams();
		//console.log("url params -- ", url_params);
		// -- Load any initial settings.
		Main.setSettings({within_om : !Object.isUndefined(window.location.search.toQueryParams().om ) });

		// -- Execute any resizing, if necessary...
		Main.resize();
		
		// -- Prep-View
		Main.setSettings({editMode : false});
		
		// -- Build Order Options...
		Main.appOptions = new OptionsDropdown('available-options-container', {
		   menuActions: {
		      'option-1': function(){ Main.AvailableOptions.customerInformation(); },
		      'option-2': function(){ Main.AvailableOptions.jobEstimating(); },
		      'option-3': function(){ Main.AvailableOptions.orderDates(); },
		      'option-5': function(){ Main.AvailableOptions.installationScheduler(); },
		      'option-6': function(){ Main.AvailableOptions.openPrintWindow(); },
		      'additionalCharges': function() { new AdditionalCharges({referenceid: Main.record.header.reference ,orderid: Main.record.header.orderid }); },
		      'shippingCharges': function() { new ShippingCharges({referenceid: Main.record.header.reference ,orderid: Main.record.header.orderid }); },
		      'notepad' :  function() { Main.AvailableOptions.openNotepadWindow(); },
		      'orderstatus' :  function() { 
		    	  $App.Fire("order-status", {
		    		  orderid: Main.record.header.orderid, 
		    		  referenceid: Main.record.header.reference
		    	  });
		      }
				
				
		   }
		});
		
		// -- When the Header boxes are 'clicked', the forward to the Header window.
		$("Main_Header_Boxes").observe('click', Main.gotoHeader);
		
		// -- Get the Order...
		Main.getOrder({ firstload : true});

	//define and set order type if order type exists
		if (url_params.type) {
			switch (url_params.type) {
				case 'po': //Purchase Order
					show_multi_unit = false;
					break;
				case 's2s': //Stock-To-Stock
					show_multi_unit = false;
					break;
				default:
					show_multi_unit = true;
			}
		}
		//if defined and empty string
		//TODO: new orders do not have a defined order type. Suggest adding an
		//order type to prevent undefined variables from passing this conditional check 
		if (url_params.parm_OrderType || url_params.parm_OrderType == '') {
			switch (url_params.parm_OrderType) {
				case 'Q': //New Quote
					show_multi_unit = false;
					break;
				case 'D': //New Direct Ship Order
					show_multi_unit = false;
					break;
				default:
					show_multi_unit = true;
			}
		}

        //if order id does not exist and show_multi_unit flag is true
        //(used to determine if coming form a new order versus an edit order)
        if (!url_params.parm_OrderId && show_multi_unit) {
            //if customer is multi unit and ref ID exists
            if (url_params.multi_unit_customer.equals('Y') && url_params.parm_ReferenceId) {
                //open multi unit modal
                $App.Fire('multi_unit', {
                    omAccount: url_params.parm_AccountNum,
                    omReference: url_params.parm_ReferenceId
                });
            }
        }
                
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.Search()
	// --------------------------------------------------------------------------------------------------- 
		execute : function(e, opts) {
			Popup2Search.open(e, Object.extend({
				bufferLeft: 4,
				preload : true }, opts));		
		},
			shipvia : function (e) {
				this.execute(e, { title : 'Ship Via', file : 'ship_via', positionElement : 'parm_shipviaid', toElements : ['parm_shipviaid'], descriptionElement : 'shipvia_description' });
			},
			truckroute : function (e) {
				this.execute(e, { title : 'Truck Route', file : 'truck_route', positionElement : 'parm_truckrouteid', toElements : ['parm_truckrouteid'], descriptionElement : 'truckroute_description' });
			},
			
	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.getOrder()
	// --------------------------------------------------------------------------------------------------- 
	getOrder : function(opts) {
		var options = Object.extend({
			firstload : false,
			avoidToggle : false
		}, opts || {});
		
		if (Main.duplicateWindow) {
			Main.duplicateWindow.close();
			Main.duplicateWindow = null;
		}
		// -- Avoid multi-loading...
		Dancik.abortAjax( Main.ajax );
		
		// -- Show the Full-Screen "In-Process" blanket...
		Dancik.Blanket.InProcess.show({ message : 'Retrieving Order', sizeByStretch : true, zIndex : 100 });

		// -- Reset Main record...
		Main.record = {};
		
		// -- Hide those elements that should only be view when in edit mode....
		if (!Main.settings.editMode) { 
			$$('.only_show_in_editmode').each(function(o) { Element.hide(o); });
		}
		
		
		// -- Build parameters...
		var p = Object.extend( Form.serialize('Main_Form', true), { 
			serviceid : 'manager', 
			option : 'getOrder',
			random : new Date().getTime()
		});
		Main.ajax = new Ajax.Request('../jsonservice/OM_WebService/execute', {
			method: 'get', 
			parameters: p,	 
			evalJSON: "force",
			onInteractive:  function(res) {
				Dancik.Blanket.InProcess.setMessage("Building View");
			},
			onSuccess: function(res) {
				try {
			 		var json = res.responseJSON;
					if (!json) { throw 'EmptyResult'; }
					
					if ( json.errors != null) { throw 'ErrorCaught'; }
					
					Main.setSettings(json.settings); 
					if (!Main.settings  ||  Main.settings.use_jobestimates  != 'Y') {
						Element.hide('optionEstimating');
					}
					// -- Save Main record...
					Main.record = json;
					// -- If the Order is 'unprocessed'...
					if (Main.settings.unprocessed_mode == '1') {
						Main.mode.unprocessed = true;
						if (Main.settings.within_om) {
							Main.putIntoEditMode();
						}
						// -- Hide anything that is intended to be viewed only when not in unprocessed, only...
						$$('.not_allowed_in_unprocessed').each(function(o) { Element.hide(o); });
						
						
					// -- If the Order has been 'processed'...
					} else 	if (Main.settings.processed_mode == '1') {
						Main.mode.processed = true;
						// -- Hide anything that is intended to be viewed only when not in processed, only...
						$$('.not_allowed_in_processed').each(function(o) { Element.hide(o); });
						
						
					// -- If the Order has been 'rolled over'...
					} else  if (Main.settings.rolledover_mode == '1') {
						Main.mode.rolledover = true;
						$$(".not_allowed_in_rollover").each(function(o) { Element.hide(o); })
					}
					if (p.parm_directOrder =="Y"){
						$('parm_directOrder').value ="N";
						Main.gotoHeader();
					};
					if(Main.record.header.order_definition_id=="po") {
						//Purchse order does not have installation scheduler
						$("optionInstallationScheduler").hide();
						$("screenForMultiLineEntry").disable();    //pp1
					}
					
					if (!$App.Controller("Config").getConfig().user.allowAccessToTheUpdateOrderStatusAndShippingDataProgram) {
						$("optionOrderStatus").hide();
					}
					
					
					// -- Begin construction...
					Main.rebuildHeader(json);
					Main.rebuildDetails(json);
					Main.rebuildFooter(json);
					
					if (!json.header.credithold.blank() || !json.header.extra_message_05.blank()) {
						var warning_message1 = json.header.credithold,
							warning_message2 = json.header.extra_message_05;
						
						Main.show_credit_hold(warning_message1, warning_message2);
					}
//					if (!json.header.extra_message_05.blank()) {
//						Main.show_being_invoiced(json.header.extra_message_05);
//					}
					
					// --On new orders, of Stock2Stock and Purchase Orders, open the Header window, first, after getting the order...
					var neworder = window.location.search.parseQuery()['neworder'];
					if (options.firstload && neworder) {
						if (json.header.showheader_first_on_neworder = 'Y') {
							Main.gotoHeader();
						}
					}
					// --If the hide certain elements, based on the order definition code ('po', 's2s', 'qt', 'o')....
					$$('.noShow-' + json.header.order_definition_id).each(function(o) { o.hide(); });
					
					
					Main.settings.inventorySorts = [
					    {id: "LO", description: "Bin Location"},
					    {id: "QT", description: "Quantity/Size"},
					    {id: "SE", description: "Serial Number"},
					    {id: "SH", description: "Shade"},
					    {id: "SS", description: "Total Size/Qty of Shade (spanning warehouses)"},
					    {id: "ST", description: "Status Code"},
					    {id: "WA", description: "Warehouse"},
					    {id: "WS", description: "Total Size/Qty of Shade, within Warehouse"}
					];
					
					var userSettingsRequest = ["defaultSortForInventoryAnalysisScreen"];
					var systemSettingsRequest = [
                         "BOMOP.display_inventory",
                         "SHCOE.use_shipping_charges"
                     ];
					                             
					new Ajax.Request("../config?"+Object.toQueryString({user:userSettingsRequest,system:systemSettingsRequest}),{
						method: "get",
						onSuccess: function(res) {
							var json = res.responseJSON;
							$H(json).each(function(pair) {
								$H(pair.value).each(function(pair2) {
									Main.settings[pair2.key] = pair2.value;
								});
							});
							if(Main.settings.inventorySorts.pluck("id").indexOf(Main.settings.defaultSortForInventoryAnalysisScreen)>=0) {
								$("defaultSortForInventoryAnalysisScreen").value = Main.settings.defaultSortForInventoryAnalysisScreen;
							}
							if(Main.settings.SHCOE.use_shipping_charges!="Y") {
								$("availableOptionsShippingCharges").hide();
							}
							 
						}
					})
					
					// -- TODO: For testing purposes only., to eventually be taken out...
					if (Main.user.indexOf('mbayer') > -1) {
						$$('.dancik-use').each(function(o) { Element.show(o); });
					}
					
					// -- If the user is within Order Manager, then show certain fields/options/links from usage...
					if (Main.settings.within_om) {
						$$(".in_om_only").each(function(o) { Element.show(o); })
					}
					// -- When user is Not allowed to Order Change/Cancel options, then hide those links/buttons that will allow to the user to do so...
					if	(Main.settings.allow_to_orderchangecancel != 'Y') {
						$$('.not_allow_to_orderchangecancel').each(function(o) { Element.hide(o); });
					}
					
					// -- Hide things that should not be viewed in Inquiry mode...
					if (!Main.settings.editMode) {
						if	(Main.settings.allow_to_orderinquiry_toprint != 'Y') {
							$$('.print_option').each(function(o) { Element.hide(o); });
						}
					}
					
				} catch(e) {
					var contentHTML = "";
					var extraContentHTML = "";
					
					if (e == 'ErrorCaught') {
						contentHTML = "The following errors occurred:";
						var html = [];
						json.errors.each( function(msg) { html.push("<div>- " + msg + "</div>") } );
						extraContentHTML = html.join('');
					} else if (e == 'EmptyResult') {
						contentHTML = "No order information was found.";
					} else {
						contentHTML = "Error : Main.getOrder() :";
						extraContentHTML = "- " + e.message;
					}
					Main.open_ErrorWdw({
						contentHTML : contentHTML, 
						extraContentHTML : extraContentHTML, 
						afterClose : Main.close 
					});
											
				} finally {
					Dancik.Blanket.InProcess.kill();
				}
				
			 },
			 onFailure: Dancik.catchAjaxError
		});
	},
	getInvoice: function(invoice) {
		invoiceUrl = '../../invoicing/app-inv/#invoiceInquiryOM#' + invoice;
		top.$App.Fire('openURL', {
			url: invoiceUrl,
			title: "Invoice# " + invoice
		});

	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.toggleView()
	// --------------------------------------------------------------------------------------------------- 
	toggleView : function() {
		if (Main.extendedview) {
			Main.collapseView()
		} else {
			Main.extendView();
		}

		Main.rebuildDetails(Main.record, true);

	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.extendView()
	// --------------------------------------------------------------------------------------------------- 
	extendView : function() {
		Main.extendedview = true;
		
		$('Collapse_Bttn').show();
		$('Expand_Bttn').hide();
		$('od-Data-Left').removeClassName('grid');
		$('od-Data-Right').removeClassName('grid');
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.collapseView()
	// --------------------------------------------------------------------------------------------------- 
	collapseView : function() {
		Main.extendedview = false;
		
		$('Collapse_Bttn').hide();
		$('Expand_Bttn').show();
		$('od-Data-Left').addClassName('grid');
		$('od-Data-Right').addClassName('grid');

	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.resize()
	// --------------------------------------------------------------------------------------------------- 
	resize : function() {
		var h = Dancik.getDocumentHeight();
		var w = Dancik.getDocumentWidth();
		// - Avoid errors due to obviously ridiculous resizing... 
		if (h<200 || w<200) { return; }
		
		var hdrsLeftWidth = $('od-Hdrs-Left').getWidth();
		
		$('od-XScroll').style.left = (hdrsLeftWidth) + "px"; 
		$('od-Data-Right').style.left = (hdrsLeftWidth) + "px";
		$('od-Hdrs-Right').style.left = (hdrsLeftWidth) + "px";

		$('Main_EndOrderIframe').style.height = Element.getHeight('Main_EndOrderSection') + 'px'; 
		
		Dancik.Blanket.Full.resize();
	},
	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.close()
	// --------------------------------------------------------------------------------------------------- 
	close: function(resetSearch) {
		if (parent && parent.Main && parent.Main.Orders && parent.Main.Orders.closeOrderFrame) {
			parent.Main.Orders.closeOrderFrame(resetSearch);
		}
	},


	// -------------------------------------------------------------------------------
	// -- Main.openEndOrderFrame()
	// -------------------------------------------------------------------------------
	openEndOrderFrame : function() {
		// -- Show the Full-Screen "In-Process" blanket...
		Dancik.Blanket.InProcess.show({ message : 'Validating Order', sizeByStretch : true });
		
		var _this = this;	
		var params = { 
			parm_ReferenceId : Main.record.header.reference, 
			parm_OrderId : Main.record.header.orderid 
		};
		
		var model = new Dancik_Model('../api/validateBeforeEndOfOrder');
 		model.get( params , function(is_success, json) {	
 			try{
				// -- If errors are returned, then display and exit...
				if (json.errors != null) {
					var html = []; json.errors.each( function(err) { html.push("<li> - " + err.errmsg + "</li>") } );
					
					Main.open_ErrorWdw({ 
						contentHTML : "The following errors occurred:",
						extraContentHTML : '<ul class="error-list">' + html.join('') + '</ul>',
						onConfirm : function() { Dancik.Blanket.InProcess.kill(); Main.gotoHeader(); }
					});
				} else {
					
					// -- If instructed to open Cash Register...
					if ( json.show_cashregister == 'Y' ) {
//						var maxwidth=918;
//						var maxheight=540;
//						var dh = Dancik.getDocumentHeight()-60;
//						var dw = Dancik.getDocumentWidth()-60;
//						var h = (dh >= maxheight) ? maxheight : dh;
//						var w = (dw >= maxwidth) ? maxwidth : dw;
//						var params1 = { 
//							parm_ReferenceId : Main.record.header.reference, 
//							parm_OrderId : Main.record.header.orderid 
//						};
//						_this.OM_CR_Popup = new Dancik_ConfirmWindow({ 
//							color : "blue",
//							showAsPopup : true,
//							popupTitle  : 'Complete Order',
//							destroyOnClose : true,
//							modal : true,
//							message : '<iframe src="../app-mgr-cashregister/index.jsp?' + Object.toQueryString(params1) + '" frameborder="0" width="' + (w) + 'px" height="' + (h) + 'px;"></iframe>',
//							buttons : {},
//							beforeOpen : function() { Dancik.Blanket.InProcess.kill(); }
//						});
//						_this.OM_CR_Popup.open();
						
						new CashRegister_Popup({ 
								parm_ReferenceId : Main.record.header.reference, 
								parm_OrderId : Main.record.header.orderid 
							}, {
								afterSubmit : function() {
									Main.close();
								}
							}						
						);
						
					} else {
						new PrintOrderOptions_Popup({ 
							parm_referenceid : Main.record.header.reference, 
							parm_orderid : Main.record.header.orderid,
							editmode : Main.settings.editMode
						}, {
							beforeOpen : function() { 
								Dancik.Blanket.InProcess.kill(); 
							},
							afterSubmit : function() {
								Main.close();
							}						
						});
					}
					
				}
			} catch (e) { 
				Main.open_ErrorWdw({ contentHTML : "Error : Main.openEndOrderFrame() :", extraContentHTML : "- " + e.message});
			}
			Dancik.Blanket.InProcess.hide();
    	});
		
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.closeEndOrderFrame()
	// --------------------------------------------------------------------------------------------------- 
	closeEndOrderFrame : function() {
		Element.show('Main_Details');
		Element.show('Main_Footer');
		Element.hide('Main_EndOrderSection');
		$('Main_EndOrderIframe').src = "about:blank";
		
		Dancik.Blanket.Full.kill();
	},
	
	
	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.rebuildHeader()
	// --------------------------------------------------------------------------------------------------- 
	rebuildHeader: function(json) {
		if (!json.header) { return; }
		
		$('title_OrderTypeDescription').update(json.header.order_type_description);
		$('title_OrderTypeImg').src = '../images/icons/' + json.header.order_type_img + '.png';
		
		$('title_ReferenceId').update( "Reference#: " + json.header.reference );
		$('parm_referenceid').value = json.header.reference;
		
		$('title_OrderId').update();
		if (json.header.orderid && !json.header.orderid.isEmpty()) {
			$('title_OrderId').update("Order#: " + json.header.orderid);
			$('parm_orderid').value = json.header.orderid;
		}
		if (json.header.order_lock_flag =="Y") {
			$('order_locked_icon').show();
		}
		$('oeHdr_Box1_Ttl').update( json.header.billingaccount );
		$('oeHdr_Box3_Ttl').update( json.header.orderdate );
		$('oeHdr_Box4_Ttl').update( json.header.enterdate );
		
		
		// -- Main Address
		$('oeHdr_Box1_Data').update();
		var html = [];
		html.push(json.header.billingaccount_name.trim())
		// -- To avoid showing the BillTo name twice...
		if (!json.header.billingaccount_name.equals(json.header.main_name)) {
			html.push(json.header.main_name.trim())
		}
		html.push(json.header.main_address1.trim());
		html.push(json.header.main_address2.trim());
		html.push(json.header.main_city + ", " + json.header.main_state + "  " + json.header.main_zip);
		html.push(json.header.main_phone1.trim()); 
		$('oeHdr_Box1_Data').update( html.without("").join("<br/>") );
		
		// -- Shipping Address
		$('oeHdr_Box2_Data').update();
		html = [];
		html.push(json.header.ship_name.trim());
		html.push(json.header.ship_address1.trim());
		html.push(json.header.ship_address2.trim());
		html.push(json.header.ship_city + ", " + json.header.ship_state + "  " + json.header.ship_zip);
		html.push(json.header.ship_phone1.trim());
		$('oeHdr_Box2_Data').update( html.without("").join("<br/>") );
		
	
		$('oeHdr_Box3_1').update( json.header.customerpo_with_extension );
		$('oeHdr_Box3_2').update( json.header.jobname );
		$('oeHdr_Box3_3').update( json.header.shipdate );
		$('oeHdr_Box3_4').update( json.header.shipviaid );
		$('oeHdr_Box3_5').update( json.header.initials );
		
		$('oeHdr_Box4_1').update( json.header.salespersonid1 );
		$('oeHdr_Box4_2').update( json.header.salespersonid2 );
		$('oeHdr_Box4_3').update( json.header.branchid );
		$('oeHdr_Box4_4').update( json.header.warehouseid );
		$('oeHdr_Box4_5').update( json.header.supplierid );

		
		// -- Populate the "Messages" box...
		if (!json.total) { return; }
		if (json.header.extra_message_01 != '') {
			$('box-message1').update( json.header.extra_message_01);
			var the_char=$('box-message1').innerHTML.replace(/^\s\s*/, '').charAt(0);
			if (the_char =="*"){
					$('box-message1').addClassName("important_message");
				}
		}
		if (json.header.extra_message_02 != '') {
			$('box-message2').update( json.header.extra_message_02);
			var the_char=$('box-message2').innerHTML.replace(/^\s\s*/, '').charAt(0);
			if (the_char =="*"){
					$('box-message2').addClassName("important_message");
				}
		}
		if (json.header.extra_message_03 != '') {
			$('box-message3').update( json.header.extra_message_03);
			var the_char=$('box-message3').innerHTML.replace(/^\s\s*/, '').charAt(0);
			if (the_char =="*"){
					$('box-message3').addClassName("important_message");
				}
		}
		if (json.header.extra_message_04 != '') {
			$('box-message4').update( json.header.extra_message_04);
			var the_char=$('box-message4').innerHTML.replace(/^\s\s*/, '').charAt(0);
			if (the_char =="*"){
					$('box-message4').addClassName("important_message");
				}
		}
		if (json.header.extra_message_06 != '') {
			$('box-message6').update( json.header.extra_message_06);
			var the_char=$('box-message4').innerHTML.replace(/^\s\s*/, '').charAt(0);
			if (the_char =="*"){
					$('box-message4').addClassName("important_message");
				}
		}
	},
	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.rebuildDetails()
	// --------------------------------------------------------------------------------------------------- 
	rebuildDetails : function(json, avoidToggle) {
		$('od-Data-Left-TBODY').update();	
		$('od-Data-Right-TBODY').update();	

		if (!json.details) { return; }
		
		// -- Put screen into expand mode...
		if ( !avoidToggle ) {
			Main.extendView();
		}
		
		var html1 = [];
		var html2 = [];

		var previousPrime = 0;
		var iCls = 0;
		
		Main.detailLines = [];
		// -- Make sure that 'details' was added to the results...
		if (json.details) {
			var len = json.details.length;
			for (var i=0; i<len; i++) {
				// -- Avoid non-D records if not in Extended view mode...
				if (!Main.extendedview && json.details[i].id != 'D') { continue; } 
				
				var newPrime = parseInt(json.details[i].line / 10);
				if (previousPrime != newPrime) {
					iCls++;
				}
				// -- Save records, for later usage...
				Main.detailLines[Main.detailLines.length] = json.details[i];
				
				// -- Build the ROW classname...
				var cls = '';
				if (json.details[i].deletecode && json.details[i].deletecode.equals("D")) {
					cls = 'deleted';
				} else if ((iCls%2)==0) {
					cls = 'hi';
				} else {
					cls = 'lo';
				}

				previousPrime = newPrime;
				// -- If loading a Message Line, and there is no foreign currency code to load, then use alternate class....
				if (!json.details[i].id.equals('D') &&  json.total.curexc_code == '') {
					cls += ' no-fc';
				}
				
				html1.push("<tr class='" + cls + "'>");
					html1.push("<td>");
						html1.push("<div class='od-col-opts'>");
							if (json.details[i].id.equals('D')) {
								if (json.details[i].deletecode && json.details[i].deletecode.equals("D") ) {	
									html1.push("<img src='../images/icons/lineDeleted.png' class='loneOption' alt='Available Options : Line " + json.details[i].line + "' onclick='Main.Options.openDeleted(this, " + (Main.detailLines.length-1) + ");'/>");
								} else {
									html1.push("<img src='../../dws/images/option_arrow.png' class='loneOption' alt='Available Options : Line " + json.details[i].line + "' onclick='Main.Options.open(this, " + (Main.detailLines.length-1) + ");'/>");
								}
							}
						html1.push("</div>");
					html1.push("</td>");
					html1.push("<td>");
						html1.push("<div class='od-col6' style='text-align:center;'>");
							if (json.details[i].id.equals('D')) {
								html1.push( json.details[i].line ); 
							} else {
								html1.push("<span class='dws-contextlink' onclick='Main.openMsgLines(" + json.details[i].line + ");'>" + json.details[i].line + "</span>");
							}
						html1.push("</div>");
					html1.push("</td>");
					
					
					html1.push("<td" + (json.details[i].id.equals('D') ? "" : " colspan='2'") + ">");
						html1.push("<div class='" + (json.details[i].id.equals('D') ? "od-col1" : "od-col1-msg") + "'>");
							if (json.details[i].id.equals('D')) {
								html1.push("<span class='dws-contextlink' onclick='Main.ItemOptions.open(this);'>" + json.details[i].item + "</span>");
										if (json.details[i].special_item =="Y"){
											//if header exists - fix for EVNT 28FM
											if (json.header) {
												if (json.header.orderid == json.details[i].special_po_number) {
													html1.push("<span class='specialPO dws-contextlink' onclick='Main.ItemOptions.openSpecialOrder(" + json.details[i].special_order_number + ");'><img src='../../dws/images/icons/pobo.png' alt='Special Order PO#'>" + json.details[i].special_order_number + "</span>");
												} else if (json.header.orderid == json.details[i].special_order_number) {
													html1.push("<span class='specialPO dws-contextlink' onclick='Main.ItemOptions.openSpecialOrder(" + json.details[i].special_po_number + ");'><img src='../../dws/images/icons/pobo.png' alt='Special Order PO#'>" + json.details[i].special_po_number + "</span>");
												}
											}
										}
								html1.push("<div style='padding-left:5px;'>" + json.details[i].item_description + "</div>");
								html1.push("<div style='padding-left:5px;'>" + json.details[i].item_description2 + "</div>");
							} else {
								html1.push( json.details[i].message001 );
							}
						html1.push("</div>");
					html1.push("</td>");
					
					if (json.details[i].id.equals('D')) {
						html1.push("<td>");
							html1.push("<div class='od-col2' style='text-align:right;'>");
								if (json.details[i].id.equals('D')) {
									html1.push(json.details[i].qtyordered + " " + json.details[i].uom);
									if (json.details[i].slab_flag == 'Y') {
										html1.push("<br/><span class='foreigncurrency'>" + json.details[i].slab_details + "</span>" );
									} else if (json.details[i].laminate_flag == 'Y') {
											html1.push("<br/><span class='foreigncurrency'>" + json.details[i].laminate_details + "</span>" );
									} else if (json.details[i].qtyordered_in_feetinches != '') {
										html1.push("<br/><span class='foreigncurrency'>" + json.details[i].qtyordered_in_feetinches + "</span>" );
									}
								}
							html1.push("</div>");
						html1.push("</td>");
					}
					html1.push("<td>"); 
						html1.push("<div class='od-col4' style='text-align:right;'>");
							if	(Main.settings.fund_option == '1') {
								html1.push(json.details[i].price_plus_fund_peruom );
							} else if (Main.settings.fund_option == '3'  && json.details[i].fundflag_seperate_dollars == 'N') {
								html1.push(json.details[i].price_plus_fund_peruom );
							} else {
								html1.push(json.details[i].priceperuom );
							}
							if (json.total.curexc_code != '') {
								html1.push("<br/><span class='foreigncurrency'>" + json.details[i].curexc_price + " " + json.total.curexc_code + "</span>" );
							}
						html1.push("</div>");
					html1.push("</td>");
					
					html1.push("<td>");
						html1.push("<div class='od-col5' style='text-align:right;'>");
							if ( (json.details[i].id == 'D')  &&  (json.details[i].status_is_cancelled != 'Y' )) {
								html1.push(json.details[i].totalextendedprice);
								if (json.total.curexc_code != '') {
									html1.push("<br/><span class='foreigncurrency'>" + json.details[i].curexc_extendedprice + " " + json.total.curexc_code + "</span>");
								}
							}
						html1.push("</div>");
					html1.push("</td>");
				html1.push("</tr>");
				
				
				html2.push("<tr class='" + cls + "'>");
				    html2.push("<td><div class='od-col6'>&nbsp;</div>");
					html2.push("<div class='od-col6'>" + json.details[i].warehouse + "</div>");
					html2.push("<div class='od-col6'>&nbsp;</div></td>")
					html2.push("<td>");
						html2.push("<div class='od-col6a' style='text-align:left;'>");
							if (json.details[i].id.equals('D')) {
								if (json.details[i].invoice_number != '0') {
									if (json.details[i].statusdescription == "OPEN") {
										html2.push( "Open/Partially Invoiced" );
									} else {
										html2.push( json.details[i].statusdescription );
									}
								} else {
									html2.push( json.details[i].statusdescription );	
								}
								
								if (json.details[i].invoice_number != '0') {
									if (json.header.accountid !== '00002' && json.header.accountid !== '00001' ){
										html2.push("&nbsp");
										html2.push("<span class='dws-contextlink' onclick='Main.getInvoice(" + json.details[i].invoice_number + ")'>");
										html2.push(json.details[i].invoice_number);
										html2.push("</span>");
									}
									else {
										html2.push("&nbsp");
										html2.push("<span" + json.details[i].invoice_number + ">");
										html2.push(json.details[i].invoice_number);
										html2.push("</span>");
									}
								}
								
								if (json.details[i].statusdescription != ''  &&  json.details[i].extra_message_01 != '') {
									html2.push("<br/>");
								}
								html2.push( json.details[i].extra_message_01 );
							}
						html2.push("</div>");
					html2.push("</td>");
					html2.push("<td><div class='od-col7'>" + json.details[i].serialnumber + "</div></td>");
					html2.push("<td><div class='od-col8'>" + json.details[i].location + "</div></td>");
					html2.push("<td><div class='od-col8'>" + json.details[i].rollsshdlt + "</div></td>");
					html2.push("<td>");
						html2.push("<div class='od-col8a' style='text-align:right;'>");
							if ( (json.details[i].id.equals('D'))  &&  (json.details[i].status_is_cancelled != 'Y' )) {
								if (json.details[i].qtyorderedweight != '') {
									html2.push(json.details[i].qtyorderedweight + " LB");
								}
							}
						html2.push("</div>");
					html2.push("</td>");
					//if header exists - fix for EVNT 28FM
					if (json.header) {
						if (json.header.supplier !== '001') {
							html2.push("<td><div class='od-col8b'>" + json.details[i].quantity_received + "</div></td>");
							html2.push("<td><div class='od-col8c'>" + json.details[i].quantity_pre_receipts + "</div></td>");
							html2.push("<td><div class='od-col8d'>" + json.details[i].receipt_associated + "</div></td>");
						} else {
							$("qty_rcvd").hide();
							$("qty_rcpts").hide();
							$("rcpt_assoc").hide();
						}
						if (json.header.supplier == '001') {
							html2.push("<td><div class='od-col8e'>" + json.details[i].quantity_shipped + "</div></td>");
						} else {
							$("qty_shpd").hide();
						}
					}
				
					html2.push("<td><div class='od-col8f'>" + json.details[i].quantity_open + "</div></td>");
					html2.push("<td><div class='od-col9'>" + json.details[i].pricerestrictioncode + "</div></td>");
					html2.push("<td><div class='od-col10' style='text-align:left;'>");
					if (json.details[i].id.equals('D')) {
							html2.push( json.details[i].message001 );
						}
					html2.push("</div></td>");
					html2.push("<td><div class='od-col11' style='text-align:left;'>" + json.details[i].received + "</div></td>");
					html2.push("<td><div class='od-col27'>" + json.details[i].isoselected + "</div></td>");
					html2.push("<td><div class='od-col12'>" + json.details[i].shipdate + "</div></td>");
					html2.push("<td><div class='od-col13'>" + json.details[i].restockingchargepercent + "</div></td>");
					html2.push("<td><div class='od-col14'>" + json.details[i].creditcode + "</div></td>");
					if	(Main.settings.allow_to_viewcosts == 'Y') {
						html2.push("<td>");
							html2.push("<div class='od-col4a' style='text-align:right;'>");
								html2.push( json.details[i].costperuom );
								// (json.total.curexc_code != '') {
								//tml2.push("<br/><span class='foreigncurrency'>" + json.details[i].curexc_cost + " " + json.total.curexc_code + "</span>");
								//
							html2.push("</div>");
						html2.push("</td>");
						html2.push("<td>");
							html2.push("<div class='od-col5a' style='text-align:right;'>");
								if (json.details[i].id.equals('D')) {
									html2.push(json.details[i].totalextendedcost);
									//if (json.total.curexc_code != '') {
									//	html2.push("<br/><span class='foreigncurrency'>" + json.details[i].curexc_extendedcost + " " + json.total.curexc_code + "</span>" );
									//}
								}
							html2.push("</div>");
						html2.push("</td>");
						html2.push("<td>");
							html2.push("<div class='od-col4b' style='text-align:right;'>");
							if (json.details[i].id.equals('D')) {
								html2.push(json.details[i].extendedmarginpercent);
							}
							html2.push("</div>");
						html2.push("</td>");
						html2.push("<td>");
							html2.push("<div class='od-col5b' style='text-align:right;'>");
							if (json.details[i].id.equals('D')) {
								html2.push(json.details[i].extendedmargin);
							}
							html2.push("</div>");
						html2.push("</td>");
					}
					html2.push("<td><div class='od-col15'>" + json.details[i].pricepgm + "</div></td>");
					html2.push("<td><div class='od-col16' style='text-align:right;'>" + json.details[i].priceallowance + "</div></td>");
					if	(Main.settings.allow_to_viewcosts == 'Y') {
						html2.push("<td><div class='od-col15'>" + json.details[i].costpgm + "</div></td>");
						html2.push("<td><div class='od-col17' style='text-align:right;'>" + json.details[i].costallowance + "</div></td>");
					}
					html2.push("<td><div class='od-col15'>" + json.details[i].fundpgm + "</div></td>");
					html2.push("<td><div class='od-col22' style='text-align:right;'>" + json.details[i].fund + "</div></td>");
					html2.push("<td><div class='od-col18'>" + json.details[i].points + "</div></td>");
					html2.push("<td><div class='od-col18'>" + json.details[i].points_extended + "</div></td>");
					html2.push("<td><div class='od-col15'>" + json.details[i].marketingpgm + "</div></td>");
					html2.push("<td><div class='od-col19'>" + json.details[i].termscode + "</div></td>");
					html2.push("<td><div class='od-col20'>" + json.details[i].pricemethod + "</div></td>");
					html2.push("<td><div class='od-col21'>" + json.details[i].pricelist + "</div></td>");
					html2.push("<td><div class='od-col23'>" + json.details[i].special_directship + "</div></td>");
					html2.push("<td><div class='od-col24'>" + json.details[i].special_fob + "</div></td>");
					html2.push("<td><div class='od-col25'>" + json.details[i].special_shipvia + "</div></td>");
					html2.push("<td><div class='od-col26'>" + json.details[i].special_supplier + "</div></td>");
					html2.push("<td><div class='od-col1'>" + json.details[i].item_description2 + "</div></td>");
				html2.push("</tr>");
			}
			$('od-Data-Left-TBODY').update( html1.join("") );
			$('od-Data-Right-TBODY').update( html2.join("") );
		}

		$('od-YScroll-Inner').style.height = ($('od-Data-Right-TABLE').getHeight()) + "px";
		$('od-XScroll-Inner').style.width = ($('od-Data-Right-TABLE').getWidth()) + "px";
	},
	
	// ---------------------------------------------------------------------------------------------------
	// - Function : Main.rebuildFooter()
	// --------------------------------------------------------------------------------------------------- 
	rebuildFooter : function(json) {
		if (!json.total) { return; }
		if (json.total.handledescription == '' ) {
			$('handlingCharge').hide();
		}
		$('Footer_ItemTotal').update( json.total.purchaseamount || '0.00' );
		$('Footer_TermsDiscount').update( json.total.discount || '0.00' );
		$('Footer_HandlingCharge').update( json.total.handleamount || '0.00' );
		$('Footer_HandlingDescription').update( json.total.handledescription);
		$('Footer_Tax').update( json.total.tax || '0.00' );
		$('Footer_GrandTotal').update( json.total.ordertotal || '0.00' );
		$('Footer_BalanceDue').update( json.total.balancedue || '0.00' );
		$('Footer_Freight').update( json.total.freightcharge|| '0.00' );
		$('Footer_PaidPrev').update( json.total.previouslypaid|| '0.00' );
		$('Footer_TotalWeight').update( json.total.weight +" LB" || '0' +" LB" );
		
		// -- If Foreign Currency is not used, then hide it.  Else, populate...
		if (json.total.curexc_code == '') {
			Element.select($('Footer_Totals'), '.foreigncurrency').each(function(o){
				Element.hide(o);
			});
		} else {
			Element.select($('Footer_Totals'), '.foreigncurrency').each(function(o){
				(o).setStyle({minWidth:'50px'});
			});
			Element.select($('Footer-Summary'), '.foreigncurrency').each(function(o){
				(o).setStyle({minWidth:'50px'});
			});
			$('Footer_ItemTotal_FC').update( json.total.curexc_purchaseamount || '0.00' );
			$('Footer_TermsDiscount_FC').update( json.total.curexc_discount || '0.00' );
			$('Footer_HandlingCharge_FC').update( json.total.curexc_handleamt || '0.00' );
			$('Footer_Tax_FC').update( json.total.curexc_tax || '0.00' );
			$('Footer_GrandTotal_FC').update( json.total.curexc_ordertotal || '0.00' );
			$('Footer_BalanceDue_FC').update( json.total.curexc_balancedue || '0.00' );
			$('ForeignCurrency_Code').update( json.total.curexc_code );
			$('Footer_Freight_FC').update( json.total.curexc_freightcharge|| '0.00' );
			$('Footer_PaidPrev_FC').update( json.total.curexc_previouslypaid|| '0.00' );
			$('Footer_TotalWeight').update( json.total.weight +" LB"|| '0' +"LB");
		}
		if (json.settings) {
			if (json.settings.use_retailenvironment !=='Y'){
				$('balance_due').hide();
			} 
		}
		if (json.header) {  // EVNT26HM
			if (json.header.termsdays =='3' || json.header.termsdays =='5'){
				$('balance_due').show();
			} 			
		}
		
				
	},

	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.gotoHeader()
	// --------------------------------------------------------------------------------------------------- 
	gotoHeader: function() {
		var params = Object.extend(Form.serialize('Main_Form', true), { 
			parm_AccessMode : (Main.settings.editMode ? '*EDIT' : '') 
		});
		
		var opts = {};
		if (Main.settings.editMode) {
			opts = Object.extend(opts, { afterClose : function() { Main.getOrder({avoidToggle:true}); }});
		}
		
		Main.openHeaderWdw(params, opts);
	},
	
	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.openEditOrderWdw()
	// --------------------------------------------------------------------------------------------------- 
	openEditOrderWdw: function() {
		new EditReason_Popup({parm_referenceid:$F('parm_referenceid'), parm_orderid:$F('parm_orderid'), parm_mode:'EDIT'}, {
			title : true,
			popupTitle: "Reason for Editing Order",
			afterContinue : function() { Main.putIntoEditMode(); }
		});
	},		
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.openCancelOrderWdw()
	// --------------------------------------------------------------------------------------------------- 
	openCancelOrderWdw: function() {
		if (Main.mode.unprocessed) {			
			Main.openCancelConfirmWdw(); 
		} else {
			new EditReason_Popup({parm_referenceid:$F('parm_referenceid'), parm_orderid:$F('parm_orderid'), parm_mode:'CANCEL'}, {
				title : true,
				popupTitle: "Reason for Canceling Order",
				afterContinue : function() {
					Main.putIntoEditMode();
					Main.openCancelConfirmWdw(); 
				}
			});
		}
	},	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.openCancelConfirmWdw()
	// --------------------------------------------------------------------------------------------------- 
	openCancelConfirmWdw: function() {
		new Dancik_ConfirmWindow({
			color:"yellow",
			content: 'You have selected to cancel this order.',
			modal:true,
			onConfirm: function() { Main.cancelOrder(); }
		}).open();
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.cancelOrder()
	// --------------------------------------------------------------------------------------------------- 
	cancelOrder: function(execAfter) {
		
		// -- Show the Full-Screen "In-Process" blanket...
		Dancik.Blanket.InProcess.show({ message : 'Cancel Order in Progress', sizeByStretch : true, zIndex : 100000 });
		
		// -- Build parameters...
		var params = Object.extend( Form.serialize('Main_Form', true), { 
			serviceid : 'manager', 
			option : 'cancelOrder', 
			random : new Date().getTime() 
		});			

		Main.model.update(params, 
			function(is_success, json) {
				try{
					if (!json) { throw 'EmptyResult'; }
					
					if ( json.errors != null) { throw 'ErrorCaught'; }
					
					
					
					// -- Cancel was successful, not return to Order Search...
					if (typeof(execAfter)=="function") {
						execAfter();
					} else {
						Dancik.Blanket.InProcess.kill();
						new Dancik_ConfirmWindow({
							color:"yellow",
							content: 'Order is tagged for cancellation.',
							showAsInfoOnly:true,
							modal:true,
							onConfirm: function() {
								Main.close(true);}
						}).open();	
					}
				} catch(e) {
					var contentHTML = "";
					var extraContentHTML = "";
					var html = [];
					
					if (e == 'ErrorCaught') {
						contentHTML = "The following errors occurred:";
						json.errors.each( function(msg) { html.push("<li> - " + msg + "</li>") } );
						extraContentHTML = '<ul class="error-list">' + html.join('') + '</ul>';
					} else if (e == 'EmptyResult') {
						contentHTML = "No order information was found.";
					} else {
						contentHTML = "Error : Main.cancelOrder() :";
						extraContentHTML = "- " + e.message;
					}						
					Main.open_ErrorWdw({ contentHTML : contentHTML, extraContentHTML : extraContentHTML });
				} finally {
					Dancik.Blanket.InProcess.kill();
				}
			}
		);				
	},
//	show_being_invoiced: function (message) {
//		$('Main_Being_Invoiced_Message').show().update(message);
//		$('Main_Header').setStyle({top: '61px'});
//		$('Main_Body').setStyle({top: '190px'});
//	},
//	hide_being_invoiced: function () {
//		$('Main_Being_Invoiced_Message').hide();
//		$('Main_Body').setStyle({bottom: '108px'});
//	},
	show_credit_hold: function (message1, message2) {
			$('Main_Credit_Hold_Message').show().update(message1+"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"+message2);
			$('Main_Body').setStyle({top: (169 + 2 + $('Main_Credit_Hold_Message').getHeight()) + 'px'});
	},
	hide_credit_hold: function () {
		$('Main_Credit_Hold_Message').hide();
		$('Main_Body').setStyle({top: null});
	},
	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.putIntoEditMode()
	// --------------------------------------------------------------------------------------------------- 
	putIntoEditMode: function() {
		Main.setSettings({editMode : true});

		Element.hide('link_PutIntoEditMode');
		$("Main_AddItem").show();
		$('Main_Details').setStyle({top:($("Main_AddItem").getHeight() - 1) + 'px'});
		
		if (Main.mode.processed == true) {
			// -- Hide anything that is intended to be viewed only when in display-mode, only...
			$$('.not_allowed_in_processed_editmode').invoke('hide');
		}
		
		$$('.only_show_in_editmode').invoke('show');
		
		$$('.displaymode_only').invoke('hide');
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.openShipToPopup()
	// --------------------------------------------------------------------------------------------------- 
	openShipToPopup: function() {
		new OrderShipto_Popup(
			{ parm_referenceid:$F('parm_referenceid'), parm_orderid:$F('parm_orderid') }, 
			{ afterUpdate : function() { Main.getOrder({avoidToggle:true}); } }
		).open();
		
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.openMsgLines()
	// --------------------------------------------------------------------------------------------------- 
 	openMsgLines: function(line) {
 		new MessageLines_Popup({ 
 			parm_referenceid : $F('parm_referenceid'), 
 			parm_orderid : $F('parm_orderid'), 
 			parm_line : line
 		}, {
 			editmode : Main.settings.editMode,
 			afterUpdate : function() { Main.getOrder({avoidToggle:true});  }
 		}).open();
 	},	
	// ---------------------------------------------------------------------------------------------------
	duplicateOrderOptions: function(element,jsonString) {
		var json = jsonString.evalJSON();
		if(!Main.dOptionsWdw) {
			Main.dOptionsWdw = new Dancik_OptionsWindow({ 
				style : 'width:175px;z-index:50000;',
				title : 'Available Options'
			});
		}
		Main.dOptionsWdw.removeOptions();
		Main.dOptionsWdw.setTitle(json.referencetext);			
		Main.dOptionsWdw.addOption({ title : "View", icon : "../../dws/images/clear.gif", action : function () { alert("Inquire order not implemented yet.") } } );
		Main.dOptionsWdw.addOption({ title : "Delete current and switch", icon : "../../dws/images/clear.gif", action : function() { Main.switchOrderConfirm(json,true); } });
		Main.dOptionsWdw.addOption({ title : "Leave current and switch", icon : "../../dws/images/clear.gif", action : function() { Main.switchOrderConfirm(json); } });

		Main.dOptionsWdw.open(element);
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.switchOrder()
	// --------------------------------------------------------------------------------------------------- 
	switchOrderConfirm: function(json,withDelete) {
		//Warning: You have requested to exit the current order (and
		//leave "as is"), and then you will be redirected to the    
		//selected order.
		
		//Warning: You have requested that your current order should 
		//be deleted, and that you will be redirected to the selected
		//order.
		var action =  withDelete?"delete":"close";   
		var msg = "You have requested to "+action+" this order<br/>"+
				  "and open the selected order.";                                                                                            
		
		new Dancik_ConfirmWindow({
			color:"yellow",
			content: msg,
			modal:true,
			zIndexModal: 50001,
			onConfirm: function() {
				Main.switchOrder(json,withDelete);
			}
		}).open();
		
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.switchOrder()
	// --------------------------------------------------------------------------------------------------- 
	switchOrder: function(json,withDelete) {
		if(withDelete) {
			//alert("delete not implemented yet");
			//ajax request to delete this order, then call switch order
			Main.cancelOrder(function() {Main.switchOrder(json)});
			return;
		}
		
		if(json.orderrefnum!="0") {
			new Dancik_ConfirmWindow({
				content: "Please refer to your Quote Management System to view this quote.",
				showAsInfoOnly:true,
				modal:true,
				onConfirm: function() {
					Main.close(true)
				}
			}).open();
			return;
		}
		
		var url = frameElement.src;
		url = url.replace(/parm_ReferenceId=\d*&?/,"").replace(/parm_OrderId=\d*&?/,"");
		if(json.referencenumber!=0) {
			url = url+"&parm_ReferenceId="+json.referencenumber;
		} else {
			url = url+"&parm_OrderId="+json.ordernumber;
		}
		frameElement.src = url;
	},
	searchItem: function(e) {
		var event = e || window.event;
		var element = Event.element(e);
		var parent = element.up();
		var input = parent.down("input");
		
		Popup_Search_ForITEM.open(event, { 
			blanketStretchBySize : true, 
			toElements : [ input ]
		});
	},
	multiEntryOnDemand: function() {
		var form = $("addItemForm");
		var data = Object.extend(form.serialize(true));
		
		if(data.item.blank()) {
			new MultiEntry();
		} else {
			data.flag_bom = "Y";
			Main.handleAddItem(data);
		}
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.handleAddItemForm()
	// --------------------------------------------------------------------------------------------------- 
	handleAddItemFormEvent: function(event) {
		Event.stop(event);
		Main.handleAddItemForm();
	},
	handleAddItemForm: function(opts) {
		var form = $("addItemForm");
		var data = Object.extend(form.serialize(true),opts || {});
		
		Main.handleAddItem(data);
		
	},
	handleAddItem: function(data) {
		//console.log(data);
		if(Main.addItemAjax) {
			return;
		}
		//add fields from order header
		data.hdr_ware = Main.record.header.warehouseid;
		data.account = Main.record.header.billingaccount;
		data.ref7 = Main.record.header.reference;
		data.orderid = Main.record.header.orderid;
		data.hdr_ship = Main.record.header.shipdate.replace(/[^\d]/g,"");
		data.hdr_supplierid = Main.record.header.supplierid;
		
		Dancik.Blanket.InProcess.show({ message : 'Retrieving Item Information', sizeByStretch : true, zIndex : 1000 });
		Main.addItemAjax = new Ajax.Request("../api/ai/getItem",{
			method:"post",
			parameters: data,
			onSuccess: function(res) {
				var json = res.responseJSON || {};
				if(json.errors) {
					var html = ['<ul class="dws-form-error-list">'];
					var errors = [json.errors].flatten();
					errors.each( function(msg) { html.push("<li>- " + msg.errmsg + "</li>") } );
					html.push('</ul>');
					var extraContentHTML = html.join('');
					var contentHTML = "The following error"+(html.length>1?'s':'')+" occurred:";
					Main.open_ErrorWdw({
						contentHTML : contentHTML, 
						extraContentHTML : extraContentHTML 
					});
					return;		
				}
				// check to see if the header supplier is <> to this items supplier, if not then send a warning message
				var poError = "";  // BKLG 570
				if(json.results) { // BKLG 570
					poError = json.results[0].po_warning; // BKLG 570
				}
				
				if(poError) {
					Main.handlePOWarningMessage(json, data);
				} else if(json.duplicate) {
					Main.handleAddItemDuplicates(json, data);
				} else {
					Main.handleAddItemISO(json, data);
				}
			},
			onException: function(req,e) {
				var html = [];
				var contentHTML = "An error occurred while attempting to access the server or network, please try again.<br>If the problem persists, contact your system administrator.";
				html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see response.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+req.transport.responseText+"</textarea></div>");
				html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see exception.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+e+"</textarea></div>");
				var extraContentHTML = html.join('');
				Main.open_ErrorWdw({
					contentHTML : contentHTML, 
					extraContentHTML : extraContentHTML 
				});
			},
			onComplete: function() {
				Dancik.Blanket.InProcess.kill();
				Main.addItemAjax = null;
			}
					
		});

	},
	
/*
	handleAddItemAjax: function(data) {
		
		Dancik.Blanket.InProcess.show({ message : 'Retrieving Item Information', sizeByStretch : true, zIndex : 1000 });
		Main.addItemAjax = new Ajax.Request("../api/ai/getItem",{
			method:"post",
			parameters: data,
			onSuccess: function(res) {
				var json = res.responseJSON || {};
				if(json.errors) {
					var html = ['<ul class="dws-form-error-list">'];
					var errors = [json.errors].flatten();
					errors.each( function(msg) { html.push("<li>- " + msg.errmsg + "</li>") } );
					html.push('</ul>');
					var extraContentHTML = html.join('');
					var contentHTML = "The following error"+(html.length>1?'s':'')+" occurred:";
					Main.open_ErrorWdw({
						contentHTML : contentHTML, 
						extraContentHTML : extraContentHTML 
					});
					return;		
				}
				// check to see if the header supplier is <> to this items supplier, if not then send a warning message
				if(json.results) { // BKLG 570
					var poError = json.results[0].po_warning; // BKLG 570
					if(poError) {
						Main.handlePOWarningMessage(json, data);
					} else if(json.duplicate) {
						Main.handleAddItemDuplicates(json, data);
					} else {
						Main.handleAddItemISO(json, data);
					}
				}
			},
			onException: function(req,e) {
				var html = [];
				var contentHTML = "An error occurred while attempting to access the server or network, please try again.<br>If the problem persists, contact your system administrator.";
				html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see response.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+req.transport.responseText+"</textarea></div>");
				html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see exception.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+e+"</textarea></div>");
				var extraContentHTML = html.join('');
				Main.open_ErrorWdw({
					contentHTML : contentHTML, 
					extraContentHTML : extraContentHTML 
				});
			},
			onComplete: function() {
				Dancik.Blanket.InProcess.kill();
				Main.addItemAjax = null;
			}
					
		});

	},
*/
	// ---------------------------------------------------------------------------------------------------
	handleAddItemDuplicates: function(json, data) {
		json.id = new Date().getTime();
		var template = new EJS({url:"duplicateOrders.ejs"});
		var html = template.render(json);
		
		Main.duplicateWindow = new Dancik_ConfirmWindow({
			color:"blue",
			showAsPopup: true,
			popupTitle: "Potential Duplicate Orders",
			message: html,
			modal:true,
			buttons: {cont:"Continue"},
			onCont: function() {
				Main.handleAddItemForm({flag_nodup:"Y"});
			},
			defaultAction: "cont"
		});
		Main.duplicateWindow.open();
		
	},
	// ---------------------------------------------------------------------------------------------------
	handlePOWarningMessage: function(json, data) {
		data.flag_po_supplier_warning = 'Y';
		Main.poWarningWindow = new Dancik_ConfirmWindow({
			color:"yellow",
			content: "Warning: Supplier "  + data.hdr_supplierid + " is not a regular supplier of this item.",
			modal: true,
			destroyOnClose: true,
			buttons: {yes:"Yes", no:"No"},
			onYes: function() {  // BKLG 570
				data.flag_po_supplier_warning = 'Y';
				//add fields from order header
				data.hdr_ware = Main.record.header.warehouseid;
				data.account = Main.record.header.billingaccount;
				data.ref7 = Main.record.header.reference;
				data.orderid = Main.record.header.orderid;
				data.hdr_ship = Main.record.header.shipdate.replace(/[^\d]/g,"");
				data.hdr_supplierid = Main.record.header.supplierid;
				
				// Backlog 570
				// This call wraps the error functions with json.results
				Dancik.Blanket.InProcess.show({ message : 'Retrieving Item Information', sizeByStretch : true, zIndex : 1000 });
				Main.addItemAjax = new Ajax.Request("../api/ai/getItem",{
					method:"post",
					parameters: data,
					onSuccess: function(res) {
						var json = res.responseJSON || {};
						if(json.errors) {
							var html = ['<ul class="dws-form-error-list">'];
							var errors = [json.errors].flatten();
							errors.each( function(msg) { html.push("<li>- " + msg.errmsg + "</li>") } );
							html.push('</ul>');
							var extraContentHTML = html.join('');
							var contentHTML = "The following error"+(html.length>1?'s':'')+" occurred:";
							Main.open_ErrorWdw({
								contentHTML : contentHTML, 
								extraContentHTML : extraContentHTML 
							});
							return;		
						}
						// check to see if the header supplier is <> to this items supplier, if not then send a warning message
						if(json.results) { // BKLG 570
							var poError = json.results[0].po_warning; // BKLG 570
							if(poError) {
								Main.handlePOWarningMessage(json, data);
							} else if(json.duplicate) {
								Main.handleAddItemDuplicates(json, data);
							} else {
								Main.handleAddItemISO(json, data);
							}
						}
					},
					onException: function(req,e) {
						var html = [];
						var contentHTML = "An error occurred while attempting to access the server or network, please try again.<br>If the problem persists, contact your system administrator.";
						html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see response.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+req.transport.responseText+"</textarea></div>");
						html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see exception.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+e+"</textarea></div>");
						var extraContentHTML = html.join('');
						Main.open_ErrorWdw({
							contentHTML : contentHTML, 
							extraContentHTML : extraContentHTML 
						});
					},
					onComplete: function() {
						Dancik.Blanket.InProcess.kill();
						Main.addItemAjax = null;
					}
							
				});

				
				Main.getOrder();
				data.flag_po_supplier_warning = '';
			},
			onNo: function() {  // BKLG 570
				Main.getOrder();
			},
			defaultAction: "no"
		});
		Main.poWarningWindow.open();
		
	},
	// ---------------------------------------------------------------------------------------------------
	handleAddItemISO: function(json, data) {
		/*
	 	if(!json.iso && !json.bom && !json.inventory) {
			Main.open_ErrorWdw({
				contentHTML: "Item information not returned correctly.",
				modal:true
			});
			json.inventory = [];
			return;				
		}
		*/
		if(json.bom) {
			json.items = json.bom;
			json.title = "Bill of Material / Kit Item",
			json.bom = null;
			new MultiEntry(json);
		} else if(json.inventory) {
			new AddItem(json);
		} else if(json.iso){
			new ISO(json, data);
		} else {
			$("Main_AddItem").select("input").each(function(input) {
				if(input.type=="text") {
					input.value="";
				}
			});
			Main.getOrder.defer({avoidToggle:true});
		}
	},
	addItemDropUM: function(e) {
		var event = e || window.event;
		var element = Event.element(event);
		var parent = element.up();
		var input = parent.down("input");
		
		var item = $("addItem_item").value;
		if(item.blank()) {
			Main.open_ErrorWdw({
				content: "Item required."
			});
			return;
		}
		
		Popup_Search.open(event,{ 
			title : 'Available UM',
			url : '../../dws/jsonservice/Item_WebService/getUOMList_JSON',
			params : { 
				parm_Item : item 
			},
			positionElement : parent,
			toElements : [input],
			omitIdInDescription : true,
			preload : true,
			hideHeader : true,
			showIdInTable : false,
			bufferLeft: 1,
			bufferTop:-4,
			widthOverride: 50,
			heightOverride: 80,
			noRecordMessage: "<center>No<br/>UOMs<br/>found.</center>",
			noRecordClass: " "
			//parentZindex: this.getZindexElement(100000)
		});
	},
	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.splitLine()
	// --------------------------------------------------------------------------------------------------- 
	splitLine: function(data) {
		(function ($) {
			var _this = this;
			parent.$App.Fire('open_split_window', data);
		})(jQuery);
	},

	// ***********************************************************************************************
	//	Main.Header 
	// ***********************************************************************************************
	Header : {
		// ---------------------------------------------------------------------------------------------------
		// Main.Header.open---------------------------------------------------------------------------
		// ---------------------------------------------------------------------------------------------------
		open : function(element) {
			
			if (!Main.hdrOptions) {
				Main.hdrOptions = new Dancik_OptionsWindow({ 
					style : 'width:175px;',
					header_style : 'background-color:#EEF2DD; color:#000; border-bottom:solid #AAA 1px; text-align:center;', 
					title : 'Available Header Options'
				});
			}

			Main.hdrOptions.removeOptions();
			if (Main.settings.editMode) {
				Main.hdrOptions.addOption( { title : "Edit Header", icon : '../../dws/images/edit.png', action : function() { Main.gotoHeader(); } } );
				Main.hdrOptions.addOption( { title : "ShipTo Address", icon : '../images/icons/shipToOverride.png', action : function() { Main.openShipToPopup(); } } );
			} else {
				Main.hdrOptions.addOption( { title : "Display Header", icon : '../images/table.png', action : function() { Main.gotoHeader(); } } );
			}
			Main.hdrOptions.addOption( { title : "Message Lines", icon : '../images/icons/msgLines.png', action : function() { Main.openMsgLines(0); } } );
			Main.hdrOptions.open(element);			
	 	}
	},	
	
	// ***********************************************************************************************
	//	Main.ItemOptions 
	// ***********************************************************************************************
	ItemOptions : {
		wdw : null,	
		i : -1,
		// ---------------------------------------------------------------------------------------------------
		// ---------------------------------------------------------------------------------------------------
		// ---------------------------------------------------------------------------------------------------
		open : function(element) {
			var parentElement = Element.up(element, 'TR'); 
			this.i = parentElement.rowIndex;
			
			// -- Check to see if it already exists...
			var popup = new Dancik_RightClicks({
				 dataKey : "item",
				 key : Main.detailLines[this.i].item_16
				});
			popup.addOption({ 
				title : "Related Items", 
				icon : '../../dws/images/icons/relatedItems.png', 
				action : function() { Main.ItemOptions.relatedItems(); } 
			},"itemRelated");
			popup.open(element);			
	 	},
	 	openSpecialOrder:function(orderNum){
	 		top.$App.Fire('openURL', {
				url: "../../om/app-mgr/order.jsp?parm_OrderId="+orderNum,
				title: "Order Inquiry"
			});
	 	},
		// ---------------------------------------------------------------------------------------------------
		// - Function    : Main.ItemOptions.relatedItems()
		// --------------------------------------------------------------------------------------------------- 
		relatedItems: function() {
			var data = {
				item: Main.detailLines[this.i].item_16,
				desc1: Main.detailLines[this.i].item_description,
				desc2: Main.detailLines[this.i].item_description2				
			}
			
			new RelatedItems(data);
		}
		
	},	
	
	// ***********************************************************************************************
	//	Main.RightClickOptions 
	// ***********************************************************************************************
	RightClickOptions : {
		wdw : null,	
		// ---------------------------------------------------------------------------------------------------
		// -- Main.RightClickOptions.billto()
		// ---------------------------------------------------------------------------------------------------
		billto : function(e, element) {
			Event.stop(e);
			
			// -- Check to see if it already exists...
			this.open(element, {
				 dataKey : "billto",
				 key : Main.record.header['billingaccount']
			} , {
				 title : 'Account: ' + Main.record.header['billingaccount']
			});			
		},
		// ---------------------------------------------------------------------------------------------------
		// -- Main.RightClickOptions.branch()
		// ---------------------------------------------------------------------------------------------------
		branch : function(e, element, datakey) {
			Event.stop(e);
			
			// -- Check to see if it already exists...
			this.open(element, {
				 dataKey : "branch",
				 key01 : Main.record.header['companyid'],
				 key02 : Main.record.header['branchid']
				}, { 
					title : 'Branch: ' + Main.record.header['branchid']
				});			
		},
		// ---------------------------------------------------------------------------------------------------
		// -- Main.RightClickOptions.warehouse()
		// ---------------------------------------------------------------------------------------------------
		warehouse : function(e, element, datakey) {
			Event.stop(e);
			
			// -- Check to see if it already exists...
			this.open(element, {
				 dataKey : "warehouse",
				 key01 : Main.record.header['warehouseid']
			}, {
				 title : 'Warehouse: ' + Main.record.header['warehouseid']
			});
		},
		// ---------------------------------------------------------------------------------------------------
		// -- Main.RightClickOptions.salesperson1()
		// ---------------------------------------------------------------------------------------------------
		salesperson1 : function(e, element, datakey) {
			Event.stop(e);
			
			// -- Check to see if it already exists...
			this.open(element, {
				 dataKey : "salesman",
				 key01 : Main.record.header['companyid'],
				 key02 : Main.record.header['salespersonid1']
			}, {
				 title : 'Salesperson 1: ' + Main.record.header['salespersonid1']
			});			
		},
		// ---------------------------------------------------------------------------------------------------
		// -- Main.RightClickOptions.salesperson2()
		// ---------------------------------------------------------------------------------------------------
		salesperson2 : function(e, element, datakey) {	
			Event.stop(e);
			
			this.open(element, {
				 dataKey : "salesman",
				 key01 : Main.record.header['companyid'],
				 key02 : Main.record.header['salespersonid2']
			}, {
				 title : 'Salesperson 2: ' + Main.record.header['salespersonid2']
			});			
		},
		// ---------------------------------------------------------------------------------------------------
		// -- Main.RightClickOptions.open()
		// ---------------------------------------------------------------------------------------------------
		open : function(element, params, opts) {
			var popup = new Dancik_RightClicks(params, opts).open(element);			
		}
	},	
	
	// ***********************************************************************************************
	//	Main.Options 
	// ***********************************************************************************************
	Options : {
		i : -1,	
		// ---------------------------------------------------------------------------------------------------
		// ---------------------------------------------------------------------------------------------------
		// ---------------------------------------------------------------------------------------------------
		open : function(element, i) {
			this.i = i;
			
			Main.build_OptionsWdw();
			var url_params = window.location.search.toQueryParams();
			var line = Main.detailLines[this.i];

			Main.optionsWdw.removeOptions();
			if (Main.settings.editMode) {
				Main.optionsWdw.addOption( { title : "Edit Line", icon : '../../dws/images/edit.png', action : function() { Main.Options.editLineItem(line); } } );
				Main.optionsWdw.addOption( { title : "Cancel Line", icon : '../../dws/images/delete.png', action : function() { Main.Options.confirmCancelLineItem(); } } );
			}
			Main.optionsWdw.addOption( { title : "Message Lines", icon : '../images/icons/msgLines.png', action : function() { Main.Options.prepareToOpenMsgLines(); } } );
			
			
			if (Main.settings.SHCOE.use_shipping_charges=="Y") {
				Main.optionsWdw.addOption({ 
					title : "Shipping Charges", 
					icon : '../images/icons/addtShip_charges.png', 
					action : function() { 
						new ShippingCharges({
								referenceid: Main.record.header.reference ,
								orderid: Main.record.header.orderid, 
								line: line.line
						}); 
					} 
				});
			}
			if (line.split_order=="Y"  && !Main.settings.editMode){
				var purchOrder="N";
				if (url_params.type == "po"){
					var purchOrder="Y"
				}
				Main.optionsWdw.addOption( { 
						title : "Split Line", 
						icon : '../images/icons/tableSplit.png', 
						action : function() { 
							Main.splitLine({
								purchase_order:purchOrder,
								order:Main.record.header,
								line: line}); 
						} 
				});
			}
			Main.optionsWdw.setTitle('Line Item: ' + Main.detailLines[this.i].line);			
			Main.optionsWdw.open(element);			
	 	},
		// ---------------------------------------------------------------------------------------------------
		// ---------------------------------------------------------------------------------------------------
		// ---------------------------------------------------------------------------------------------------
		openDeleted : function(element, i) {
			this.i = i;
			
			if (!Main.optsWdw_Deleted) {
				Main.optsWdw_Deleted = new Dancik_OptionsWindow();
	 		}
			Main.optsWdw_Deleted.removeOptions();

			Main.optsWdw_Deleted.addOption( { title : "Message Lines", icon : '../images/icons/msgLines.png', action : function() { Main.Options.prepareToOpenMsgLines(); } } );
			
			Main.optsWdw_Deleted.setTitle('Line Item : ' + Main.detailLines[this.i].line);			
			Main.optsWdw_Deleted.open(element);			
	 	},
		
		// ---------------------------------------------------------------------------------------------------
		// - Function    : Main.Options.editLineItem()
		// --------------------------------------------------------------------------------------------------- 
	 	editLineItem: function(line) {

			Dancik.Blanket.InProcess.show({ message : 'Retrieving Line', sizeByStretch : true, zIndex : 1000 });
			new Ajax.Request("../api/getLineDetail",{
				parameters: {
					parm_referenceid: $F('parm_referenceid'),
					parm_orderid: $F('parm_orderid'),
					parm_line:line.line
				},
				onSuccess: function(res) {
					var json = res.responseJSON || {};
					if(json.errors) {
						var html = [];
						var errors = [json.errors].flatten();
						errors.each( function(msg) { html.push("<div>- " + msg.errmsg + "</div>") } );
						var extraContentHTML = html.join('');
						var contentHTML = "The following error"+(html.length>1?'s':'')+" occurred:";
						Main.open_ErrorWdw({
							contentHTML : contentHTML, 
							extraContentHTML : extraContentHTML 
						});
						return;		
					} else {
						new EditItem(json);
					}
				},
				onFailure: function(res) {
					alert("Edit FAIL: "+res.responseText);
				},
				onComplete: function() {
					Dancik.Blanket.InProcess.kill();
				},
				onException: function(req,e) {
					var html = [];
					var contentHTML = "An error occurred while attempting to access the server or network, please try again.<br>If the problem persists, contact your system administrator.";
					html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see response.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+req.transport.responseText+"</textarea></div>");
					html.push("<div onclick='$(this).hide().next().show();' style='text-decoration:underline;'>Click here to see exception.</div><div style='display:none;width:300px;height:50px;'><textarea class='dws-no-caps' style='width:100%;height:100%;'>"+e+"</textarea></div>");
					var extraContentHTML = html.join('');
					new Dancik_ConfirmWindow({
						color:"red",
						showAsInfoOnly:true,
						contentHTML: contentHTML,
						extraContentHTML: extraContentHTML,
						modal:true
					}).open();
				}
			});
	 	},
		
		// ---------------------------------------------------------------------------------------------------
		// - Function    : Main.Options.editItem(element)
		// --------------------------------------------------------------------------------------------------- 
		editItem: function() {
	 		if (this.i == -1) { return; }

			// -- Avoid multi-loading...
			Dancik.abortAjax( Main.ajax );
	 		
		},
		// ---------------------------------------------------------------------------------------------------
		// - Function    : Main.Options.confirmCancelLineItem()
		// --------------------------------------------------------------------------------------------------- 
		confirmCancelLineItem: function() {
			var html = [];
			
			html.push('<div>');
				html.push('<div style="margin-top:10px;"> Line#: ' + Main.detailLines[this.i].line + '</div>'); 
				html.push('<div style="margin-top:5px;"> Item#: ' + Main.detailLines[this.i].item + '</div>');
				html.push('<div style="margin-top:5px;"> Qty/UM: ' + Main.detailLines[this.i].qtyordered + ' ' + Main.detailLines[this.i].uom + '</div>');
			html.push('</div>'); 
				
			new Dancik_ConfirmWindow({
				color:"yellow",
				content: 'You have selected to cancel the following line.',
				extraContent : html.join(''),
				modal:true,
				onConfirm: function() {
					Main.Options.cancelLineItem();
				}
			}).open();
			
		},
		// ---------------------------------------------------------------------------------------------------
		// - Function    : Main.Options.cancelLineItem()
		// --------------------------------------------------------------------------------------------------- 
		cancelLineItem: function() {
			// -- Show the Full-Screen "In-Process" blanket...
			Dancik.Blanket.InProcess.show({ message : 'Cancel Line in Progress', sizeByStretch : true, zIndex : 1000 });
			
			// -- Build parameters...
			var params = Object.extend( Form.serialize('Main_Form', true), { 
				parm_Line : Main.detailLines[this.i].line, 
				random : new Date().getTime() 
			});			
			
			var model = new Dancik_Model('../api/order-line/cancel');
			model.post(params, 
				function(is_success, json) {
					try{
						if (!json) { throw 'EmptyResult'; }
						
						if ( json.errors != null) { throw 'ErrorCaught'; }

						Dancik.Blanket.InProcess.setMessage("Re-building View");
					
						// -- Save Main record...
						Main.record.details = json.details;
						Main.record.total = json.total;

					
						Main.rebuildDetails(json);
						Main.rebuildFooter(json);
						
					} catch(e) {
						var contentHTML = "";
						var extraContentHTML = "";
						var html = [];
						if (e == 'ErrorCaught') {
							contentHTML = "The following errors occurred:";
							json.errors.each( function(msg) { html.push("<li> - " + msg.errmsg + "</li>") } );
							extraContentHTML = '<ul class="error-list">' + html.join('') + '</ul>';
						} else if (e == 'EmptyResult') {
							contentHTML = "No order information was found.";
						} else {
							contentHTML = "Error : Main.getOrder() :";
							extraContentHTML = "- " + e.message;
						}						
						Main.open_ErrorWdw({ contentHTML : contentHTML, extraContentHTML : extraContentHTML });
					} finally {
						Dancik.Blanket.InProcess.kill();
					}
				});
		},
		
		// ---------------------------------------------------------------------------------------------------
		// - Function    : Main.Options.prepareToOpenMsgLines()
		// --------------------------------------------------------------------------------------------------- 
	 	prepareToOpenMsgLines: function() {
	 		if (this.i == -1) { return; }

	 		Main.openMsgLines(Main.detailLines[this.i].line);
	 	}
		
	},
	
	
	// ***********************************************************************************************
	//	Main.AvailableOptions 
	// ***********************************************************************************************
	AvailableOptions : {

		// -------------------------------------------------------------------------------
		// -- Main.AvailableOptions.customerInformation()
		// -------------------------------------------------------------------------------
		customerInformation : function() {
			// -- Construct window...
			var h = Dancik.getDocumentHeight()-100;
			var w = (Dancik.getDocumentWidth() > 940) ? 940 : (Dancik.getDocumentWidth()-25);
			
			var url = '../../dws/exec/CustomerInformation?parm_Acct=' + Main.record.header.billingaccount;
			
			var html = '<div style="width:'+w+'px;height:'+h+'px;"><iframe src="'+url+'" frameborder="0" style="width:100%;height:100%"></iframe></div>';
			new Dancik_ConfirmWindow({
				showAsPopup:true,
				popupTitle: "Customer Information",
				message: html,
				buttons: {},
				modal:true,
				color:"blue"
			}).open();
		},
		// -------------------------------------------------------------------------------
		// -- Main.AvailableOptions.jobEstimating()
		// -------------------------------------------------------------------------------
		jobEstimating : function() {
			Main.AddOns.jobEstimating(Main.record.header.reference);			
		},
		// -------------------------------------------------------------------------------
		// -- Main.AvailableOptions.orderDates()
		// -------------------------------------------------------------------------------
		orderDates : function() {
			// -- Construct window...
			var h = 450;
			var w = 700;
			
			var params = {parm_Ref : Main.record.header.reference, parm_Ord : '' };
			var url = '../app-mgr-addons/orderdates.jsp?' + Object.toQueryString(params);
			
			var opts = {
				color : "blue",
				showAsPopup : true,
				popupTitle : 'Delivery/Pickup Dates',
				destroyOnClose : true,
				modal : true,
				message : '<iframe src="' + url + '" frameborder="0" width="' + (w) + 'px" height="' + (h) + 'px;"></iframe>',
				buttons : {}
			};
			if (Main.mode.unprocessed) {			
				opts = Object.extend(opts, { afterClose : function() { Main.getOrder({avoidToggle:true}); }});
			}
			
			new Dancik_ConfirmWindow(opts).open();
		},
		// -------------------------------------------------------------------------------
		// -- Main.AvailableOptions.installationScheduler()
		// -------------------------------------------------------------------------------
		installationScheduler : function() {
			Main.AddOns.installationScheduler(Main.record.header.reference, Main.record.header.orderid);
		},
		/** -------------------------------------------------------------------------
		*	Main.AvailableOptions.openPrintWindow : 
		*   ------------------------------------------------------------------------- */
		openPrintWindow : function () {
			new PrintOrderOptions_Popup({ 
				parm_referenceid : Main.record.header.reference, 
				parm_orderid : Main.record.header.orderid,
				fromEndOrder : false,
				editmode : Main.settings.editMode,
				forUnprocessedOrder : (!Main.record.header.orderid || Main.record.header.orderid.isEmpty()) 
			});
		},
		/** -------------------------------------------------------------------------
		*	Main.AvailableOptions.openNotepadWindow : 
		*   ------------------------------------------------------------------------- */
		openNotepadWindow : function () {
			new OrderNotepad_Popup({
				parm_orderid: Main.record.header.orderid, 
				parm_referenceid : Main.record.header.reference
			}, {
				editmode : true	// - Add per bug#2934
			}).open();
	   },
	/** -------------------------------------------------------------------------
	*	Main.AvailableOptions.openOrderStatusWindow : 
	*   ------------------------------------------------------------------------- */
	openOrderStatusWindow : function () {
		new OrderStatus_Popup({
			parm_orderid: Main.record.header.orderid, 
			parm_referenceid : Main.record.header.reference
		}, {
			editmode : true	
		});
	}
}	
});