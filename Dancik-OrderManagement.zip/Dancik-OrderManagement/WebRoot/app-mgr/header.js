// *******************************************************************************************************
//*******************************************************************************************************
//*******************************************************************************************************
var Main = Object.extend( OM_Main, {
	
	model : null,

	recordChangedIndicator : false,

	makeTaxReason_wdw : null,
	makeTaxReason_wdwTitle : '',
	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.initialize()
	// --------------------------------------------------------------------------------------------------- 
	initialize: function() {
		Messaging.init("../../dws/");
		
		
		Main.rebuild();
	},

	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.rebuild()
	// --------------------------------------------------------------------------------------------------- 
	rebuild: function(json) {
		Dancik.Blanket.InProcess.show({ message : 'Preparing Header', sizeByStretch : true });

		var params = Object.extend( Form.serialize('Main_Form', true), { 
			serviceid : 'manager', 
			option : 'getHeader', 
			random : new Date().getTime() 
		});
		this.model = new Dancik_Model('../jsonservice/OM_WebService/execute');
		this.model.get(params, function(is_success, json ) {
			try {
				
				Main.record = json;
				if (json.header) {
	
					var template = new EJS({url: 'header.ejs'});
					json.parmAccessMode = window.location.search.parseQuery()['parm_AccessMode'];	
					$('Main').update( template.render(json) );
	
					var h = $H(json.header);
					// -- Extra-Header (hidden) data
					$$('INPUT[type="hidden"]').each(function(o, i) { o.setValue( h.get(o.id.replace('parm_', '')) ); });					
				}
				
				if (json.settings) {
					// -- Construct 'settings'...
					Main.setSettings( json.settings );
				}
				if ($('parm_floorplanuse').visible()){
					$('parm_floorplanuse_text').hide();
				}
				var parmAccessMode = window.location.search.parseQuery()['parm_AccessMode'];		
				if (parmAccessMode == "*EDIT") {
					Element.setStyle('Main', {bottom:'30px'});
					
					Element.select( $('Main_Form'), 'input[type="text"]').each(function(o) {  
						Event.observe(o, 'blur', function() { this.value = this.value.toUpperCase(); });
						Event.observe(o, 'focus', function() { this.select(); });
					});
	
					// -- Build validator...
					var testValidator = new Validation('Main_Form', {
						onValidSubmit : function(event) {
						if (json.header.ordertypeid =="D"){
							$('new_direct_order').value = "Y";
						}
							event.stop();
							Main.update();
						},
						fieldNames: {
							parm_customerpo: "PO#",
							parm_jobid: "Job#",
							parm_xferorder: "Transfer Order#",
							parm_xferinvoice: "Transfer Ivc#",
							parm_termsdays: "Terms Days",
							parm_termspercent: "Terms Disc%",
							parm_floorplanaccountid: "FP Account#",
							parm_finaldestination_zip5: "Final Destination - Zip Code",
							parm_finaldestination_zip4: "Final Destination - Zip Code",
							parm_termspercent: "Terms Disc%",
							parm_hndlchrg_discount: "HndlChrg/Disc%",
							parm_shipdate: "Ship Date",
							parm_etadate: "ETA Date",
							parm_orderdate: "Order Date"	
						}
					});			
				//Hides certain fields if retail environment is set to Y
					if (json.settings.use_retailenvironment =="Y"){
						document.getElementById("parm_branchid").readOnly = true;
						$('parm_floorplanuse').hide();
						document.getElementById('parm_floorplanaccountid').readOnly = true;
						document.getElementById('parm_floorplantermscodeid').readOnly = true;
						document.getElementById('parm_termscodeid').readOnly = true;
						document.getElementById('parm_termspercent').readOnly = true;
						document.getElementById('parm_termsdays').readOnly = true;
						$('parm_termscodeid').next('img').hide();
						$('parm_floorplanaccountid').next('img').hide();
						$('parm_floorplantermscodeid').next('img').hide();
						$('parm_branchid').next('img').hide();
						if ($('parm_retailidFloorplan')){
							$('parm_floorplanuse_text').hide();
						}
						else{
							$('parm_floorplanuse_text').show();
						}
					}
					else{
						$('parm_measure').disable();
						$('parm_install').disable();
						if ($('parm_retailidFloorplan')){
							$('parm_termscodeid').next('img').hide();
							$('parm_floorplanaccountid').next('img').hide();
							$('parm_floorplantermscodeid').next('img').hide();
						}
					}
					if (json.header.ordertypeid =="D"){
						$('parm_warehouseid').value = "DIR";
						document.getElementById('parm_warehouseid').readOnly =true;
						if ($('parm_supplierid').value == ""){
							$('parm_warehouseid').next('img').hide();
							$('new_direct_order').value = "Y";
						}
					}
					if ($('parm_floorplanuse').visible()){
						$('parm_floorplanuse_text').hide();
					}
					
					// -- Sets up all fields in Form, to watch for 'unsaved' changes
					Main.recordChangedIndicator = false;
					$("Main_Form").select('input[type="text"]').invoke("observe","change", function() { Main.flagChanged(this) });
					
					var val2 = new Validation('MakeTaxableReason_Form', {
						onValidSubmit : function(event) {
							event.stop();
							Main.makeTaxReason_wdw.close();
							Main.makeTaxable(true);
						},
						errorMessages: {
							parm_maketaxablereason: { required: "Reason/Description is required." }
						}
					});			
					
					// -- Prepare Field Restricter/Formatter...
					var frm = new FormFormatter('Main_Form');
					
					// -- Determine if "Make Taxable" button should be shown...
					if (json.header.accountid5 == '1' || json.header.accountid5 == '2') {
						Element.hide('ToggleTax_Bttn');
					} else {
						Main.set_ToggleTax_Bttn();
					}
					
				} else {
					Form.disable('Main_Form');
					Element.addClassName('Main_Form', 'dws-disabled');
				}			
				
				
			} catch(e) {
				Main.open_ErrorWdw({ contentHTML : "Error : Main.rebuild() :", extraContentHTML : "- " + e.message});
			} finally {
				Dancik.Blanket.InProcess.kill();
			}	
		});
	},
	
	

	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.flagChanged()
	// --------------------------------------------------------------------------------------------------- 
	flagChanged: function(element) {
		Main.recordChangedIndicator = true;
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.set_ToggleTax_Bttn()
	// --------------------------------------------------------------------------------------------------- 
	set_ToggleTax_Bttn: function(element) {
		if ($('ToggleTax_Bttn')) {
			$('ToggleTax_Bttn').update('Make Non-Taxable');
			this.makeTaxReason_wdwTitle = 'Reason for toggling to non-taxable';
			
			if (Main.record.header.countryid == 'CA') {
				if ($F('parm_statetaxid').empty()  ||  $F('parm_othertaxid').empty()) {
					$('ToggleTax_Bttn').update('Make Taxable');
					this.makeTaxReason_wdwTitle = 'Reason for toggling to taxable';
				}
			} else {
				if ($F('parm_statetaxid').empty()  &&  $F('parm_othertaxid').empty()) {
					$('ToggleTax_Bttn').update('Make Taxable');
					this.makeTaxReason_wdwTitle = 'Reason for toggling to taxable';
				}
			}
		}
	},	
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.beforeMakeTaxable()
	// --------------------------------------------------------------------------------------------------- 
	beforeMakeTaxable: function() {
		if ( Main.record.settings.use_forcereason_onmaketaxable == 'Y') {
			if (!this.makeTaxReason_wdw) {
				this.makeTaxReason_wdw = new Dancik_ConfirmWindow({ 
					color : "blue",
					showAsPopup : true,
					popupTitle  : 'Reason',
					modal : true,
					message : $('MakeTaxableReason_Window'),
					buttons : {}
				});
				Element.show('MakeTaxableReason_Window');
			}
			// -- Determine window title...
			this.makeTaxReason_wdw.setPopupTitle(this.makeTaxReason_wdwTitle);
			
			
			this.makeTaxReason_wdw.openModal();
			
			var params = Object.extend( Form.serialize('Main_Form', true), { 
				serviceid : 'manager', 
				option : 'getMsgLineMsg', 
				random : new Date().getTime(),
				parm_line : 9969
			});
			Main.model.get(params, function(is_success, json) {
				try {
					if (json  &&  json.errors) { throw 'ErrorCaught'; }
					
					if (json  &&  json.record) {
						$('parm_maketaxablereason').value = json.record.message;
					}
					Main.makeTaxReason_wdw.open();
					
				} catch(e) {
					if (e == 'ErrorCaught') {
						var html = [];
						json.errors.each( function(msg) { html.push("<li> - " + msg + "</li>") } );
						Main.open_ErrorWdw({ 
							contentHTML : "The following errors occurred:", 
							extraContentHTML:  '<ul class="error-list">' + html.join('') + '</ul>'
						});
					} else {
						Main.open_ErrorWdw({contentHTML : "Error : Main.makeTaxable() :", extraContentHTML : "- " + e.message});
					}
					Main.makeTaxReason_wdw.closeModal();
											
				} finally {
				}
			});				
			
		} else {
			Main.makeTaxable();
		}
	},
	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.makeTaxable()
	// --------------------------------------------------------------------------------------------------- 
	makeTaxable: function(includeReason) {
		// -- Show the Full-Screen "In-Process" blanket...
		Dancik.Blanket.InProcess.show({ message : 'Toggling Taxable Status', sizeByStretch : true });

		// -- Build parameters...
		var params = Object.extend( Form.serialize('Main_Form', true), { 
			serviceid : 'manager', 
			option : 'makeTaxable', 
			random : new Date().getTime() 
		});
		if (includeReason) {
			params = Object.extend(params,  Form.serialize('MakeTaxableReason_Form', true));
		}
		
		Main.model.update(params, function(is_success, json) {
			try {
				if (!json) { throw 'EmptyResult'; }
				
				if ( json.errors != null) { throw 'ErrorCaught'; }
				
				$('parm_statetaxid').value = json.record.state_tax;
				$('statetax_description').update( json.record.state_tax_desc );
				$('parm_othertaxid').value = json.record.other_tax;
				$('othertax_description').update( json.record.other_tax_desc );
				
				Main.set_ToggleTax_Bttn();
				
			} catch(e) {
				if (e == 'ErrorCaught') {
					var html = [];
					html.push('<ul class="error-list">');
					json.errors.each( function(msg) { html.push("<li> - " + msg + "</li>") } );
					html.push('</ul>');
					Main.open_ErrorWdw({ contentHTML : "The following errors occurred:", extraContentHTML:  html.join('')});
				} else if (e == 'EmptyResult') {
//					Main.open_ErrorWdw({ contentHTML : "Empty Resultset."});
				} else {
					Main.open_ErrorWdw({ contentHTML : "Error : Main.makeTaxable() :", extraContentHTML : "- " + e.message});
				}
										
			} finally {
				Dancik.Blanket.InProcess.kill();
			}
		});
	},


	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.closeWindow()
	// --------------------------------------------------------------------------------------------------- 
	closeWindow: function() {
		if (Main.recordChangedIndicator) {
			new Dancik_ConfirmWindow({
				contentHTML : 'Unsaved changes were made and will be lost.',
				modal : true,
				onConfirm : function() {
					if (parent.Main  &&  parent.Main.hdrWdw) {
						if ($('new_direct_order').value == 'Y'){
							parent.parent.Main.Orders.closeOrderFrame();
							Main.cancelDirectOrder();
						}
						parent.Main.hdrWdw.close();
					}
				}
			}).open();
		} else {
			if (parent.Main  &&  parent.Main.hdrWdw) {
				if ($('new_direct_order').value == 'Y'){
					parent.parent.Main.Orders.closeOrderFrame();
					Main.cancelDirectOrder();;
				}
				parent.Main.hdrWdw.close();
			}
		}
	},

	cancelDirectOrder : function() {
		// -- Build parameters...
		var p = Object.extend( Form.serialize('Main_Form', true), { 
			serviceid : 'manager', 
			option : 'cancelOrder',
			random : new Date().getTime()
		});
		Main.ajax = new Ajax.Request('../jsonservice/OM_WebService/execute', {
			method: 'get', 
			parameters: p,	 
			evalJSON: "force",
			onInteractive:  function(res) {
				Dancik.Blanket.InProcess.setMessage("Building View");
			},
			onSuccess: function(res) {
				
			},
			onFailure: Dancik.catchAjaxError
		});
	},


	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.update()
	// --------------------------------------------------------------------------------------------------- 
	update: function() {
		// -- Show the Full-Screen "In-Process" blanket...
		Dancik.Blanket.InProcess.show({ message : 'Updating Header', sizeByStretch : true });
		
		// -- Build parameters...
		var params = Object.extend( Form.serialize('Main_Form', true), { 
			serviceid : 'manager', 
			option : 'saveHeader', 
			random : new Date().getTime() 
		});
		
		Main.model.update(params, function(is_success, json) {
			try {
				// -- Errors were caught...
				if ( json  &&  json.errors) { 
					var html = [];
					html.push('<ul class="error-list">');
					json.errors.each( function(msg) { html.push("<li> - " + msg + "</li>") } );
					html.push('</ul>');
					Main.open_ErrorWdw({ contentHTML : "The following errors occurred:", extraContentHTML:  html.join('')});
					
				// -- Alerts were caught...
				} else if ( (json  &&  json.alerts) ) { 
					var html = []; 
					if (json) {
						json.alerts.each( function(m) { html.push(m.errmsg) } );
					}
					new Dancik_ConfirmWindow({ 
						color : "yellow",
						showAsPopup:true,
						popupTitle  : '',
						modal : true,
						destroyOnClose : true,
						message : '<div style="padding:15px;">' + html.join('') + '</div>',
						zIndexModal : 11000,
						buttons: {},
						afterClose: function() { Main.rebuild(); }
					}).open();
					
				// -- Successful update...	
				} else {
					Main.recordChangedIndicator = false;
					$('new_direct_order').value ="N";
					Main.closeWindow();
				}	
				
				
				
			} catch(e) {
				Main.open_ErrorWdw({ contentHTML : "Error : Main.update() :", extraContentHTML : "- " + e.message});
										
			} finally {
				Dancik.Blanket.InProcess.kill();
			}
		});
	},


	// ---------------------------------------------------------------------------------------------------
	// - Function    : Main.openShipToPopup()
	// --------------------------------------------------------------------------------------------------- 
	openShipToPopup: function() {
		new OrderShipto_Popup({ parm_referenceid:$F('parm_referenceid'), parm_orderid:$F('parm_orderid') }, {}).open();
	},

	
	
	// *******************************************************************************
	// * Main.Search Object...
	// *******************************************************************************
	Search : {
		
		execute : function(e, opts) {
			Popup2Search.open(e, Object.extend({
				bufferLeft: 4,
				preload : true }, opts));		
		},
		warehouse : function (e) {
			this.execute(e, { title : 'Warehouse', file : 'warehouse', positionElement : 'parm_warehouseid', toElements : ['parm_warehouseid'], descriptionElement : 'warehouse_description' });
		},
		branch : function (e) {
			this.execute(e, { title : 'Branch', file : 'branch', positionElement : 'parm_branchid', toElements : ['parm_branchid'], descriptionElement : 'branch_description', additionalParams : { filterCompany: $F('parm_companyid') } });
		},
		salesperson1 : function (e) {
			this.execute(e, { title : 'Salesperson 1', file : 'salesman', positionElement : 'parm_salespersonid1', toElements : ['parm_salespersonid1'], descriptionElement : 'salesperson1_description', additionalParams : { filterCompany: $F('parm_companyid') } });
		},
		salesperson2 : function (e) {
			this.execute(e, { title : 'Salesperson 2', file : 'salesman', positionElement : 'parm_salespersonid2', toElements : ['parm_salespersonid2'], descriptionElement : 'salesperson2_description', additionalParams : { filterCompany: $F('parm_companyid') } });
		},
		supplier : function (e) {
			this.execute(e, { title : 'Supplier', file : 'supplier', positionElement : 'parm_supplierid', toElements : ['parm_supplierid'], descriptionElement : 'supplier_description'  });
		},
		shipvia : function (e) {
			this.execute(e, { title : 'Ship Via', file : 'ship_via', positionElement : 'parm_shipviaid', toElements : ['parm_shipviaid'], descriptionElement : 'shipvia_description' });
		},
		ordertype : function (e) {
			this.execute(e, { title : 'Order Type', file : 'systtbl_ordertype', positionElement : 'parm_ordertypeid', toElements : ['parm_ordertypeid'], descriptionElement : 'ordertype_description', widthOverride : 360  });
		},
		fob : function (e) {
			this.execute(e, { title : 'FOB', file : 'classes_fb', positionElement : 'parm_fobid', toElements : ['parm_fobid'], descriptionElement : 'fob_description'  });
		},
		pricelist : function (e) {
			this.execute(e, { title : 'Cust Price List', file : 'classes_pl', positionElement : 'parm_custpricelistid', toElements : ['parm_custpricelistid'], descriptionElement : 'custpricelist_description'  });
		},
		paymentterms : function (e) {
			this.execute(e, { title : 'Terms', file : 'termsfil', positionElement : 'parm_termscodeid', toElements : ['parm_termscodeid'], descriptionElement : 'termscode_description'  });
		},
		orderhandling : function (e) {
			this.execute(e, { title : 'Order Handling', file : 'systtbl_orderhand', positionElement : 'parm_orderhandlingid', toElements : ['parm_orderhandlingid'], descriptionElement : 'orderhandling_description', widthOverride : 360  });
		},
		truckroute : function (e) {
			this.execute(e, { title : 'Truck Route', file : 'truck_route', positionElement : 'parm_truckrouteid', toElements : ['parm_truckrouteid'], descriptionElement : 'truckroute_description' });
		},
		reasoncode : function (e) {
			this.execute(e, { title : 'Reason Code', file : 'systtbl_orderreas', positionElement : 'parm_reasoncodeid', toElements : ['parm_reasoncodeid'], descriptionElement : 'reasoncode_description', widthOverride : 450 });
		},
		statetax : function (e) {
			this.execute(e, { title : 'State Tax', file : 'tax_state', positionElement : 'parm_statetaxid', toElements : ['parm_statetaxid'], descriptionElement : 'statetax_description' });
		},
		othertax : function (e) {
			this.execute(e, { title : 'Other Tax', file : 'tax_other', positionElement : 'parm_othertaxid', toElements : ['parm_othertaxid'], descriptionElement : 'othertax_description' });
		},
		fpterms : function (e) {
			this.execute(e, { title : 'Floor Plan Terms', file : 'termsfp', positionElement : 'parm_floorplantermscodeid', toElements : ['parm_floorplantermscodeid'], descriptionElement : 'floorplantermscode_description' });
		},
		
		fpaccount: function (e) {
			Popup_Search_ForBILLTO.open(e, {
				title : 'Floor Plan Account',
				toElements : ['parm_floorplanaccountid'],
				descriptionElement : 'floorplanaccount_description',
				params : 'parm_FilterFileType=B&parm_FilterCompany=' + $F('parm_companyid'),
				omitCompanyInId : false,
				blanketStretchBySize : true 
			 });
		},
		whereShown : function (e) {
			Popup_Search.open(e, { 
				title : 'Extra Charges',
				positionElement : 'parm_whereshownid',
				toElements : ['parm_whereshownid'],
				descriptionElement : 'whereshown_description',
				bufferLeft : 2,
				heightOverride : 65,
				widthOverride : 300,
				preloadedContents : [ { id : 'L', description : 'Applied at individual line item level' }, { id : 'S', description : 'Applied as one single line item at the order level' }]
			});
		},
		orderDate : function (e) {
			new CalendarObject({
				toElements : [ $('parm_orderdate') ],  
			    toFormats : [ 'M/D/Y' ],
			    positionElement: Element.up('parm_orderdate', 'SPAN'),
				offsetTop: Prototype.Browser.IE?-1:1
			});
		},
		shipDate : function (e) {
			new CalendarObject({
				toElements : [ $('parm_shipdate') ],  
			    toFormats : [ 'M/D/Y' ],
			    positionElement: Element.up('parm_shipdate', 'SPAN'),
				offsetTop: Prototype.Browser.IE?-1:1
			});
		},
		etaDate : function (e) {
			new CalendarObject({
				toElements : [ 'parm_etadate' ],  
			    toFormats : [ 'M/D/Y' ],
			    positionElement: Element.up('parm_etadate', 'SPAN'),
				offsetTop: Prototype.Browser.IE?-1:1
			});
		},
		orderContacts : function (e) {
			var params = { 
				serviceid : 'manager', 
				option : 'listOrderContacts',
				parm_accountid : Main.record.header.accountid
			};
			
			Popup_Search.open(e, { 
				title : 'Order Contact',
				positionElement : 'parm_ordercontact',
				toElements : ['parm_ordercontact'],
				widthOverride : 450,
				url : '../jsonservice/OM_WebService/execute',
				params : params,
				showIdInTable : false
			});
		}
		
	}
});