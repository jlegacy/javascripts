//*******************************************************************************************************
//*******************************************************************************************************
//*******************************************************************************************************
var EditReason_Popup = Class.create(Dancik_ConfirmWindow, {
	// --------------------------------------------------------------------------------------------------
	initialize: function($super, params, opts) {
		this.params = $H(params || {});
		// -- Construct 'options'...
		this.popup_options = Object.extend({
			afterContinue : null		// -- Additional function(s) to execute (after) continue().
		}, opts || {} );
	
		var _this = this;
		this.popupid="edtRsn_PopupWdw_" + new Date().getTime();
		this.recordChangedIndicator = false;
		
		var h = 150;
		var w = 725;
		$super(Object.extend({ 
				color : "blue",
				showAsPopup : true,
				popupTitle  : 'Reason Window',
				destroyOnClose : true,
				modal : true,
				message: '<div class="EditReason_Popup" id="EditReason_Popup_' + this.popupid + '" style="position:relative; height:' + h + 'px; width:' + w + 'px;"></div>',
				buttons : {}
			}, opts || {})
		);
		
		this.open();
		this.model = new Dancik_Model('../jsonservice/OM_WebService/execute');
		
		var template = new EJS({url: '../app-mgr/edit-reason-window.ejs'});
		
		var json = {
			id : this.popupid,
			referenceid : _this.params.get('parm_referenceid'),
			orderid : _this.params.get('parm_orderid'),
			mode : _this.params.get('parm_mode')
		};

		$('EditReason_Popup_' + _this.popupid).update( template.render(json) );
		
		Event.observe('EditReason_ContinueButton_'+_this.popupid, "click", _this.save.bindAsEventListener(_this));
		
		Event.observe(document, 'keypress', function(event){ if(event.keyCode == '13') {_this.save(); } });

		
		Element.select( $('EditReason_Form_'+_this.popupid), 'input').each(function(o) {  
			Event.observe(o, 'blur', function() { this.value = this.value.toUpperCase(); });
			Event.observe(o, 'focus', function() { this.select(); });
		});		
	},

	// --------------------------------------------------------------------------------------------------
	save: function(event) {
		var _this = this;
		
		var params = Form.serialize('EditReason_Form_'+this.popupid, true);
		
		this.model.get(Object.extend({
			serviceid : 'addons', 
			option : 'putOrderChangeReason', 
			random : new Date().getTime() 
		}, params || {}), 
		function(is_success, json) { 
			// -- If a problem with continuing, shows errors...
			if (json && json.errors) {
				var html = [];
				html.push('<ul class="error-list">');
				json.errors.each( function(msg) { html.push("<li> - " + msg + "</li>") } );
				html.push('</ul>');
			
				new Dancik_ConfirmWindow({ 
					color : "red",
					showAsInfoOnly : true,
					modal : true,
					destroyOnClose : true,
					contentHTML : "The following errors occurred:",
					extraContentHTML : html.join(''),
					beforeOpen : function() { Element.setStyle( _this.id, {zIndex:1}); },
					afterClose : function() { Element.setStyle( _this.id, {zIndex:10000}); }
				}).open();
				
			// -- Else, continue and close window...	
			} else {
				if (_this.popup_options.afterContinue) {
					_this.popup_options.afterContinue();
				}
				_this.close();
			}
			
		});
		
	}
});